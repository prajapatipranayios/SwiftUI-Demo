//
//  Novasol Ingredients
//
//  Created by Pranay on 31/05/24.
//

import Foundation
import DynamicCodable

struct ApiResponseCRM: Codable {
    var status: Int?
    var result: ResponseCRM?
    var message: String
}

struct ResponseCRM: Codable {
    
    // CRM
    var crmList: [CRMList]?
    var statusCount: StatusCount?
    var hasMore: Bool?
    //var hasMore: Int?
    var businessPartners: [BusinessPartner]?
    var businessPartnerAddress: [BusinessPartnerAddress]?
    var branch: [Branch]?
    var principalCompany: [PrincipalCompany]?
    var productCategories: [ProductCategory]?
    
    
    enum CodingKeys: String, CodingKey {
        
        // CRM
        case crmList
        case statusCount
        case hasMore
        case businessPartners
        case businessPartnerAddress
        case branch
        case principalCompany
        case productCategories
        
        
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        
        // CRM
        crmList = try values.decodeIfPresent([CRMList].self, forKey: .crmList)
        statusCount = try values.decodeIfPresent(StatusCount.self, forKey: .statusCount)
        hasMore = try values.decodeIfPresent(Bool.self, forKey: .hasMore)
        //hasMore = try values.decodeIfPresent(Int.self, forKey: .hasMore)
        businessPartners = try values.decodeIfPresent([BusinessPartner].self, forKey: .businessPartners)
        businessPartnerAddress = try values.decodeIfPresent([BusinessPartnerAddress].self, forKey: .businessPartnerAddress)
        branch = try values.decodeIfPresent([Branch].self, forKey: .branch)
        principalCompany = try values.decodeIfPresent([PrincipalCompany].self, forKey: .principalCompany)
        productCategories = try values.decodeIfPresent([ProductCategory].self, forKey: .productCategories)
        
        
    }
    
    func encode(to encoder: Encoder) throws {
        do {
            var container = encoder.container(keyedBy: CodingKeys.self)
            
            // CRM
            try container.encodeIfPresent(crmList, forKey: .crmList)
            try container.encodeIfPresent(statusCount, forKey: .statusCount)
            try container.encodeIfPresent(hasMore, forKey: .hasMore)
            try container.encodeIfPresent(businessPartners, forKey: .businessPartners)
            try container.encodeIfPresent(businessPartnerAddress, forKey: .businessPartnerAddress)
            try container.encodeIfPresent(branch, forKey: .branch)
            try container.encodeIfPresent(principalCompany, forKey: .principalCompany)
            try container.encodeIfPresent(productCategories, forKey: .productCategories)
            
            
        }
        catch let err {
            print(err)
        }
    }
}
