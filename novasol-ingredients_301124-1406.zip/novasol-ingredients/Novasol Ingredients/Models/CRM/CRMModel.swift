//
//  CRMModel.swift
//  Novasol Ingredients
//
//  Created by Pranay on 26/07/24.
//

import Foundation



// MARK: - CRMList
struct CRMList: Codable {
    var crmId: Int?
    var projectStatus: String?
    var companyType: Int?
    var companyName: String?
    var salesEmployee: String?
    var stateName: String?
    var cityName: String?
    var updatedBy: String?
    var projectType: String?
    var startDate: String?
    var timeAgo: String?
    
    var crmSeries: String?
    var userID: Int?
    var reason: String?
    var projectPriority: String?
    var projectPriorityReason: String?
    var timeDifference: String?
    
    
    enum CodingKeys: String, CodingKey {
        case crmId
        case projectStatus, companyType, companyName, salesEmployee, stateName, cityName, updatedBy, projectType, startDate, timeAgo
        case crmSeries, userID, reason, projectPriority, projectPriorityReason, timeDifference
    }
}


// MARK: - StatusCount
struct StatusCount: Codable {
    var allCount: Int?
    var pendingCount: Int?
    var completedCount: Int?
    var rejectedCount: Int?
    var reOpenCount: Int?
}


// MARK: - PrincipalCompany
struct PrincipalCompany: Codable {
    var name: String?
    var itemGroup: [String]?
}


// MARK: - ProductCategory
struct ProductCategory: Codable {
    
    var id: Int?
    var parentId: Int?
    var name: String?
    var type: String?
    var createdAt: String?
    var updatedAt: String?
    var children: [ProductCategory]?
    
    var isOpened: Bool? = false

    enum CodingKeys: String, CodingKey {
        case id
        case parentId
        case name, type, createdAt, updatedAt, children
        
        case isOpened
    }
}
