//
//  ForgotPasswordVC.swift
//  GE Sales
//
//  Created by Auxano on 15/04/24.
//

import UIKit

class ForgotPasswordVC: UIViewController {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var lblTitleForgotPassword: UILabel!
    @IBOutlet weak var txtEmail: TLTextField!
    @IBOutlet weak var lblEmailError: UILabel!
    @IBOutlet weak var btnNext: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        self.lblTitleForgotPassword.textColor = Colors.titleLabel.returnColor()
        
        self.txtEmail.delegate = self
        
        self.btnNext.layer.cornerRadius = 15
        self.btnNext.layer.masksToBounds = true
    }
    
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.txtEmail.resignFirstResponder()
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnNextTap(_ sender: UIButton) {
        self.txtEmail.resignFirstResponder()
        
        if checkValidation(to: 0, from: 1) {
            self.forgotEmail()
        }
    }
    
    func loginNav() {
        let viewControllers: [UIViewController] = self.navigationController!.viewControllers
        for aViewController in viewControllers {
            if aViewController is LoginVC {
                self.navigationController!.popToViewController(aViewController, animated: true)
                break
            } else {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                self.navigationController?.pushViewController(vc, animated: true)
                break
            }
        }
    }
}

// MARK: - UITextFieldDelegate

extension ForgotPasswordVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        if textField == self.txtEmail {
            if (self.txtEmail.text?.isNumber)! {
                return newString.length <= MAX_MOBILE_LENGTH
            }
            else {
                return true
            }
        }
        else {
            return true
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.txtEmail.resignFirstResponder()
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            if i == 0 {
                txtEmail.text = txtEmail.text?.trimmingCharacters(in: .whitespaces)
                
                if txtEmail.text == "" {
                    self.lblEmailError.getEmptyValidationString(txtEmail.placeholder ?? "")
                    value = false
                }
                else {
                    
                    if !(txtEmail.text?.isValidEmail())! {
                        self.lblEmailError.setLeftArrow(title: Valid_Forgot_Email)
                        value = false
                    } else {
                        self.lblEmailError.text = ""
                    }
                }
            }
        }
        return value
    }
}

// MARK: Webservices

extension ForgotPasswordVC {
    
    func forgotEmail() {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.forgotEmail()
                }
            }
            return
        }
        
        var param = Dictionary<String, Any>()
        param = [
            "email": self.txtEmail.text!
        ]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.FORGOT_PASSWORD, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    Utilities.showPopup(title: response?.message ?? "", type: .success)
                    self.loginNav()
                }
            } else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
