//
//  LoginVC.swift
//  GE Sales
//
//  Created by Auxano on 15/04/24.
//

import UIKit

class LoginVC: UIViewController {
    
    // MARK: - Controls
    
    @IBOutlet weak var txtEmailMobile: TLTextField!
    @IBOutlet weak var txtPassword: TLTextField!
    @IBOutlet weak var btnRememberMe: UIButton!
    @IBOutlet weak var btnForgotPassword: UIButton!
    @IBOutlet weak var btnSignIn: UIButton!
    @IBOutlet weak var lblEmailError: UILabel!
    
    @IBOutlet weak var btnPswdVisible: UIButton!
    @IBAction func btnPswdVisibleTap(_ sender: UIButton) {
        if self.btnPswdVisible.isSelected {
            self.btnPswdVisible.isSelected = false
            self.txtPassword.isSecureTextEntry = true
        }
        else {
            self.btnPswdVisible.isSelected = true
            self.txtPassword.isSecureTextEntry = false
        }
    }
    
    
    // MARK: - Variables
    
    var rememberMe: Bool = false
    var userDict = Dictionary<String, Any>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.btnSignIn.layer.cornerRadius = 15
        self.btnSignIn.layer.masksToBounds = true
        
        if (UserDefaults.standard.value(forKey: UserDefaultType.rememberMe) != nil) && UserDefaults.standard.value(forKey: UserDefaultType.rememberMe)! is Dictionary<String, Any> {
            let credentials = UserDefaults.standard.value(forKey: UserDefaultType.rememberMe)! as! Dictionary<String, Any>
            self.txtEmailMobile.text = credentials["email"] as? String
            txtPassword.text = credentials["password"] as? String
            self.btnRememberMeTap(btnRememberMe)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if (UserDefaults.standard.value(forKey: UserDefaultType.rememberMe) != nil) && UserDefaults.standard.value(forKey: UserDefaultType.rememberMe)! is Dictionary<String, Any> {
            
            let credentials = UserDefaults.standard.value(forKey: UserDefaultType.rememberMe)! as! Dictionary<String, Any>
            self.txtEmailMobile.text = credentials["email"] as? String
            self.txtPassword.text = credentials["password"] as? String
        }
    }
    
    @IBAction func btnRememberMeTap(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        rememberMe = sender.isSelected
        
        if rememberMe {
            sender.tintColor = .init(hexString: "#87BE5D")
        }
        else {
            sender.tintColor = .init(hexString: "#9f9999")
        }
    }
    
    @IBAction func btnForgotPasswordTap(_ sender: UIButton) {
        self.forgotPasswordNav()
    }
    
    @IBAction func btnSignInTap(_ sender: UIButton) {
        if checkValidation(to: 0, from: 1) {
            if !(self.txtEmailMobile.text!.isEmpty) {
                if self.rememberMe {
                    let userName = self.txtEmailMobile.text!
                    let password = self.txtPassword.text!
                    
                    let dictCredentials = ["email": userName, "password": password]
                    UserDefaults.standard.set(dictCredentials, forKey: UserDefaultType.rememberMe)
                    //UserDefaults.standard.set(97, forKey: UserDefaultType.userId)
                    //appDelegate.isAutoLogin = true
                }
                else {
                    UserDefaults.standard.removeObject(forKey: UserDefaultType.rememberMe)
                }
                
                //self.homeNav()
                self.userLogIn()
            }
        }
    }
    
    func homeNav() {
        /*let viewControllers: [UIViewController] = self.navigationController!.viewControllers
        for aViewController in viewControllers {
            if aViewController is HomeVC {
                self.navigationController!.popToViewController(aViewController, animated: true)
                break
            } else {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                self.navigationController?.pushViewController(vc, animated: true)
                break
            }
        }   //  */
        self.restartApplication()
    }
    
    func forgotPasswordNav() {
//        let sb = UIStoryboard(name: "Main", bundle: nil)
//        let vc = sb.instantiateViewController(withIdentifier: "ForgotPasswordVC") as! ForgotPasswordVC
//        self.navigationController?.pushViewController(vc, animated: true)
        
        self.navigateToVC(ForgotPasswordVC.self, storyboardId: "ForgotPasswordVC")
    }
}

// MARK: - UITextFieldDelegate

extension LoginVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        if textField == self.txtEmailMobile {
            if (self.txtEmailMobile.text?.isNumber)! {
                return newString.length <= MAX_MOBILE_LENGTH
            }
            else {
                return true
            }
        }
        else {
            return true
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.txtEmailMobile.resignFirstResponder()
        self.txtPassword.resignFirstResponder()
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            if i == 0 {
                txtEmailMobile.text = txtEmailMobile.text?.trimmingCharacters(in: .whitespaces)
                
                if txtEmailMobile.text == "" {
                    self.lblEmailError.getEmptyValidationString(txtEmailMobile.placeholder ?? "")
                    value = false
                }
                else {
                    if (txtEmailMobile.text?.isNumber)! {
                        if !((txtEmailMobile.text?.count)! >= MIN_MOBILE_LENGTH) {
                            lblEmailError.setLeftArrow(title: Valid_Mobile)
                            value = false
                        }
                        else if !((txtEmailMobile.text?.count)! <= MAX_MOBILE_LENGTH) {
                            lblEmailError.setLeftArrow(title: Valid_Mobile)
                            value = false
                        }
                        else {
                            lblEmailError.text = ""
                        }
                    }
                    else {
                        lblEmailError.text = ""
                    }
                }
            }
        }
        
        return value
    }
}

// MARK: Webservices

extension LoginVC {
    
    func userLogIn() {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.userLogIn()
                }
            }
            return
        }
        
        let userName = self.txtEmailMobile.text!
        let password = self.txtPassword.text!
        
        userDict = [
            "mobile_no": userName,
            "password": password,
            "device_id": AppInfo.DeviceId.returnAppInfo(),
            "fcm_token": "UserDefaults.standard.value(forKey: UserDefaultType.fcmToken) as Any"
        ]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.LOGIN, parameters: userDict) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                APIManager.sharedManager.userDetail = response?.result?.userDetail
                APIManager.sharedManager.userId = response?.result?.userDetail?.id ?? 0
                APIManager.sharedManager.authToken = response?.result?.userDetail?.token ?? ""
                
                DispatchQueue.main.async {
                    UserDefaults.standard.set(APIManager.sharedManager.userId, forKey: UserDefaultType.userId)
                    UserDefaults.standard.set(response?.result?.userDetail?.roleId ?? 0, forKey: UserDefaultType.userRole)
                    UserDefaults.standard.set(APIManager.sharedManager.authToken, forKey: UserDefaultType.accessToken)
                    
                    if self.rememberMe {
                        let dictCredentials = ["email": userName, "password": password]
                        UserDefaults.standard.set(dictCredentials, forKey: UserDefaultType.rememberMe)
                    }
                    else {
                        UserDefaults.standard.removeObject(forKey: UserDefaultType.rememberMe)
                    }
                    
                    appDelegate.isAutoLogin = true
                    self.homeNav()
                    
//                    UserDefaults.standard.set(0, forKey: UserDefaultType.notificationCount)
//                    UserDefaults.standard.synchronize()
//                    //self.view!.tusslyTabVC.selectedIndex = 0
//                    //self.view!.tusslyTabVC.loadTabsOfHomeScreen(isUserLoggedIn: true)
                }
            } else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
