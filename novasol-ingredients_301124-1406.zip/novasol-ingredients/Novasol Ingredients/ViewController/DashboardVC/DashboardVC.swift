//
//  DashboardVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 17/07/24.
//

import UIKit

class DashboardVC: UIViewController {

    // MARK: - Controls
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    
    @IBOutlet weak var viewOptions: UIView!
    @IBOutlet weak var stackOptions: UIStackView!
    
    @IBOutlet weak var viewBMReportMain: UIView!
    @IBOutlet weak var viewBMReport: PlainCircularProgressBar!
    @IBOutlet weak var ivBMReport: UIImageView!
    @IBOutlet weak var btnBMReport: UIButton!
    @IBAction func btnBMReportTap(_ sender: UIButton) {
        self.intSelectedOption = 1
        
        self.ivBMReport.isHidden = false
        self.viewBMReport.progress = 1
        self.lblBMReport.textColor = Colors.theme.returnColor()
        
        self.ivSalesReport.isHidden = true
        self.viewSalesReport.progress = 0
        self.lblSalesReport.textColor = .black
        
        self.ivStockReport.isHidden = true
        self.viewStockReport.progress = 0
        self.lblStockReport.textColor = .black
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "DashboardReportsVC") as! DashboardReportsVC
        viewController.strScreenTitle = "BM Report"
        viewController.intSelectedOption = self.intSelectedOption
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    @IBOutlet weak var lblBMReport: UILabel!
    
    @IBOutlet weak var viewSalesReportMain: UIView!
    @IBOutlet weak var viewSalesReport: PlainCircularProgressBar!
    @IBOutlet weak var ivSalesReport: UIImageView!
    @IBOutlet weak var btnSalesReport: UIButton!
    @IBAction func btnSalesReportTap(_ sender: UIButton) {
        self.intSelectedOption = 2
        
        self.ivBMReport.isHidden = true
        self.viewBMReport.progress = 0
        self.lblBMReport.textColor = .black
        
        self.ivSalesReport.isHidden = false
        self.viewSalesReport.progress = 1
        self.lblSalesReport.textColor = Colors.theme.returnColor()
        
        self.ivStockReport.isHidden = true
        self.viewStockReport.progress = 0
        self.lblStockReport.textColor = .black
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "DashboardReportsVC") as! DashboardReportsVC
        viewController.strScreenTitle = "Sales Report"
        viewController.intSelectedOption = self.intSelectedOption
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    @IBOutlet weak var lblSalesReport: UILabel!
    
    @IBOutlet weak var viewStockReportMain: UIView!
    @IBOutlet weak var viewStockReport: PlainCircularProgressBar!
    @IBOutlet weak var ivStockReport: UIImageView!
    @IBOutlet weak var btnStockReport: UIButton!
    @IBAction func btnStockReportTap(_ sender: UIButton) {
        self.intSelectedOption = 3
        
        self.ivBMReport.isHidden = true
        self.viewBMReport.progress = 0
        self.lblBMReport.textColor = .black
        
        self.ivSalesReport.isHidden = true
        self.viewSalesReport.progress = 0
        self.lblSalesReport.textColor = .black
        
        self.ivStockReport.isHidden = false
        self.viewStockReport.progress = 1
        self.lblStockReport.textColor = Colors.theme.returnColor()
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "DashboardReportsVC") as! DashboardReportsVC
        viewController.strScreenTitle = "Stock Report"
        viewController.intSelectedOption = self.intSelectedOption
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    @IBOutlet weak var lblStockReport: UILabel!
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Dashboard"
    /**** 0 - None, 1 - BM Report, 2 - Sales Report, 3 - Stock Report  */
    var intSelectedOption: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.viewBMReport.ringWidth = 10
        self.viewBMReport.backgroundColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)
        self.viewBMReport.color = Colors.theme.returnColor()
        self.viewBMReport.progress = 0
        self.ivBMReport.corners(radius: self.ivBMReport.frame.width / 2)
        self.ivBMReport.isHidden = true
        self.btnBMReport.corners(radius: self.btnBMReport.frame.width / 2)
        self.lblBMReport.textColor = .black
        
        self.viewSalesReport.backgroundColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)
        self.viewSalesReport.color = Colors.theme.returnColor()
        self.viewSalesReport.progress = 0
        self.ivSalesReport.corners(radius: self.ivSalesReport.frame.width / 2)
        self.ivSalesReport.isHidden = true
        self.btnSalesReport.corners(radius: self.btnSalesReport.frame.width / 2)
        self.lblSalesReport.textColor = .black
        
        self.viewStockReport.backgroundColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)
        self.viewStockReport.color = Colors.theme.returnColor()
        self.viewStockReport.progress = 0
        self.ivStockReport.corners(radius: self.ivStockReport.frame.width / 2)
        self.ivStockReport.isHidden = true
        self.btnStockReport.corners(radius: self.btnStockReport.frame.width / 2)
        self.lblStockReport.textColor = .black
        
        self.btnBMReport.corners(radius: self.btnBMReport.frame.height / 2)
        self.btnSalesReport.corners(radius: self.btnSalesReport.frame.width / 2)
        self.btnStockReport.corners(radius: self.btnStockReport.frame.width / 2)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if self.intSelectedOption == 1 {
            self.ivBMReport.isHidden = false
            self.viewBMReport.progress = 1
            self.lblBMReport.textColor = .black
        }
        else if self.intSelectedOption == 2 {
            self.ivSalesReport.isHidden = false
            self.viewSalesReport.progress = 1
            self.lblSalesReport.textColor = .black
        }
        else if self.intSelectedOption == 3 {
            self.ivStockReport.isHidden = false
            self.viewStockReport.progress = 1
            self.lblStockReport.textColor = .black
        }
        
    }
}
