//
//  DashboardSalesRDetailsVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 24/07/24.
//

import UIKit

class DashboardSalesRDetailsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBOutlet weak var viewReportDetails: UIView!
    
    @IBOutlet weak var tvReportDetails: UITableView! {
        didSet {
            self.tvReportDetails.delegate = self
            self.tvReportDetails.dataSource = self
            self.tvReportDetails.register(UINib(nibName: "DashboardSalesRDetailsTVCell", bundle: nil), forCellReuseIdentifier: "DashboardSalesRDetailsTVCell")
            /*self.tvReportDetails.register(UINib(nibName: "DashboardSalesReportTVCell", bundle: nil), forCellReuseIdentifier: "DashboardSalesReportTVCell")
            self.tvReportDetails.register(UINib(nibName: "DashboardSalesOrderTVHFView", bundle: nil), forHeaderFooterViewReuseIdentifier: "DashboardSalesOrderTVHFView")
            if #available(iOS 15.0, *) {
                self.tvReportDetails.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }   //  */
        }
    }
    
    
    
    // MARK: - Variable
    
    var strScreenTitle = "Sales Report Details"
    var intSelectedOption: Int = 0
    var intSelectedTab: Int = 1
    
    var strStartDate: String = ""
    var strEndDate: String = ""
    var intEmployeeId: Int = 0
    var arrSelectedState: [Int] = []
    var arrSelectedZone: [Int] = []
    var arrSelectedCategory: [Int] = []
    var strFilter: String = ""
    var strStatus: String = ""
    
    var arrOrders: [Order]? = []
    var total: Total?
    
    var hasMore: Bool = false
    var intPage: Int = 1
    
    var intCellTapIndex: Int = -1
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.getSaleOrderReportDetail(startDate: self.strStartDate, endDate: self.strEndDate, employeeId: self.intEmployeeId, arrIntState: self.arrSelectedState, arrIntZone: self.arrSelectedZone, arrIntcCategoryId: self.arrSelectedCategory, filter: self.strFilter, status: self.strStatus, isExcel: 0, isChart: 0, page: 1)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
}
