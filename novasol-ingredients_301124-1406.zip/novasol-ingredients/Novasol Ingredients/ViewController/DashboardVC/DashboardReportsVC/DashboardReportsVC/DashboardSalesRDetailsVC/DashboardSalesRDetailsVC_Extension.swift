//
//  DashboardSalesRDetailsVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 24/07/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, Datasourse

extension DashboardSalesRDetailsVC: UITableViewDelegate, UITableViewDataSource {
    
    //    func numberOfSections(in tableView: UITableView) -> Int {
    //        if self.intSelectedOption == 2 {
    //            if self.arrOrders?.count ?? 0 > 0 {
    //                return 1
    //            }
    //            return 0
    //        }
    //        return 1
    //    }
    
    //    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
    //        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "DashboardSalesOrderTVHFView") as! DashboardSalesOrderTVHFView
    //        headerView.viewMain.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
    //        headerView.lblTotalOrderTitle.textColor = Colors.theme.returnColor()
    //        headerView.lblTotalValue.textColor = Colors.theme.returnColor()
    //
    //        headerView.lblTotalOrder.text = "\(self.total?.orders ?? 0)"
    //        headerView.lblTotalValue.text = "₹ " + "\(self.total?.amount ?? 0.0)".curFormatAsRegion()
    //
    //        headerView.lblMaterialDispatchColor.backgroundColor = Colors.themeGreen.returnColor()
    //        headerView.lblMaterialDispatchColor.corners(radius: headerView.lblMaterialDispatchColor.frame.height / 2)
    //
    //        headerView.lblBackOrdersColor.backgroundColor = Colors.themeRed.returnColor()
    //        headerView.lblBackOrdersColor.corners(radius: headerView.lblBackOrdersColor.frame.height / 2)
    //        return headerView
    //    }
    
    //    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
    //        if self.intSelectedOption == 2 {
    //            if self.arrOrders?.count ?? 0 > 0 {
    //                return 66
    //            }
    //            return 0
    //        }
    //        return 1
    //    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //        if self.intSelectedOption == 1 {
        //            return self.arrBusinessP?.count ?? 0
        //        }
        //        else if self.intSelectedOption == 2 {
        //            return self.arrOrders?.count ?? 0
        //        }
        return self.arrOrders?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DashboardSalesRDetailsTVCell", for: indexPath) as! DashboardSalesRDetailsTVCell
        
        //DispatchQueue.main.async {
        cell.index = indexPath.row
        
        cell.lblColor.backgroundColor = UIColor(hexString: "\(self.arrOrders?[indexPath.row].bmOrderStatus ?? "")", alpha: 1.0)
        cell.lblName.text = self.arrOrders?[indexPath.row].name ?? ""
        cell.lblAmount.text = "₹" + "\(self.arrOrders?[indexPath.row].basicTotal ?? 0.0)".curFormatAsRegion()
        
        if "#008000" == self.arrOrders?[indexPath.row].bmOrderStatus ?? "" {
            cell.lblOrders.text = "\(self.arrOrders?[indexPath.row].orderTotal ?? 0) Invoice"
        }
        else {
            cell.lblOrders.text = "\(self.arrOrders?[indexPath.row].orderTotal ?? 0) Orders"
        }
        
        cell.lblBMNo.text = "\(self.arrOrders?[indexPath.row].codeID ?? "")"
        cell.lblBMName.text = "\(self.arrOrders?[indexPath.row].name ?? "")"
        cell.lblEmployee.text = "\(self.arrOrders?[indexPath.row].employeeName ?? "")"
        cell.lblIndustry.text = "\(self.arrOrders?[indexPath.row].industryType ?? "")"
        cell.lblEmail.text = "\(self.arrOrders?[indexPath.row].email ?? "")"
        cell.lblCity.text = "\(self.arrOrders?[indexPath.row].cityName ?? "")"
        cell.lblState.text = "\(self.arrOrders?[indexPath.row].stateName ?? "")"
        cell.lblBasicValue.text = "₹" + "\(self.arrOrders?[indexPath.row].basicTotal ?? 0.0)".curFormatAsRegion()
        
        cell.viewMoreDetails.isHidden = true
        cell.constraintHeightViewMoreDetails.priority = .required
        cell.colleCategories.delegate = nil
        cell.colleCategories.dataSource = nil
        if self.intCellTapIndex == indexPath.row {
            cell.viewMoreDetails.isHidden = false
            cell.constraintHeightViewMoreDetails.priority = .defaultLow
            
            cell.constraintHeightColleCategories.constant = CGFloat((self.arrOrders?[indexPath.row].categories?.count ?? 0) + 1) * 35.0
            cell.loadCollection(self.arrOrders?[indexPath.row].categories ?? [])
        }
        
        if self.hasMore {
            if indexPath.row >= (self.arrOrders?.count ?? 0) - 5 {
                self.intPage = self.intPage + 1
                self.getSaleOrderReportDetail(startDate: self.strStartDate,
                                              endDate: self.strEndDate,
                                              employeeId: self.intEmployeeId,
                                              arrIntState: self.arrSelectedState,
                                              arrIntZone: self.arrSelectedZone,
                                              arrIntcCategoryId: self.arrSelectedCategory,
                                              filter: self.strFilter,
                                              status: self.strStatus,
                                              isExcel: 0,
                                              isChart: 0,
                                              page: self.intPage)
            }
        }
        
        //}
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        DispatchQueue.main.async {
            if self.intCellTapIndex == indexPath.row {
                self.intCellTapIndex = -1
            }
            else {
                self.intCellTapIndex = indexPath.row
            }
            self.tvReportDetails.reloadData()
            //self.tvReportDetails.reloadRows(at: [indexPath], with: .none)
        }
    }
}


// MARK: - WebServices

extension DashboardSalesRDetailsVC {
    func getSaleOrderReportDetail(startDate: String, endDate: String, employeeId: Int, arrIntState: [Int], arrIntZone: [Int], arrIntcCategoryId: [Int], filter: String, status: String, isExcel: Int, isChart: Int, page: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getSaleOrderReportDetail(startDate: startDate, endDate: endDate, employeeId: employeeId, arrIntState: arrIntState, arrIntZone: arrIntZone, arrIntcCategoryId: arrIntcCategoryId, filter: filter, status: status, isExcel: isExcel, isChart: isChart, page: page)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate,
            "employeeId": employeeId,
            "state": arrIntState,
            "zone": arrIntZone,
            "category_id": arrIntcCategoryId,
            "filter": filter,
            "status": status,
            "page": page,
            "isExcel": isExcel,
            "isChart": isChart
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_SALES_ORDER_REPORT_DETAIL, parameters: param) { (response: ApiResponseDashboard?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    let arrTempOrders = response?.result?.orders ?? []
                    self.hasMore = response?.result?.hasMore ?? false
                    self.arrOrders?.append(contentsOf: arrTempOrders)
                    self.tvReportDetails.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
