//
//  DashboardSalesRDetailsTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 24/07/24.
//

import UIKit

class DashboardSalesRDetailsTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewShadow: UIView!
    
    @IBOutlet weak var viewNameAmount: UIView!
    @IBOutlet weak var constraintBottomViewNameAmountToSuper: NSLayoutConstraint!
    @IBOutlet weak var lblColor: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblOrders: UILabel!
    
    @IBOutlet weak var viewMoreDetails: UIView!
    @IBOutlet weak var constraintHeightViewMoreDetails: NSLayoutConstraint!
    @IBOutlet weak var constraintBottomViewMoreDetailsToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var viewBMNo: UIView!
    @IBOutlet weak var lblBMNoTitle: UILabel!
    @IBOutlet weak var lblBMNo: UILabel!
    @IBOutlet weak var lblSeparatorBMNo: UILabel!
    
    @IBOutlet weak var viewBMName: UIView!
    @IBOutlet weak var lblBMNameTitle: UILabel!
    @IBOutlet weak var lblBMName: UILabel!
    @IBOutlet weak var lblSeparatorBMName: UILabel!
    
    @IBOutlet weak var viewEmployee: UIView!
    @IBOutlet weak var lblEmployeeTitle: UILabel!
    @IBOutlet weak var lblEmployee: UILabel!
    @IBOutlet weak var lblSeparatorEmployee: UILabel!
    
    @IBOutlet weak var viewIndustry: UIView!
    @IBOutlet weak var lblIndustryTitle: UILabel!
    @IBOutlet weak var lblIndustry: UILabel!
    @IBOutlet weak var lblSeparatorIndustry: UILabel!
    
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var lblEmailTitle: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblSeparatorEmail: UILabel!
    
    @IBOutlet weak var viewCity: UIView!
    @IBOutlet weak var lblCityTitle: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    
    @IBOutlet weak var viewState: UIView!
    @IBOutlet weak var lblStateTitle: UILabel!
    @IBOutlet weak var lblState: UILabel!
    
    @IBOutlet weak var lblSeparatorCityState: UILabel!
    
    @IBOutlet weak var viewBasicValue: UIView!
    @IBOutlet weak var lblBasicValueTitle: UILabel!
    @IBOutlet weak var lblBasicValue: UILabel!
    @IBOutlet weak var lblSeparatorBasicValue: UILabel!
    
    @IBOutlet weak var viewCategories: UIView!
    @IBOutlet weak var lblSeparatorCategories: UILabel!
    @IBOutlet weak var colleCategories: UICollectionView! {
        didSet {
            //self.colleCategories.delegate = self
            //self.colleCategories.dataSource = self
            self.colleCategories.register(UINib(nibName: "WarehouseCVCell", bundle: nil), forCellWithReuseIdentifier: "WarehouseCVCell")
        }
    }
    @IBOutlet weak var constraintHeightColleCategories: NSLayoutConstraint!
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var rowHeaders: [String] = ["Item Group", "Qty", "Unit", "Amount"]
    var arrCategories: [Category]?
    var doubleViewWidth: Double = 0
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.lblName.textColor = Colors.theme.returnColor()
        self.lblAmount.textColor = Colors.theme.returnColor()
        self.lblBMNoTitle.textColor = Colors.theme.returnColor()
        self.lblBMNameTitle.textColor = Colors.theme.returnColor()
        self.lblEmployeeTitle.textColor = Colors.theme.returnColor()
        self.lblIndustryTitle.textColor = Colors.theme.returnColor()
        self.lblEmailTitle.textColor = Colors.theme.returnColor()
        self.lblCityTitle.textColor = Colors.theme.returnColor()
        self.lblStateTitle.textColor = Colors.theme.returnColor()
        self.lblBasicValueTitle.textColor = Colors.theme.returnColor()
        
        self.lblColor.corners(radius: self.lblColor.frame.width / 2)
        self.viewShadow.corners(radius: 3)
        self.viewShadow.addShadow(offset: .zero, color: .black, radius: 2, opacity: 0.5)
        self.viewMoreDetails.corners(radius: 8)
        //self.constraintBottomViewNameAmountToSuper.priority = .required
        
        if #available(iOS 14.0, *) {
            self.automaticallyUpdatesContentConfiguration = true
        } else {
            // Fallback on earlier versions
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}


// MARK: UICollectionView Delegate, DataSource, FlowLayout

extension DashboardSalesRDetailsTVCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func loadCollection(_ arrCategories: [Category]) {
        DispatchQueue.main.async {
            self.arrCategories = arrCategories
            //self.constraintHeightColleCategories.constant = CGFloat((self.arrCategories?.count ?? 0) + 1) * 35.0
            
            self.colleCategories.delegate = self
            self.colleCategories.dataSource = self
            self.colleCategories.reloadData()
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return (self.arrCategories?.count ?? 0) + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return rowHeaders.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WarehouseCVCell", for: indexPath) as! WarehouseCVCell
        cell.lblValue.backgroundColor = .clear
        if indexPath.section == 0 {
            cell.lblValue.text = rowHeaders[indexPath.item]
            cell.lblValue.textAlignment = .center
            cell.viewMain.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        }
        else {
            cell.viewMain.backgroundColor = UIColor(hexString: "#F3F3F3", alpha: 1.0)
            cell.lblValue.font = Fonts.Regular.returnFont(size: 15.0)
            if indexPath.item == 0 {
                cell.lblValue.text = "\(self.arrCategories?[indexPath.section - 1].name ?? "")"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 1 {
                cell.lblValue.text = "\(self.arrCategories?[indexPath.section - 1].productQty ?? "")"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 2 {
                cell.lblValue.text = "\(self.arrCategories?[indexPath.section - 1].productUnit ?? "")"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 3 {
                cell.lblValue.text = "₹" + "\(self.arrCategories?[indexPath.section - 1].totalAmount ?? 0.0)".curFormatAsRegion()
                cell.lblValue.textAlignment = .center
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (self.viewMoreDetails.frame.width - 0) / CGFloat(self.rowHeaders.count)
        let height = 35.0
        return CGSize(width: width, height: height)
    }
}
