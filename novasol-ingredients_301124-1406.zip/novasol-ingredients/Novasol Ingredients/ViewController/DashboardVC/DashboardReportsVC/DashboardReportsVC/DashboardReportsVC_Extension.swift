//
//  DashboardReportsVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 19/07/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, Datasourse

extension DashboardReportsVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if self.intSelectedOption == 2 {
            if self.arrOrders?.count ?? 0 > 0 {
                return 1
            }
            return 0
        }
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "DashboardSalesOrderTVHFView") as! DashboardSalesOrderTVHFView
        headerView.viewMain.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
        headerView.lblTotalOrderTitle.textColor = Colors.theme.returnColor()
        headerView.lblTotalValue.textColor = Colors.theme.returnColor()
        
        headerView.lblTotalOrder.text = "\(self.total?.orders ?? 0)"
        headerView.lblTotalValue.text = "₹ " + "\(self.total?.amount ?? 0.0)".curFormatAsRegion()
        
        headerView.lblMaterialDispatchColor.backgroundColor = Colors.themeGreen.returnColor()
        headerView.lblMaterialDispatchColor.corners(radius: headerView.lblMaterialDispatchColor.frame.height / 2)
        
        headerView.lblBackOrdersColor.backgroundColor = Colors.themeRed.returnColor()
        headerView.lblBackOrdersColor.corners(radius: headerView.lblBackOrdersColor.frame.height / 2)
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if self.intSelectedOption == 2 {
            if self.arrOrders?.count ?? 0 > 0 {
                return 66
            }
            return 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.intSelectedOption == 1 {
            return self.arrBusinessP?.count ?? 0
        }
        else if self.intSelectedOption == 2 {
            return self.arrOrders?.count ?? 0
        }
        else if self.intSelectedOption == 3 {
            return self.arrStockProductList?.count ?? 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.tvReport {
            if self.intSelectedOption == 1 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "DashboardBMReportTVCell", for: indexPath) as! DashboardBMReportTVCell
                
                cell.index = indexPath.row
                cell.lblName.text = self.arrBusinessP?[indexPath.row].name ?? ""
                cell.lblEmpName.text = self.arrBusinessP?[indexPath.row].employeeName ?? ""
                
                cell.lblTime.text = ""
                if self.arrBusinessP?[indexPath.row].lastOrderDate ?? "" != "" {
                    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    let date = dateFormatter.date(from: self.arrBusinessP?[indexPath.row].lastOrderDate ?? "")
                    cell.lblTime.text = Date().offset(from: date!)
                }
                
                cell.lblM_SO.text = "\(self.arrBusinessP?[indexPath.row].saleOrderCount ?? 0)"
                cell.lblM_QI.text = "\(self.arrBusinessP?[indexPath.row].qiOrderCount ?? 0)"
                cell.lblM_PI.text = "\(self.arrBusinessP?[indexPath.row].piOrderCount ?? 0)"
                cell.lblM_SR.text = "\(self.arrBusinessP?[indexPath.row].sampleOrderCount ?? 0)"
                
                cell.lblBMNo.text = "\(self.arrBusinessP?[indexPath.row].codeId ?? "")" == "" ? "-" : "\(self.arrBusinessP?[indexPath.row].codeId ?? "")"
                cell.lblBMName.text = "\(self.arrBusinessP?[indexPath.row].name ?? "")" == "" ? "-" : "\(self.arrBusinessP?[indexPath.row].name ?? "")"
                cell.lblEmployee.text = "\(self.arrBusinessP?[indexPath.row].employeeName ?? "")" == "" ? "-" : "\(self.arrBusinessP?[indexPath.row].employeeName ?? "")"
                cell.lblIndustryType.text = "\(self.arrBusinessP?[indexPath.row].industryType ?? "")" == "" ? "-" : "\(self.arrBusinessP?[indexPath.row].industryType ?? "")"
                cell.lblContactNo.text = "\(self.arrBusinessP?[indexPath.row].contactNumber ?? "")" == "" ? "-" : "\(self.arrBusinessP?[indexPath.row].contactNumber ?? "")"
                cell.lblContactName.text = "\(self.arrBusinessP?[indexPath.row].contactPerson ?? "")" == "" ? "-" : "\(self.arrBusinessP?[indexPath.row].contactPerson ?? "")"
                cell.lblEmail.text = "\(self.arrBusinessP?[indexPath.row].email ?? "")" == "" ? "" : "\(self.arrBusinessP?[indexPath.row].email ?? "")"
                cell.lblCity.text = "\(self.arrBusinessP?[indexPath.row].cityName ?? "")" == "" ? "-" : "\(self.arrBusinessP?[indexPath.row].cityName ?? "")"
                cell.lblState.text = "\(self.arrBusinessP?[indexPath.row].stateName ?? "")" == "" ? "-" : "\(self.arrBusinessP?[indexPath.row].stateName ?? "")"
                
                cell.lblSO.text = "\(self.arrBusinessP?[indexPath.row].saleOrderCount ?? 0)"
                cell.lblQI.text = "\(self.arrBusinessP?[indexPath.row].qiOrderCount ?? 0)"
                cell.lblPI.text = "\(self.arrBusinessP?[indexPath.row].piOrderCount ?? 0)"
                cell.lblSR.text = "\(self.arrBusinessP?[indexPath.row].sampleOrderCount ?? 0)"
                
                
                cell.viewDisplayDetails.isHidden = true
                cell.constraintBottomViewM_SoQiPiSrToSuper.priority = .required
                if self.intCellTapIndex == indexPath.row {
                    cell.viewDisplayDetails.isHidden = false
                    cell.constraintBottomViewM_SoQiPiSrToSuper.priority = .defaultLow
                }
                
                if self.hasMore {
                    if indexPath.row >= (self.arrBusinessP?.count ?? 0) - 5 {
                        self.intPage = self.intPage + 1
                        self.getBusinessPartnerReport(startDate: self.strStartDate2,
                                                      endDate: self.strEndDate2,
                                                      arrEmployee: self.arrSelectedEmp2,
                                                      arrIntState: self.arrSelectedState2,
                                                      arrStrIndustry: self.arrSelectedIndustry2,
                                                      arrIntZone: self.arrSelectedZone2,
                                                      intPage: self.intPage)
                    }
                }
                
                return cell
            }
            else if self.intSelectedOption == 2 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "DashboardSalesReportTVCell", for: indexPath) as! DashboardSalesReportTVCell
                
                cell.index = indexPath.row
                
                cell.lblName.text = self.arrOrders?[indexPath.row].employeeName ?? ""
                cell.lblAmount.text = "₹ " + "\(self.arrOrders?[indexPath.row].totalAmount ?? 0.0)".curFormatAsRegion()
                cell.lblOrders.text = "\(self.arrOrders?[indexPath.row].totalOrders ?? 0) Orders"
                cell.lblMDispatchCount.text = "\(self.arrOrders?[indexPath.row].materialDispatchedCount ?? 0)"
                cell.lblBackOrderCount.text = "\(self.arrOrders?[indexPath.row].backOrderCount ?? 0)"
                
                if (self.arrOrders?[indexPath.row].targetStatus ?? 0) == 0 {
                    cell.ivArrow.image = UIImage(systemName: "arrow.down")
                    cell.ivArrow.tintColor = Colors.themeRed.returnColor()
                }
                else {
                    cell.ivArrow.image = UIImage(systemName: "arrow.up")
                    cell.ivArrow.tintColor = Colors.themeGreen.returnColor()
                }
                
                if self.hasMore {
                    if indexPath.row >= (self.arrOrders?.count ?? 0) - 5 {
                        self.intPage = self.intPage + 1
                        self.getSaleOrderReport(startDate: self.strStartDate2,
                                                endDate: self.strEndDate2,
                                                arrEmployee: self.arrSelectedEmp2,
                                                arrIntState: self.arrSelectedState2,
                                                arrStrIndustry: self.arrSelectedIndustry2,
                                                arrIntZone: self.arrSelectedZone2,
                                                intPage: self.intPage)
                    }
                }
                
                return cell
            }
        }
        else if tableView == self.tvStockData {
            if self.intSelectedOption == 3 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "DashboardStockReportTVCell", for: indexPath) as! DashboardStockReportTVCell
                //"₹"
                cell.index = indexPath.row
                cell.lblCategory.text = self.arrStockProductList?[indexPath.row].categoryName ?? ""
                
                cell.constraintTopViewProductDetailToSuper.priority = .defaultLow
                if indexPath.row > 0 {
                    if (self.arrStockProductList?[indexPath.row].categoryName ?? "") == (self.arrStockProductList?[indexPath.row - 1].categoryName ?? "") {
                        cell.constraintTopViewProductDetailToSuper.priority = .required
                    }
                }
                
                cell.lblProductNameTitle.text = self.arrProductCellHeader[0]
                cell.lblBasicPriceTitle.text = self.arrProductCellHeader[1]
                cell.lblClosingStockTitle.text = self.arrProductCellHeader[2]
                
                cell.lblProductName.text = self.arrStockProductList?[indexPath.row].name ?? ""
                cell.lblBasicPrice.text = "₹" + "\(self.arrStockProductList?[indexPath.row].unitPrice ?? 0)".curFormatAsRegion()
                cell.lblClosingStock.text = self.arrStockProductList?[indexPath.row].categoryName ?? ""
                
                let arrTempClosingStock = (self.arrStockProductList?[indexPath.row].productWarehouse ?? []).map { "\($0.inStock!) (\(($0.branchName!).prefix(1)))" }
                
                var strClosingStock = arrTempClosingStock.joined(separator: "\n")
                cell.lblClosingStock.text = strClosingStock
                cell.lblClosingStock.textAlignment = .left
                
                if self.hasMore {
                    if indexPath.row >= (self.arrStockProductList?.count ?? 0) - 5 {
                        self.intPage = self.intPage + 1
                        self.getStockReport(arrIntBranch: self.arrSelectedStockBranch,
                                            arrIntCategory: self.arrSelectedStockItemGrp,
                                            intExcel: 0,
                                            intPage: self.intPage)
                    }
                }
                
                return cell
            }
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == self.tvReport {
            if self.intSelectedOption == 1 {
                if self.intCellTapIndex == indexPath.row {
                    self.intCellTapIndex = -1
                }
                else {
                    self.intCellTapIndex = indexPath.row
                }
                self.tvReport.reloadData()
            }
            else if self.intSelectedOption == 2 {
                let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                let viewController = storyBoard.instantiateViewController(withIdentifier: "DashboardSalesRDetailsVC") as! DashboardSalesRDetailsVC
                viewController.strStartDate = self.strStartDate2
                viewController.strEndDate = self.strEndDate2
                viewController.intEmployeeId = self.arrOrders?[indexPath.row].employeeID ?? 0
                viewController.arrSelectedState = self.arrSelectedState2
                viewController.arrSelectedZone = self.arrSelectedZone2
                viewController.arrSelectedCategory = self.arrSelectedCategory2
                viewController.strFilter = self.strSelectedFilter
                viewController.strStatus = self.strSelectedStatus
                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
    }
}


// MARK: - WebServices

extension DashboardReportsVC {
    func getStates(isBtnTap: Bool = false) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getStates(isBtnTap: isBtnTap)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_STATES, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrState = response?.result?.state ?? []
                    
                    if isBtnTap {
                        self.btnSelectStateTap(UIButton())
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getBusinessPartnerReport(startDate: String = "", endDate: String = "", arrEmployee: [Int] = [], arrIntState: [Int] = [], arrStrIndustry: [String] = [], arrIntBranch: [Int] = [], arrIntCategory: [Int] = [], arrIntZone: [Int] = [], filter: String = "", intExcel: Int = 0, intChart: Int = 0, intPage: Int = 1) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBusinessPartnerReport(startDate: startDate,
                                                  endDate: endDate,
                                                  arrEmployee: arrEmployee,
                                                  arrIntState: arrIntState,
                                                  arrStrIndustry: arrStrIndustry,
                                                  arrIntBranch: arrIntBranch,
                                                  arrIntCategory: arrIntCategory,
                                                  arrIntZone: arrIntZone,
                                                  filter: filter,
                                                  intExcel: intExcel,
                                                  intChart: intChart,
                                                  intPage: intPage)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate,
            "employee": arrEmployee,
            "state": arrIntState,
            "industry_type": arrStrIndustry,
            "branch_id": arrIntBranch,
            "category_id": arrIntCategory,
            "zone": arrIntZone,
            "filter": filter,
            "isExcel": intExcel,
            "isChart": intChart,
            "page": intPage,
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_BUSINESS_PARTNER_REPORT, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.hasMore = response?.result?.hasMore ?? false
                    
                    if intChart == 1 {
                        //self.setupWebView(htmlContent: response?.result?.path ?? "", viewWeb: self.webView)
                        self.webView.setupWebView(htmlContent: response?.result?.path ?? "")
                    }
                    else {
                        var arrTempBusinessP = response?.result?.businessPartners ?? []
                        
                        if intPage > 1 {
                            self.arrBusinessP?.append(contentsOf: arrTempBusinessP)
                        }
                        else {
                            self.arrBusinessP = arrTempBusinessP
                        }
                        
                        if self.arrBusinessP?.count ?? 0 > 0 {
                            if [3, 4, 10].contains(APIManager.sharedManager.userDetail?.roleId ?? 0) {
                                self.viewFilter2.isHidden = false
                            }
                        }
                        else {
                            self.viewFilter2.isHidden = true
                        }
                        self.tvReport.reloadData()
                    }
                    
                    if intExcel == 1 {
                        guard let url = URL(string: response?.result?.path ?? "") else { return }
                        UIApplication.shared.open(url)
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    self.viewFilter2.isHidden = true
                    Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }
    
    func getSaleOrderReport(startDate: String = "", endDate: String = "", arrEmployee: [Int] = [], arrIntState: [Int] = [], arrStrIndustry: [String] = [], arrIntBranch: [Int] = [], arrIntCategory: [Int] = [], arrIntZone: [Int] = [], filter: String = "", strStatus: String = "", intExcel: Int = 0, intChart: Int = 0, intPage: Int = 1) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getSaleOrderReport(startDate: startDate,
                                                  endDate: endDate,
                                                  arrEmployee: arrEmployee,
                                                  arrIntState: arrIntState,
                                                  arrStrIndustry: arrStrIndustry,
                                                  arrIntBranch: arrIntBranch,
                                                  arrIntCategory: arrIntCategory,
                                                  arrIntZone: arrIntZone,
                                                  filter: filter,
                                                  intExcel: intExcel,
                                                  intChart: intChart,
                                                  intPage: intPage)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate,
            "employee": arrEmployee,
            "state": arrIntState,
            "industry_type": arrStrIndustry,
            "branch_id": arrIntBranch,
            "category_id": arrIntCategory,
            "zone": arrIntZone,
            "filter": filter,
            "status": strStatus,
            "isExcel": intExcel,
            "isChart": intChart,
            "page": intPage,
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_SALES_ORDER_REPORT, parameters: param) { (response: ApiResponseDashboard?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.hasMore = response?.result?.hasMore ?? false
                    
                    if intChart == 1 {
                        //self.setupWebView(htmlContent: response?.result?.path ?? "", viewWeb: self.webView)
                        self.webView.setupWebView(htmlContent: response?.result?.path ?? "")
                    }
                    else {
                        var arrTempOrders = response?.result?.orders ?? []
                        self.total = response?.result?.total
                        
                        if intPage > 1 {
                            self.arrOrders?.append(contentsOf: arrTempOrders)
                        }
                        else {
                            self.arrOrders = arrTempOrders
                        }
                        
                        self.tvReport.reloadData()
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getStockReport(arrIntBranch: [Int] = [], arrIntCategory: [Int] = [], intExcel: Int = 0, intPage: Int = 1) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getStockReport(arrIntBranch: arrIntBranch,
                                        arrIntCategory: arrIntCategory,
                                        intExcel: intExcel,
                                        intPage: intPage)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": APIManager.sharedManager.companyType,
            "branch_id": arrIntBranch,
            "category_id": arrIntCategory,
            "isExcel": intExcel,
            "page": intPage,
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_STOCK_REPORT, parameters: param) { (response: ApiResponseDashboard?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.hasMore = response?.result?.hasMore ?? false
                    
                    if intExcel == 0 {
                        let arrTempProductList = response?.result?.productList ?? []
                        
                        if intPage > 1 {
                            self.arrStockProductList?.append(contentsOf: arrTempProductList)
                            self.tvStockData.reloadData()
                        }
                        else {
                            self.arrStockProductList = arrTempProductList
                            self.tvStockData.scrollsToTop = true
                            self.tvStockData.reloadData()
                        }
                        
                    }
                    else {
                        guard let url = URL(string: response?.result?.path ?? "") else { return }
                        UIApplication.shared.open(url)
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getEmployeeListZoneWise(arrIntZone: [Int] = [], isBtnTap: Bool = false) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployeeListZoneWise(arrIntZone: arrIntZone)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "zone": arrIntZone
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EMPLOYEE_LIST_ZONE_WISE, parameters: param) { (response: ApiResponseDashboard?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrEmp = response?.result?.employee ?? []
                    
                    if isBtnTap {
                        self.btnSelectEmp2Tap(UIButton())
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getUserCategories(isBtnTap: Bool = false) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getUserCategories()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_USER_CATEGORIES, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrCategory = response?.result?.categoryList ?? []
                    
                    if isBtnTap {
                        self.btnItemGrpTap(UIButton())
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getIndustriesCategoryList() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getIndustriesCategoryList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_INDUSTRIES_CATEGORY_LIST, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrIndustriesCategory = response?.result?.industriesCategory ?? []
                }
            }
            else {
                
            }
        }
    }
}
