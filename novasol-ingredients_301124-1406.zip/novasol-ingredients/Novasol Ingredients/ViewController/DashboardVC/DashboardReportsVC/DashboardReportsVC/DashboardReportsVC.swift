//
//  ReportVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 18/07/24.
//

import UIKit

class DashboardReportsVC: UIViewController {
    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBOutlet weak var viewButtons: UIView!
    
    @IBOutlet weak var viewButton1: UIView!
    @IBOutlet weak var btn1: UIButton!
    @IBAction func btn1Tap(_ sender: UIButton) {
        if self.intSelectedTab != 1 {
            self.btn1.setTitleColor(Colors.theme.returnColor(), for: .normal)
            self.lblSeparatorBtn1.isHidden = false
            self.intSelectedTab = 1
            
            self.btn2.setTitleColor(Colors.gray.returnColor(), for: .normal)
            self.lblSeparatorBtn2.isHidden = true
            
            self.viewSearchTab1.isHidden = false
            self.webView.isHidden = false
            
            self.constraintTopViewToSearchTab1.priority = .required
            self.constraintTopViewToSearchTab2.priority = .defaultLow
            
        }
    }
    @IBOutlet weak var lblSeparatorBtn1: UILabel!
    
    @IBOutlet weak var viewButton2: UIView!
    @IBOutlet weak var btn2: UIButton!
    @IBAction func btn2Tap(_ sender: UIButton) {
        if self.intSelectedTab != 2 {
            self.btn1.setTitleColor(Colors.gray.returnColor(), for: .normal)
            self.lblSeparatorBtn1.isHidden = true
            
            self.btn2.setTitleColor(Colors.theme.returnColor(), for: .normal)
            self.lblSeparatorBtn2.isHidden = false
            self.intSelectedTab = 2
            
            self.viewSearchTab1.isHidden = true
            self.webView.isHidden = true
            
            self.constraintTopViewToSearchTab1.priority = .defaultLow
            self.constraintTopViewToSearchTab2.priority = .required
            
//            if (APIManager.sharedManager.userDetail?.roleId ?? 0 == 2) || (APIManager.sharedManager.userDetail?.roleId ?? 0 == 4) || (APIManager.sharedManager.userDetail?.roleId ?? 0 == 10) {
//                self.constraintHeightViewMEmp2.constant = 49
//            }
        }
    }
    @IBOutlet weak var lblSeparatorBtn2: UILabel!
    
    
    // View Chart tab 1
    @IBOutlet weak var viewSearchTab1: UIView!
    @IBOutlet weak var viewSelectDate: UIView!
    
    @IBOutlet weak var viewStartDate: UIView!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var ivStartDate: UIImageView!
    @IBOutlet weak var constraintTrailingLblStartDate: NSLayoutConstraint!
    @IBOutlet weak var btnStartDate: UIButton!
    @IBAction func btnStartDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.didSelectDate = { date in
            self.ivStartDate.isHidden = true
            self.constraintTrailingLblStartDate.priority = .required
            
            self.lblStartDate.text = date
            self.strStartDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy-M-d")
        }
        popupVC.onClose = {
            self.lblStartDate.text = "Start Date"
            self.lblEndDate.text = "End Date"
            self.constraintTrailingLblStartDate.priority = .defaultLow
            self.constraintTrailingLblEndDate.priority = .defaultLow
            self.strStartDate = ""
            self.strEndDate = ""
            self.ivStartDate.isHidden = false
            self.ivEndDate.isHidden = false
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewEndDate: UIView!
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var ivEndDate: UIImageView!
    @IBOutlet weak var constraintTrailingLblEndDate: NSLayoutConstraint!
    @IBOutlet weak var btnEndDate: UIButton!
    @IBAction func btnEndDateTap(_ sender: UIButton) {
        if self.lblStartDate.text == "Start Date" {
            Utilities.showPopup(title: Messages.SelectStartDate, type: .error)
        }
        else {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.dateFormat = "dd-MMM-yyyy"
            popupVC.minStartDate = self.lblStartDate.text!
            popupVC.didSelectDate = { date in
                self.ivEndDate.isHidden = true
                self.constraintTrailingLblEndDate.priority = .required
                
                self.lblEndDate.text = date
                self.strEndDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy-M-d")
            }
            popupVC.onClose = {
                self.lblEndDate.text = "End Date"
                self.constraintTrailingLblEndDate.priority = .defaultLow
                
                self.strEndDate = ""
                self.ivEndDate.isHidden = false
            }
            self.present(popupVC, animated: true, completion: nil)
        }
    }
    
    @IBOutlet weak var viewZone: UIView!
    @IBOutlet weak var lblZone: UILabel!
    @IBOutlet weak var btnSelectZone: UIButton!
    @IBAction func btnSelectZoneTap(_ sender: UIButton) {
        struct Zone: Codable {
            var id: Int?
            var name: String?
        }
        
        var arrZone: [Zone] = []
        arrZone.append(Zone(id: 1, name: "North"))
        arrZone.append(Zone(id: 2, name: "East"))
        arrZone.append(Zone(id: 3, name: "South"))
        arrZone.append(Zone(id: 4, name: "West"))
        
        //let arrBranch: [String] = (APIManager.sharedManager.arrBranches ?? []).map { $0.branchName! }
        let arrTempZone: [String] = arrZone.map { $0.name! }
        
        var arrTempSelectedValue: [String] = []
        for strValue in self.arrSelectedZone.enumerated() {
            let tempValue = arrZone.filter { $0.id! == strValue.element }
            if tempValue.count > 0 {
                arrTempSelectedValue.append("\(tempValue[0].name!)")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Zone"
        popupVC.value = arrTempZone
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.didSelectItem = { arrValue in
            self.arrSelectedZone.removeAll()
            var  strZone: String = ""
            for strValue in arrValue.enumerated() {
                let tempValue = arrZone.filter { $0.name! == strValue.element }
                if tempValue.count > 0 {
                    self.arrSelectedZone.append(tempValue[0].id ?? 0)
                    if strZone != "" {
                        strZone = strZone + ", " + strValue.element
                    }
                    else {
                        strZone = strValue.element
                    }
                }
            }
            if strZone != "" {
                self.lblZone.text = strZone
            }
            else {
                self.lblZone.text = "Zone"
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewState: UIView!
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var btnSelectState: UIButton!
    @IBAction func btnSelectStateTap(_ sender: UIButton) {
        if (self.arrState?.count ?? 0) > 0 {
            let arrTempState: [String] = (self.arrState ?? []).map { $0.stateName! }
            
            var arrTempSelectedValue: [String] = []
            for strValue in self.arrSelectedState.enumerated() {
                let tempValue = (self.arrState ?? []).filter { $0.id! == strValue.element }
                if tempValue.count > 0 {
                    arrTempSelectedValue.append("\(tempValue[0].stateName!)")
                }
            }
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.strTitleText = "State"
            popupVC.value = arrTempState
            popupVC.arrSelectedValue = arrTempSelectedValue
            popupVC.didSelectItem = { arrValue in
                self.arrSelectedState.removeAll()
                var strState: String = ""
                for strValue in arrValue.enumerated() {
                    let tempValue = (self.arrState ?? []).filter { "\($0.stateName!)" == strValue.element }
                    if tempValue.count > 0 {
                        self.arrSelectedState.append(tempValue[0].id ?? 0)
                        if strState != "" {
                            strState = strState + ", " + strValue.element
                        }
                        else {
                            strState = strValue.element
                        }
                    }
                }
                if strState != "" {
                    self.lblState.text = strState
                }
                else {
                    self.lblState.text = "State"
                }
            }
            popupVC.onClose = { arrValue in
            }
            self.present(popupVC, animated: true, completion: nil)
        }
        else {
            self.getStates(isBtnTap: true)
        }
    }
    
    @IBOutlet weak var btnSearch: UIButton!
    @IBAction func btnSearchTap(_ sender: UIButton) {
        var isValid: Bool = true
        var strValidMsg: String = ""
        
        if self.strStartDate == "" {
            isValid = false
            strValidMsg = "Please select start date."
        }
        else if self.strEndDate == "" {
            isValid = false
            strValidMsg = "Please select end date."
        }
        
        if isValid {
            self.intPage = 1
            if self.intSelectedOption == 1 {
                self.getBusinessPartnerReport(startDate: self.strStartDate, 
                                              endDate: self.strEndDate,
                                              arrIntState: self.arrSelectedState,
                                              arrIntZone: self.arrSelectedZone,
                                              intChart: 1)
            }
            else if self.intSelectedOption == 2 {
                
                self.getSaleOrderReport(startDate: self.strStartDate, 
                                        endDate: strEndDate,
                                        arrIntState: self.arrSelectedState,
                                        arrIntZone: self.arrSelectedZone,
                                        intChart: 1)
            }
        }
        else {
            Utilities.showPopup(title: strValidMsg, type: .error)
        }
    }
    
    
    // View Report tab 2
    @IBOutlet weak var viewSearchTab2: UIView!
    @IBOutlet weak var viewSelectDate2: UIView!
    
    @IBOutlet weak var viewStartDate2: UIView!
    @IBOutlet weak var lblStartDate2: UILabel!
    @IBOutlet weak var ivStartDate2: UIImageView!
    @IBOutlet weak var constraintTrailingLblStartDate2: NSLayoutConstraint!
    @IBOutlet weak var btnStartDate2: UIButton!
    @IBAction func btnStartDate2Tap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.didSelectDate = { date in
            self.ivStartDate2.isHidden = true
            self.constraintTrailingLblStartDate2.priority = .required
            
            self.lblStartDate2.text = date
            self.strStartDate2 = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy-M-d")
        }
        popupVC.onClose = {
            self.lblStartDate2.text = "Start Date"
            self.lblEndDate2.text = "End Date"
            self.constraintTrailingLblStartDate.priority = .defaultLow
            self.constraintTrailingLblEndDate.priority = .defaultLow
            self.strStartDate2 = ""
            self.strEndDate2 = ""
            self.ivStartDate2.isHidden = false
            self.ivEndDate2.isHidden = false
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewEndDate2: UIView!
    @IBOutlet weak var lblEndDate2: UILabel!
    @IBOutlet weak var ivEndDate2: UIImageView!
    @IBOutlet weak var constraintTrailingLblEndDate2: NSLayoutConstraint!
    @IBOutlet weak var btnEndDate2: UIButton!
    @IBAction func btnEndDate2Tap(_ sender: UIButton) {
        if self.lblStartDate2.text == "Start Date" {
            Utilities.showPopup(title: Messages.SelectStartDate, type: .error)
        }
        else {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.dateFormat = "dd-MMM-yyyy"
            popupVC.minStartDate = self.lblStartDate2.text!
            popupVC.didSelectDate = { date in
                self.ivEndDate2.isHidden = true
                self.constraintTrailingLblEndDate2.priority = .required
                
                self.lblEndDate2.text = date
                self.strEndDate2 = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy-M-d")
            }
            popupVC.onClose = {
                self.lblEndDate2.text = "End Date"
                self.constraintTrailingLblEndDate2.priority = .defaultLow
                
                self.strEndDate2 = ""
                self.ivEndDate2.isHidden = false
            }
            self.present(popupVC, animated: true, completion: nil)
        }
    }
    
    
    @IBOutlet weak var viewZoneStateIndustry: UIView!
    
    @IBOutlet weak var viewMEmp2: UIView!
    @IBOutlet weak var constraintHeightViewMEmp2: NSLayoutConstraint!
    @IBOutlet weak var stackEmp2: UIStackView!
    @IBOutlet weak var viewEmp2: UIView!
    @IBOutlet weak var lblEmp2: UILabel!
    @IBOutlet weak var btnSelectEmp2: UIButton!
    @IBAction func btnSelectEmp2Tap(_ sender: UIButton) {
        
        if (self.arrEmp?.count ?? 0) > 0 {
            let arrTempEmp: [String] = (self.arrEmp ?? []).map { $0.firstname! + " " + $0.lastname! }
            
            var arrTempSelectedValue: [String] = []
            for strValue in self.arrSelectedEmp2.enumerated() {
                let tempValue = (self.arrEmp ?? []).filter { $0.id! == strValue.element }
                if tempValue.count > 0 {
                    arrTempSelectedValue.append("\(tempValue[0].firstname!) \(tempValue[0].lastname!)")
                }
            }
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.strTitleText = "Employee"
            popupVC.value = arrTempEmp
            popupVC.arrSelectedValue = arrTempSelectedValue
            popupVC.didSelectItem = { arrValue in
                self.arrSelectedEmp2.removeAll()
                var strEmpName: String = ""
                for strValue in arrValue.enumerated() {
                    let tempValue = (self.arrEmp ?? []).filter { "\($0.firstname!) \($0.lastname!)" == strValue.element }
                    if tempValue.count > 0 {
                        self.arrSelectedEmp2.append(tempValue[0].id ?? 0)
                        if strEmpName != "" {
                            strEmpName = strEmpName + ", " + strValue.element
                        }
                        else {
                            strEmpName = strValue.element
                        }
                    }
                }
                
                if strEmpName != "" {
                    self.lblEmp2.text = strEmpName
                }
                else {
                    self.lblEmp2.text = "Employee"
                }
            }
            popupVC.onClose = { arrValue in
            }
            self.present(popupVC, animated: true, completion: nil)
        }
        else {
            self.getEmployeeListZoneWise(arrIntZone: self.arrSelectedZone, isBtnTap: true)
        }
    }
    
    @IBOutlet weak var viewZone2: UIView!
    @IBOutlet weak var lblZone2: UILabel!
    @IBOutlet weak var btnSelectZone2: UIButton!
    @IBAction func btnSelectZone2Tap(_ sender: UIButton) {
        struct Zone: Codable {
            var id: Int?
            var name: String?
        }
        
        var arrZone: [Zone] = []
        arrZone.append(Zone(id: 1, name: "North"))
        arrZone.append(Zone(id: 2, name: "East"))
        arrZone.append(Zone(id: 3, name: "South"))
        arrZone.append(Zone(id: 4, name: "West"))
        
        //let arrBranch: [String] = (APIManager.sharedManager.arrBranches ?? []).map { $0.branchName! }
        let arrTempZone: [String] = arrZone.map { $0.name! }
        
        var arrTempSelectedValue: [String] = []
        for strValue in self.arrSelectedZone2.enumerated() {
            let tempValue = arrZone.filter { $0.id! == strValue.element }
            if tempValue.count > 0 {
                arrTempSelectedValue.append("\(tempValue[0].name!)")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Zone"
        popupVC.value = arrTempZone
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.didSelectItem = { arrValue in
            self.arrSelectedZone2.removeAll()
            var strZone: String = ""
            for strValue in arrValue.enumerated() {
                let tempValue = arrZone.filter { $0.name! == strValue.element }
                if tempValue.count > 0 {
                    self.arrSelectedZone2.append(tempValue[0].id ?? 0)
                    if strZone != "" {
                        strZone = strZone + ", " + strValue.element
                    }
                    else {
                        strZone = strValue.element
                    }
                }
            }
            
            if strZone != "" {
                self.lblZone2.text = strZone
            }
            else {
                self.lblZone2.text = "Zone"
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewState2: UIView!
    @IBOutlet weak var lblState2: UILabel!
    @IBOutlet weak var btnSelectState2: UIButton!
    @IBAction func btnSelectState2Tap(_ sender: UIButton) {
        if (self.arrState?.count ?? 0) > 0 {
            let arrTempState: [String] = (self.arrState ?? []).map { $0.stateName! }
            
            var arrTempSelectedValue: [String] = []
            for strValue in self.arrSelectedState2.enumerated() {
                let tempValue = (self.arrState ?? []).filter { $0.id! == strValue.element }
                if tempValue.count > 0 {
                    arrTempSelectedValue.append("\(tempValue[0].stateName!)")
                }
            }
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.strTitleText = "State"
            popupVC.value = arrTempState
            popupVC.arrSelectedValue = arrTempSelectedValue
            popupVC.didSelectItem = { arrValue in
                self.arrSelectedState2.removeAll()
                var strState: String = ""
                for strValue in arrValue.enumerated() {
                    let tempValue = (self.arrState ?? []).filter { "\($0.stateName!)" == strValue.element }
                    if tempValue.count > 0 {
                        self.arrSelectedState2.append(tempValue[0].id ?? 0)
                        if strState != "" {
                            strState = strState + ", " + strValue.element
                        }
                        else {
                            strState = strValue.element
                        }
                    }
                }
                
                if strState != "" {
                    self.lblState2.text = strState
                }
                else {
                    self.lblState2.text = "State"
                }
            }
            popupVC.onClose = { arrValue in
            }
            self.present(popupVC, animated: true, completion: nil)
        }
        else {
            self.getStates(isBtnTap: true)
        }
    }
    
    @IBOutlet weak var viewIndustry2: UIView!
    @IBOutlet weak var lblIndustry2: UILabel!
    @IBOutlet weak var btnSelectIndustry2: UIButton!
    @IBAction func btnSelectIndustry2Tap(_ sender: UIButton) {
        //let arrTempZone: [String] = (self.arrIndustriesCategory ?? []).map { $0.! }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Industry Category"
        popupVC.value = self.arrIndustriesCategory ?? []
        popupVC.arrSelectedValue = self.arrSelectedIndustry2
        popupVC.didSelectItem = { arrValue in
            self.arrSelectedIndustry2 = arrValue
            var strIndustryCat: String = ""
            for strValue in arrValue.enumerated() {
                if strIndustryCat != "" {
                    strIndustryCat = strIndustryCat + ", " + strValue.element
                }
                else {
                    strIndustryCat = strValue.element
                }
            }
            
            if strIndustryCat != "" {
                self.lblIndustry2.text = strIndustryCat
            }
            else {
                self.lblIndustry2.text = "Industry"
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewItemGrpStatus: UIView!
    @IBOutlet weak var constraintHeightItemGrpStatus: NSLayoutConstraint!
    @IBOutlet weak var stackItemGrpStatus: UIStackView!
    
    @IBOutlet weak var viewItemGrp: UIView!
    @IBOutlet weak var lblItemGrp: UILabel!
    @IBOutlet weak var btnItemGrp: UIButton!
    @IBAction func btnItemGrpTap(_ sender: UIButton) {
        if (self.arrCategory?.count ?? 0) > 0 {
            let arrTempCategory: [String] = (self.arrCategory ?? []).map { $0.name! }
            
            var arrTempSelectedValue: [String] = []
            for strValue in self.arrSelectedCategory2.enumerated() {
                let tempValue = (self.arrCategory ?? []).filter { $0.categoryId! == strValue.element }
                if tempValue.count > 0 {
                    arrTempSelectedValue.append("\(tempValue[0].name!)")
                }
            }
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.strTitleText = "Item Group"
            popupVC.value = arrTempCategory
            popupVC.arrSelectedValue = arrTempSelectedValue
            popupVC.didSelectItem = { arrValue in
                self.arrSelectedCategory2.removeAll()
                var strState: String = ""
                for strValue in arrValue.enumerated() {
                    let tempValue = (self.arrCategory ?? []).filter { "\($0.name!)" == strValue.element }
                    if tempValue.count > 0 {
                        self.arrSelectedCategory2.append(tempValue[0].categoryId ?? 0)
                        if strState != "" {
                            strState = strState + ", " + strValue.element
                        }
                        else {
                            strState = strValue.element
                        }
                    }
                }
                
                if strState != "" {
                    self.lblItemGrp.text = strState
                }
                else {
                    self.lblItemGrp.text = "Item Group"
                }
            }
            popupVC.onClose = { arrValue in
            }
            self.present(popupVC, animated: true, completion: nil)
        }
        else {
            self.getStates(isBtnTap: true)
        }
    }
    
    @IBOutlet weak var viewStatus: UIView!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var btnStatusGrp: UIButton!
    @IBAction func btnStatusTap(_ sender: UIButton) {
        var arrSalesOrderStatus: [String] = ["Both", "Back Orders", "Material Dispatch"]
        
        if arrSalesOrderStatus.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = "Sales Order Status"
            popupVC.value = arrSalesOrderStatus
            popupVC.selectedValue = ""
            popupVC.isSearchActive = false
            popupVC.isOpenCloseAnimation = false
            popupVC.isFromDashboard = true
            popupVC.isFromSalesReport = true
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.lblStatus.text = strValue
                
                self.strSelectedStatus = ""
                if strValue == "Back Orders" {
                    self.strSelectedStatus = "back_order"
                }
                else if strValue == "Material Dispatch" {
                    self.strSelectedStatus = "a_r_invoice"
                }
                
                if self.intSelectedOption == 2 {
                    /*self.getSaleOrderReport(startDate: self.strStartDate2,
                                            endDate: self.strEndDate2,
                                            arrEmployee: self.arrSelectedEmp2,
                                            arrIntState: self.arrSelectedState2,
                                            arrStrIndustry: self.arrSelectedIndustry2,
                                            arrIntZone: self.arrSelectedZone2) */
                }
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    
    @IBOutlet weak var btnSearch2: UIButton!
    @IBAction func btnSearch2Tap(_ sender: UIButton) {
        var isValid: Bool = true
        var strValidMsg: String = ""
        
        if self.strStartDate2 == "" {
            isValid = false
            strValidMsg = "Please select start date."
        }
        else if self.strEndDate2 == "" {
            isValid = false
            strValidMsg = "Please select end date."
        }
        
        if isValid {
            self.intPage = 1
            if self.intSelectedOption == 1 {
                self.getBusinessPartnerReport(startDate: self.strStartDate2,
                                              endDate: self.strEndDate2,
                                              arrEmployee: self.arrSelectedEmp2,
                                              arrIntState: self.arrSelectedState2,
                                              arrStrIndustry: self.arrSelectedIndustry2,
                                              arrIntZone: self.arrSelectedZone2)
            }
            else if self.intSelectedOption == 2 {
                self.getSaleOrderReport(startDate: self.strStartDate2,
                                        endDate: self.strEndDate2,
                                        arrEmployee: self.arrSelectedEmp2,
                                        arrIntState: self.arrSelectedState2,
                                        arrStrIndustry: self.arrSelectedIndustry2,
                                        arrIntZone: self.arrSelectedZone2,
                                        strStatus: self.strSelectedStatus)
            }
        }
        else {
            Utilities.showPopup(title: strValidMsg, type: .error)
        }
    }
    
    
    @IBOutlet weak var viewFilter2: UIView!
    @IBOutlet weak var btnFilter2Tap: UIButton!
    @IBAction func btnFilter2Tap(_ sender: UIButton) {
        var arrFilter: [String] = ["Employee", "Zone", "State", "Industry"]
        
        if arrFilter.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
            popupVC.titleTxt = Title.BPCreditDaysTitle
            popupVC.value = arrFilter
            popupVC.selectedValue = ""
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelect = { strValue in
                
                self.strSelectedFilter = strValue
                if strValue == "Industry" { self.strSelectedFilter = "industryType" }
                else {self.strSelectedFilter = self.strSelectedFilter.lowercased()}
                    
                if self.intSelectedOption == 1 {
                    self.intPage = 1
                    self.getBusinessPartnerReport(startDate: self.strStartDate2,
                                                  endDate: self.strEndDate2,
                                                  arrEmployee: self.arrSelectedEmp2,
                                                  arrIntState: self.arrSelectedState2,
                                                  arrStrIndustry: self.arrSelectedIndustry2,
                                                  arrIntZone: self.arrSelectedZone2,
                                                  filter: self.strSelectedFilter)
                }
            }
            popupVC.onClose = { days in
            }
            self.present(popupVC, animated: true)
        }
    }
    
    @IBOutlet weak var constraintTopViewToSearchTab1: NSLayoutConstraint!
    @IBOutlet weak var constraintTopViewToSearchTab2: NSLayoutConstraint!
    
    @IBOutlet weak var webView: UIView!
    @IBOutlet weak var constraintBottomWebViewToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var viewReport: UIView!
    @IBOutlet weak var constraintBottomViewReportToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var tvReport: UITableView! {
        didSet {
            self.tvReport.delegate = self
            self.tvReport.dataSource = self
            self.tvReport.register(UINib(nibName: "DashboardBMReportTVCell", bundle: nil), forCellReuseIdentifier: "DashboardBMReportTVCell")
            self.tvReport.register(UINib(nibName: "DashboardSalesReportTVCell", bundle: nil), forCellReuseIdentifier: "DashboardSalesReportTVCell")
            self.tvReport.register(UINib(nibName: "DashboardSalesOrderTVHFView", bundle: nil), forHeaderFooterViewReuseIdentifier: "DashboardSalesOrderTVHFView")
            if #available(iOS 15.0, *) {
                self.tvReport.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
    @IBOutlet weak var btnExcel: UIButton!
    @IBAction func btnExcelTap(_ sender: UIButton) {
        var isValid: Bool = true
        var strValidMsg: String = ""
        
        if self.strStartDate2 == "" {
            isValid = false
            strValidMsg = "Please select start date."
        }
        else if self.strEndDate2 == "" {
            isValid = false
            strValidMsg = "Please select end date."
        }
        
        if isValid {
            if self.intSelectedOption == 1 {
                self.intPage = 1
                self.getBusinessPartnerReport(startDate: self.strStartDate2,
                                              endDate: self.strEndDate2,
                                              arrEmployee: self.arrSelectedEmp2,
                                              arrIntState: self.arrSelectedState2,
                                              arrStrIndustry: self.arrSelectedIndustry2,
                                              arrIntZone: self.arrSelectedZone2,
                                              intExcel: 1)
            }
        }
        else {
            Utilities.showPopup(title: strValidMsg, type: .error)
        }
    }
    
    
    /// View Stock Report
    
    @IBOutlet weak var viewStockReport: UIView!
    
    @IBOutlet weak var viewBranchNItemGrp: UIView!
    @IBOutlet weak var stackBranchNItemGrp: UIStackView!
    
    @IBOutlet weak var viewSelectStockBranch: UIView!
    @IBOutlet weak var lblStockBranch: UILabel!
    @IBOutlet weak var btnStockBranch: UIButton!
    @IBAction func btnStockBranchTap(_ sender: UIButton) {
        var arrBranch: [String] = (APIManager.sharedManager.arrBranches ?? []).map { $0.branchName! }
        arrBranch.insert("Select Branch", at: 0)
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.BPBrachTitle
        popupVC.value = arrBranch
        popupVC.selectedValue = self.lblStockBranch.text ?? "Select Branch"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { strValue in
            self.lblStockBranch.text = strValue
            if strValue != "Select Branch" {
                let tempBranch = APIManager.sharedManager.arrBranches?.filter{ ($0.branchName! == strValue) }
                self.intSelectedStockBranch = tempBranch?[0].id ?? 0
                self.arrSelectedStockBranch.removeAll()
                self.arrSelectedStockBranch.append(self.intSelectedStockBranch)
            }
            else {
                self.intSelectedStockBranch = 0
                self.arrSelectedStockBranch.removeAll()
                self.arrSelectedStockBranch.append(self.intSelectedStockBranch)
            }
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewSelectStockItemGrp: UIView!
    @IBOutlet weak var lblStockItemGrp: UILabel!
    @IBOutlet weak var btnStockItemGrp: UIButton!
    @IBAction func btnStockItemGrpTap(_ sender: UIButton) {
        if (self.arrCategory?.count ?? 0) > 0 {
            let arrTempCategory: [String] = (self.arrCategory ?? []).map { $0.name! }
            
            var arrTempSelectedValue: [String] = []
            for strValue in self.arrSelectedStockItemGrp.enumerated() {
                let tempValue = (self.arrCategory ?? []).filter { $0.categoryId! == strValue.element }
                if tempValue.count > 0 {
                    arrTempSelectedValue.append("\(tempValue[0].name!)")
                }
            }
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.strTitleText = "Item Group"
            popupVC.value = arrTempCategory
            popupVC.arrSelectedValue = arrTempSelectedValue
            popupVC.didSelectItem = { arrValue in
                self.arrSelectedStockItemGrp.removeAll()
                var strState: String = ""
                for strValue in arrValue.enumerated() {
                    let tempValue = (self.arrCategory ?? []).filter { "\($0.name!)" == strValue.element }
                    if tempValue.count > 0 {
                        self.arrSelectedStockItemGrp.append(tempValue[0].categoryId ?? 0)
                        if strState != "" {
                            strState = strState + ", " + strValue.element
                        }
                        else {
                            strState = strValue.element
                        }
                    }
                }
                
                if strState != "" {
                    self.lblStockItemGrp.text = strState
                }
                else {
                    self.lblStockItemGrp.text = "Item Group"
                }
            }
            popupVC.onClose = { arrValue in
            }
            self.present(popupVC, animated: true, completion: nil)
        }
    }
    
    @IBOutlet weak var btnStockSearch: UIButton!
    @IBAction func btnStockSearchTap(_ sender: UIButton) {
        self.intPage = 1
        self.getStockReport(arrIntBranch: self.arrSelectedStockBranch, arrIntCategory: self.arrSelectedStockItemGrp, intExcel: 0, intPage: self.intPage)
    }
    
    @IBOutlet weak var viewStockData: UIView!
    
    @IBOutlet weak var tvStockData: UITableView! {
        didSet {
            self.tvStockData.delegate = self
            self.tvStockData.dataSource = self
            self.tvStockData.register(UINib(nibName: "DashboardStockReportTVCell", bundle: nil), forCellReuseIdentifier: "DashboardStockReportTVCell")
            if #available(iOS 15.0, *) {
                self.tvStockData.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
    @IBOutlet weak var btnStockExcel: UIButton!
    @IBAction func btnStockExcelTap(_ sender: UIButton) {
        self.intPage = 1
        self.getStockReport(arrIntBranch: self.arrSelectedStockBranch, arrIntCategory: self.arrSelectedStockItemGrp, intExcel: 1, intPage: 1)
    }
    
    // MARK: - Variable
    
    var strScreenTitle = "BM Report"
    var intSelectedOption: Int = 0
    var intSelectedTab: Int = 1
    
    var strStartDate: String = ""
    var strEndDate: String = ""
    
    var strStartDate2: String = ""
    var strEndDate2: String = ""
    
    var arrState: [State]? = []
    var arrEmp: [Employee]? = []
    var arrCategory: [CategoryList]? = []
    var arrIndustriesCategory: [String]? = []
    
    var arrSelectedZone: [Int] = []
    var arrSelectedState: [Int] = []
    //var arrSelectedIndustry: [Int] = []
    
    var arrSelectedEmp2: [Int] = []
    var arrSelectedZone2: [Int] = []
    var arrSelectedState2: [Int] = []
    var arrSelectedIndustry2: [String] = []
    var arrSelectedCategory2: [Int] = []
    var strSelectedFilter: String = ""
    var strSelectedStatus: String = ""
    
    var intSelectedStockBranch: Int = 0
    var arrSelectedStockBranch: [Int] = [0]
    var arrSelectedStockItemGrp: [Int] = []
    
    var arrBusinessP: [BusinessPartner]?
    var arrOrders: [Order]?
    var total: Total?
    var arrStockProductList: [ProductList]? = []
    var arrProductCellHeader: [String] = ["Product Name", "Basic Price", "Closing Stock"]
    
    var hasMore: Bool = false
    var intPage: Int = 1
    
    private var stringContent = ""
    var path: String = ""
    
    var intCellTapIndex: Int = -1
    var dateFormatter = DateFormatter()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.btn2.setTitle(strScreenTitle.uppercased(), for: .normal)
        
        self.btnSearch.corners(radius: 12.0)
        self.btnExcel.corners(radius: 12.0)
        
        self.btn1.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.lblSeparatorBtn1.isHidden = false
        
        self.btn2.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.lblSeparatorBtn2.isHidden = true
        
        self.btnStockSearch.corners(radius: 8)
        self.btnStockExcel.corners(radius: 8)
        
        self.constraintTopViewToSearchTab1.priority = .required
        self.constraintTopViewToSearchTab2.priority = .defaultLow
        
        self.constraintHeightViewMEmp2.constant = 0
        if (APIManager.sharedManager.userDetail?.roleId ?? 0 == 3) || (APIManager.sharedManager.userDetail?.roleId ?? 0 == 4) || (APIManager.sharedManager.userDetail?.roleId ?? 0 == 10) {
            self.constraintHeightViewMEmp2.constant = 49
        }
        
        self.viewStockReport.isHidden = true
        
        self.constraintHeightItemGrpStatus.constant = 0
        if self.intSelectedOption == 2 {
            self.viewIndustry2.isHidden = true
            self.constraintHeightItemGrpStatus.constant = 49
            self.constraintBottomViewReportToSuper.priority = .required
        }
        else if self.intSelectedOption == 3 {
            self.viewStockReport.isHidden = false
            self.getStockReport(arrIntBranch: self.arrSelectedStockBranch, arrIntCategory: self.arrSelectedStockItemGrp, intExcel: 0, intPage: 1)
        }
        
        self.getStates()
        self.getEmployeeListZoneWise()
        self.getUserCategories()
        self.getIndustriesCategoryList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
}
