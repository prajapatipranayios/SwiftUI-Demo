//
//  DashboardReportTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 19/07/24.
//

import UIKit

class DashboardBMReportTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewShadow: UIView!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblEmpName: UILabel!
    
    @IBOutlet weak var lblM_SOTitle: UILabel!
    @IBOutlet weak var lblM_SO: UILabel!
    @IBOutlet weak var lblM_QITitle: UILabel!
    @IBOutlet weak var lblM_QI: UILabel!
    @IBOutlet weak var lblM_PITitle: UILabel!
    @IBOutlet weak var lblM_PI: UILabel!
    @IBOutlet weak var lblM_SRTitle: UILabel!
    @IBOutlet weak var lblM_SR: UILabel!
    
    @IBOutlet weak var constraintBottomViewM_SoQiPiSrToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var viewDisplayDetails: UIView!
    
    @IBOutlet weak var viewBMNo: UIView!
    @IBOutlet weak var lblBMNoTitle: UILabel!
    @IBOutlet weak var lblBMNo: UILabel!
    @IBOutlet weak var lblSeparatorBMNo: UILabel!
    
    @IBOutlet weak var viewBMName: UIView!
    @IBOutlet weak var lblBMNameTitle: UILabel!
    @IBOutlet weak var lblBMName: UILabel!
    @IBOutlet weak var lblSeparatorBMName: UILabel!
    
    @IBOutlet weak var viewEmployee: UIView!
    @IBOutlet weak var lblEmployeeTitle: UILabel!
    @IBOutlet weak var lblEmployee: UILabel!
    @IBOutlet weak var lblSeparatorEmployee: UILabel!
    
    @IBOutlet weak var viewIndustryType: UIView!
    @IBOutlet weak var lblIndustryTypeTitle: UILabel!
    @IBOutlet weak var lblIndustryType: UILabel!
    @IBOutlet weak var lblSeparatorIndustryType: UILabel!
    
    @IBOutlet weak var viewContactNo: UIView!
    @IBOutlet weak var lblContactNoTitle: UILabel!
    @IBOutlet weak var lblContactNo: UILabel!
    @IBOutlet weak var lblSeparatorContactNo: UILabel!
    
    @IBOutlet weak var viewContactName: UIView!
    @IBOutlet weak var lblContactNameTitle: UILabel!
    @IBOutlet weak var lblContactName: UILabel!
    @IBOutlet weak var lblSeparatorContactName: UILabel!
    
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var lblEmailTitle: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblSeparatorEmail: UILabel!
    
    
    @IBOutlet weak var viewCityState: UIView!
    @IBOutlet weak var stackCityState: UIStackView!
    
    @IBOutlet weak var viewCity: UIView!
    @IBOutlet weak var lblCityTitle: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    
    @IBOutlet weak var viewState: UIView!
    @IBOutlet weak var lblStateTitle: UILabel!
    @IBOutlet weak var lblState: UILabel!
    
    @IBOutlet weak var lblSeparatorViewCityState: UILabel!
    
    
    @IBOutlet weak var viewSoQiPiSr: UIView!
    @IBOutlet weak var stackSoQiPiSr: UIStackView!
    
    @IBOutlet weak var viewSO: UIView!
    @IBOutlet weak var lblSOTitle: UILabel!
    @IBOutlet weak var lblSO: UILabel!
    
    @IBOutlet weak var viewQI: UIView!
    @IBOutlet weak var lblQITitle: UILabel!
    @IBOutlet weak var lblQI: UILabel!
    
    @IBOutlet weak var viewPI: UIView!
    @IBOutlet weak var lblPITitle: UILabel!
    @IBOutlet weak var lblPI: UILabel!
    
    @IBOutlet weak var viewSR: UIView!
    @IBOutlet weak var lblSRTitle: UILabel!
    @IBOutlet weak var lblSR: UILabel!
    
    @IBOutlet weak var lblSeparatorViewSoQiPiSr: UILabel!
    
    
    
    // MARK: - Variables
    
    var onCellTap: ((Int)->Void)?
    var index = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.viewShadow.corners(radius: 3)
        self.viewShadow.addShadow(offset: .zero, color: .black, radius: 3, opacity: 0.50)
        
        self.lblTime.textColor = Colors.theme.returnColor()
        
        self.lblM_SOTitle.textColor = Colors.theme.returnColor()
        self.lblM_QITitle.textColor = Colors.theme.returnColor()
        self.lblM_PITitle.textColor = Colors.theme.returnColor()
        self.lblM_SRTitle.textColor = Colors.theme.returnColor()
        
        self.viewDisplayDetails.corners(radius: 7)
        self.viewDisplayDetails.backgroundColor = UIColor(hexString: "#F3F3F3", alpha: 1.0)
        
        self.lblBMNoTitle.textColor = Colors.theme.returnColor()
        self.lblBMNameTitle.textColor = Colors.theme.returnColor()
        self.lblEmployeeTitle.textColor = Colors.theme.returnColor()
        self.lblIndustryTypeTitle.textColor = Colors.theme.returnColor()
        self.lblContactNoTitle.textColor = Colors.theme.returnColor()
        self.lblContactNameTitle.textColor = Colors.theme.returnColor()
        self.lblEmailTitle.textColor = Colors.theme.returnColor()
        self.lblCityTitle.textColor = Colors.theme.returnColor()
        self.lblStateTitle.textColor = Colors.theme.returnColor()
        self.lblSOTitle.textColor = Colors.theme.returnColor()
        self.lblQITitle.textColor = Colors.theme.returnColor()
        self.lblPITitle.textColor = Colors.theme.returnColor()
        self.lblSRTitle.textColor = Colors.theme.returnColor()
        
        self.viewDisplayDetails.isHidden = true
        self.constraintBottomViewM_SoQiPiSrToSuper.priority = .required
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
