//
//  DashboardSalesOrderHFView.swift
//  Novasol Ingredients
//
//  Created by Auxano on 24/07/24.
//

import UIKit

class DashboardSalesOrderTVHFView: UITableViewHeaderFooterView {
    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblTotalOrderTitle: UILabel!
    @IBOutlet weak var lblTotalOrder: UILabel!
    @IBOutlet weak var lblTotalValueTitle: UILabel!
    @IBOutlet weak var lblTotalValue: UILabel!
    
    @IBOutlet weak var lblMaterialDispatchColor: UILabel!
    @IBOutlet weak var lblBackOrdersColor: UILabel!
    
}
