//
//  DashboardSalesReportTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 24/07/24.
//

import UIKit

class DashboardSalesReportTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblMDispatchColor: UILabel!
    @IBOutlet weak var lblMDispatchCount: UILabel!
    
    @IBOutlet weak var lblBackOrderColor: UILabel!
    @IBOutlet weak var lblBackOrderCount: UILabel!
    
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblOrders: UILabel!
    
    @IBOutlet weak var ivArrow: UIImageView!
    
    // MARK: - Variable
    
    var index: Int = 0
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //arrow.up
        //arrow.down
        
        self.lblMDispatchColor.corners(radius: self.lblMDispatchColor.frame.height / 2)
        self.lblMDispatchColor.backgroundColor = Colors.themeGreen.returnColor()
        self.lblBackOrderColor.corners(radius: self.lblBackOrderColor.frame.height / 2)
        self.lblBackOrderColor.backgroundColor = Colors.themeRed.returnColor()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
