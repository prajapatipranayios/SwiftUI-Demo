//
//  DashboardStockReportTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 25/07/24.
//

import UIKit

class DashboardStockReportTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewCategory: UIView!
    @IBOutlet weak var constraintHeightViewCategory: NSLayoutConstraint!
    @IBOutlet weak var lblCategory: UILabel!
    
    @IBOutlet weak var viewHeader: UIView!
    @IBOutlet weak var constraintHeightViewHeader: NSLayoutConstraint!
    
    @IBOutlet weak var viewProductNameTitle: UIView!
    @IBOutlet weak var lblProductNameTitle: UILabel!
    
    @IBOutlet weak var viewBasicPriceTitle: UIView!
    @IBOutlet weak var lblBasicPriceTitle: UILabel!
    
    @IBOutlet weak var viewClosingStockTitle: UIView!
    @IBOutlet weak var lblClosingStockTitle: UILabel!
    
    @IBOutlet weak var viewProductDetail: UIView!
    @IBOutlet weak var constraintTopViewProductDetailToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var viewProductName: UIView!
    @IBOutlet weak var lblProductName: UILabel!
    
    @IBOutlet weak var viewBasicPrice: UIView!
    @IBOutlet weak var lblBasicPrice: UILabel!
    
    @IBOutlet weak var viewClosingStock: UIView!
    @IBOutlet weak var lblClosingStock: UILabel!
    
    
    // MARK: - Variable
    
    var index: Int = 0
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.lblCategory.textColor = Colors.theme.returnColor()
        
        self.viewProductNameTitle.cornersWFullBorder(radius: 0, borderColor: UIColor(hexString: "#A1A1A1", alpha: 1.0), colorOpacity: 1.0)
        self.viewBasicPriceTitle.cornersWFullBorder(radius: 0, borderColor: UIColor(hexString: "#A1A1A1", alpha: 1.0), colorOpacity: 1.0)
        self.viewClosingStockTitle.cornersWFullBorder(radius: 0, borderColor: UIColor(hexString: "#A1A1A1", alpha: 1.0), colorOpacity: 1.0)
        
        self.viewProductName.cornersWFullBorder(radius: 0, borderColor: UIColor(hexString: "#A1A1A1", alpha: 1.0), colorOpacity: 1.0)
        self.viewBasicPrice.cornersWFullBorder(radius: 0, borderColor: UIColor(hexString: "#A1A1A1", alpha: 1.0), colorOpacity: 1.0)
        self.viewClosingStock.cornersWFullBorder(radius: 0, borderColor: UIColor(hexString: "#A1A1A1", alpha: 1.0), colorOpacity: 1.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
