//
//  ProjectDisplayVC_Extesion.swift
//  Novasol Ingredients
//
//  Created by Auxano on 22/11/24.
//

import Foundation
import UIKit


// MARK: - UICollectionView DataSource, Delegate

extension ProjectDisplayVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TabCellCV", for: indexPath) as! TabCVCell
        
        var name: String = self.arrTab[indexPath.item]
        
        if self.isOrderCountAvailable {
            name = self.setCountToCollection(name: name)
        }
        
        cell.lblName.text = name
        cell.lblName.textColor = (Colors.gray.returnColor()).withAlphaComponent(0.7)
        cell.lblName.backgroundColor = .white
        cell.lblUnderline.backgroundColor = (Colors.gray.returnColor()).withAlphaComponent(0.5)
        cell.constraintHeightUnderLine.constant = 3
        
        if self.intSelectedTab == indexPath.item {
            cell.lblName.textColor = Colors.theme.returnColor()
            cell.lblUnderline.backgroundColor = Colors.theme.returnColor()
            cell.constraintHeightUnderLine.constant = 4
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = ("\(self.arrTab[indexPath.item])000").size(withAttributes:[NSAttributedString.Key.font: Fonts.Regular.returnFont(size: 15.0)])
        let width = size.width + 40
        let height = 50.0
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.dismissMyKeyboard()
        self.intSelectedTab = indexPath.item
        self.page = 1
        
        self.arrCRMList?.removeAll()
        
        if indexPath.row == 0 {
            self.strFilterBy = "All"
        }
        else if indexPath.row == 1 {
            self.strFilterBy = "Completed"
        }
        else if indexPath.row == 2 {
            self.strFilterBy = "Pending"
        }
        else if indexPath.row == 3 {
            self.strFilterBy = "Rejected"
        }
        else if indexPath.row == 4 {
            self.strFilterBy = "Re-Open"
        }
        
        if self.isDairyProduct {
            //self.getCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: self.strFilterBy, type: "dairy", intPage: self.page)
            self.getOldCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: self.strFilterBy, type: "dairy", intPage: self.page)
        }
        else if self.isNonDairyProduct {
            //self.getCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: self.strFilterBy, type: "non-dairy", intPage: self.page)
        }
        
        self.colleTab.reloadData()
    }
    
    func setCountToCollection(name: String) -> String {
        var strName: String = ""
        switch name {
        case CRMScreen.all.rawValue:
            strName = name + " (\(self.statusCount?.allCount ?? 0))"
        case CRMScreen.pending.rawValue:
            strName = name + " (\(self.statusCount?.pendingCount ?? 0))"
        case CRMScreen.completed.rawValue:
            strName = name + " (\(self.statusCount?.completedCount ?? 0))"
        case CRMScreen.rejected.rawValue:
            strName = name + " (\(self.statusCount?.rejectedCount ?? 0))"
        case CRMScreen.reOpen.rawValue:
            strName = name + " (\(self.statusCount?.reOpenCount ?? 0))"
        default:
            strName = name
        }
        return strName
    }
}



// MARK: - UITableView Delegate, Datasource

extension ProjectDisplayVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrCRMList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DisplayProjectTVCell", for: indexPath) as! DisplayProjectTVCell
        
        cell.index = indexPath.row
        
        cell.lblProjectCompName.text = self.arrCRMList?[indexPath.row].companyName ?? ""
        cell.lblCity.text = "\(self.arrCRMList?[indexPath.row].cityName ?? "")" + " " + "\(self.arrCRMList?[indexPath.row].stateName ?? "")"
        cell.lblTime.text = self.arrCRMList?[indexPath.row].timeAgo ?? ""
        cell.lblSalesEmp.text = self.arrCRMList?[indexPath.row].salesEmployee ?? ""
        
        cell.lblStartDate.text = self.arrCRMList?[indexPath.row].startDate ?? ""
        cell.lblStartDate.textColor = UIColor(hexString: "#000000", alpha: 0.5)
        cell.constraintTopViewMainBorder.priority = .defaultLow
        
        if indexPath.row > 0 {
            cell.constraintTopViewMainBorder.priority = .required
            if (self.arrCRMList?[indexPath.row - 1].startDate ?? "") != (self.arrCRMList?[indexPath.row].startDate ?? "") {
                cell.constraintTopViewMainBorder.priority = .defaultLow
            }
        }
        
        cell.btnInfo.isHidden = true
        if (self.arrCRMList?[indexPath.row].projectPriority ?? "") == "High" {
            cell.btnInfo.isHidden = false
            cell.onSelect = { index in
                //print("Selected index -> \(index)")
                let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
                popupVC.modalPresentationStyle = .overCurrentContext
                popupVC.modalTransitionStyle = .crossDissolve
                popupVC.titleTxt = "Alert"
                popupVC.strImgName = "InfoWLightRed"
                popupVC.strMessage = self.arrCRMList?[index].projectPriorityReason ?? ""
                popupVC.onTapOk = { str in
                }
                self.present(popupVC, animated: true)
            }
        }
        
        if (self.arrCRMList?[indexPath.row].projectStatus ?? "") == "Pending" {
            cell.lblProjectStatusColor.backgroundColor = UIColor(hexString: "#ED8322")
            cell.lblProjectStatus.text = self.arrCRMList?[indexPath.row].projectStatus ?? ""
            cell.lblProjectStatus.textColor = UIColor(hexString: "#ED8322")
        }
        else if (self.arrCRMList?[indexPath.row].projectStatus ?? "") == "Completed" {
            cell.lblProjectStatusColor.backgroundColor = UIColor(hexString: "#20DC3E")
            cell.lblProjectStatus.text = self.arrCRMList?[indexPath.row].projectStatus ?? ""
            cell.lblProjectStatus.textColor = UIColor(hexString: "#20DC3E")
        }
        else if (self.arrCRMList?[indexPath.row].projectStatus ?? "") == "Rejected" {
            cell.lblProjectStatusColor.backgroundColor = UIColor(hexString: "#FF3102")
            cell.lblProjectStatus.text = self.arrCRMList?[indexPath.row].projectStatus ?? ""
            cell.lblProjectStatus.textColor = UIColor(hexString: "#FF3102")
        }
        else if (self.arrCRMList?[indexPath.row].projectStatus ?? "") == "Re-Open" {
            cell.lblProjectStatusColor.backgroundColor = UIColor(hexString: "#ED8322")
            cell.lblProjectStatus.text = "OPEN (TPM)"
            cell.lblProjectStatus.textColor = UIColor(hexString: "#007AFF")
        }
        
        
        if self.isLoadMore && (indexPath.row == ((self.arrCRMList?.count ?? 0) - 3)) {
            self.isLoadMore = false
            self.page += 1
            
            if self.isDairyProduct {
                //self.getCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: self.strFilterBy, type: "dairy", intPage: self.page)
                self.getOldCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: self.strFilterBy, type: "dairy", intPage: self.page)
            }
            else if self.isNonDairyProduct {
                //self.getCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: self.strFilterBy, type: "non-dairy", intPage: self.page)
            }
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       
    }
}



// MARK: - Keyboard

extension ProjectDisplayVC {
    
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomViewBodyToSuper.constant = keyboardOverlap > 0 ? (keyboardOverlap - 0) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}



// MARK: - Weeb Service

extension ProjectDisplayVC {
    
    func getCRMList(strSDate: String = "", strEDate: String = "", strSearchValue: String = "", strFilterBy: String = "All", type: String, intPage: Int = 1) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getCRMList(strSDate: strSDate, strEDate: strEDate, strSearchValue: strSearchValue, strFilterBy: strFilterBy, type: type, intPage: intPage)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "startDate": strSDate,
            "endDate": strEDate,
            "search": strSearchValue,
            "filterBy": strFilterBy,
            "type": type,
            "companyType": 1,
            "page": intPage
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_CRM_LIST, parameters: param) { (response: ApiResponseCRM?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    
                    let arrTempCRMList = response?.result?.crmList ?? []
                    self.statusCount = response?.result?.statusCount
                    self.isOrderCountAvailable = true
                    //self.hasMore = (response?.result?.hasMore ?? 0) == 1 ? true : false
                    self.hasMore = response?.result?.hasMore ?? false
                    self.isLoadMore = self.hasMore
                    
                    if intPage > 1 {
                        self.arrCRMList?.append(contentsOf: arrTempCRMList)
                    }
                    else {
                        self.arrCRMList = response?.result?.crmList ?? []
                    }
                    
                    self.colleTab.reloadData()
                    self.tvProjectList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getOldCRMList(strSDate: String = "", strEDate: String = "", strSearchValue: String = "", strFilterBy: String = "All", type: String, intPage: Int = 1) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getCRMList(strSDate: strSDate, strEDate: strEDate, strSearchValue: strSearchValue, strFilterBy: strFilterBy, type: type, intPage: intPage)
                }
            }
            return
        }
        
        let param = [
            "user_id": 85,
            "startDate": strSDate,
            "endDate": strEDate,
            "search": strSearchValue,
            "filterBy": strFilterBy,
            "type": type,
            "companyType": 1,
            "page": intPage
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.oldPostData(url: "http://14.99.147.156:8585/ge/public/api/getCrmList", parameters: param) { (response: ApiResponseCRM?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    
                    let arrTempCRMList = response?.result?.crmList ?? []
                    self.statusCount = response?.result?.statusCount
                    self.isOrderCountAvailable = true
                    //self.hasMore = (response?.result?.hasMore ?? 0) == 1 ? true : false
                    self.hasMore = response?.result?.hasMore ?? false
                    self.isLoadMore = self.hasMore
                    
                    if intPage > 1 {
                        self.arrCRMList?.append(contentsOf: arrTempCRMList)
                    }
                    else {
                        self.arrCRMList = response?.result?.crmList ?? []
                    }
                    
                    self.lblNoData.isHidden = true
                    if self.arrCRMList?.count ?? 0 == 0 {
                        self.lblNoData.isHidden = false
                    }
                    
                    self.colleTab.reloadData()
                    self.tvProjectList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
}
