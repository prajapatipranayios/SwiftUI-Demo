//
//  ProjectDisplayVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 22/11/24.
//

import UIKit


class ProjectDisplayVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var btnInfo: UIButton!
    @IBAction func btnInfoTap(_ sender: UIButton) {
    }
    
    @IBOutlet weak var viewTab: UIView!
    @IBOutlet weak var lblSeparator1: UILabel!
    @IBOutlet weak var colleTab: UICollectionView! {
        didSet {
            self.colleTab.delegate = self
            self.colleTab.dataSource = self
        }
    }
    @IBOutlet weak var constraintHeightViewTab: NSLayoutConstraint!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var viewDate: UIView!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var imgStartD: UIImageView!
    @IBOutlet weak var btnStartDate: UIButton!
    @IBAction func btnStartDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.didSelectDate = { date in
            self.imgStartD.isHidden = true
            
            self.lblStartDate.text = date
            self.strStartDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy/MM/dd")
        }
        popupVC.onClose = {
            self.lblStartDate.text = "Start Date"
            self.lblEndDate.text = "End Date"
            //self.strStartDate = ""
            self.strEndDate = ""
            self.imgStartD.isHidden = false
            self.imgEndD.isHidden = false
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var imgEndD: UIImageView!
    @IBOutlet weak var btnEndDate: UIButton!
    @IBAction func btnEndDateTap(_ sender: UIButton) {
        if self.lblStartDate.text == "Start Date" {
            Utilities.showPopup(title: Messages.SelectStartDate, type: .error)
        }
        else {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.minStartDate = lblStartDate.text!
            popupVC.dateFormat = "dd-MMM-yyyy"
            popupVC.didSelectDate = { date in
                self.imgEndD.isHidden = true
                
                self.lblEndDate.text = date
                self.strEndDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy/MM/dd")
                
                if self.isDairyProduct {
                    //self.getCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: "All", type: "dairy", intPage: self.page)
                    self.getOldCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: "All", type: "dairy", intPage: self.page)
                }
                else if self.isNonDairyProduct {
                    //self.getCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, srFilterBy: "All", type: "non-dairy", intPage: self.page)
                }
                
            }
            popupVC.onClose = {
                self.lblEndDate.text = "End Date"
                //self.strEndDate = ""
                self.imgEndD.isHidden = false
            }
            self.present(popupVC, animated: true, completion: nil)
        }
    }
    
    @IBOutlet weak var viewTblProject: UIView!
    @IBOutlet weak var tvProjectList: UITableView! {
        didSet {
            self.tvProjectList.delegate = self
            self.tvProjectList.dataSource = self
            self.tvProjectList.register(UINib(nibName: "DisplayProjectTVCell", bundle: nil), forCellReuseIdentifier: "DisplayProjectTVCell")
            //self.tvProjectList.register(UINib(nibName: "OrdersCustomTHView", bundle: nil), forHeaderFooterViewReuseIdentifier: "OrdersCustomTHView")
            if #available(iOS 15.0, *) {
                //self.tvProjectList.sectionHeaderTopPadding = 0
            } else { }
        }
    }
    
    //@IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Dairy Project"
    var arrTab: [String] = CRMScreen.getTab(intScreen: 0)
    
    var strStartDate: String = ""
    var strEndDate: String = ""
    
    var page: Int = 1
    var searchText: String = ""
    
    var hasMore: Bool = false
    var isLoadMore: Bool = false
    var intSelectedTab: Int = 0
    var isOrderCountAvailable: Bool = false
    
    var isDairyProduct: Bool = false
    var isNonDairyProduct: Bool = false
    
    var arrCRMList: [CRMList]?
    var arrTempDate: [String] = []
    var statusCount: StatusCount?
    var strFilterBy: String = "All"
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.isNonDairyProduct = !self.isDairyProduct
        
        if self.isDairyProduct {
            //self.getCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: "All", type: "dairy", intPage: self.page)
            self.getOldCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, strFilterBy: "All", type: "dairy", intPage: self.page)
        }
        else if self.isNonDairyProduct {
            //self.getCRMList(strSDate: self.strStartDate, strEDate: self.strEndDate, strSearchValue: self.searchText, srFilterBy: "All", type: "non-dairy", intPage: self.page)
        }
        
    }
}

extension ProjectDisplayVC {
    
//    func setDetail(ordersList: [CRMList]?) {
//        
//        if self.page == 1 {
//            self.arrTempDate.removeAll()
//            self.arrDateNOrderList?.removeAll()
//        }
//        
//        for i in 0 ..< (ordersList?.count ?? 0)
//        {
//            let strDate: String = ordersList?[i].requestDate ?? ""
//            if self.arrTempDate.contains(strDate) {
//                for j in 0 ..< (self.arrDateNOrderList?.count ?? 0) {
//                    if strDate == (self.arrDateNOrderList?[j].requestDate ?? "") {
//                        self.arrDateNOrderList?[j].ordersList?.append((ordersList?[i])!)
//                    }
//                }
//            }
//            else {
//                self.arrTempDate.append(strDate)
//                let tempLObj = ordersList?[i]
//                var tempCObj = (self.arrOrderCounts ?? []).filter { $0.requestDate == strDate }
//                tempCObj[0].ordersList = []
//                tempCObj[0].ordersList?.append(tempLObj!)
//                
//                self.arrDateNOrderList?.append(tempCObj[0])
//            }
//        }
//        DispatchQueue.main.async {
//            //if (self.arrDateNOrderList?.count ?? 0) > 0 {
//            self.isOrderCountAvailable = true
//            self.isLoadMore = self.hasMore
//            self.viewNoData.isHidden = true
//            
//            self.colleTab.reloadData()
//            self.tvOrders.reloadData()
//            //}
//        }
//    }
    
}
