//
//  CRMVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 11/11/24.
//

import UIKit

class CRMVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    @IBOutlet weak var btnInfo: UIButton!
    @IBAction func btnInfoTap(_ sender: UIButton) {
    }
    
    @IBOutlet weak var viewBody: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var viewSVMain: UIView!
    
    @IBOutlet weak var lblChartTitle: UILabel!
    @IBOutlet weak var viewChart: UIView!
    
    
    @IBOutlet weak var viewDairyProduct: UIView!
    @IBOutlet weak var lblDPColor1: UILabel!
    @IBOutlet weak var lblDPCompleted: UILabel!
    @IBOutlet weak var lblDPCompletedCount: UILabel!
    @IBOutlet weak var lblDPColor2: UILabel!
    @IBOutlet weak var lblDPPending: UILabel!
    @IBOutlet weak var lblDPPendingCount: UILabel!
    @IBOutlet weak var lblDPColor3: UILabel!
    @IBOutlet weak var lblDPRejected: UILabel!
    @IBOutlet weak var lblDPRejectedCount: UILabel!
    @IBOutlet weak var lblDPColor4: UILabel!
    @IBOutlet weak var lblDPReOpen: UILabel!
    @IBOutlet weak var lblDPReOpenCount: UILabel!
    @IBOutlet weak var lblDPTotalProject: UILabel!
    @IBOutlet weak var lblDPTotalProjectCount: UILabel!
    @IBAction func btnDairyProductTap(_ sender: UIButton) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "ProjectDisplayVC") as! ProjectDisplayVC
        vc.strScreenTitle = "Dairy Product"
        vc.isDairyProduct = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBOutlet weak var viewNonDairyProduct: UIView!
    @IBOutlet weak var lblNDPColor1: UILabel!
    @IBOutlet weak var lblNDPCompleted: UILabel!
    @IBOutlet weak var lblNDPCompletedCount: UILabel!
    @IBOutlet weak var lblNDPColor2: UILabel!
    @IBOutlet weak var lblNDPPending: UILabel!
    @IBOutlet weak var lblNDPPendingCount: UILabel!
    @IBOutlet weak var lblNDPColor3: UILabel!
    @IBOutlet weak var lblNDPRejected: UILabel!
    @IBOutlet weak var lblNDPRejectedCount: UILabel!
    @IBOutlet weak var lblNDPColor4: UILabel!
    @IBOutlet weak var lblNDPReOpen: UILabel!
    @IBOutlet weak var lblNDPReOpenCount: UILabel!
    @IBOutlet weak var lblNDPTotalProject: UILabel!
    @IBOutlet weak var lblNDPTotalProjectCount: UILabel!
    @IBAction func btnNonDairyProductTap(_ sender: UIButton) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "ProjectDisplayVC") as! ProjectDisplayVC
        vc.strScreenTitle = "Non Dairy Product"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBOutlet weak var viewAddNewProject: UIView!
    @IBOutlet weak var btnAddNewProject: UIButton!
    @IBAction func btnAddNewProjectTap(_ sender: UIButton) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "AddNewProjectVC") as! AddNewProjectVC
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    
    
    
    
    
    
    // MARK: - Variables
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewBody.isHidden = false
        
        self.setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        
    }
    
    func setupView() {
        self.viewChart.backgroundColor = .white
        self.viewChart.corners(radius: 10)
        self.viewChart.addShadow(offset: .zero, color: .black, radius: 3, opacity: 0.50)
        
        self.viewDairyProduct.backgroundColor = .white
        self.viewDairyProduct.corners(radius: 10)
        self.viewDairyProduct.addShadow(offset: .zero, color: .black, radius: 3, opacity: 0.50)
        self.lblDPColor1.corners(radius: self.lblDPColor1.frame.width / 2)
        self.lblDPColor1.backgroundColor = .green
        self.lblDPColor2.corners(radius: self.lblDPColor2.frame.width / 2)
        self.lblDPColor2.backgroundColor = OrderStatus.pendingStatus.statusColor
        self.lblDPColor3.corners(radius: self.lblDPColor3.frame.width / 2)
        self.lblDPColor3.backgroundColor = Colors.themeRed.returnColor()
        self.lblDPColor4.corners(radius: self.lblDPColor4.frame.width / 2)
        self.lblDPColor4.backgroundColor = Colors.theme.returnColor()
        
        self.viewNonDairyProduct.backgroundColor = .white
        self.viewNonDairyProduct.corners(radius: 10)
        self.viewNonDairyProduct.addShadow(offset: .zero, color: .black, radius: 3, opacity: 0.50)
        self.lblNDPColor1.corners(radius: self.lblNDPColor1.frame.width / 2)
        self.lblNDPColor1.backgroundColor = .green
        self.lblNDPColor2.corners(radius: self.lblNDPColor2.frame.width / 2)
        self.lblNDPColor2.backgroundColor = OrderStatus.pendingStatus.statusColor
        self.lblNDPColor3.corners(radius: self.lblNDPColor3.frame.width / 2)
        self.lblNDPColor3.backgroundColor = Colors.themeRed.returnColor()
        self.lblNDPColor4.corners(radius: self.lblNDPColor4.frame.width / 2)
        self.lblNDPColor4.backgroundColor = Colors.theme.returnColor()
        
        self.viewAddNewProject.backgroundColor = .white
        self.btnAddNewProject.cornersWFullBorder(radius: 10, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        self.btnAddNewProject.setTitleColor(Colors.theme.returnColor(), for: .normal)
        
    }
    
    
}


extension CRMVC {
    
}
