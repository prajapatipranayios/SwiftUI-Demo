//
//  SPrincipalCompanyTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/11/24.
//

import UIKit

class SPrincipalCompanyTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblNo: UILabel!
    @IBOutlet weak var lblPrincipalCompanyTitle: UILabel!
    @IBOutlet weak var lblPrincipalCompany: UILabel!
    @IBOutlet weak var lblItemGroupTitle: UILabel!
    @IBOutlet weak var lblItemGroup: UILabel!
    
    @IBOutlet weak var btnDelete: UIButton!
    @IBAction func btnDeleteTap(_ sender: UIButton) {
        if self.onDeleteTap != nil {
            self.onDeleteTap?(self.index)
        }
    }
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onDeleteTap: ((Int)->Void)?
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
