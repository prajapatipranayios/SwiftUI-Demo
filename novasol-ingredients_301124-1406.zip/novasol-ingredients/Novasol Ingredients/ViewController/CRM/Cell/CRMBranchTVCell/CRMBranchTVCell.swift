//
//  CRMBranchTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 18/11/24.
//

import UIKit

class CRMBranchTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblBranchTitle: UILabel!
    @IBOutlet weak var btnSelect: UIButton!
    @IBAction func btnSelectTap(_ sender: UIButton) {
        if self.onBranchSelect != nil {
            self.onBranchSelect!(index)
        }
    }
    
    
    
    
    // MARK: - Variables
    
    var index: Int = 0
    var onBranchSelect:((Int)->Void)?
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
