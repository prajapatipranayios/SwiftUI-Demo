//
//  CRMBillingLocationTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 18/11/24.
//

import UIKit

class CRMBillingLocationTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblLocationTitle: UILabel!
    @IBOutlet weak var btnSelect: UIButton!
    @IBAction func btnSelectTap(_ sender: UIButton) {
        if self.onLocationSelect != nil {
            self.onLocationSelect!(index)
        }
    }
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var viewCompanyName: UIView!
    @IBOutlet weak var lblCompanyNameTitle: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    
    @IBOutlet weak var viewBlockNo: UIView!
    @IBOutlet weak var lblBlockNoTitle: UILabel!
    @IBOutlet weak var lblBlockNo: UILabel!
    
    @IBOutlet weak var viewBuildigFloorRoom: UIView!
    @IBOutlet weak var lblBuildigFloorRoomTitle: UILabel!
    @IBOutlet weak var lblBuildigFloorRoom: UILabel!
    
    @IBOutlet weak var viewStreetPOBox: UIView!
    @IBOutlet weak var lblStreetPOBoxTitle: UILabel!
    @IBOutlet weak var lblStreetPOBox: UILabel!
    
    @IBOutlet weak var viewZipCode: UIView!
    @IBOutlet weak var lblZipCodeTitle: UILabel!
    @IBOutlet weak var lblZipCode: UILabel!
    
    @IBOutlet weak var viewCity: UIView!
    @IBOutlet weak var lblCityTitle: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    
    
    
    
    // MARK: - Variables
    
    var index: Int = 0
    var onLocationSelect:((Int)->Void)?
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
