//
//  CRMBusinessPTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 16/11/24.
//

import UIKit

class CRMBusinessPTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var btnSelect: UIButton!
    @IBAction func btnSelectTap(_ sender: UIButton) {
        if self.onCompanySelect != nil {
            self.onCompanySelect!(index)
        }
    }
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var viewCompCity: UIView!
    @IBOutlet weak var lblCompCityTitle: UILabel!
    @IBOutlet weak var lblCompCity: UILabel!
    
    @IBOutlet weak var viewCompState: UIView!
    @IBOutlet weak var lblCompStateTitle: UILabel!
    @IBOutlet weak var lblCompState: UILabel!
    
    @IBOutlet weak var viewCompSalesEmp: UIView!
    @IBOutlet weak var lblCompSalesEmpTitle: UILabel!
    @IBOutlet weak var lblCompSalesEmp: UILabel!
    
    @IBOutlet weak var viewCompProjCategory: UIView!
    @IBOutlet weak var lblCompProjCategoryTitle: UILabel!
    @IBOutlet weak var lblCompProjCategory: UILabel!
    
    @IBOutlet weak var viewCompDateNTime: UIView!
    @IBOutlet weak var lblCompDateNTimeTitle: UILabel!
    @IBOutlet weak var lblCompDateNTime: UILabel!
    
    
    
    
    // MARK: - Variables
    
    var index: Int = 0
    var onCompanySelect:((Int)->Void)?
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
