//
//  DisplayProjectTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 22/11/24.
//

import UIKit

class DisplayProjectTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMainBorder: UIView!
    @IBOutlet weak var constraintTopViewMainBorder: NSLayoutConstraint!
    @IBOutlet weak var viewMainBorder1: UIView!
    
    @IBOutlet weak var lblProjectStatusColor: UILabel!
    @IBOutlet weak var lblProjectCompName: UILabel!
    @IBOutlet weak var lblProjectStatus: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblSalesEmpTitle: UILabel!
    @IBOutlet weak var lblSalesEmp: UILabel!
    @IBOutlet weak var btnInfo: UIButton!
    @IBAction func btnInfoTap(_ sender: UIButton) {
        if self.onSelect != nil {
            self.onSelect!(index)
        }
    }
    @IBOutlet weak var lblStartDate: UILabel!
    
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onSelect:((Int)->Void)?
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        //self.lblProjectStatusColor.clipsToBounds = true
        self.viewMain.clipsToBounds = true
        self.viewMainBorder.clipsToBounds = true
        self.viewMainBorder.corners(radius: 12.0)
        self.viewMainBorder1.corners(radius: 12.0)
        self.viewMainBorder1.addShadow()
        
        self.btnInfo.tintColor = Colors.themeRed.returnColor()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
