//
//  ANPProjectProductTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 29/11/24.
//

import UIKit

class ANPProjectProductTVCell: UITableViewCell {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblSectionTitle: UILabel!
    @IBOutlet weak var lblSaperatorTop: UILabel!
    @IBOutlet weak var lblSaperatorBottom: UILabel!
    
    @IBOutlet weak var btnExpand: UIButton!
    
    // MARK: - Variable
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.lblSaperatorTop.backgroundColor = Colors.separator.returnColor()
        self.lblSaperatorBottom.backgroundColor = Colors.separator.returnColor()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
