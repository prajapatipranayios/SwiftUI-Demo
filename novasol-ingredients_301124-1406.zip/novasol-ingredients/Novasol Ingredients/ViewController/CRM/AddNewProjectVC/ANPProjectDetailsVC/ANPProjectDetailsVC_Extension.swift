//
//  ANPProjectDetailsVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 26/11/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, DataSource
extension ANPProjectDetailsVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if (self.tvSelectedPrincipalCompany == tableView) || (self.tvSelectedProjectProductData == tableView) {
            return 1
        }
        else {
            if self.isCategoryData {
                return 1
            }
            else if self.isProductData {
                return self.arrSelectedPrincipalCompany?.count ?? 0
            }
            else if self.isSelectProduct {
                return self.arrProductCategories?.count ?? 0
            }
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if self.tvDisplayData == tableView {
            if self.isCategoryData {
                return ""
            }
            else if self.isProductData {
                return self.arrSelectedPrincipalCompany?[section].name ?? ""
            }
            return ""
        }
        return ""
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if self.tvDisplayData == tableView {
            if self.isCategoryData {
                return 0
            }
            else if self.isProductData {
                return 30
            }
            return 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.tvDisplayData == tableView {
            if self.isCategoryData {
                return self.arrPrincipalCompany?.count ?? 0
            }
            else if self.isProductData {
                return self.arrSelectedPrincipalCompany?[section].itemGroup?.count ?? 0
            }
            else {
                //return (self.arrSelectedProductCategories?[section].children?.count ?? 0) + 1
                
                let section = self.arrProductCategories?[section]
                
                if section?.isOpened ?? false {
                    return (section?.children?.count ?? 0) + 1
                }
                else {
                    return 1
                }
            }
        }
        else if self.tvSelectedPrincipalCompany == tableView {
            return self.arrSelectedPrincipalCompany?.count ?? 0
        }
        else if self.tvSelectedProjectProductData == tableView {
            return self.arrSelectedProductCategories?.count ?? 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if self.tvDisplayData == tableView {
            
            if self.isSelectProduct {
                
                if indexPath.row == 0 {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "ANPProjectProductTVCell", for: indexPath) as! ANPProjectProductTVCell
                    
                    cell.lblSectionTitle.text = self.arrProductCategories?[indexPath.section].name ?? ""
                    
                    cell.btnExpand.tintColor = Colors.theme.returnColor()
                    cell.btnExpand.isSelected = self.arrProductCategories?[indexPath.section].isOpened ?? false
                    
                    cell.lblSaperatorBottom.isHidden = true
                    if indexPath.section == ((self.arrProductCategories?.count ?? 0) - 1) {
                        cell.lblSaperatorBottom.isHidden = (self.arrProductCategories?[indexPath.section].isOpened ?? false)
                    }
                    
                    return cell
                }
                else {
                    let cell = tableView.dequeueReusableCell(withIdentifier: ANPProjectDetailsVC.cellIdentifire1, for: indexPath) as! TransportTVCell
//                    
                    cell.section = indexPath.section
                    cell.index = indexPath.row
                    cell.btnSelect1.isHidden = true
                    cell.btnSelect.isSelected = false
                    
                    cell.lblName.text = self.arrProductCategories?[indexPath.section].children?[indexPath.row - 1].name ?? ""
                    
                    let value = self.arrProductCategories?[indexPath.section].children?[indexPath.row - 1]
                    if (self.arrSelectedProductCategories?.count ?? 0) > 0{
                        let value2 = self.arrSelectedProductCategories?[0]
                        if (value?.id ?? 0) == (value2?.children?[0].id ?? 0) {
                            cell.btnSelect.isSelected = true
                        }
                    }
                    
                    cell.didSelect = { section, index in
                        self.arrSelectedProductCategories?.removeAll()
                        self.arrSelectedProductCategories?.append((self.arrProductCategories?[section])!)
                        self.arrSelectedProductCategories?[0].children?.removeAll()
                        self.arrSelectedProductCategories?[0].children?.append((self.arrProductCategories?[section].children?[index - 1])!)
                        //self.tvDisplayData.reloadSections([section], with: .none)
                        self.tvDisplayData.reloadData()
                    }
                    return cell
                }
            }
            else {
                let cell = tableView.dequeueReusableCell(withIdentifier: ANPProjectDetailsVC.cellIdentifire1, for: indexPath) as! TransportTVCell
                
                cell.section = indexPath.section
                cell.index = indexPath.row
                cell.btnSelect1.isHidden = true
                
                if self.isCategoryData {
                    cell.lblName.text = self.arrPrincipalCompany?[indexPath.row].name ?? ""
                }
                else if self.isProductData {
                    cell.lblName.text = self.arrSelectedPrincipalCompany?[indexPath.section].itemGroup?[indexPath.row] ?? ""
                }
                
                cell.btnSelect.isSelected = false
                //let tempObj = self.arrSelectedPrincipalCompany?.filter({ $0.name == (self.arrPrincipalCompany?[indexPath.row].name ?? "") })
                if self.isCategoryData {
                    if let index = self.arrSelectedPrincipalCompany?.firstIndex(where: { $0.name == (self.arrPrincipalCompany?[indexPath.row].name ?? "") }) {
                        // Remove the company at the found index
                        cell.btnSelect.isSelected = true
                        
                        self.btnSelectProductDetailsNext.isEnabled = true
                        self.btnSelectProductDetailsNext.backgroundColor = Colors.theme.returnColor()
                    }
                }
                else if self.isProductData {
                    if (self.arrSelectedPrincipalCompany?[indexPath.section].itemGroup?[indexPath.row] ?? "") == self.dictSelectedProduct?[self.arrSelectedPrincipalCompany?[indexPath.section].name ?? ""] {
                        cell.btnSelect.isSelected = true
                    }
                }
                
                cell.didSelect = { section, index in
                    
                    if self.isCategoryData {
                        print("Selected value -> \(self.arrPrincipalCompany?[index].name ?? "")")
                        
                        // Find the index of the "Monkfruit" company
                        if let index = self.arrSelectedPrincipalCompany?.firstIndex(where: { $0.name == (self.arrPrincipalCompany?[index].name ?? "") }) {
                            // Remove the company at the found index
                            self.arrSelectedPrincipalCompany?.remove(at: index)
                        }
                        else {
                            self.arrSelectedPrincipalCompany?.append(self.arrPrincipalCompany![index])
                        }
                        //                if !(self.arrSelectedPrincipalCompany?.isEmpty ?? false) {
                        //                    self.btnSelectProductDetailsNext.isEnabled = true
                        //                    self.btnSelectProductDetailsNext.backgroundColor = Colors.theme.returnColor()
                        //                }
                    }
                    else if self.isProductData {
                        print("Selected value -> \(self.arrSelectedPrincipalCompany?[section].itemGroup?[index] ?? "")")
                        self.dictSelectedProduct?[self.arrSelectedPrincipalCompany?[section].name ?? ""] = self.arrSelectedPrincipalCompany?[section].itemGroup?[index] ?? ""
                    }
                    
                    self.tvDisplayData.reloadData()
                }
                
                return cell
            }
        }
        else if self.tvSelectedPrincipalCompany == tableView {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "SPrincipalCompanyTVCell", for: indexPath) as! SPrincipalCompanyTVCell
            
            cell.index = indexPath.row
            
            cell.lblNo.text = "\(indexPath.row + 1)."
            
            cell.lblPrincipalCompanyTitle.text = "Principal Company"
            cell.lblItemGroupTitle.text = "Item Group"
            
            cell.lblPrincipalCompany.text = self.arrSelectedPrincipalCompany?[indexPath.row].name ?? ""
            cell.lblItemGroup.text = self.dictSelectedProduct?[self.arrSelectedPrincipalCompany?[indexPath.row].name ?? ""]
            
            cell.onDeleteTap = { index in
                
                self.dictSelectedProduct?.removeValue(forKey: self.arrSelectedPrincipalCompany?[index].name ?? "")
                self.arrSelectedPrincipalCompany?.remove(at: index)
                self.tvSelectedPrincipalCompany.reloadData()
                self.constraintHeightTVSPrincipalCompany.constant = CGFloat((self.arrSelectedPrincipalCompany?.count ?? 0) * 78)
                
                if self.arrSelectedPrincipalCompany?.count ?? 0 < 1 {
                    self.constraintBottomViewSPrincipalCompany.priority = .defaultLow
                    self.btnPrincipalCompanyEdit.isHidden = true
                    self.btnPrincipalCompanyEdit1.isHidden = false
                }
            }
            
            return cell
        }
        else if self.tvSelectedProjectProductData == tableView {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "SPrincipalCompanyTVCell", for: indexPath) as! SPrincipalCompanyTVCell
            
            cell.index = indexPath.row
            
            cell.lblNo.text = "\(indexPath.row + 1)."
            
            cell.lblPrincipalCompanyTitle.text = "Product Name"
            cell.lblItemGroupTitle.text = "Category"
            
            cell.lblPrincipalCompany.text = self.arrSelectedProductCategories?[indexPath.row].name ?? ""
            cell.lblItemGroup.text = self.arrSelectedProductCategories?[indexPath.row].children?[0].name ?? ""
            
            cell.onDeleteTap = { index in
                
                self.arrSelectedProductCategories?.removeAll()
                
                if self.arrSelectedProductCategories?.count ?? 0 < 1 {
                    self.constraintBottomViewSProduct.priority = .defaultLow
                    self.btnProductEdit.isHidden = true
                    self.btnProductEdit1.isHidden = false
                }
            }
            
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.isSelectProduct {
            if indexPath.row == 0 {
                tableView.deselectRow(at: indexPath, animated: false)
                let isActive = !(self.arrProductCategories?[indexPath.section].isOpened ?? false)
                self.arrProductCategories?[indexPath.section].isOpened = isActive
                tableView.reloadSections([indexPath.section], with: .none)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.tvDisplayData == tableView {
            return 40
        }
        else {
            return 78
        }
    }
    
}


// MARK: - Keyboard

extension ANPProjectDetailsVC {
    
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomViewBodyToSuper.constant = keyboardOverlap > 0 ? (keyboardOverlap - 0) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}


// MARK: - Weeb Service

extension ANPProjectDetailsVC {
    
    func getPrincipalCompanyGroupDetails() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getPrincipalCompanyGroupDetails()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_PRINCIPAL_COMPANY_AND_GROUP_DETAILS, parameters: param) { (response: ApiResponseCRM?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrPrincipalCompany = response?.result?.principalCompany ?? []
                    self.isCategoryData = true
                    self.tvDisplayData.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getProjectProduct(type: String = "dairy", search: String = "") {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getProjectProduct(type: type, search: search)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "type": type,
            "search": search
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_PROJECT_PRODUCT, parameters: param) { (response: ApiResponseCRM?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //self.arrProductCategories = response?.result?.productCategories ?? []
                    self.tvDisplayData.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
}
