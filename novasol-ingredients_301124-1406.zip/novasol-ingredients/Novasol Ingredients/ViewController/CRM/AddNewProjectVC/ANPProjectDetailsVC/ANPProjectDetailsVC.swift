//
//  ANPProjectDetailsVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 26/11/24.
//

import UIKit


class ANPProjectDetailsVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    @IBOutlet weak var btnInfo: UIButton!
    @IBAction func btnInfoTap(_ sender: UIButton) {
    }
    
    
    /// Project Details.
    
    @IBOutlet weak var viewANPProjectDetails: UIView!
    
    @IBOutlet weak var viewProjectProcess: UIView!
    @IBOutlet weak var lblProjectProcess: UILabel!
    
    @IBOutlet weak var viewANPProjectDetailsBack: UIView!
    @IBOutlet weak var btnANPProjectDetailsBack: UIButton!
    @IBAction func btnANPClientDetails1BackTap(_ sender: UIButton) {
        //self.viewAddNProject1.isHidden = false
        //self.viewANPClientDetails1.isHidden = true
        //self.viewSelectBP.isHidden = true
        
        self.addNewProjectVC!().setProjectDetails(strValue: "ASADFG")
        self.addNewProjectVC!().isProjectDetailSet = true
        self.navigationController?.popViewController(animated: false)
    }
    @IBOutlet weak var lblANPProjectDetailsTitle: UILabel!
    
    
    @IBOutlet weak var viewProjectType: UIView!
    @IBOutlet weak var constraintHeightViewProjectType: NSLayoutConstraint!
    @IBOutlet weak var viewProjectTypeBorder: UIView!
    @IBOutlet weak var lblProjectType: UILabel!
    @IBOutlet weak var viewType1: UIView!
    @IBOutlet weak var btnProjectType1: UIButton!
    @IBAction func btnProjectType1Tap(_ sender: UIButton) {
        self.btnProjectType1.isSelected = true
        self.btnProjectType2.isSelected = false
        self.strProjectType = "dairy"
    }
    @IBOutlet weak var viewType2: UIView!
    @IBOutlet weak var btnProjectType2: UIButton!
    @IBAction func btnProjectType2Tap(_ sender: UIButton) {
        self.btnProjectType1.isSelected = false
        self.btnProjectType2.isSelected = true
        self.strProjectType = "non-dairy"
    }
    
    
    @IBOutlet weak var viewPrincipalCompany: UIView!
    @IBOutlet weak var viewPrincipalCompanyBorder: UIView!
    @IBOutlet weak var lblPrincipalCompany: UILabel!
    
    @IBOutlet weak var viewSPrincipalCompany: UIView!
    @IBOutlet weak var constraintBottomViewSPrincipalCompany: NSLayoutConstraint!
    @IBOutlet weak var tvSelectedPrincipalCompany: UITableView! {
        didSet {
            self.tvSelectedPrincipalCompany.delegate = self
            self.tvSelectedPrincipalCompany.dataSource = self
            self.tvSelectedPrincipalCompany.register(UINib(nibName: "SPrincipalCompanyTVCell", bundle: nil), forCellReuseIdentifier: "SPrincipalCompanyTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVSPrincipalCompany: NSLayoutConstraint!
    
    @IBOutlet weak var btnPrincipalCompanyEdit: UIButton!
    @IBAction func btnPrincipalCompanyEditTap(_ sender: UIButton) {
        
        self.viewANPProjectDetails.isHidden = true
        self.viewSelectOption.isHidden = false
        self.viewSelectProjectRequirement.isHidden = true
        
        self.btnSelectOptionAdd.isHidden = true
        
        self.getPrincipalCompanyGroupDetails()
    }
    @IBOutlet weak var ivPrincipalCompany: UIImageView!
    @IBOutlet weak var btnPrincipalCompanyEdit1: UIButton!
    @IBAction func btnPrincipalCompanyEdit1Tap(_ sender: UIButton) {
        
        self.viewANPProjectDetails.isHidden = true
        self.viewSelectOption.isHidden = false
        self.viewSelectProjectRequirement.isHidden = true
        
        self.btnSelectOptionAdd.isHidden = true
        
        self.getPrincipalCompanyGroupDetails()
    }
    
    
    @IBOutlet weak var viewProjectRequirement: UIView!
    @IBOutlet weak var viewProjectRequirementBorder: UIView!
    @IBOutlet weak var lblProjectRequirement: UILabel!
    
    @IBOutlet weak var viewSProjectRequirement: UIView!
    @IBOutlet weak var constraintBottomViewSProjectRequirement: NSLayoutConstraint!
    
    @IBOutlet weak var ivSelectedProjectRequirement: UIImageView!
    @IBOutlet weak var lblSelectedProjectRequirement: UILabel!
    
    @IBOutlet weak var btnProjectRequirementEdit: UIButton!
    @IBAction func btnProjectRequirementEditTap(_ sender: UIButton) {
        
        self.selectProductRequirement()
    }
    @IBOutlet weak var ivProjectRequirement: UIImageView!
    @IBOutlet weak var btnProjectRequirementEdit1: UIButton!
    @IBAction func btnProjectRequirementEdit1Tap(_ sender: UIButton) {
        
        self.selectProductRequirement()
    }
    
    
    
    @IBOutlet weak var viewProduct: UIView!
    @IBOutlet weak var viewProductBorder: UIView!
    @IBOutlet weak var lblProduct: UILabel!
    
    @IBOutlet weak var viewSProduct: UIView!
    @IBOutlet weak var constraintBottomViewSProduct: NSLayoutConstraint!
    @IBOutlet weak var tvSelectedProjectProductData: UITableView! {
        didSet {
            self.tvSelectedProjectProductData.delegate = self
            self.tvSelectedProjectProductData.dataSource = self
            self.tvSelectedProjectProductData.register(UINib(nibName: "SPrincipalCompanyTVCell", bundle: nil), forCellReuseIdentifier: "SPrincipalCompanyTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVSProjectProductData: NSLayoutConstraint!
    
    @IBOutlet weak var btnProductEdit: UIButton!
    @IBAction func btnProductEditTap(_ sender: UIButton) {
        
        // Select Business Partner
        //self.selectBusinessPartner()
        
        self.viewANPProjectDetails.isHidden = true
        self.viewSelectOption.isHidden = false
        self.viewSelectProjectRequirement.isHidden = true
    }
    @IBOutlet weak var ivProduct: UIImageView!
    @IBOutlet weak var btnProductEdit1: UIButton!
    @IBAction func btnProductEdit1Tap(_ sender: UIButton) {
        
        self.arrProductCategories = [
            ProductCategory(
                id: 1,
                parentId: nil,
                name: "Fermented Milk",
                type: "dairy",
                createdAt: "2024-02-29 11:51:10",
                updatedAt: "2024-02-29 11:51:10",
                children: [
                    ProductCategory(
                        id: 2,
                        parentId: 1,
                        name: "Curd",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 3,
                        parentId: 1,
                        name: "Butter Milk",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 4,
                        parentId: 1,
                        name: "Lassi",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 5,
                        parentId: 1,
                        name: "Shrikhand",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 6,
                        parentId: 1,
                        name: "Yoghurt",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 7,
                        parentId: 1,
                        name: "Drinking yoghurt",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 8,
                        parentId: 1,
                        name: "Mishti Doi",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                ],
                isOpened: false),
            ProductCategory(
                id: 9,
                parentId: nil,
                name: "Non Fermented Milk",
                type: "dairy",
                createdAt: "2024-02-29 11:51:10",
                updatedAt: "2024-02-29 11:51:10",
                children: [
                    ProductCategory(
                        id: 10,
                        parentId: 9,
                        name: "Flavour Milk",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 11,
                        parentId: 9,
                        name: "Milk Shake",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 12,
                        parentId: 9,
                        name: "High Protein Milk Shake",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 13,
                        parentId: 9,
                        name: "Pourable Custard",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 14,
                        parentId: 9,
                        name: "Cooking Cream",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 15,
                        parentId: 9,
                        name: "Whipping Cream",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 16,
                        parentId: 9,
                        name: "Breakfast cereal drink",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                ],
                isOpened: false),
            ProductCategory(
                id: 17,
                parentId: nil,
                name: "Ice Cream & Frozen Desert",
                type: "dairy",
                createdAt: "2024-02-29 11:51:10",
                updatedAt: "2024-02-29 11:51:10",
                children: [
                    ProductCategory(
                        id: 18,
                        parentId: 17,
                        name: "Ice cream -High Fat,Low Fat,Medium Fat",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 19,
                        parentId: 17,
                        name: "Frozen Desert-High Fat,Low Fat,Medium Fat",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 20,
                        parentId: 17,
                        name: "Kulfi",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 21,
                        parentId: 17,
                        name: "Ice Lolly",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 22,
                        parentId: 17,
                        name: "Sorbet",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 23,
                        parentId: 17,
                        name: "High protein Ice Cram",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 24,
                        parentId: 17,
                        name: "Nutraceutical Ice cream",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                ],
                isOpened: false),
            ProductCategory(
                id: 25,
                parentId: nil,
                name: "Cheese/Analog Cheese",
                type: "dairy",
                createdAt: "2024-02-29 11:51:10",
                updatedAt: "2024-02-29 11:51:10",
                children: [
                    ProductCategory(
                        id: 26,
                        parentId: 25,
                        name: "Processed Cheese",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 27,
                        parentId: 25,
                        name: "Mozzarella Cheese",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 28,
                        parentId: 25,
                        name: "Cheddar Cheese",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 29,
                        parentId: 25,
                        name: "Block Cheese",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10"),
                    ProductCategory(
                        id: 30,
                        parentId: 25,
                        name: "Analog Cheese",
                        type: "dairy",
                        createdAt: "2024-02-29 11:51:10",
                        updatedAt: "2024-02-29 11:51:10")
                ],
                isOpened: false)
        ]
        
        self.viewANPProjectDetails.isHidden = true
        self.viewSelectOption.isHidden = false
        self.viewSelectProjectRequirement.isHidden = true
        
        self.constraintHeightSearchBar.constant = 0
        self.btnSelectOptionAdd.isHidden = true
        
        self.isSelectProduct = true
        self.isCategoryData = false
        self.isProductData = false
        
        self.tvDisplayData.reloadData()
        
        //self.getProjectProduct()
    }
    
    @IBOutlet weak var btnSelectNextProjectDetails: UIButton!
    @IBAction func btnSelectNextProjectDetailsTap(_ sender: UIButton) {
        self.addNewProjectVC!().setProjectDetails(strValue: "ASADFG asd sdf sdf sdf sdf l")
    }
    
    
    
    /// Select Business Partner, Location, Branch
    
    static let cellIdentifire1: String = "TransportTVCell"
    
    @IBOutlet weak var viewSelectOption: UIView!
    @IBOutlet weak var viewSelectOptionBack: UIView!
    @IBOutlet weak var btnSelectBPBack: UIButton!
    @IBAction func btnSelectBPBackTap(_ sender: UIButton) {
        if self.isCategoryData && self.isSelectProduct {
            self.viewANPProjectDetails.isHidden = false
            self.viewSelectOption.isHidden = true
            self.viewSelectProjectRequirement.isHidden = true
        }
        else if self.isProductData {
            self.viewANPProjectDetails.isHidden = true
            self.viewSelectOption.isHidden = false
            self.viewSelectProjectRequirement.isHidden = true
            
            self.btnSelectOptionAdd.isHidden = true
            self.isCategoryData = true
            self.isProductData = false
            
            self.getPrincipalCompanyGroupDetails()
        }
    }
    @IBOutlet weak var btnSelectOptionAdd: UIButton!
    @IBAction func btnSelectOptionAddTap(_ sender: UIButton) {
        
    }
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var constraintHeightSearchBar: NSLayoutConstraint!
    
    @IBOutlet weak var tvDisplayData: UITableView! {
        didSet {
            self.tvDisplayData.delegate = self
            self.tvDisplayData.dataSource = self
            self.tvDisplayData.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
            self.tvDisplayData.register(UINib(nibName: ANPProjectDetailsVC.cellIdentifire1, bundle: nil), forCellReuseIdentifier: ANPProjectDetailsVC.cellIdentifire1)
            self.tvDisplayData.register(UINib(nibName: "ANPProjectProductTVCell", bundle: nil), forCellReuseIdentifier: "ANPProjectProductTVCell")
        }
    }
    
    @IBOutlet weak var btnSelectProductDetailsNext: UIButton!
    @IBAction func btnSelectProductDetailsNextTap(_ sender: UIButton) {
        
        if self.isCategoryData {
            
            self.isCategoryData = false
            self.isProductData = true
            
            self.constraintHeightSearchBar.constant = 0
            
            //self.dictSelectedProduct?.removeAll()
            
            for value in (self.arrSelectedPrincipalCompany ?? []).enumerated() {
                
                if let value1 = self.dictSelectedProduct?[value.element.name ?? ""] {
                    print("Selected value --> \(value1)")
                }
                else {
                    self.dictSelectedProduct?[value.element.name ?? ""] = ""
                }
            }
            
            self.tvDisplayData.reloadData()
        }
        else if self.isProductData  {
            var isValid: Bool = true
            for value in (self.arrSelectedPrincipalCompany ?? []).enumerated() {
                if self.dictSelectedProduct?[value.element.name ?? ""] == "" {
                    isValid = false
                }
                
                if !isValid {
                    break
                }
            }
            
            if isValid {
                print("All product selected.")
                
                self.viewANPProjectDetails.isHidden = false
                self.viewSelectOption.isHidden = true
                self.viewSelectProjectRequirement.isHidden = true
                
                self.constraintHeightTVSPrincipalCompany.constant = CGFloat((self.arrSelectedPrincipalCompany?.count ?? 0) * 78)
                self.tvSelectedPrincipalCompany.reloadData()
                
                self.btnPrincipalCompanyEdit.isHidden = false
                self.btnPrincipalCompanyEdit1.isHidden = true
                self.constraintBottomViewSPrincipalCompany.priority = .required
                
                
                self.viewProjectRequirementBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
                self.lblProjectRequirement.textColor = Colors.theme.returnColor()
                self.btnProjectRequirementEdit1.isEnabled = true
                
                self.isSelectedPrincipalCompany = true
                
                self.checkProjectDetailSelected()
            }
            else {
                print("Please select product.")
                Utilities.showPopup(title: "Please select product.", type: .error)
            }
        }
        else if self.isSelectProduct {
            
            self.isSelectProduct = false
            
            self.viewANPProjectDetails.isHidden = false
            self.viewSelectOption.isHidden = true
            self.viewSelectProjectRequirement.isHidden = true
            
            self.btnProductEdit.isHidden = false
            self.btnProductEdit1.isHidden = true
            
            self.isSelectedProduct = true
            
            self.constraintHeightTVSProjectProductData.constant = CGFloat((self.arrSelectedProductCategories?.count ?? 0) * 78)
            
            self.constraintBottomViewSProduct.priority = .required
            
            self.tvSelectedProjectProductData.reloadData()
        }
        
        self.setUpAllDetail()
    }
    
    
    
    /// Project Requirement
    
    @IBOutlet weak var viewSelectProjectRequirement: UIView!
    @IBOutlet weak var viewSelectProjectRequirementBack: UIView!
    @IBOutlet weak var btnSelectProjectRequirementBack: UIButton!
    @IBAction func btnSelectProjectRequirementBackTap(_ sender: UIButton) {
        self.viewANPProjectDetails.isHidden = false
        self.viewSelectOption.isHidden = true
        self.viewSelectProjectRequirement.isHidden = true
    }
    
    @IBOutlet weak var viewSelectNewProjectDev: UIView!
    @IBOutlet weak var viewSelectNewProjectDevBorder: UIView!
    @IBOutlet weak var ivNewProjectDev: UIImageView!
    @IBOutlet weak var lblNewProjectDev: UILabel!
    @IBOutlet weak var btnSelectNewProductDev: UIButton!
    @IBAction func btnSelectNewProductDevTap(_ sender: UIButton) {
        self.viewSelectNewProjectDevBorder.backgroundColor = .white
        self.viewSelectNewProjectDevBorder.cornersWFullBorder(radius: 15, borderColor: Colors.theme.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        self.ivNewProjectDev.tintColor = Colors.theme.returnColor()
        
        self.viewSelectTechSupportBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectTechSupportBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        self.ivTechSupport.tintColor = Colors.gray.returnColor()
        
        self.viewSelectPrototypeSampleBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectPrototypeSampleBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        self.ivPrototypeSample.tintColor = Colors.gray.returnColor()
        
        self.isNewProductDev = true
        self.isTechSupport = false
        self.isPrototypeSample = false
        self.strRequirementImage = "NewProductDev"
        self.strRequirementText = "New Product Development"
    }
    
    @IBOutlet weak var viewSelectTechSupport: UIView!
    @IBOutlet weak var viewSelectTechSupportBorder: UIView!
    @IBOutlet weak var ivTechSupport: UIImageView!
    @IBOutlet weak var lblTechSupport: UILabel!
    @IBOutlet weak var btnSelectTechSupport: UIButton!
    @IBAction func btnSelectTechSupportTap(_ sender: UIButton) {
        self.viewSelectNewProjectDevBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectNewProjectDevBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectNewProjectDevBorder.addShadow()
        self.ivNewProjectDev.tintColor = Colors.gray.returnColor()
        
        self.viewSelectTechSupportBorder.backgroundColor = .white
        self.viewSelectTechSupportBorder.cornersWFullBorder(radius: 15, borderColor: Colors.theme.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectTechSupportBorder.addShadow()
        self.ivTechSupport.tintColor = Colors.theme.returnColor()
        
        self.viewSelectPrototypeSampleBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectPrototypeSampleBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectPrototypeSampleBorder.addShadow()
        self.ivPrototypeSample.tintColor = Colors.gray.returnColor()
        
        self.isNewProductDev = false
        self.isTechSupport = true
        self.isPrototypeSample = false
        self.strRequirementImage = "TechSupport"
        self.strRequirementText = "Technical Support"
    }
    
    @IBOutlet weak var viewSelectPrototypeSample: UIView!
    @IBOutlet weak var viewSelectPrototypeSampleBorder: UIView!
    @IBOutlet weak var ivPrototypeSample: UIImageView!
    @IBOutlet weak var lblPrototypeSample: UILabel!
    @IBOutlet weak var btnSelectPrototypeSample: UIButton!
    @IBAction func btnSelectPrototypeSampleTap(_ sender: UIButton) {
        self.viewSelectNewProjectDevBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectNewProjectDevBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectNewProjectDevBorder.addShadow()
        self.ivNewProjectDev.tintColor = Colors.gray.returnColor()
        
        self.viewSelectTechSupportBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectTechSupportBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectTechSupportBorder.addShadow()
        self.ivTechSupport.tintColor = Colors.gray.returnColor()
        
        self.viewSelectPrototypeSampleBorder.backgroundColor = .white
        self.viewSelectPrototypeSampleBorder.cornersWFullBorder(radius: 15, borderColor: Colors.theme.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectPrototypeSampleBorder.addShadow()
        self.ivPrototypeSample.tintColor = Colors.theme.returnColor()
        
        self.isNewProductDev = false
        self.isTechSupport = false
        self.isPrototypeSample = true
        self.strRequirementImage = "PrototypeSample"
        self.strRequirementText = "Prototype Sample"
    }
    
    @IBOutlet weak var btnSelectProjectRequirementNext: UIButton!
    @IBAction func btnSelectSelectProjectRequirementNextTap(_ sender: UIButton) {
        
        self.ivSelectedProjectRequirement.image = UIImage(named: self.strRequirementImage)
        self.lblSelectedProjectRequirement.text = self.strRequirementText
        
        self.viewANPProjectDetails.isHidden = false
        self.viewSelectOption.isHidden = true
        self.viewSelectProjectRequirement.isHidden = true
        
        self.constraintBottomViewSProjectRequirement.priority = .required
        self.btnProjectRequirementEdit.isHidden = false
        self.btnProjectRequirementEdit1.isHidden = true
        
        self.viewProductBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        self.lblProduct.textColor = Colors.theme.returnColor()
        self.btnProductEdit1.isEnabled = true
        
        self.isSelectedProjectedRequirement = true
        
        self.checkProjectDetailSelected()
    }
    
    
    
    
    
    
    
    
    // MARK: - Variable
    
    var onBack: ((Int)->Void)?
    var onOk: ((Int)->Void)?
    
    
    var addNewProjectVC: (()->AddNewProjectVC)?
    
    var isSelectedProjectType: Bool = false
    
    var isSelectedPrincipalCompany: Bool = false
    var isSelectedProjectedRequirement: Bool = false
    var isSelectedProduct: Bool = false
    
    
    var strProjectType: String = "dairy"
    
    
    var arrPrincipalCompany: [PrincipalCompany]?
    var arrSelectedPrincipalCompany: [PrincipalCompany]? = []
    var dictSelectedProduct: [String: String]? = [:]
    var isCategoryData: Bool = false
    var isProductData: Bool = false
    var isSearchActive: Bool = false
    
    
    var isNewProductDev: Bool = false
    var isTechSupport: Bool = false
    var isPrototypeSample: Bool = false
    var strRequirementImage: String = ""
    var strRequirementText: String = ""
    
    
    
    var arrProductCategories: [ProductCategory]?
    var arrSelectedProductCategories: [ProductCategory]? = []
    var isSelectProduct: Bool = false
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewANPProjectDetails.isHidden = false
        self.viewSelectOption.isHidden = true
        self.viewSelectProjectRequirement.isHidden = true
        
        
        
        self.constraintBottomViewSPrincipalCompany.priority = .defaultLow
        self.constraintBottomViewSProjectRequirement.priority = .defaultLow
        self.constraintBottomViewSProduct.priority = .defaultLow
        
        self.viewProjectTypeBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        self.lblProjectType.textColor = Colors.theme.returnColor()
        
        self.btnProjectType1.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.isSelectedProjectType = true
        self.btnProjectType1.isSelected = self.isSelectedProjectType
        
        self.viewPrincipalCompanyBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        self.lblPrincipalCompany.textColor = Colors.theme.returnColor()
        self.btnPrincipalCompanyEdit.isHidden = true
        
        self.viewProjectRequirementBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblProjectRequirement.textColor = Colors.gray.returnColor()
        self.btnProjectRequirementEdit.isHidden = true
        self.btnProjectRequirementEdit1.isEnabled = false
        self.viewSProjectRequirement.corners(radius: 12)
        
        self.viewProductBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblProduct.textColor = Colors.gray.returnColor()
        self.btnProductEdit.isHidden = true
        self.btnProductEdit1.isEnabled = false
        
        
        
        self.viewSelectOption.isHidden = true
        
        self.viewSelectNewProjectDevBorder.backgroundColor = .white
        self.viewSelectNewProjectDevBorder.cornersWFullBorder(radius: 15, borderColor: Colors.theme.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectNewProjectDevBorder.addShadow()
        self.ivNewProjectDev.tintColor = Colors.theme.returnColor()
        
        self.viewSelectTechSupportBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectTechSupportBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectTechSupportBorder.addShadow()
        self.ivTechSupport.tintColor = Colors.gray.returnColor()
        
        self.viewSelectPrototypeSampleBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectPrototypeSampleBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectPrototypeSampleBorder.addShadow()
        self.ivPrototypeSample.tintColor = Colors.gray.returnColor()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        let strValue = self.lblProjectProcess.text ?? ""
        self.lblProjectProcess.attributedText = strValue.setColorToString(strValue: ["Project Details"], color: [Colors.theme.returnColor()], fontSize: 19)
        
        
        self.addNewProjectVC!().setProjectDetails(strValue: "ASADFG")
    }
    
}


extension ANPProjectDetailsVC {
    
    func setUpAllDetail() {
        
        if self.isSelectedPrincipalCompany && self.isSelectedProjectedRequirement && self.isSelectedProduct {
            print("All data set.")
        }
        else {
            print("All data not set.")
        }
        
    }
    
    func selectProductRequirement() {
        
        if !self.isSelectedProjectedRequirement {
            self.isNewProductDev = true
            self.isTechSupport = false
            self.isPrototypeSample = false
            self.strRequirementImage = "NewProductDev"
            self.strRequirementText = "New Product Development"
        }
        self.viewANPProjectDetails.isHidden = true
        self.viewSelectOption.isHidden = true
        self.viewSelectProjectRequirement.isHidden = false
        
        self.btnSelectProjectRequirementNext.isEnabled = true
        self.btnSelectProjectRequirementNext.backgroundColor = Colors.theme.returnColor()
    }
    
    func checkProjectDetailSelected() {
        
        var isValid: Bool = true
        
        if !self.isSelectedPrincipalCompany {
            isValid = false
        }
        else if !self.isSelectedProjectedRequirement {
            isValid = false
        }
        else if !self.isSelectedProduct {
            isValid = false
        }
        
        if isValid {
            
        }
        else {
            print("All value selected ---> \(isValid)")
        }
        
    }
    
}


