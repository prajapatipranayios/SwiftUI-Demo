//
//  ANPTechInformationVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 30/11/24.
//

import UIKit

class ANPTechInformationVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    @IBOutlet weak var btnInfo: UIButton!
    @IBAction func btnInfoTap(_ sender: UIButton) {
    }
    
    
    /// Project Details.
    
    @IBOutlet weak var viewANPTechInformation: UIView!
    
    @IBOutlet weak var viewProjectProcess: UIView!
    @IBOutlet weak var lblProjectProcess: UILabel!
    
    @IBOutlet weak var viewANPTechInformationBack: UIView!
    @IBOutlet weak var btnANPTechInformationBack: UIButton!
    @IBAction func btnANPTechInformationBackTap(_ sender: UIButton) {
        //self.viewAddNProject1.isHidden = false
        //self.viewANPClientDetails1.isHidden = true
        //self.viewSelectBP.isHidden = true
        
        self.addNewProjectVC!().setProjectDetails(strValue: "ASADFG")
        self.addNewProjectVC!().isProjectDetailSet = true
        self.navigationController?.popViewController(animated: false)
    }
    @IBOutlet weak var lblANPTechInformationTitle: UILabel!
    
    
    @IBOutlet weak var viewTechProcess: UIView!
    @IBOutlet weak var viewTechProcessBorder: UIView!
    @IBOutlet weak var lblTechProcess: UILabel!
    
    @IBOutlet weak var viewSTechProcess: UIView!
    @IBOutlet weak var constraintBottomViewSTechProcess: NSLayoutConstraint!
    
    @IBOutlet weak var btnTechProcessEdit: UIButton!
    @IBAction func btnTechProcessEditTap(_ sender: UIButton) {
        
        self.viewANPTechInformation.isHidden = true
        self.viewSelectOption.isHidden = false
        self.viewSelectProjectRequirement.isHidden = true
        
        self.btnSelectOptionAdd.isHidden = true
        
        //self.getPrincipalCompanyGroupDetails()
    }
    @IBOutlet weak var ivTechProcess: UIImageView!
    @IBOutlet weak var btnTechProcessEdit1: UIButton!
    @IBAction func btnTechProcessEdit1Tap(_ sender: UIButton) {
        
        self.viewANPTechInformation.isHidden = true
        self.viewSelectOption.isHidden = false
        self.viewSelectProjectRequirement.isHidden = true
        
        self.btnSelectOptionAdd.isHidden = true
        
        //self.getPrincipalCompanyGroupDetails()
    }
    
    
    @IBOutlet weak var viewTechSpecification: UIView!
    @IBOutlet weak var viewTechSpecificationBorder: UIView!
    @IBOutlet weak var lblTechSpecification: UILabel!
    
    @IBOutlet weak var viewSTechSpecification: UIView!
    @IBOutlet weak var constraintBottomViewSTechSpecification: NSLayoutConstraint!
    
    @IBOutlet weak var btnTechSpecificationEdit: UIButton!
    @IBAction func btnTechSpecificationEditTap(_ sender: UIButton) {
        
        //self.selectProductRequirement()
    }
    @IBOutlet weak var ivTechSpecification: UIImageView!
    @IBOutlet weak var btnTechSpecificationEdit1: UIButton!
    @IBAction func btnTechSpecificationEdit1Tap(_ sender: UIButton) {
        
        //self.selectProductRequirement()
    }
    
    
    
    @IBOutlet weak var viewExistingSEnNewProject: UIView!
    @IBOutlet weak var viewExistingSEnNewProjectBorder: UIView!
    @IBOutlet weak var lblExistingSEnNewProject: UILabel!
    
    @IBOutlet weak var viewSExistingSEnNewProject: UIView!
    @IBOutlet weak var constraintBottomViewSExistingSEnNewProject: NSLayoutConstraint!
    
    @IBOutlet weak var btnExistingSEnNewProjectEdit: UIButton!
    @IBAction func btnExistingSEnNewProjectEditTap(_ sender: UIButton) {
        
        // Select Business Partner
        //self.selectBusinessPartner()
        
        self.viewANPTechInformation.isHidden = true
        self.viewSelectOption.isHidden = false
        self.viewSelectProjectRequirement.isHidden = true
    }
    @IBOutlet weak var ivExistingSEnNewProject: UIImageView!
    @IBOutlet weak var btnExistingSEnNewProjectEdit1: UIButton!
    @IBAction func btnExistingSEnNewProjectEdit1Tap(_ sender: UIButton) {
        
        self.arrProductCategories = []
        
        self.viewANPTechInformation.isHidden = true
        self.viewSelectOption.isHidden = false
        self.viewSelectProjectRequirement.isHidden = true
        
        self.constraintHeightSearchBar.constant = 0
        self.btnSelectOptionAdd.isHidden = true
        
        self.isSelectProduct = true
        self.isCategoryData = false
        self.isProductData = false
        
        self.tvDisplayData.reloadData()
        
        //self.getProjectProduct()
    }
    
    
    @IBOutlet weak var btnMainNextGoToProjectDetails: UIButton!
    @IBAction func btnMainNextGoToProjectDetailsTap(_ sender: UIButton) {
        self.addNewProjectVC!().setProjectDetails(strValue: "ASADFG asd sdf sdf sdf sdf l")
    }
    
    
    
    /// Select Business Partner, Location, Branch
    
    static let cellIdentifire1: String = "TransportTVCell"
    
    @IBOutlet weak var viewSelectOption: UIView!
    @IBOutlet weak var viewSelectOptionBack: UIView!
    @IBOutlet weak var btnSelectBPBack: UIButton!
    @IBAction func btnSelectBPBackTap(_ sender: UIButton) {
        if self.isCategoryData && self.isSelectProduct {
            self.viewANPTechInformation.isHidden = false
            self.viewSelectOption.isHidden = true
            self.viewSelectProjectRequirement.isHidden = true
        }
        else if self.isProductData {
            self.viewANPTechInformation.isHidden = true
            self.viewSelectOption.isHidden = false
            self.viewSelectProjectRequirement.isHidden = true
            
            self.btnSelectOptionAdd.isHidden = true
            self.isCategoryData = true
            self.isProductData = false
            
            //self.getPrincipalCompanyGroupDetails()
        }
    }
    @IBOutlet weak var btnSelectOptionAdd: UIButton!
    @IBAction func btnSelectOptionAddTap(_ sender: UIButton) {
        
    }
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var constraintHeightSearchBar: NSLayoutConstraint!
    
    @IBOutlet weak var tvDisplayData: UITableView! {
        didSet {
//            self.tvDisplayData.delegate = self
//            self.tvDisplayData.dataSource = self
//            self.tvDisplayData.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
//            self.tvDisplayData.register(UINib(nibName: ANPProjectDetailsVC.cellIdentifire1, bundle: nil), forCellReuseIdentifier: ANPProjectDetailsVC.cellIdentifire1)
//            self.tvDisplayData.register(UINib(nibName: "ANPProjectProductTVCell", bundle: nil), forCellReuseIdentifier: "ANPProjectProductTVCell")
        }
    }
    
    @IBOutlet weak var btnSelectProductDetailsNext: UIButton!
    @IBAction func btnSelectProductDetailsNextTap(_ sender: UIButton) {
        
        if self.isCategoryData {
            
            self.isCategoryData = false
            self.isProductData = true
            
            self.constraintHeightSearchBar.constant = 0
            
            //self.dictSelectedProduct?.removeAll()
            
            for value in (self.arrSelectedPrincipalCompany ?? []).enumerated() {
                
                if let value1 = self.dictSelectedProduct?[value.element.name ?? ""] {
                    print("Selected value --> \(value1)")
                }
                else {
                    self.dictSelectedProduct?[value.element.name ?? ""] = ""
                }
            }
            
            self.tvDisplayData.reloadData()
        }
        else if self.isProductData  {
            var isValid: Bool = true
            for value in (self.arrSelectedPrincipalCompany ?? []).enumerated() {
                if self.dictSelectedProduct?[value.element.name ?? ""] == "" {
                    isValid = false
                }
                
                if !isValid {
                    break
                }
            }
            
            if isValid {
                print("All product selected.")
                
                self.viewANPTechInformation.isHidden = false
                self.viewSelectOption.isHidden = true
                self.viewSelectProjectRequirement.isHidden = true
                
                //self.tvSelectedPrincipalCompany.reloadData()
                
                //self.btnPrincipalCompanyEdit.isHidden = false
                //self.btnPrincipalCompanyEdit1.isHidden = true
                //self.constraintBottomViewSPrincipalCompany.priority = .required
                
                
                //self.viewProjectRequirementBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
                //self.lblProjectRequirement.textColor = Colors.theme.returnColor()
                //self.btnProjectRequirementEdit1.isEnabled = true
                
                //self.isSelectedPrincipalCompany = true
                
                //self.checkProjectDetailSelected()
            }
            else {
                print("Please select product.")
                Utilities.showPopup(title: "Please select product.", type: .error)
            }
        }
        else if self.isSelectProduct {
            
            self.isSelectProduct = false
            
            self.viewANPTechInformation.isHidden = false
            self.viewSelectOption.isHidden = true
            self.viewSelectProjectRequirement.isHidden = true
            
            //self.btnProductEdit.isHidden = false
            //self.btnProductEdit1.isHidden = true
            
            //self.isSelectedProduct = true
            
            //self.constraintHeightTVSProjectProductData.constant = CGFloat((self.arrSelectedProductCategories?.count ?? 0) * 78)
            
            //self.constraintBottomViewSProduct.priority = .required
            
            //self.tvSelectedProjectProductData.reloadData()
        }
        
        //self.setUpAllDetail()
    }
    
    
    
    /// Project Requirement
    
    @IBOutlet weak var viewSelectProjectRequirement: UIView!
    @IBOutlet weak var viewSelectProjectRequirementBack: UIView!
    @IBOutlet weak var btnSelectProjectRequirementBack: UIButton!
    @IBAction func btnSelectProjectRequirementBackTap(_ sender: UIButton) {
        self.viewANPTechInformation.isHidden = false
        self.viewSelectOption.isHidden = true
        self.viewSelectProjectRequirement.isHidden = true
    }
    
    @IBOutlet weak var viewSelectNewProjectDev: UIView!
    @IBOutlet weak var viewSelectNewProjectDevBorder: UIView!
    @IBOutlet weak var ivNewProjectDev: UIImageView!
    @IBOutlet weak var lblNewProjectDev: UILabel!
    @IBOutlet weak var btnSelectNewProductDev: UIButton!
    @IBAction func btnSelectNewProductDevTap(_ sender: UIButton) {
        
        self.viewSelectNewProjectDevBorder.backgroundColor = .white
        self.viewSelectNewProjectDevBorder.cornersWFullBorder(radius: 15, borderColor: Colors.theme.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        self.ivNewProjectDev.tintColor = Colors.theme.returnColor()
        
        self.viewSelectTechSupportBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectTechSupportBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        self.ivTechSupport.tintColor = Colors.gray.returnColor()
        
        self.viewSelectPrototypeSampleBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectPrototypeSampleBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        self.ivPrototypeSample.tintColor = Colors.gray.returnColor()
        
        self.isNewProductDev = true
        self.isTechSupport = false
        self.isPrototypeSample = false
        self.strRequirementImage = "NewProductDev"
        self.strRequirementText = "New Product Development"
    }
    
    @IBOutlet weak var viewSelectTechSupport: UIView!
    @IBOutlet weak var viewSelectTechSupportBorder: UIView!
    @IBOutlet weak var ivTechSupport: UIImageView!
    @IBOutlet weak var lblTechSupport: UILabel!
    @IBOutlet weak var btnSelectTechSupport: UIButton!
    @IBAction func btnSelectTechSupportTap(_ sender: UIButton) {
        
        self.viewSelectNewProjectDevBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectNewProjectDevBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectNewProjectDevBorder.addShadow()
        self.ivNewProjectDev.tintColor = Colors.gray.returnColor()
        
        self.viewSelectTechSupportBorder.backgroundColor = .white
        self.viewSelectTechSupportBorder.cornersWFullBorder(radius: 15, borderColor: Colors.theme.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectTechSupportBorder.addShadow()
        self.ivTechSupport.tintColor = Colors.theme.returnColor()
        
        self.viewSelectPrototypeSampleBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectPrototypeSampleBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectPrototypeSampleBorder.addShadow()
        self.ivPrototypeSample.tintColor = Colors.gray.returnColor()
        
        self.isNewProductDev = false
        self.isTechSupport = true
        self.isPrototypeSample = false
        self.strRequirementImage = "TechSupport"
        self.strRequirementText = "Technical Support"
    }
    
    @IBOutlet weak var viewSelectPrototypeSample: UIView!
    @IBOutlet weak var viewSelectPrototypeSampleBorder: UIView!
    @IBOutlet weak var ivPrototypeSample: UIImageView!
    @IBOutlet weak var lblPrototypeSample: UILabel!
    @IBOutlet weak var btnSelectPrototypeSample: UIButton!
    @IBAction func btnSelectPrototypeSampleTap(_ sender: UIButton) {
        
        self.viewSelectNewProjectDevBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectNewProjectDevBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectNewProjectDevBorder.addShadow()
        self.ivNewProjectDev.tintColor = Colors.gray.returnColor()
        
        self.viewSelectTechSupportBorder.backgroundColor = UIColor(hexString: "#E7ECF2")
        self.viewSelectTechSupportBorder.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectTechSupportBorder.addShadow()
        self.ivTechSupport.tintColor = Colors.gray.returnColor()
        
        self.viewSelectPrototypeSampleBorder.backgroundColor = .white
        self.viewSelectPrototypeSampleBorder.cornersWFullBorder(radius: 15, borderColor: Colors.theme.returnColor(), borderWidth: 1.5, colorOpacity: 1.0)
        //self.viewSelectPrototypeSampleBorder.addShadow()
        self.ivPrototypeSample.tintColor = Colors.theme.returnColor()
        
        self.isNewProductDev = false
        self.isTechSupport = false
        self.isPrototypeSample = true
        self.strRequirementImage = "PrototypeSample"
        self.strRequirementText = "Prototype Sample"
    }
    
    @IBOutlet weak var btnSelectProjectRequirementNext: UIButton!
    @IBAction func btnSelectSelectProjectRequirementNextTap(_ sender: UIButton) {
        
        //self.ivSelectedProjectRequirement.image = UIImage(named: self.strRequirementImage)
        //self.lblSelectedProjectRequirement.text = self.strRequirementText
        
        //self.viewANPTechInformation.isHidden = false
        //self.viewSelectOption.isHidden = true
        //self.viewSelectProjectRequirement.isHidden = true
        
        //self.constraintBottomViewSProjectRequirement.priority = .required
        //self.btnProjectRequirementEdit.isHidden = false
        //self.btnProjectRequirementEdit1.isHidden = true
        
        //self.viewProductBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        //self.lblProduct.textColor = Colors.theme.returnColor()
        //self.btnProductEdit1.isEnabled = true
        
        //self.isSelectedProjectedRequirement = true
        
        //self.checkProjectDetailSelected()
    }
    
    
    
    
    
    
    
    
    // MARK: - Variable
    
    var onBack: ((Int)->Void)?
    var onOk: ((Int)->Void)?
    
    
    var addNewProjectVC: (()->AddNewProjectVC)?
    
    var isSelectedProjectType: Bool = false
    
    var isSelectedPrincipalCompany: Bool = false
    var isSelectedProjectedRequirement: Bool = false
    var isSelectedProduct: Bool = false
    
    
    var strProjectType: String = "dairy"
    
    
    var arrPrincipalCompany: [PrincipalCompany]?
    var arrSelectedPrincipalCompany: [PrincipalCompany]? = []
    var dictSelectedProduct: [String: String]? = [:]
    var isCategoryData: Bool = false
    var isProductData: Bool = false
    var isSearchActive: Bool = false
    
    
    var isNewProductDev: Bool = false
    var isTechSupport: Bool = false
    var isPrototypeSample: Bool = false
    var strRequirementImage: String = ""
    var strRequirementText: String = ""
    
    
    
    var arrProductCategories: [ProductCategory]?
    var arrSelectedProductCategories: [ProductCategory]? = []
    var isSelectProduct: Bool = false
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        let strValue = self.lblProjectProcess.text ?? ""
        self.lblProjectProcess.attributedText = strValue.setColorToString(strValue: ["Technical Information"], color: [Colors.theme.returnColor()], fontSize: 19)
        
        
        self.addNewProjectVC!().setProjectDetails(strValue: "ASADFG")
    }
    
}
