//
//  ANPTechInformationVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 30/11/24.
//

import Foundation
import UIKit
