//
//  AddNewProjectVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 21/11/24.
//

import UIKit

class AddNewProjectVC: UIViewController {
    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    @IBOutlet weak var btnInfo: UIButton!
    @IBAction func btnInfoTap(_ sender: UIButton) {
    }
    
    
    
    /// Add New Project
        
    @IBOutlet weak var viewAddNProject1: UIView!
    
    @IBOutlet weak var viewANProject1Back: UIView!
    @IBOutlet weak var btnANP1Back: UIButton!
    @IBAction func btnANP1BackTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = "Are you sure you want to discard changes?"
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            self.navigationController?.popViewController(animated: false)
        }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewCompanyType: UIView!
    @IBOutlet weak var constraintHeightViewCompanyType: NSLayoutConstraint!
    
    @IBOutlet weak var viewCompanyTypeBorder: UIView!
    @IBOutlet weak var lblCompanyType: UILabel!
    @IBOutlet weak var viewType1: UIView!
    @IBOutlet weak var btnCompanyType1: UIButton!
    @IBAction func btnCompanyType1Tap(_ sender: UIButton) {
    }
    @IBOutlet weak var viewType2: UIView!
    @IBOutlet weak var btnCompanyType2: UIButton!
    @IBAction func btnCompanyType2Tap(_ sender: UIButton) {
    }
    
    @IBOutlet weak var viewCompanyDetails: UIView!
    @IBOutlet weak var viewCompanyDetailsBorder: UIView!
    @IBOutlet weak var lblCompanyDetailsStatus: UILabel!
    @IBOutlet weak var ivCompanyDetailsStatus: UIImageView!
    @IBOutlet weak var lblCompanyDetails: UILabel!
    @IBOutlet weak var btnCompanyDetails: UIButton!
    @IBAction func btnCompanyDetailsTap(_ sender: UIButton) {
        
        //self.viewBody.isHidden = true
        self.viewAddNProject1.isHidden = true
        self.viewANPClientDetails1.isHidden = false
        self.viewSelectBP.isHidden = true
        
        self.setClientDetails()
    }
    
    @IBOutlet weak var viewProjectDetails: UIView!
    @IBOutlet weak var viewProjectDetailsBorder: UIView!
    @IBOutlet weak var lblProjectDetailsStatus: UILabel!
    @IBOutlet weak var ivProjectDetailsStatus: UIImageView!
    @IBOutlet weak var lblProjectDetails: UILabel!
    @IBOutlet weak var btnProjectDetails: UIButton!
    @IBAction func btnProjectDetailsTap(_ sender: UIButton) {

//        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ANPProjectDetailsVC") as! ANPProjectDetailsVC
//        popupVC.modalPresentationStyle = .overCurrentContext
//        popupVC.modalTransitionStyle = .crossDissolve
//        popupVC.onOk = { intA in
//            
//        }
//        popupVC.onBack = { intA in
//        }
//        self.present(popupVC, animated: false)
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "ANPProjectDetailsVC") as! ANPProjectDetailsVC
        vc.addNewProjectVC = {
            self
        }
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    @IBOutlet weak var viewTechnicalInformation: UIView!
    @IBOutlet weak var viewTechnicalInformationBorder: UIView!
    @IBOutlet weak var lblTechnicalInformationStatus: UILabel!
    @IBOutlet weak var ivTechnicalInformationStatus: UIImageView!
    @IBOutlet weak var lblTechnicalInformation: UILabel!
    @IBOutlet weak var btnTechnicalInformation: UIButton!
    @IBAction func btnTechnicalInformationTap(_ sender: UIButton) {
//        self.isTechnicalInformation = !self.isTechnicalInformation
//        
//        if self.isTechnicalInformation {
//            self.viewTechnicalInformationBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
//            self.lblTechnicalInformation.textColor = Colors.theme.returnColor()
//            self.ivTechnicalInformationStatus.isHidden = false
//        }
//        else {
//            self.viewTechnicalInformationBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
//            self.lblTechnicalInformation.textColor = Colors.gray.returnColor()
//            self.ivTechnicalInformationStatus.isHidden = true
//        }
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "ANPTechInformationVC") as! ANPTechInformationVC
        vc.addNewProjectVC = {
            self
        }
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    
    @IBOutlet weak var btnSubmitToRDTeam: UIButton!
    @IBAction func btnSubmitToRDTeamTap(_ sender: UIButton) {
    }
    
    
    
    
    /// Client Details.
    
    @IBOutlet weak var viewANPClientDetails1: UIView!
    
    @IBOutlet weak var viewProjectProcess: UIView!
    @IBOutlet weak var lblProjectProcess: UILabel!
    
    @IBOutlet weak var viewANPClientDetails1Back: UIView!
    @IBOutlet weak var btnANPClientDetails1Back: UIButton!
    @IBAction func btnANPClientDetails1BackTap(_ sender: UIButton) {
        self.viewAddNProject1.isHidden = false
        self.viewANPClientDetails1.isHidden = true
        self.viewSelectBP.isHidden = true
    }
    @IBOutlet weak var lblANPClientDetails1Title: UILabel!
    
    
    @IBOutlet weak var viewBusinessP: UIView!
    @IBOutlet weak var viewBusinessPBorder: UIView!
    @IBOutlet weak var lblBusinessP: UILabel!
    
    @IBOutlet weak var viewSBusinessPDetail: UIView!
    @IBOutlet weak var constraintBottomViewSBusinessPDetail: NSLayoutConstraint!
    @IBOutlet weak var lblSBusinessPCompanyTitle: UILabel!
    @IBOutlet weak var lblSBusinessPCompany: UILabel!
    @IBOutlet weak var lblSBusinessPCityTitle: UILabel!
    @IBOutlet weak var lblSBusinessPCity: UILabel!
    @IBOutlet weak var lblSBusinessPStateTitle: UILabel!
    @IBOutlet weak var lblSBusinessPState: UILabel!
    
    @IBOutlet weak var btnBusinssPEdit: UIButton!
    @IBAction func btnBusinssPEditTap(_ sender: UIButton) {
        
        // Select Business Partner
        self.selectBusinessPartner()
    }
    @IBOutlet weak var ivBusinssP: UIImageView!
    @IBOutlet weak var btnBusinssPEdit1: UIButton!
    @IBAction func btnBusinssPEdit1Tap(_ sender: UIButton) {
        
        // Select Business Partner
        self.selectBusinessPartner()
    }
    
    @IBOutlet weak var viewBillingLocation: UIView!
    @IBOutlet weak var viewBillingLocationBorder: UIView!
    @IBOutlet weak var lblBillingLocation: UILabel!
    
    @IBOutlet weak var viewSBillingLocationDetail: UIView!
    @IBOutlet weak var constraintBottomViewSBillingLocationDetail: NSLayoutConstraint!
    @IBOutlet weak var lblSBillingCompanyTitle: UILabel!
    @IBOutlet weak var lblSBillingCompany: UILabel!
    @IBOutlet weak var lblSBillingBlockNoTitle: UILabel!
    @IBOutlet weak var lblSBillingBlockNo: UILabel!
    @IBOutlet weak var lblSBillingBuildingFRTitle: UILabel!
    @IBOutlet weak var lblSBillingBuildingFR: UILabel!
    @IBOutlet weak var lblSBillingStreetPOBoxTitle: UILabel!
    @IBOutlet weak var lblSBillingStreetPOBox: UILabel!
    @IBOutlet weak var lblSBillingZipCodeTitle: UILabel!
    @IBOutlet weak var lblSBillingZipCode: UILabel!
    @IBOutlet weak var lblSBillingCityTitle: UILabel!
    @IBOutlet weak var lblSBillingCity: UILabel!
    @IBOutlet weak var lblSBillingGSTTitle: UILabel!
    @IBOutlet weak var lblSBillingGST: UILabel!
    
    @IBOutlet weak var btnBillingLocationEdit: UIButton!
    @IBAction func btnBillingLocationEditTap(_ sender: UIButton) {
        
        // Select Location
        self.selectLocation()
    }
    @IBOutlet weak var ivBillingLocation: UIImageView!
    @IBOutlet weak var btnBillingLocationEdit1: UIButton!
    @IBAction func btnBillingLocationEdit1Tap(_ sender: UIButton) {
        
        // Select Location
        self.selectLocation()
    }
    
    @IBOutlet weak var viewBranch: UIView!
    @IBOutlet weak var viewBranchBorder: UIView!
    @IBOutlet weak var lblBranch: UILabel!
    @IBOutlet weak var btnBranchEdit: UIButton!
    @IBAction func btnBranchEditTap(_ sender: UIButton) {
        
        self.selectBranch()
    }
    @IBOutlet weak var ivBranch: UIImageView!
    
    @IBOutlet weak var viewBranchDetail: UIView!
    @IBOutlet weak var constraintBottomViewBranchDetail: NSLayoutConstraint!
    @IBOutlet weak var lblSBranchLTitle: UILabel!
    @IBOutlet weak var lblSBranchL: UILabel!
    
    @IBOutlet weak var btnBranchEdit1: UIButton!
    @IBAction func btnBranchEdit1Tap(_ sender: UIButton) {
        
        self.selectBranch()
    }
    
    @IBOutlet weak var viewProjectSDate: UIView!
    @IBOutlet weak var viewProjectSDateBorder: UIView!
    @IBOutlet weak var lblProjectSDate: UILabel!
    @IBOutlet weak var btnProjectSDateEdit: UIButton!
    @IBAction func btnProjectSDateEditTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "dd MMMM, yyyy"
        popupVC.isMaxDateLimit = false
        popupVC.minStartDate = Utilities.convertDateToString(date: Date(), NewDateFormate: "dd MMMM, yyyy")
        popupVC.didSelectDate = { date in
            
            self.lblProjectSDate.text = date
            
            self.btnGoToProjectDetails.isEnabled = true
            self.btnGoToProjectDetails.backgroundColor = Colors.theme.returnColor()
            self.isSelectedProjectSD = true
        }
        popupVC.onClose = {
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var ivProjectSDate: UIImageView!
    
    
    @IBOutlet weak var viewGoToProjectDetails: UIView!
    @IBOutlet weak var btnGoToProjectDetails: UIButton!
    @IBAction func btnGoToProjectDetailsTap(_ sender: UIButton) {
        self.setupNewProject()
    }
    
    
    
    
    /// Select Business Partner, Location, Branch
    
    static let cellIdentifire1: String = "CRMBusinessPTVCell"
    static let cellIdentifire2: String = "CRMBillingLocationTVCell"
    static let cellIdentifire3: String = "CRMBranchTVCell"
    
    @IBOutlet weak var viewSelectBP: UIView!
    @IBOutlet weak var viewSelectBPBack: UIView!
    @IBOutlet weak var btnSelectBPBack: UIButton!
    @IBAction func btnSelectBPBackTap(_ sender: UIButton) {
        //self.viewBody.isHidden = true
        self.viewAddNProject1.isHidden = true
        self.viewANPClientDetails1.isHidden = false
        self.viewSelectBP.isHidden = true
    }
    @IBOutlet weak var btnSelectBPAdd: UIButton!
    @IBAction func btnSelectBPAddTap(_ sender: UIButton) {
        //self.viewBody.isHidden = true
        self.viewAddNProject1.isHidden = true
        self.viewANPClientDetails1.isHidden = false
        self.viewSelectBP.isHidden = true
    }
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var tvDisplayData: UITableView! {
        didSet {
            self.tvDisplayData.delegate = self
            self.tvDisplayData.dataSource = self
            self.tvDisplayData.register(UINib(nibName: AddNewProjectVC.cellIdentifire1, bundle: nil), forCellReuseIdentifier: AddNewProjectVC.cellIdentifire1)
            self.tvDisplayData.register(UINib(nibName: AddNewProjectVC.cellIdentifire2, bundle: nil), forCellReuseIdentifier: AddNewProjectVC.cellIdentifire2)
            self.tvDisplayData.register(UINib(nibName: AddNewProjectVC.cellIdentifire3, bundle: nil), forCellReuseIdentifier: AddNewProjectVC.cellIdentifire3)
        }
    }
    
    @IBOutlet weak var btnSelectNextClientDetails: UIButton!
    @IBAction func btnSelectNextClientDetailsTap(_ sender: UIButton) {
        if self.isSelectBusinssPartneer {
            self.isSelectedBusinssPartneer = true
            
            self.isSelectBusinssPartneer = false
            self.isSelectBillingLocation = true
            self.isSelectBranch = false
            
            self.btnSelectNextClientDetails.isEnabled = false
            self.btnSelectNextClientDetails.backgroundColor = Colors.gray.returnColor()
            
            // Select Location
            self.selectLocation()
        }
        else if self.isSelectBillingLocation {
            self.isSelectedBillingLocation = true
            
            self.isSelectBusinssPartneer = false
            self.isSelectBillingLocation = false
            self.isSelectBranch = true
            
            self.btnSelectNextClientDetails.isEnabled = false
            self.btnSelectNextClientDetails.backgroundColor = Colors.gray.returnColor()
            
            // Select Branch
            self.selectBranch()
        }
        else if self.isSelectBranch {
            self.isSelectedBranch = true
            
            self.isSelectBusinssPartneer = false
            self.isSelectBillingLocation = false
            self.isSelectBranch = false
            
            self.btnSelectNextClientDetails.isEnabled = false
            self.btnSelectNextClientDetails.backgroundColor = Colors.gray.returnColor()
            
            self.viewAddNProject1.isHidden = true
            self.viewANPClientDetails1.isHidden = false
            self.viewSelectBP.isHidden = true
        }
    }
    
    
    
    
    
    // MARK: - Variables
    
    var isCompanyDetails: Bool = false
    var isProjectDetails: Bool = false
    var isTechnicalInformation: Bool = false
    
    var isSelectBusinssPartneer: Bool = false
    var isSelectBillingLocation: Bool = false
    var isSelectBranch: Bool = false
    
    var isSelectedBusinssPartneer: Bool = false
    var isSelectedBillingLocation: Bool = false
    var isSelectedBranch: Bool = false
    var isSelectedProjectSD: Bool = false
    
    var intPage: Int = 1
    
    
    /// Select Business Partner
    var arrBusinessPartner: [BusinessPartner]?
    var selectedBusinessPartner: BusinessPartner?
    var selectedOldBusinessPartner: BusinessPartner?
    
    var arrBusinessPartnerAddress: [BusinessPartnerAddress]?
    var selectedBusinessPartnerAddress: BusinessPartnerAddress?
    
    var arrBranch: [Branch]?
    var selectedBranch: Branch?
    
    var isProjectDetailSet: Bool = false
    
    
    /// Select Project Details
    
    var arrPrincipalCompany: [PrincipalCompany]?
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.viewBody.isHidden = false
        self.viewAddNProject1.isHidden = false
        self.viewANPClientDetails1.isHidden = true
        self.viewSelectBP.isHidden = true
        
        
        self.viewCompanyDetailsBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        self.lblCompanyDetailsStatus.corners(radius: self.lblCompanyDetailsStatus.frame.width / 2)
        self.lblCompanyDetailsStatus.backgroundColor = Colors.theme.returnColor()
        self.lblCompanyDetails.textColor = Colors.theme.returnColor()
        self.ivCompanyDetailsStatus.isHidden = true
        
        self.viewProjectDetailsBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblProjectDetailsStatus.corners(radius: self.lblProjectDetailsStatus.frame.width / 2)
        self.lblProjectDetailsStatus.backgroundColor = Colors.gray.returnColor()
        self.lblProjectDetails.textColor = Colors.gray.returnColor()
        self.ivProjectDetailsStatus.isHidden = true
        
        self.viewTechnicalInformationBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblTechnicalInformationStatus.corners(radius: self.lblTechnicalInformationStatus.frame.width / 2)
        self.lblTechnicalInformationStatus.backgroundColor = Colors.gray.returnColor()
        self.lblTechnicalInformation.textColor = Colors.gray.returnColor()
        self.ivTechnicalInformationStatus.isHidden = true
        
        
        self.btnSubmitToRDTeam.isEnabled = false
        
        let strValue = self.lblProjectProcess.text ?? ""
        self.lblProjectProcess.attributedText = strValue.setColorToString(strValue: ["Client Details"], color: [Colors.theme.returnColor()], fontSize: 19)
        
        
        self.constraintHeightViewCompanyType.priority = .required
        
        
        self.viewBillingLocationBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblBillingLocation.textColor = Colors.gray.returnColor()
        
        self.viewBranchBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblBranch.textColor = Colors.gray.returnColor()
        
        self.viewProjectSDateBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblProjectSDate.textColor = Colors.gray.returnColor()
        
        
        self.viewCompanyDetails.backgroundColor = .white
        self.viewProjectDetails.backgroundColor = .white
        self.viewTechnicalInformation.backgroundColor = .white
        
        self.viewBusinessP.backgroundColor = .white
        self.viewBillingLocation.backgroundColor = .white
        self.viewBranch.backgroundColor = .white
        self.viewProjectSDate.backgroundColor = .white
        
        self.constraintBottomViewSBusinessPDetail.priority = .defaultLow
        self.constraintBottomViewSBillingLocationDetail.priority = .defaultLow
        self.constraintBottomViewBranchDetail.priority = .defaultLow
        
        self.isSelectBusinssPartneer = false
        self.isSelectBillingLocation = false
        self.isSelectBranch = false
        
        //self.setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if self.isProjectDetailSet {
            self.setProjectDetails(strValue: "DADASFDSFDSFDSF")
        }
    }
    
    func setupNewProject() {
        
        self.viewCompanyDetailsBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        self.lblCompanyDetailsStatus.corners(radius: self.lblCompanyDetailsStatus.frame.width / 2)
        self.lblCompanyDetailsStatus.backgroundColor = Colors.theme.returnColor()
        self.lblCompanyDetails.textColor = Colors.theme.returnColor()
        self.ivCompanyDetailsStatus.isHidden = true
        
        self.viewProjectDetailsBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblProjectDetailsStatus.corners(radius: self.lblProjectDetailsStatus.frame.width / 2)
        self.lblProjectDetailsStatus.backgroundColor = Colors.gray.returnColor()
        self.lblProjectDetails.textColor = Colors.gray.returnColor()
        self.ivProjectDetailsStatus.isHidden = true
        
        self.viewTechnicalInformationBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblTechnicalInformationStatus.corners(radius: self.lblTechnicalInformationStatus.frame.width / 2)
        self.lblTechnicalInformationStatus.backgroundColor = Colors.gray.returnColor()
        self.lblTechnicalInformation.textColor = Colors.gray.returnColor()
        self.ivTechnicalInformationStatus.isHidden = true
        
        if self.isSelectedBusinssPartneer && self.isSelectedBillingLocation && self.isSelectedBranch && self.isSelectedProjectSD {
            
            self.ivCompanyDetailsStatus.isHidden = false
            
            self.viewProjectDetailsBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
            self.lblProjectDetailsStatus.corners(radius: self.lblProjectDetailsStatus.frame.width / 2)
            self.lblProjectDetailsStatus.backgroundColor = Colors.theme.returnColor()
            self.lblProjectDetails.textColor = Colors.theme.returnColor()
            self.ivProjectDetailsStatus.isHidden = true
            
            self.viewAddNProject1.isHidden = false
            self.viewANPClientDetails1.isHidden = true
            self.viewSelectBP.isHidden = true
        }
    }
    
    func setClientDetails() {
        self.viewBusinessPBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        self.lblBusinessP.textColor = Colors.theme.returnColor()
        
        self.viewBillingLocationBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblBillingLocation.textColor = Colors.gray.returnColor()
        
        self.viewBranchBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblBranch.textColor = Colors.gray.returnColor()
        
        self.viewProjectSDateBorder.cornersWFullBorder(radius: 12, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.lblProjectSDate.textColor = Colors.gray.returnColor()
        
        
        self.btnBusinssPEdit.isHidden = true
        self.btnBusinssPEdit1.isHidden = false
        
        self.btnBillingLocationEdit.isHidden = true
        self.btnBillingLocationEdit1.isHidden = false
        
        self.btnBranchEdit.isHidden = true
        self.btnBranchEdit1.isHidden = false
        
        self.btnProjectSDateEdit.isEnabled = false
        
        
        self.btnBusinssPEdit.isHidden = true
        self.btnBusinssPEdit1.isHidden = false
        
        self.btnBillingLocationEdit1.isEnabled = false
        
        self.btnBillingLocationEdit.isHidden = true
        self.btnBillingLocationEdit1.isHidden = false
        
        self.btnBranchEdit1.isEnabled = false
        
        self.btnBranchEdit.isHidden = true
        self.btnBranchEdit1.isHidden = false
        
        self.constraintBottomViewSBusinessPDetail.priority = .defaultLow
        self.constraintBottomViewSBillingLocationDetail.priority = .defaultLow
        self.constraintBottomViewBranchDetail.priority = .defaultLow
        
        if !self.isSelectedBranch {
            self.lblProjectSDate.text = "Project Start Date"
            self.isSelectedProjectSD = false
            self.btnGoToProjectDetails.isEnabled = false
            self.btnGoToProjectDetails.backgroundColor = Colors.gray.returnColor().withAlphaComponent(0.85)
        }
        
        if self.isSelectedBusinssPartneer {
            self.viewBillingLocationBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
            self.lblBillingLocation.textColor = Colors.theme.returnColor()
            
            self.btnBusinssPEdit.isHidden = false
            self.btnBusinssPEdit1.isHidden = true
            
            self.btnBillingLocationEdit1.isEnabled = true
            
            self.lblSBusinessPCompany.text = self.selectedBusinessPartner?.name ?? ""
            self.lblSBusinessPCity.text = self.selectedBusinessPartner?.cityName ?? ""
            self.lblSBusinessPState.text = self.selectedBusinessPartner?.stateName ?? ""
            
            self.constraintBottomViewSBusinessPDetail.priority = .required
        }
        if self.isSelectedBillingLocation {
            self.viewBranchBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
            self.lblBranch.textColor = Colors.theme.returnColor()
            
            self.btnBillingLocationEdit.isHidden = false
            self.btnBillingLocationEdit1.isHidden = true
            
            self.btnBranchEdit1.isEnabled = true
            
            self.lblSBillingCompany.text = self.selectedBusinessPartnerAddress?.blockNo ?? ""
            self.lblSBillingBlockNo.text = self.selectedBusinessPartnerAddress?.blockNo ?? ""
            self.lblSBillingBuildingFR.text = self.selectedBusinessPartnerAddress?.buildingFloorRoom ?? ""
            self.lblSBillingStreetPOBox.text = self.selectedBusinessPartnerAddress?.streetPoBox ?? ""
            self.lblSBillingZipCode.text = self.selectedBusinessPartnerAddress?.pinCode ?? ""
            self.lblSBillingCity.text = self.selectedBusinessPartnerAddress?.city ?? ""
            self.lblSBillingGST.text = (self.selectedBusinessPartnerAddress?.gstIn ?? "") == "" ? "-" : (self.selectedBusinessPartnerAddress?.gstIn ?? "")
            
            self.constraintBottomViewSBillingLocationDetail.priority = .required
        }
        if self.isSelectedBranch {
            self.viewBranchBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
            self.lblBranch.textColor = Colors.theme.returnColor()
            
            self.viewProjectSDateBorder.cornersWFullBorder(radius: 12, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
            self.lblProjectSDate.textColor = Colors.theme.returnColor()
            
            self.btnBranchEdit.isHidden = false
            self.btnBranchEdit1.isHidden = true
            
            self.btnProjectSDateEdit.isEnabled = true
            
            self.btnSelectNextClientDetails.setTitle("Submit", for: .normal)
            
            self.lblSBranchL.text = self.selectedBranch?.branchName ?? ""
            
            self.constraintBottomViewBranchDetail.priority = .required
        }
    }
    
}


extension AddNewProjectVC {
    
    func selectBusinessPartner() {
        //self.viewBody.isHidden = true
        self.viewAddNProject1.isHidden = true
        self.viewANPClientDetails1.isHidden = true
        self.viewSelectBP.isHidden = false
        
        self.isSelectBusinssPartneer = true
        self.isSelectBillingLocation = true
        self.isSelectBranch = false
        
        self.btnSelectNextClientDetails.isEnabled = false
        self.btnSelectNextClientDetails.backgroundColor = Colors.gray.returnColor()
        
        self.getBusinessPartnerList(employeeId: APIManager.sharedManager.userId)
        //self.tvDisplayData.reloadData()
        //getBusinessPartnerList(employeeId: Int = 0, strSearchValue: String = "", intPage: Int = 1)
    }
    
    func selectLocation() {
        //self.viewBody.isHidden = true
        self.viewAddNProject1.isHidden = true
        self.viewANPClientDetails1.isHidden = true
        self.viewSelectBP.isHidden = false
        
        self.isSelectBusinssPartneer = false
        self.isSelectBillingLocation = true
        self.isSelectBranch = false
        
        self.btnSelectNextClientDetails.isEnabled = false
        self.btnSelectNextClientDetails.backgroundColor = Colors.gray.returnColor()
        
        self.getBusinessPartnerAddressList(businessPId: "\(self.selectedBusinessPartner?.id ?? 0)")
        //getBusinessPartnerAddressList(businessPId: String = "0", strSearchValue: String = "", intPage: Int = 1)
        //self.tvDisplayData.reloadData()
    }
    
    func selectBranch() {
        //self.viewBody.isHidden = true
        self.viewAddNProject1.isHidden = true
        self.viewANPClientDetails1.isHidden = true
        self.viewSelectBP.isHidden = false
        
        self.isSelectBusinssPartneer = false
        self.isSelectBillingLocation = false
        self.isSelectBranch = true
        
        self.btnSelectNextClientDetails.isEnabled = false
        self.btnSelectNextClientDetails.backgroundColor = Colors.gray.returnColor()
        
        self.getBranch(businessPId: "\(self.selectedBusinessPartner?.id ?? 0)")
        //getBranch(businessPId: String = "0", strSearchValue: String = "", intPage: Int = 1)
        //self.tvDisplayData.reloadData()
    }
    
    func setProjectDetails(strValue: String) {
        print("Project details set proper --> \(strValue)")
    }
    
}
