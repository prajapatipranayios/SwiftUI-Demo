//
//  SupportVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/09/24.
//

import UIKit
import AVFoundation

class SupportVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnMenu: UIButton!
    @IBAction func btnMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    
    
    @IBOutlet weak var viewBody: UIView!
    @IBOutlet weak var constraintBottomViewBodyToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var viewScrollViewIn: UIView!
    @IBOutlet weak var viewBodyInScroll: UIView!
    
    @IBOutlet weak var txtTitle: TLTextField!
    @IBOutlet weak var lblErrorTitle: UILabel!
    
    @IBOutlet weak var txtDescription: TLTextField!
    @IBOutlet weak var lblErrorDescription: UILabel!
    
    @IBOutlet weak var ivSupport: UIImageView!
    
    @IBOutlet weak var btnUploadImg: UIButton!
    @IBAction func btnUploadImgTap(_ sender: UIButton) {
        
        self.selectImgFromGallery()
    }
    
    @IBOutlet weak var btnSend: UIButton!
    @IBAction func btnSend(_ sender: UIButton) {
        
        var isValid: Bool = true
        self.lblErrorTitle.text = ""
        self.lblErrorDescription.text = ""
        
        if (self.txtTitle.text ?? "" == "") && isValid {
            isValid = false
            self.lblErrorTitle.text = "enter title"
        }
        else if (self.txtDescription.text ?? "" == "") && isValid {
            isValid = false
            self.lblErrorDescription.text = "enter description"
        }
        
        if isValid {
            self.sendSupportQuery(image: self.selectedImage)
        }
    }
    
    
    
    
    // MARK: - Variable
    
    var selectedImage: UIImage? = nil
    var isCameraClick : Bool = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblErrorTitle.text = ""
        self.lblErrorDescription.text = ""
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        self.checkKeyboard(kView: self.viewBodyInScroll)
    }

    func captureImageFromCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            imagePicker.allowsEditing = false
            imagePicker.mediaTypes = ["public.image"]
            isCameraClick = true
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func selectImgFromGallery() {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false

            present(imagePicker, animated: true, completion: nil)
            
        }
    }
    
}


// MARK: - Web Services

extension SupportVC {

    func sendSupportQuery(image: UIImage?) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.sendSupportQuery(image: image)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "description": self.txtTitle.text ?? "",
            "title": self.txtDescription.text ?? "",
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.supportPostData(url: APIManager.sharedManager.SEND_SUPPORT_QUERY, parameters: param, image: image) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.displaySuccessMsg(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func displaySuccessMsg(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.navigateToHome()
        }
        self.present(popupVC, animated: true)
    }
    
    func navigateToHome() {
        revealViewController()?.revealSideMenu(navigateHome: true)
    }
    
}

// MARK: - Selet Image

extension SupportVC: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if isCameraClick && (info[.originalImage] is UIImage)
        {
            picker.dismiss(animated: true) {
                guard let image = info[.originalImage] as? UIImage else {
                    print("No image found")
                    return
                }
                self.ivSupport.image = image
                self.selectedImage = image
            }
            
        }
        else if info[UIImagePickerController.InfoKey.originalImage] is UIImage
        {
            picker.dismiss(animated: true) {
                //let imageUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL
                //let imageUrl = info[.imageURL] as? URL
                /*let checkUrl: String = String(describing: info[.referenceURL] ?? "")
                let imgUrl: String = String(describing: info[.imageURL] ?? "")
                
                if !self.arrImg.contains(checkUrl) {
                    self.arrImg.append(checkUrl)
                    let temp = ImgUpload(img: imgUrl, comment: "", isNew: true)
                    self.arrUploadImg?.append(temp)
                }
                else {
                    Utilities.showPopup(title: "Please select different image.", type: .error)
                }
                DispatchQueue.main.async {
                    if self.arrImg.count > 0 {
                        self.constraintHeightCVUploadImg.constant = 170
                    }
                    self.cvUploadImg.reloadData()
                    
                    if self.arrImg.count > 4 {
                        self.btnUploadImg.isHidden = true
                    }
                }   /// */
                
                guard let image = info[.originalImage] as? UIImage else {
                    print("No image found")
                    return
                }
                self.ivSupport.image = image
                self.selectedImage = image
            }
        }
    }
    
}


// MARK: - Keyboard

extension SupportVC {
    
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            self.constraintBottomViewBodyToSuper.constant = keyboardOverlap > 0 ? (keyboardOverlap - 0) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}
