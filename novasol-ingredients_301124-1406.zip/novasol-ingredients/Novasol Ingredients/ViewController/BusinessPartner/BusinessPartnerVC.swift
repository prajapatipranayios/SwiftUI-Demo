//
//  BusinessPartnerVC.swift
//  GE Sales
//
//  Created by Auxano on 25/04/24.
//

import UIKit

class BusinessPartnerVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        if self.isFromAddOrder {
            self.dismiss(animated: true) {
                if self.onCellTap != nil {
                    self.onCellTap!(false, nil)
                }
            }
        }
        else {
            revealViewController()?.revealSideMenu()
        }
    }
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var viewDateNSort: UIView!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var imgStartD: UIImageView!
    @IBOutlet weak var btnStartDate: UIButton!
    @IBAction func btnStartDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectDate = { date in
            self.imgStartD.isHidden = true
            
            self.lblStartDate.text = date
            self.strStartDate = date
        }
        popupVC.onClose = {
            if (self.lblStartDate.text != "Start Date" && self.lblEndDate.text != "End Date") {
                self.page = 1
                
                self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
            }
            
            self.lblStartDate.text = "Start Date"
            self.lblEndDate.text = "End Date"
            self.strStartDate = ""
            self.strEndDate = ""
            self.imgStartD.isHidden = false
            self.imgEndD.isHidden = false
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var imgEndD: UIImageView!
    @IBOutlet weak var btnEndDate: UIButton!
    @IBAction func btnEndDateTap(_ sender: UIButton) {
        if self.lblStartDate.text == "Start Date" {
            Utilities.showPopup(title: Messages.SelectStartDate, type: .error)
        }
        else {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.minStartDate = lblStartDate.text!
            popupVC.didSelectDate = { date in
                self.imgEndD.isHidden = true
                
                self.lblEndDate.text = date
                self.strEndDate = date
                
                if (self.lblStartDate.text != "Start Date" && self.lblEndDate.text != "End Date") && (self.strStartDate != "" && self.strEndDate != "") {
                    self.page = 1
                    
                    self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
                }
            }
            popupVC.onClose = {
                self.lblEndDate.text = "End Date"
                self.strEndDate = ""
                self.imgEndD.isHidden = false
            }
            self.present(popupVC, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var viewSort: UIView!
    @IBOutlet weak var lblSort: UILabel!
    @IBOutlet weak var btnSort: UIButton!
    @IBAction func btnSortTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "SortVC") as! SortVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Sorting"
        popupVC.selectedValue = self.lblSort.text!
        popupVC.didSelect = { sorting in
            if self.lblSort.text! != sorting {
                //["Newest", "Oldest", "A - Z", "Z - A"]
                self.lblSort.text = sorting
                switch sorting {
                case "Newest":
                    self.strOrderBy = Sort.Newest.rawValue
                case "Oldest":
                    self.strOrderBy = Sort.Oldest.rawValue
                case "A - Z":
                    self.strOrderBy = Sort.Ascending.rawValue
                case "Z - A":
                    self.strOrderBy = Sort.Descending.rawValue
                default:
                    self.strOrderBy = self.strOrderBy
                }
                
                self.page = 1
                
                self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
            }
        }
        popupVC.onClose = { sorting in
            
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var viewEmpFilter: UIView!
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var btnSelectEmp: UIButton!
    @IBAction func btnSelectEmpTap(_ sender: UIButton) {
        
        var arrEmpName: [String] = (self.arrEmployee ?? []).map { "\($0.firstname ?? "") " +  "\($0.lastname ?? "")" }
        arrEmpName.insert("Select Employee Name", at: 0)
        
        if arrEmpName.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.SelectEmployee
            popupVC.value = arrEmpName
            popupVC.selectedValue = self.lblEmpName.text ?? "All"
            popupVC.isSearchActive = true
            popupVC.isOpenCloseAnimation = true
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { name in
                let tempCategoryList = self.arrEmployee?.filter{ ("\($0.firstname ?? "") \($0.lastname ?? "")" == name) }
                if (tempCategoryList?.count ?? 0) > 0 {
                    self.intEmployeeId = tempCategoryList?[0].id ?? 0
                }
                else {
                    self.intEmployeeId = 0
                }
                self.lblEmpName.text = name
                self.page = 1
                
                self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    @IBOutlet weak var tvBusinessP: UITableView!
    @IBOutlet weak var btnAddBusinessP: UIButton!
    @IBAction func btnAddBusinessPTap(_ sender: UIButton) {
        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "AddBusinessPVC") as! AddBusinessPVC
        viewController.isSalesPersonVisible = Role.IsSalesPersonVisible(forRole: APIManager.sharedManager.userDetail?.roleId ?? 0)
        viewController.strScreenTitle = self.strScreenTitle
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Business Partner"
    var strStartDate: String = ""
    var strEndDate: String = ""
    var strOrderBy: String = Sort.Newest.rawValue
    var intEmployeeId: Int = 0
    var arrEmployee: [Employee]?
    var page: Int = 1
    var searchText: String = ""
    var businessPartners: [BusinessPartner]?
    var hasMore: Bool = false
    var isLoadMore: Bool = false
    var isRefreshData: Bool = false
    
    
    // Present From Add Sales Order
    var isFromAddOrder: Bool = false
    var onCellTap:((Bool, BusinessPartner?)->Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.searchBar.delegate = self
        self.searchBar.showsCancelButton = true
        self.searchBar.enablesReturnKeyAutomatically = true
        
        self.btnAddBusinessP.tintColor = Colors.theme.returnColor()
        self.btnAddBusinessP.isHidden = true
        if Role.canAddBusinessP(forRole: APIManager.sharedManager.userDetail?.roleId ?? 0) {
            self.btnAddBusinessP.isHidden = false
        }
        
        self.tvBusinessP.dataSource = self
        self.tvBusinessP.delegate = self
        
        self.tvBusinessP.register(UINib(nibName: "BusinessPTVCell", bundle: nil), forCellReuseIdentifier: "BusinessPTVCell")
        
        self.getEmployeeList()
        self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if APIManager.sharedManager.isRefreshData {
            
            self.getEmployeeList()
            self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
            APIManager.sharedManager.isRefreshData = false
        }
        
        if self.isFromAddOrder {
            self.btnSideMenu.setImage(UIImage(named: "Back"), for: .normal)
            self.btnAddBusinessP.isHidden = true
        }
        else {
            self.btnSideMenu.setImage(UIImage(named: "Sidemenu"), for: .normal)
            self.btnAddBusinessP.isHidden = false
        }
    }
}
