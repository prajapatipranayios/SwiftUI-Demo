//
//  CameraViewController.swift
//  GE Sales
//
//  Created by Auxano on 23/05/24.
//

import Foundation
import UIKit
import AVFoundation
import Vision

class CameraViewController: UIViewController, AVCapturePhotoCaptureDelegate {

    var captureSession: AVCaptureSession!
    var photoOutput: AVCapturePhotoOutput!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var captureImg: ((UIImage?)->Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo
        
        guard let backCamera = AVCaptureDevice.default(for: .video) else {
            print("Unable to access back camera!")
            return
        }
        
        do {
            let input = try AVCaptureDeviceInput(device: backCamera)
            captureSession.addInput(input)
            
            photoOutput = AVCapturePhotoOutput()
            captureSession.addOutput(photoOutput)
            
            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            previewLayer.frame = view.bounds
            previewLayer.videoGravity = .resizeAspectFill
            view.layer.addSublayer(previewLayer)
            
            captureSession.startRunning()
            
        } catch let error {
            print("Error Unable to initialize back camera:  \(error.localizedDescription)")
        }
        
        let captureButton = UIButton(type: .system)
        captureButton.frame = CGRect(x: (self.view.frame.width / 2) - 50 , y: self.view.frame.height - 150, width: 100, height: 50)
        //captureButton.center = self.view.center
        //captureButton.font = Fonts.Medium.returnFont(size: 18.0)
        captureButton.setTitleColor(.black, for: .normal)
        captureButton.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        captureButton.setTitle("Capture", for: .normal)
        captureButton.addTarget(self, action: #selector(self.captureButtonTapped), for: .touchUpInside)
        
        self.view.addSubview(captureButton)
    }
    
    @IBAction func captureButtonTapped(_ sender: UIButton) {
        let settings = AVCapturePhotoSettings()
        photoOutput.capturePhoto(with: settings, delegate: self)
    }
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        guard let imageData = photo.fileDataRepresentation() else { return }
        let image = UIImage(data: imageData)
        //recognizeTextInImage(image)
        
        dismiss(animated: true) {
            if self.captureImg != nil {
                self.captureImg!(image)
            }
         }
    }
    
    func recognizeTextInImage(_ image: UIImage?) {
        guard let cgImage = image?.cgImage else { return }
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        let request = VNRecognizeTextRequest { (request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            let recognizedStrings = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }
            
            // Process the recognized text as needed
            print(recognizedStrings.joined(separator: "\n"))
        }
        request.recognitionLevel = .accurate
        do {
            try requestHandler.perform([request])
        } catch {
            print(error)
        }
    }
}
