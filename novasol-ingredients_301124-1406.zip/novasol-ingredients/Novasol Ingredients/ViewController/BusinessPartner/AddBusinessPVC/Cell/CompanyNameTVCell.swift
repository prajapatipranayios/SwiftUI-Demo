//
//  CompanyNameTVCell.swift
//  GE Sales
//
//  Created by Auxano on 16/05/24.
//

import UIKit

class CompanyNameTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    
    // MARK: - Variable
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
