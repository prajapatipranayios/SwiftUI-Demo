//
//  TransportTVCell.swift
//  GE Sales
//
//  Created by Auxano on 21/05/24.
//

import UIKit

class TransportTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnSelect: UIButton!
    @IBAction func btnSelectTap(_ sender: UIButton) {
        if self.didSelect != nil {
            self.didSelect!(self.section, self.index)
        }
    }
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnSelect1: UIButton!
    
    // MARK: - Variable
    
    var didSelect: ((Int, Int)->Void)?
    var index: Int = 0
    var section: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
