//
//  AddContactTVCell.swift
//  GE Sales
//
//  Created by Auxano on 17/05/24.
//

import UIKit

class AddContactTVCell: UITableViewCell {

    //MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewName: UIView!
    @IBOutlet weak var lblNameTtitle: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var constraintHeightViewName: NSLayoutConstraint!
    
    @IBOutlet weak var viewMobile: UIView!
    @IBOutlet weak var lblMobileNoTitle: UILabel!
    @IBOutlet weak var lblMobileNo: UILabel!
    @IBOutlet weak var constraintHeightviewMobile: NSLayoutConstraint!
    
    @IBOutlet weak var viewTeleNo: UIView!
    @IBOutlet weak var lblTeleNoTitle: UILabel!
    @IBOutlet weak var lblTeleNo: UILabel!
    @IBOutlet weak var constraintHeightviewTeleNo: NSLayoutConstraint!
    
    @IBOutlet weak var viewDesignation: UIView!
    @IBOutlet weak var lblDesignationTitle: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    @IBOutlet weak var constraintHeightviewDesignation: NSLayoutConstraint!
    
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var lblEmailTitle: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var constraintHeightviewEmail: NSLayoutConstraint!
    
    @IBOutlet weak var btnDelete: UIButton!
    @IBAction func btnDeleteTap(_ sender: UIButton) {
        if self.onDeleteTap != nil {
            self.onDeleteTap!(index)
        }
    }
    
    //MARK: - Variable
    
    var index: Int = 0
    var onDeleteTap: ((Int)->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewMain.cornersWFullBorder(radius: 12, borderColor: .black, colorOpacity: 1.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
