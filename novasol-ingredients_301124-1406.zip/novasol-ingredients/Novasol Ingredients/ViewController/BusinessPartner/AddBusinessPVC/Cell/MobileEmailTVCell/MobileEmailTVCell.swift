//
//  MobileEmailTVCell.swift
//  GE Sales
//
//  Created by Auxano on 16/05/24.
//

import UIKit

class MobileEmailTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var costraintBottomViewMainToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var lblValue: UILabel!
    @IBOutlet weak var btnDelete: UIButton!
    @IBAction func btnDeleteTap(_ sender: UIButton) {
        if self.onDeleteTap != nil {
            self.onDeleteTap!(index)
        }
    }
    
    // MARK: - Variable
    
    var index: Int = 0
    var onDeleteTap: ((Int)->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.lblValue.textColor = Colors.darkGray.returnColor()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
