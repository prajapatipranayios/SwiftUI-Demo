//
//  TabCVCell.swift
//  GE Sales
//
//  Created by Auxano on 13/05/24.
//

import UIKit

class TabCVCell: UICollectionViewCell {
    
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblUnderline: UILabel!
    
    @IBOutlet weak var constraintHeightUnderLine: NSLayoutConstraint!
}
