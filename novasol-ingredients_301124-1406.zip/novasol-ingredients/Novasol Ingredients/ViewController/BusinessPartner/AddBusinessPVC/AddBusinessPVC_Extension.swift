//
//  AddBusinessPVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 13/05/24.
//

import Foundation
import UIKit
import Vision

// MARK: - UICollectionView DataSource, Delegate

extension AddBusinessPVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return AddBPTab.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TabCellCV", for: indexPath) as! TabCVCell
        
        cell.lblName.text = AddBPTab[indexPath.item]
        cell.lblName.textColor = (Colors.gray.returnColor()).withAlphaComponent(0.7)
        cell.lblName.backgroundColor = .white
        cell.lblUnderline.backgroundColor = (Colors.gray.returnColor()).withAlphaComponent(0.5)
        cell.constraintHeightUnderLine.constant = 3
        
        if self.intSelectedTab == indexPath.item {
            cell.lblName.textColor = Colors.theme.returnColor()
            cell.lblUnderline.backgroundColor = Colors.theme.returnColor()
            cell.constraintHeightUnderLine.constant = 4
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = ((collectionView.frame.width) / CGFloat(AddBPTab.count)) > 75.0 ? ((collectionView.frame.width) / CGFloat(AddBPTab.count)) : 75.0
        let height = 50.0
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.intSelectedTab = indexPath.item
        self.setupTabView(intSelectedTab: indexPath.item)
        self.colleTab.reloadData()
    }
    
    func setupTabView(intSelectedTab: Int) {
        
        self.dismissMyKeyboard()
        self.resetTab()
        
        switch intSelectedTab {
        case 0:
            self.viewTabCompany.isHidden = false
            self.constraintBottomViewTabCompany.priority = .required
        case 1:
            self.viewTabContact.isHidden = false
            self.constraintBottomViewTabContact.priority = .required
        case 2:
            self.viewTabBilling.isHidden = false
            self.constraintBottomViewTabBilling.priority = .required
        case 3:
            self.viewTabDelivery.isHidden = false
            self.constraintBottomViewTabDelivery.priority = .required
        case 4:
            self.viewTabTransport.isHidden = false
            self.constraintBottomViewTabTransport.priority = .required
            self.getTransporter(intCourier: 0, searchText: "", page: self.page, companyType: 1)
        default:
            return
        }
    }
    
    func resetTab() {
        self.viewTabCompany.isHidden = true
        self.constraintBottomViewTabCompany.priority = .defaultLow
        
        self.viewTabContact.isHidden = true
        self.constraintBottomViewTabContact.priority = .defaultLow
        
        self.viewTabBilling.isHidden = true
        self.constraintBottomViewTabBilling.priority = .defaultLow
        
        self.viewTabDelivery.isHidden = true
        self.constraintBottomViewTabDelivery.priority = .defaultLow
        
        self.viewTabTransport.isHidden = true
        self.constraintBottomViewTabTransport.priority = .defaultLow
    }
}

// MARK: - UITableView Delegate, DataSource

extension AddBusinessPVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tvMobileNo {
            return self.arrMobileNo?.count ?? 0
        }
        else if tableView == self.tvEmail {
            return self.arrEmail?.count ?? 0
        }
        else if tableView == self.tvCompanyAlreadyExist {
            return self.arrBMList?.count ?? 0
        }
        else if tableView == self.tvContactList {
            return self.arrContactList?.count ?? 0
        }
        else if tableView == self.tvTransportList {
            return self.arrTransporters?.count ?? 0
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == self.tvMobileNo {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MobileEmailTVCell", for: indexPath) as! MobileEmailTVCell
            cell.index = indexPath.row
            cell.lblValue.text = self.arrMobileNo?[indexPath.row]
            cell.onDeleteTap = { index in
                self.arrMobileNo?.remove(at: index)
                self.setOtherMobileEmail()
            }
            return cell
        }
        else if tableView == self.tvEmail {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MobileEmailTVCell", for: indexPath) as! MobileEmailTVCell
            cell.index = indexPath.row
            cell.lblValue.text = self.arrEmail?[indexPath.row]
            cell.onDeleteTap = { index in
                self.arrEmail?.remove(at: index)
                self.setOtherMobileEmail()
            }
            return cell
        }
        else if tableView == self.tvCompanyAlreadyExist {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CompanyCell", for: indexPath) as! CompanyNameTVCell
            cell.lblCompanyName.text = self.arrBMList?[indexPath.row].bmName ?? ""
            cell.lblAddress.text = self.arrBMList?[indexPath.row].cityName ?? ""
            
            if hasMore {
                if indexPath.row >= ((self.arrBMList?.count ?? 0) - 5) {
                    self.page += 1
                    self.getExistBusinessPaartner(searchText: self.strSearchText ?? "", page: self.page)
                }
            }
            
            return cell
        }
        else if tableView == self.tvContactList {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddContactTVCell", for: indexPath) as! AddContactTVCell
            
            cell.index = indexPath.row
            cell.lblName.text = self.arrContactList?[indexPath.row].name ?? ""
            cell.lblMobileNo.text = self.arrContactList?[indexPath.row].pContact ?? ""
            cell.lblTeleNo.text = self.arrContactList?[indexPath.row].sContact ?? ""
            cell.lblDesignation.text = self.arrContactList?[indexPath.row].designation ?? ""
            cell.lblEmail.text = self.arrContactList?[indexPath.row].email ?? ""
            
            cell.constraintHeightviewTeleNo.priority = .defaultLow
            cell.constraintHeightviewDesignation.priority = .defaultLow
            if self.arrContactList?[indexPath.row].sContact ?? "" == "" {
                cell.constraintHeightviewTeleNo.priority = .required
            }
            if self.arrContactList?[indexPath.row].designation ?? "" == "" {
                cell.constraintHeightviewDesignation.priority = .required
            }
            
            cell.onDeleteTap = { index in
                self.arrContactList?.remove(at: index)
                self.tvContactList.reloadData()
                self.constraintHeightTVContactList.constant = CGFloat((self.arrContactList?.count ?? 0) >= 2 ? (166 * 2) : 166 )
                
                if (self.arrContactList?.count ?? 0) >= 2 {
                    self.tvContactList.isScrollEnabled = true
                }
                else {
                    self.tvContactList.isScrollEnabled = false
                }
            }
            return cell
        }
        else if tableView == self.tvTransportList {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TransportTVCell", for: indexPath) as! TransportTVCell
            cell.index = indexPath.row
            cell.lblName.text = self.arrTransporters?[indexPath.row].transporterTitle ?? ""
            cell.lblName.textColor = Colors.theme.returnColor()
            
            if (self.arrSelectedTransporter ?? []).contains("\(self.arrTransporters?[indexPath.row].transporterId ?? 0)") {
                cell.btnSelect.isSelected = true
                cell.btnSelect.tintColor = Colors.themeGreen.returnColor()
            }
            else {
                cell.btnSelect.isSelected = false
                cell.btnSelect.tintColor = Colors.gray.returnColor()
            }
            
            cell.didSelect = { section, index in
                if (self.arrSelectedTransporter ?? []).contains("\(self.arrTransporters?[index].transporterId ?? 0)") {
                    for z in 0 ..< (self.arrSelectedTransporter?.count ?? 0) {
                        if self.arrSelectedTransporter?[z] ?? "" == "\(self.arrTransporters?[index].transporterId ?? 0)" {
                            self.arrSelectedTransporter?.remove(at: z)
                            break
                        }
                    }
                }
                else {
                    if (self.arrSelectedTransporter?.count ?? 0) < 3 {
                        self.arrSelectedTransporter?.append("\(self.arrTransporters?[index].transporterId ?? 0)")
                    }
                    else {
                        Utilities.showPopup(title: Messages.AddBPTransporterMsg, type: .warning)
                    }
                }
                self.tvTransportList.reloadData()
            }
            
            if hasMore {
                if indexPath.row >= ((self.arrTransporters?.count ?? 0) - 5) {
                    self.page += 1
                    self.getTransporter(intCourier: 0, searchText: self.searchText, page: self.page, companyType: 1)
                }
            }
            return cell
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (tableView == self.tvCompanyAlreadyExist) || (tableView == self.tvContactList) {
            return UITableView.automaticDimension
        }
        else if (tableView == self.tvTransportList) {
            return 35
        }
        return 33.0
    }
    
    func setOtherMobileEmail() {
        self.constraintHeightTVMobileNo.constant = CGFloat((self.arrMobileNo?.count ?? 0)) * 33.0
        self.constraintHeightTVEmail.constant = CGFloat((self.arrEmail?.count ?? 0)) * 33.0
        
        self.tvMobileNo.reloadData()
        self.tvEmail.reloadData()
    }
}

// MARK: - SearchBar Delegate

extension AddBusinessPVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchText = searchText
        self.page = 1
        
        self.getTransporter(intCourier: 0, searchText: self.searchText, page: self.page, companyType: 1)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        self.searchBar.text = ""
        self.searchText = ""
        self.page = 1
        
        self.getTransporter(intCourier: 0, searchText: self.searchText, page: self.page, companyType: 1)
    }
}

// MARK: - UITextFieldDelegate

extension AddBusinessPVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        if textField == self.txtCompanyName {
            self.page = 1
            self.strSearchText = newString as String
            self.getExistBusinessPaartner(searchText: self.strSearchText ?? "", page: self.page)
            return true
        }
        else if (textField == self.txtTeleNo) || (textField == self.txtSContactNo) {
            if (self.txtTeleNo.text?.isNumber)! || (self.txtSContactNo.text?.isNumber)! {
                return newString.length <= MAX_TELE_LENGTH
            }
            else {
                return true
            }
        }
        else if (textField == self.txtMobileNo) || (textField == self.txtPContactNo) {
            if (self.txtMobileNo.text?.isNumber)! || (self.txtPContactNo.text?.isNumber)! {
                return newString.length <= MAX_MOBILE_LENGTH
            }
            else {
                return true
            }
        }
        else if (textField == self.txtZipCode) || (textField == self.txtDZipCode) {
            if (self.txtZipCode.text?.isNumber)! || (self.txtDZipCode.text?.isNumber)! {
                return newString.length <= MAX_ZIP_LENGTH
            }
            else {
                return true
            }
        }
        else if textField == self.txtAnnualTurnover {
            switch string {
            case "0","1","2","3","4","5","6","7","8","9":
                return true
            case ".":
                let array = (textField.text)!.map { String($0) }
                var decimalCount = 0
                for character in array {
                    if character == "." {
                        decimalCount += 1
                    }
                }
                
                if decimalCount == 1 {
                    return false
                } else {
                    return true
                }
            default:
                let array = Array(string)
                if array.count == 0 {
                    return true
                }
                return false
            }
        }
        else if textField == self.txtPAN {
            return newString.length <= MAX_MOBILE_LENGTH
        }
        else {
            return true
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //self.txtCompanyName.resignFirstResponder()
        textField.resignFirstResponder()
           
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        if self.checkValidation(to: textField.tag, from: textField.tag + 1) {
        }
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            
            // Company 0 - 11
            if i == 0 {
                self.txtCompanyName.text = self.txtCompanyName.text?.trimmingCharacters(in: .whitespaces)
                
                if self.txtCompanyName.text == "" {
                    self.lblErrorCompanyName.getEmptyValidationString((self.txtCompanyName.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorCompanyName.text = ""
                }
            }
            else if i == 1 {
                self.txtTeleNo.text = self.txtTeleNo.text?.trimmingCharacters(in: .whitespaces)
                
                if self.txtTeleNo.text != "" {
                    if (txtTeleNo.text?.isNumber)! {
                        if !((txtTeleNo.text?.count)! >= MIN_TELE_LENGTH) {
                            self.lblErrorTeleNo.setLeftArrow(title: Valid_Telephone)
                            value = false
                        }
                        else if !((txtTeleNo.text?.count)! <= MAX_TELE_LENGTH) {
                            self.lblErrorTeleNo.setLeftArrow(title: Valid_Telephone)
                            value = false
                        }
                        else {
                            self.lblErrorTeleNo.text = ""
                        }
                    }
                }
                else {
                    self.lblErrorTeleNo.text = ""
                }
            }
            else if i == 2 {
                self.txtMobileNo.text = self.txtMobileNo.text?.trimmingCharacters(in: .whitespaces)
                
                if self.txtMobileNo.text == "" {
                    if (self.arrMobileNo?.count ?? 0) == 0 {
                        self.lblErrorMobileNo.getEmptyValidationString((txtMobileNo.placeholder ?? "").lowercased())
                        value = false
                    }
                }
                else {
                    if (txtMobileNo.text?.isNumber)! {
                        if !((txtMobileNo.text?.count)! >= MIN_MOBILE_LENGTH) {
                            self.lblErrorMobileNo.setLeftArrow(title: Valid_Mobile)
                            value = false
                        }
                        else if !((txtMobileNo.text?.count)! <= MAX_MOBILE_LENGTH) {
                            self.lblErrorMobileNo.setLeftArrow(title: Valid_Mobile)
                            value = false
                        }
                        else {
                            self.lblErrorMobileNo.text = ""
                        }
                    }
                    else {
                        self.lblErrorMobileNo.text = ""
                    }
                }
            }
            else if i == 3 {
                self.txtEmailId.text = self.txtEmailId.text?.trimmingCharacters(in: .whitespaces)
                if self.txtEmailId.text == "" {
                    if (self.arrEmail?.count ?? 0) == 0 {
                        self.lblErrorEmailId.getEmptyValidationString((txtEmailId.placeholder ?? "").lowercased())
                        value = false
                    }
                }
                else if !Validations.isValid(email: self.txtEmailId.text!) {
                    self.lblErrorEmailId.setLeftArrow(title: Valid_Email)
                    value = false
                }
                else {
                    self.lblErrorEmailId.text = ""
                }
            }
            else if i == 4 {
                self.txtWebSite.text = self.txtWebSite.text?.trimmingCharacters(in: .whitespaces)
            }
            else if i == 5 {
                self.txtCreditLimit.text = self.txtCreditLimit.text?.trimmingCharacters(in: .whitespaces)
                if self.txtCreditLimit.text == "" {
                    self.lblErrorCreditLimit.getEmptyValidationString((txtCreditLimit.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorCreditLimit.text = ""
                }
            }
            else if i == 6 {
                self.txtDiscountPercent.text = self.txtDiscountPercent.text?.trimmingCharacters(in: .whitespaces)
            }
            else if i == 7 {
                self.txtExistingBusiness.text = self.txtExistingBusiness.text?.trimmingCharacters(in: .whitespaces)
            }
            else if i == 8 {
                self.txtAnnualTurnover.text = self.txtAnnualTurnover.text?.trimmingCharacters(in: .whitespaces)
                if self.txtAnnualTurnover.text == "" {
                    self.lblErrorAnnualTurnover.getEmptyValidationString((txtAnnualTurnover.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorAnnualTurnover.text = ""
                }
            }
            else if i == 9 {
                self.txtPAN.text = self.txtPAN.text?.trimmingCharacters(in: .whitespaces)
                if self.txtPAN.text == "" {
                    self.lblErrorPAN.getEmptyValidationString(("pancard").lowercased())
                    value = false
                }
                else if !Validations.isValidPAN(self.txtPAN.text!) {
                    self.lblErrorPAN.setLeftArrow(title: Valid_PAN)
                    value = false
                }
                else {
                    self.lblErrorPAN.text = ""
                }
            }
            else if i == 10 {
                self.txtEstablishmentYear.text = self.txtEstablishmentYear.text?.trimmingCharacters(in: .whitespaces)
                if self.txtEstablishmentYear.text == "" {
                    self.lblErrorEstablishmentYear.getEmptyValidationString((txtEstablishmentYear.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorEstablishmentYear.text = ""
                }
            }
            else if i == 11 {
                self.txtSalesPersonAccountable.text = self.txtSalesPersonAccountable.text?.trimmingCharacters(in: .whitespaces)
                if self.txtSalesPersonAccountable.text == "" {
                    self.lblErrorSalesPersonAccountable.getEmptyValidationString((txtSalesPersonAccountable.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorSalesPersonAccountable.text = ""
                }
            }
            
            // Contact  12 - 16
            else if i == 12 {
                self.txtContactName.text = self.txtContactName.text?.trimmingCharacters(in: .whitespaces)
                if self.txtContactName.text == "" {
                    self.lblErrorContactName.getEmptyValidationString((txtContactName.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorContactName.text = ""
                }
            }
            else if i == 13 {
                self.txtPContactNo.text = self.txtPContactNo.text?.trimmingCharacters(in: .whitespaces)
                if self.txtPContactNo.text == "" {
                    self.lblErrorPContactNo.getEmptyValidationString((txtPContactNo.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    if (self.txtPContactNo.text?.isNumber)! {
                        if !((self.txtPContactNo.text?.count)! >= MIN_MOBILE_LENGTH) {
                            self.lblErrorPContactNo.setLeftArrow(title: Valid_Mobile)
                            value = false
                        }
                        else if !((self.txtPContactNo.text?.count)! <= MAX_MOBILE_LENGTH) {
                            self.lblErrorPContactNo.setLeftArrow(title: Valid_Mobile)
                            value = false
                        }
                        else {
                            self.lblErrorPContactNo.text = ""
                        }
                    }
                    else {
                        self.lblErrorPContactNo.setLeftArrow(title: Valid_Mobile)
                        value = false
                    }
                }
            }
            else if i == 14 {
                self.txtSContactNo.text = self.txtSContactNo.text?.trimmingCharacters(in: .whitespaces)
                
                if self.txtSContactNo.text != "" {
                    if (self.txtSContactNo.text?.isNumber)! {
                        if !((self.txtSContactNo.text?.count)! >= MIN_TELE_LENGTH) {
                            self.lblErrorSContactNo.setLeftArrow(title: Valid_Telephone)
                            value = false
                        }
                        else if !((self.txtSContactNo.text?.count)! <= MAX_TELE_LENGTH) {
                            self.lblErrorSContactNo.setLeftArrow(title: Valid_Telephone)
                            value = false
                        }
                        else {
                            self.lblErrorSContactNo.text = ""
                        }
                    }
                }
                else {
                    self.lblErrorSContactNo.text = ""
                }
            }
            else if i == 15 {
                self.txtEmail.text = self.txtEmail.text?.trimmingCharacters(in: .whitespaces)
                if self.txtEmail.text == "" {
                    self.lblErrorEmail.getEmptyValidationString((txtEmail.placeholder ?? "").lowercased())
                    value = false
                }
                else if !Validations.isValid(email: self.txtEmail.text!) {
                    self.lblErrorEmail.setLeftArrow(title: Valid_Email)
                    value = false
                }
                else {
                    self.lblErrorEmail.text = ""
                }
            }
            else if i == 16 {
                self.txtDesignation.text = self.txtDesignation.text?.trimmingCharacters(in: .whitespaces)
                /*if self.txtDesignation.text != "" {
                    self.lblErrorDesignation.getEmptyValidationString((txtDesignation.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorDesignation.text = ""
                }   //  */
            }
            
            // Billing  -   17 to 25
            else if i == 17 {
                self.txtAddressTitle.text = self.txtAddressTitle.text?.trimmingCharacters(in: .whitespaces)
                if self.txtAddressTitle.text == "" {
                    self.lblErrorAddressTitle.getEmptyValidationString((txtAddressTitle.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorAddressTitle.text = ""
                    if self.isSameAsBillingInfo {
                        self.setDataAsBilling(isTrue: true)
                    }
                }
            }
            else if i == 18 {
                self.txtBlockNo.text = self.txtBlockNo.text?.trimmingCharacters(in: .whitespaces)
                if self.txtBlockNo.text == "" {
                    self.lblErrorBlockNo.getEmptyValidationString((txtBlockNo.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorBlockNo.text = ""
                    if self.isSameAsBillingInfo {
                        self.setDataAsBilling(isTrue: true)
                    }
                }
            }
            else if i == 19 {
                self.txtBuildingFloorRoom.text = self.txtBuildingFloorRoom.text?.trimmingCharacters(in: .whitespaces)
                if self.txtBuildingFloorRoom.text == "" {
                    self.lblErrorBuildingFloorRoom.getEmptyValidationString((txtBuildingFloorRoom.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorBuildingFloorRoom.text = ""
                    if self.isSameAsBillingInfo {
                        self.setDataAsBilling(isTrue: true)
                    }
                }
            }
            else if i == 20 {
                self.txtStreetPOBox.text = self.txtStreetPOBox.text?.trimmingCharacters(in: .whitespaces)
                if self.txtStreetPOBox.text == "" {
                    self.lblErrorStreetPOBox.getEmptyValidationString((txtStreetPOBox.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorStreetPOBox.text = ""
                    if self.isSameAsBillingInfo {
                        self.setDataAsBilling(isTrue: true)
                    }
                }
            }
            else if i == 21 {
                self.txtStreetNo.text = self.txtStreetNo.text?.trimmingCharacters(in: .whitespaces)
                if self.txtStreetNo.text == "" {
                    self.lblErrorStreetNo.getEmptyValidationString((txtStreetNo.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorStreetNo.text = ""
                    if self.isSameAsBillingInfo {
                        self.setDataAsBilling(isTrue: true)
                    }
                }
            }
            else if i == 22 {
                self.txtZipCode.text = self.txtZipCode.text?.trimmingCharacters(in: .whitespaces)
                if self.txtZipCode.text == "" {
                    self.lblErrorZipCode.getEmptyValidationString((txtZipCode.placeholder ?? "").lowercased())
                    value = false
                }
                else if !Validations.isValidZip(self.txtZipCode.text!) {
                    self.lblErrorZipCode.setLeftArrow(title: Valid_Zip)
                    value = false
                }
                else {
                    self.lblErrorZipCode.text = ""
                    if self.isSameAsBillingInfo {
                        self.setDataAsBilling(isTrue: true)
                    }
                }
            }
            else if i == 23 {
                self.txtLandmark.text = self.txtLandmark.text?.trimmingCharacters(in: .whitespaces)
                /*if self.txtLandmark.text == "" {
                    self.lblErrorLandmark.getEmptyValidationString((txtLandmark.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorLandmark.text = ""
                }   //  */
                if self.isSameAsBillingInfo {
                    self.setDataAsBilling(isTrue: true)
                }
            }
            else if i == 24 {
                /*self.txtCountry.text = self.txtCountry.text?.trimmingCharacters(in: .whitespaces)
                if self.txtContactName.text == "" {
                    self.lblErrorCountry.getEmptyValidationString((txtCountry.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorCountry.text = ""
                }   //  */
            }
            else if i == 25 {
                if self.isGSTRequired {
                    self.txtGSTNo.text = self.txtGSTNo.text?.trimmingCharacters(in: .whitespaces)
                    if self.txtGSTNo.text == "" {
                        self.lblErrorGSTNo.getEmptyValidationString((txtGSTNo.placeholder ?? "").lowercased())
                        value = false
                    }
                    else if !Validations.isValidGSTNo(self.txtGSTNo.text!) {
                        self.lblErrorGSTNo.setLeftArrow(title: Valid_GSTNo)
                    }
                    else {
                        self.lblErrorGSTNo.text = ""
                        if self.isSameAsBillingInfo {
                            self.setDataAsBilling(isTrue: true)
                        }
                    }
                }
            }
            
            // Delivery  -   26 to 34
            else if i == 26 {
                self.txtDAddressTitle.text = self.txtDAddressTitle.text?.trimmingCharacters(in: .whitespaces)
                if self.txtDAddressTitle.text == "" {
                    self.lblErrorDAddressTitle.getEmptyValidationString((txtDAddressTitle.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorDAddressTitle.text = ""
                }
            }
            else if i == 27 {
                self.txtDBlockNo.text = self.txtDBlockNo.text?.trimmingCharacters(in: .whitespaces)
                if self.txtDBlockNo.text == "" {
                    self.lblErrorDBlockNo.getEmptyValidationString((txtDBlockNo.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorDBlockNo.text = ""
                }
            }
            else if i == 28 {
                self.txtDBuildingFloorRoom.text = self.txtDBuildingFloorRoom.text?.trimmingCharacters(in: .whitespaces)
                if self.txtDBuildingFloorRoom.text == "" {
                    self.lblErrorDBuildingFloorRoom.getEmptyValidationString((txtDBuildingFloorRoom.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorDBuildingFloorRoom.text = ""
                }
            }
            else if i == 29 {
                self.txtDStreetPOBox.text = self.txtDStreetPOBox.text?.trimmingCharacters(in: .whitespaces)
                if self.txtDStreetPOBox.text == "" {
                    self.lblErrorDStreetPOBox.getEmptyValidationString((txtDStreetPOBox.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorDStreetPOBox.text = ""
                }
            }
            else if i == 30 {
                self.txtDStreetNo.text = self.txtDStreetNo.text?.trimmingCharacters(in: .whitespaces)
                if self.txtDStreetNo.text == "" {
                    self.lblErrorDStreetNo.getEmptyValidationString((txtDStreetNo.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorDStreetNo.text = ""
                }
            }
            else if i == 31 {
                self.txtDZipCode.text = self.txtDZipCode.text?.trimmingCharacters(in: .whitespaces)
                if self.txtDZipCode.text == "" {
                    self.lblErrorDZipCode.getEmptyValidationString((txtDZipCode.placeholder ?? "").lowercased())
                    value = false
                }
                else if !Validations.isValidZip(self.txtDZipCode.text!) {
                    self.lblErrorDZipCode.setLeftArrow(title: Valid_Zip)
                    value = false
                }
                else {
                    self.lblErrorDZipCode.text = ""
                }
            }
            else if i == 32 {
                self.txtDLandmark.text = self.txtDLandmark.text?.trimmingCharacters(in: .whitespaces)
                /*if self.txtLandmark.text == "" {
                    self.lblErrorLandmark.getEmptyValidationString((txtLandmark.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorLandmark.text = ""
                }   //  */
            }
            else if i == 33 {
                /*self.txtCountry.text = self.txtCountry.text?.trimmingCharacters(in: .whitespaces)
                if self.txtCountry.text == "" {
                    self.lblErrorCountry.getEmptyValidationString((txtCountry.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorCountry.text = ""
                }   //  */
            }
            else if i == 34 {
                if self.isDGSTRequired {
                    self.txtDGSTNo.text = self.txtDGSTNo.text?.trimmingCharacters(in: .whitespaces)
                    if self.txtDGSTNo.text == "" {
                        self.lblErrorDGSTNo.getEmptyValidationString((txtDGSTNo.placeholder ?? "").lowercased())
                        value = false
                    }
                    else if !Validations.isValidGSTNo(self.txtDGSTNo.text!) {
                        self.lblErrorDGSTNo.setLeftArrow(title: Valid_GSTNo)
                    }
                    else {
                        self.lblErrorDGSTNo.text = ""
                    }
                }
            }
            
            // Add Transport
            else if i == 34 {
                self.txtTransportTitle.text = self.txtTransportTitle.text?.trimmingCharacters(in: .whitespaces)
                if self.txtTransportTitle.text == "" {
                    self.lblErrorTransportTitle.text = "Please \((self.txtTransportTitle.placeholder ?? "").lowercased())"
                    value = false
                }
                else {
                    self.lblErrorTransportTitle.text = ""
                }
            }
        }
        return value
    }
}

// MARK: - Get Text from Image.

extension AddBusinessPVC {
    func recognizeTextInImage(_ image: UIImage?) {
        self.showLoading()
        
        guard let cgImage = image?.cgImage else { return }
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        let request = VNRecognizeTextRequest { (request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            let recognizedStrings = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }
            
            // Process the recognized text as needed
            print("Add BUsiness P")
            print(recognizedStrings.joined(separator: "\n"))
            let lettersAndSpacesCharacterSet = CharacterSet.letters.union(.whitespaces).inverted
            //let numberAndSpacesCharacterSet = CharacterSet.
            //let testValid1 = "Jon Doe".rangeOfCharacter(from: lettersAndSpacesCharacterSet) == nil // true
            //let testInvalid1 = "Ben&Jerry".rangeOfCharacter(from: lettersAndSpacesCharacterSet) == nil // false
            //let testInvalid2 = "Peter2".rangeOfCharacter(from: lettersAndSpacesCharacterSet) == nil // false
            
            for i in 0 ..< recognizedStrings.count {
                if Validations.isValid(email: recognizedStrings[i]) {
                    self.txtEmail.text = recognizedStrings[i]
                }
                else if recognizedStrings[i].rangeOfCharacter(from: lettersAndSpacesCharacterSet) == nil {
                    self.txtContactName.text = recognizedStrings[i]
                }
                else if Validations.isValidScanNo(recognizedStrings[i]) {
                    self.txtPContactNo.text = recognizedStrings[i]
                }
            }
            
            self.hideLoading()
        }
        request.recognitionLevel = .accurate
        do {
            try requestHandler.perform([request])
        } catch {
            print(error)
        }
    }
}

// MARK: - Webservices

extension AddBusinessPVC {
    
    func getMyTeam(intCompanyType: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getMyTeam(intCompanyType: intCompanyType)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": intCompanyType
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_MY_TEAM, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrMyTeamMember = response?.result?.teamMembers ?? []
                    
                    if self.arrMyTeamMember!.count > 0 {
                        self.lblSelectSalesPerson.text = self.arrMyTeamMember?[0].name ?? ""
                    }
                }
            }
            else {
                
            }
        }
    }
    
    func getIndustriesCategoryList() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getIndustriesCategoryList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_INDUSTRIES_CATEGORY_LIST, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrIndustriesCategory = response?.result?.industriesCategory ?? []
                }
            }
            else {
                
            }
        }
    }
    
    func getStates() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getStates()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_STATES, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrState = response?.result?.state ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getCities(intStateId: Int = 0, isDelivery: Bool = false) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getCities(intStateId: intStateId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "state_id": intStateId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_CITIES, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    if !isDelivery {
                        self.arrCity = response?.result?.city ?? []
                    }
                    else {
                        self.arrDCity = response?.result?.city ?? []
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getExistBusinessPaartner(searchText: String, page: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getExistBusinessPaartner(searchText: searchText, page: page)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "search_value": searchText,
            "page": page
        ] as [String: Any]
        
        //showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.SEARCH_EXIST_BUSINESS_PARTNER, parameters: param) { (response: ApiResponseBusinessP?, error) in
            //self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    let arrTempBMList = response?.result?.bmList ?? []
                    self.hasMore = response?.result?.hasMore ?? false
                    if page == 1 {
                        self.arrBMList = arrTempBMList
                    }
                    else if page > 1 {
                        self.arrBMList?.append(contentsOf: arrTempBMList)
                    }
                    self.constraintHeightViewCompanyAlreadyExist.constant = CGFloat((self.arrBMList?.count ?? 0) > 5 ? (5 * 65) : ((self.arrBMList?.count ?? 0) * 65))
                    self.tvCompanyAlreadyExist.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getTransporter(intCourier: Int = 0, searchText: String, page: Int, companyType: Int = 1) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getTransporter(intCourier: intCourier, searchText: searchText, page: page, companyType: companyType)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "is_courier": intCourier,
            "search_value": searchText,
            "page": page,
            "company_type": APIManager.sharedManager.companyType ?? 1
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_TRANSPORTERS, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    let arrTempTransporters = response?.result?.transporters ?? []
                    if page == 1 {
                        self.arrTransporters = arrTempTransporters
                    }
                    else if page > 1 {
                        self.arrTransporters?.append(contentsOf: arrTempTransporters)
                    }
                    self.tvTransportList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func addTransporter() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addTransporter()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": APIManager.sharedManager.companyType ?? 1,
            "transporter_title": self.txtTransportTitle.text!,
            "transporter_email_id": self.txtTransportEmail.text!,
            "transporter_tel_no": self.txtTransportTelNo.text!,
            "transporter_mobile_no": self.txtTransportMobile.text!,
            "transporter_address": self.txtTransportAddress.text!,
            "transporter_desc": self.txtTransportDesc.text!,
            "transporter_GSTNo": self.txtTransportGSTNo.text!
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_TRANSPORTER, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.viewMain.isHidden = false
                    self.viewTransport.isHidden = true
                    
                    self.txtTransportTitle.text = ""
                    self.txtTransportEmail.text = ""
                    self.txtTransportTelNo.text = ""
                    self.txtTransportMobile.text = ""
                    self.txtTransportGSTNo.text = ""
                    self.txtTransportAddress.text = ""
                    self.txtTransportDesc.text = ""
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func verifyGSTNumber(gstNo: String, stateId: Int, cityId: Int, pincode: String, addressType: Int, isDelivery: Bool = false) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.verifyGSTNumber(gstNo: gstNo, stateId: stateId, cityId: cityId, pincode: pincode, addressType: addressType, isDelivery: isDelivery)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "gst_no": gstNo,
            "state_id": stateId,
            "city_id": cityId,
            "pin_code": pincode,
            "addressType": addressType
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GST_NUMBER_VERIFY, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    if !isDelivery {
                        self.isBillingAddVerify = true
                        if self.isSameAsBillingInfo {
                            self.isDeliveryAddVerify = true
                        }
                        else {
                            self.verifyGSTNumber(gstNo: self.txtDGSTNo.text!, stateId: self.intDStateId, cityId: self.intDCityId, pincode: self.txtDZipCode.text!, addressType: 2, isDelivery: true)
                        }
                    }
                    else {
                        self.isBillingAddVerify = true
                        self.isDeliveryAddVerify = true
                    }
                    
                    if self.isBillingAddVerify && self.isDeliveryAddVerify {
                        self.addBusinessP(legalName: response?.result?.legalName ?? "")
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func addBusinessP(legalName: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addBusinessP(legalName: legalName)
                }
            }
            return
        }
        
        let tempBranch = APIManager.sharedManager.arrBranches?.filter{ ($0.branchName! == self.lblBranch.text!) }
        let tempBranchId = tempBranch?[0].id ?? 0
        
        var temptempSalesPersonId: Int = 0
        let tempSalesPerson = self.arrMyTeamMember?.filter{ ($0.name! == self.lblSelectSalesPerson.text!) }
        temptempSalesPersonId = tempSalesPerson?[0].id ?? 0
        
        var arrTempMobileNo: [String] = self.arrMobileNo ?? []
        if self.txtMobileNo.text ?? "" != "" {
            arrTempMobileNo.append(self.txtMobileNo.text!)
        }
        
        var arrTempEmail: [String] = self.arrEmail ?? []
        if self.txtEmailId.text ?? "" != "" {
            arrTempEmail.append(self.txtEmailId.text!)
        }
        
        let companyInfo: [String: Any] = [ "name": self.txtCompanyName.text!,
                                           "telephone_no": self.txtTeleNo.text!,
                                           "mobile_no": arrTempMobileNo,
                                           "email": arrTempEmail,
                                           "web_url": self.txtWebSite.text!,
                                           "credit_limit": self.txtCreditLimit.text!,
                                           "discount_percent": self.txtDiscountPercent.text!,
                                           "existing_business": self.txtExistingBusiness.text!,
                                           "annual_turnover": self.txtAnnualTurnover.text!,
                                           "currency_type": self.lblATurnoverUnit.text!,
                                           "business_partner_PanNo": self.txtPAN.text!,
                                           "business_partner_sales_person_accountable": self.txtSalesPersonAccountable.text!,
                                           "business_type": self.lblBusinessType.text!,
                                           "industry_type": self.lblIndustriesCategory.text!,
                                           "branch_id": tempBranchId,
                                           "establishment_year": self.txtEstablishmentYear.text!,
                                           "firm_type": self.lblTypeOfFirms.text!,
                                           "sales_person_id": temptempSalesPersonId,
                                           "payment_type": self.intPaymentInfo,
                                           "credit_day_limit": self.intPaymentInfo == 3 ? self.lblCraditDays.text! : "0",
                                           "company_type": APIManager.sharedManager.companyType ?? 1,
                                           "legal_name": legalName,
                                           "UseBillTo": self.isUseBillToAdd,
        ]
        
        var contact_info: [Any] = []
        for i in 0 ..< (self.arrContactList ?? []).count {
            let contact : [String: Any] = [ "contact_person_name": self.arrContactList?[i].name ?? "",
                                            "contact_person_phone_primary": self.arrContactList?[i].pContact ?? "",
                                            "contact_person_phone_secondary": self.arrContactList?[i].sContact ?? "",
                                            "contact_person_email": self.arrContactList?[i].email ?? "",
                                            "contact_person_designation": self.arrContactList?[i].designation ?? ""]
            contact_info.append(contact)
        }
        
        let billing_address: [String: Any] = [ "address_type": 1,
                                               "address_location_type": self.isWareHouse ? "Warehouse" : "Office",
                                               "address_title": self.txtAddressTitle.text!,
                                               "block_no": self.txtBlockNo.text!,
                                               "building_floor_room": self.txtBuildingFloorRoom.text!,
                                               "street_no": self.txtStreetNo.text!,
                                               "street_po_box": self.txtStreetPOBox.text!,
                                               "city_id": self.intCityId,
                                               "landmark": self.txtLandmark.text!,
                                               "pin_code": self.txtZipCode.text!,
                                               "state_id": self.intStateId,
                                               "country_id": 1,
                                               "city_name": self.lblSelectCity.text!,
                                               "is_gst": self.isGSTRequired ? 1 : 0,
                                               "GstIn": self.txtGSTNo.text!
        ]
        
        let delivery_address: [String: Any] = [ "address_type": 2,
                                                "address_location_type": self.isDWareHouse ? "Warehouse" : "Office",
                                                "address_title": self.txtDAddressTitle.text!,
                                                "block_no": self.txtDBlockNo.text!,
                                                "building_floor_room": self.txtDBuildingFloorRoom.text!,
                                                "street_no": self.txtDStreetNo.text!,
                                                "street_po_box": self.txtDStreetPOBox.text!,
                                                "city_id": self.intDCityId,
                                                "landmark": self.txtDLandmark.text!,
                                                "pin_code": self.txtDZipCode.text!,
                                                "state_id": self.intDStateId,
                                                "country_id": 1,
                                                "city_name": self.lblDSelectCity.text!,
                                                "is_gst": self.isDGSTRequired ? 1 : 0,
                                                "GstIn": self.txtDGSTNo.text!
        ]
        
        let transporters: [String: Any] = [ "transporters_id": self.arrSelectedTransporter ?? [] ]
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_info": companyInfo,
            "flag": 0,
            "contact_info": contact_info,
            "billing_address": billing_address,
            "delivery_address": delivery_address,
            "transporters": transporters
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_BUSINESS_PARTNER, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.displayMessage(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func displayMessage(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.navigationController?.popViewController(animated: true)
            APIManager.sharedManager.isRefreshData = true
        }
        self.present(popupVC, animated: true)
    }
}
