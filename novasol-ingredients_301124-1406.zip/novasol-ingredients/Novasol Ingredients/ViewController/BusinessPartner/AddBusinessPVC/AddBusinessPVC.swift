//
//  AddBusinessPVC.swift
//  GE Sales
//
//  Created by Auxano on 13/05/24.
//

import UIKit
import AVFoundation

class AddBusinessPVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = "Are you sure you want to discard \(self.strScreenTitle) ?"
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            self.navigationController?.popViewController(animated: true)
        }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var btnAddBP: UIButton!
    @IBAction func btnAddBPTap(_ sender: UIButton) {
        //Utilities.showPopup(title: "Add button tap.", type: .success)
        //self.checkAllValidation(to: self.txtCompanyName.tag, from: self.txtSalesPersonAccountable.tag + 1)
        self.checkAllValidation()
    }
    
    @IBOutlet weak var viewTab: UIView!
    @IBOutlet weak var lblSeparator1: UILabel!
    @IBOutlet weak var colleTab: UICollectionView! {
        didSet {
            self.colleTab.delegate = self
            self.colleTab.dataSource = self
        }
    }
    
    @IBOutlet weak var viewOutScrollMain: UIView!
    @IBOutlet weak var viewInScrollMain: UIView!
    
    ///     View - 1
    @IBOutlet weak var viewTabCompany: UIView!
    @IBOutlet weak var constraintBottomViewTabCompany: NSLayoutConstraint!
    
    @IBOutlet weak var viewCompanyName: UIView!
    @IBOutlet weak var txtCompanyName: TLTextField!
    @IBOutlet weak var lblErrorCompanyName: UILabel!
    @IBOutlet weak var viewCompanyAlreadyExist: UIView!
    @IBOutlet weak var tvCompanyAlreadyExist: UITableView! {
        didSet {
            self.tvCompanyAlreadyExist.delegate = self
            self.tvCompanyAlreadyExist.dataSource = self
            //self.tvCompanyAlreadyExist.register(UITableViewCell.self, forCellReuseIdentifier: "CompanyCell")
        }
    }
    @IBOutlet weak var constraintHeightViewCompanyAlreadyExist: NSLayoutConstraint!
    
    @IBOutlet weak var viewTeleNo: UIView!
    @IBOutlet weak var txtTeleNo: TLTextField!
    @IBOutlet weak var lblErrorTeleNo: UILabel!
    
    @IBOutlet weak var viewMobileNo: UIView!
    @IBOutlet weak var txtMobileNo: TLTextField!
    @IBOutlet weak var lblErrorMobileNo: UILabel!
    @IBOutlet weak var btnOtherMobileNo: UIButton!
    @IBAction func btnOtherMobileNoTap(_ sender: UIButton) {
        if self.txtMobileNo.text != "" {
            if self.checkValidation(to: self.txtMobileNo.tag, from: self.txtMobileNo.tag + 1) {
                self.arrMobileNo?.append(self.txtMobileNo.text!)
                self.txtMobileNo.text = ""
                self.setOtherMobileEmail()
            }
        }
    }
    @IBOutlet weak var tvMobileNo: UITableView! {
        didSet {
            self.tvMobileNo.delegate = self
            self.tvMobileNo.dataSource = self
            self.tvMobileNo.register(UINib(nibName: "MobileEmailTVCell", bundle: nil), forCellReuseIdentifier: "MobileEmailTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVMobileNo: NSLayoutConstraint!
    
    @IBOutlet weak var viewEmailId: UIView!
    @IBOutlet weak var txtEmailId: TLTextField!
    @IBOutlet weak var lblErrorEmailId: UILabel!
    @IBOutlet weak var btnOtherEmail: UIButton!
    @IBAction func btnOtherEmailTap(_ sender: UIButton) {
        if self.txtEmailId.text != "" {
            if self.checkValidation(to: self.txtEmailId.tag, from: self.txtEmailId.tag + 1) {
                self.arrEmail?.append(self.txtEmailId.text!)
                self.txtEmailId.text = ""
                self.setOtherMobileEmail()
            }
        }
    }
    @IBOutlet weak var tvEmail: UITableView! {
        didSet {
            self.tvEmail.delegate = self
            self.tvEmail.dataSource = self
            self.tvEmail.register(UINib(nibName: "MobileEmailTVCell", bundle: nil), forCellReuseIdentifier: "MobileEmailTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVEmail: NSLayoutConstraint!
    
    @IBOutlet weak var viewWebSite: UIView!
    @IBOutlet weak var txtWebSite: TLTextField!
    @IBOutlet weak var lblErrorWebSite: UILabel!
    
    @IBOutlet weak var viewCreditLimit: UIView!
    @IBOutlet weak var txtCreditLimit: TLTextField!
    @IBOutlet weak var lblErrorCreditLimit: UILabel!
    
    @IBOutlet weak var viewPaymentInfo: UIView!
    @IBOutlet weak var lblPaymentInfo: UILabel!
    @IBOutlet weak var btnAdvancePayment: UIButton!
    @IBAction func btnAdvancePaymentTap(_ sender: UIButton) {
        // value = 1
        self.intPaymentInfo = 1
        
        self.btnAdvancePayment.isSelected = true
        self.btnAdvancePayment.tintColor = Colors.themeGreen.returnColor()
        
        self.btnCreditDays.isSelected = false
        self.btnCreditDays.tintColor = Colors.gray.returnColor()
        self.viewCraditDays.isHidden = true
        
        self.btnAgainstDelivery.isSelected = false
        self.btnAgainstDelivery.tintColor = Colors.gray.returnColor()
        
        self.btnAgainstPDC.isSelected = false
        self.btnAgainstPDC.tintColor = Colors.gray.returnColor()
    }
    
    @IBOutlet weak var btnCreditDays: UIButton!
    @IBAction func btnCreditDaysTap(_ sender: UIButton) {
        // value = 3
        self.intPaymentInfo = 3
        
        self.btnCreditDays.isSelected = true
        self.btnCreditDays.tintColor = Colors.themeGreen.returnColor()
        self.viewCraditDays.isHidden = false
        
        self.btnAdvancePayment.isSelected = false
        self.btnAdvancePayment.tintColor = Colors.gray.returnColor()
        
        self.btnAgainstDelivery.isSelected = false
        self.btnAgainstDelivery.tintColor = Colors.gray.returnColor()
        
        self.btnAgainstPDC.isSelected = false
        self.btnAgainstPDC.tintColor = Colors.gray.returnColor()
    }
    @IBOutlet weak var viewCraditDays: UIView!
    @IBOutlet weak var lblCraditDays: UILabel!
    @IBOutlet weak var btnSelectCraditDays: UIButton!
    @IBAction func btnSelectCraditDaysTap(_ sender: UIButton) {
        let arrCreditDays: [String] = AddBusinessPartner.getCreditDays()
        //arrEmpName.insert("Select Employee Name", at: 0)
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.BPCreditDaysTitle
        popupVC.value = arrCreditDays
        popupVC.selectedValue = self.lblCraditDays.text ?? "5"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { days in
            self.lblCraditDays.text = days
        }
        popupVC.onClose = { days in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var btnAgainstDelivery: UIButton!
    @IBAction func btnAgainstDeliveryTap(_ sender: UIButton) {
        // value = 2
        self.intPaymentInfo = 2
        
        self.btnAgainstDelivery.isSelected = true
        self.btnAgainstDelivery.tintColor = Colors.themeGreen.returnColor()
        
        self.btnAdvancePayment.isSelected = false
        self.btnAdvancePayment.tintColor = Colors.gray.returnColor()
        
        self.btnCreditDays.isSelected = false
        self.btnCreditDays.tintColor = Colors.gray.returnColor()
        self.viewCraditDays.isHidden = true
        
        self.btnAgainstPDC.isSelected = false
        self.btnAgainstPDC.tintColor = Colors.gray.returnColor()
    }
    
    @IBOutlet weak var btnAgainstPDC: UIButton!
    @IBAction func btnAgainstPDCTap(_ sender: UIButton) {
        // value = 4
        self.intPaymentInfo = 4
        
        self.btnAgainstPDC.isSelected = true
        self.btnAgainstPDC.tintColor = Colors.themeGreen.returnColor()
        
        self.btnAdvancePayment.isSelected = false
        self.btnAdvancePayment.tintColor = Colors.gray.returnColor()
        
        self.btnCreditDays.isSelected = false
        self.btnCreditDays.tintColor = Colors.gray.returnColor()
        self.viewCraditDays.isHidden = true
        
        self.btnAgainstDelivery.isSelected = false
        self.btnAgainstDelivery.tintColor = Colors.gray.returnColor()
    }
    
    @IBOutlet weak var viewDiscountPercent: UIView!
    @IBOutlet weak var txtDiscountPercent: TLTextField!
    @IBOutlet weak var lblErrorDiscountPercent: UILabel!
    
    @IBOutlet weak var viewExistingBusiness: UIView!
    @IBOutlet weak var txtExistingBusiness: TLTextField!
    @IBOutlet weak var lblErrorExistingBusiness: UILabel!
    
    @IBOutlet weak var viewAnnualTurnover: UIView!
    @IBOutlet weak var txtAnnualTurnover: TLTextField!
    @IBOutlet weak var lblErrorAnnualTurnover: UILabel!
    
    @IBOutlet weak var viewSelectATurnoverUnit: UIView!
    @IBOutlet weak var lblATurnoverUnit: UILabel!
    @IBOutlet weak var btnSelectATurnoverUnit: UIButton!
    @IBAction func btnSelectATurnoverUnitTap(_ sender: UIButton) {
        let arrATurnoverUnit: [String] = AddBusinessPartner.getATurnoverUnit()
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.BPATurnoverTitle
        popupVC.value = arrATurnoverUnit
        popupVC.selectedValue = self.lblATurnoverUnit.text ?? "Thousand"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { days in
            self.lblATurnoverUnit.text = days
            self.lblErrorAnnualTurnover.text = ""
        }
        popupVC.onClose = { days in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewPAN: UIView!
    @IBOutlet weak var txtPAN: TLTextField!
    @IBOutlet weak var lblErrorPAN: UILabel!
    
    @IBOutlet weak var viewEstablishmentYear: UIView!
    @IBOutlet weak var txtEstablishmentYear: TLTextField!
    @IBOutlet weak var lblErrorEstablishmentYear: UILabel!
    @IBOutlet weak var constraintBottomToSalesPAcc: NSLayoutConstraint!
    
    @IBOutlet weak var viewSalesPerson: UIView!
    @IBOutlet weak var lblSelectSalesPersonTitle: UILabel!
    @IBOutlet weak var viewSelectSalesPerson: UIView!
    @IBOutlet weak var lblSelectSalesPerson: UILabel!
    @IBOutlet weak var btnSelectSalesPerson: UIButton!
    @IBAction func btnSelectSalesPersonTap(_ sender: UIButton) {
        let arrMyTeamM: [String] = (self.arrMyTeamMember ?? []).map { $0.name! }
        if arrMyTeamM.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.BPSSalesPersonTitle
            popupVC.value = arrMyTeamM
            popupVC.selectedValue = self.lblSelectSalesPerson.text ?? "Select Sales Person"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.lblSelectSalesPerson.text = strValue
            }
            popupVC.onClose = { strValue in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    @IBOutlet weak var lblErrorSalesPerson: UILabel!
    
    @IBOutlet weak var viewSalesPersonAccountable: UIView!
    @IBOutlet weak var txtSalesPersonAccountable: TLTextField!
    @IBOutlet weak var lblErrorSalesPersonAccountable: UILabel!
    
    @IBOutlet weak var viewMCompanyType: UIView!
    @IBOutlet weak var viewCompanyType: UIView!
    @IBOutlet weak var lblCompanyType: UILabel!
    @IBOutlet weak var btnCompanyType: UIButton!
    @IBAction func btnCompanyTypeTap(_ sender: UIButton) {
        /*let arrCompanyType: [String] = AddBusinessPartner.getCompanyType()
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = Title.BPCompanyTypeTitle
        popupVC.value = arrCompanyType
        popupVC.selectedValue = self.lblCompanyType.text ?? "Company Type"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strValue in
            self.lblCompanyType.text = strValue
            self.lblErrorCompanyType.text = ""
        }
        popupVC.onClose = { strValue in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)       //  */
    }
    @IBOutlet weak var lblErrorCompanyType: UILabel!
    
    @IBOutlet weak var viewMBranch: UIView!
    @IBOutlet weak var viewBranch: UIView!
    @IBOutlet weak var lblBranch: UILabel!
    @IBOutlet weak var btnBranch: UIButton!
    @IBAction func btnBranchTap(_ sender: UIButton) {
        let arrBranch: [String] = (APIManager.sharedManager.arrBranches ?? []).map { $0.branchName! }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.BPBrachTitle
        popupVC.value = arrBranch
        popupVC.selectedValue = self.lblBranch.text ?? "Select Branch"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { strValue in
            self.lblBranch.text = strValue
            self.lblErrorBranch.text = ""
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblErrorBranch: UILabel!
    
    @IBOutlet weak var viewMIndustriesCategory: UIView!
    @IBOutlet weak var viewIndustriesCategory: UIView!
    @IBOutlet weak var lblIndustriesCategory: UILabel!
    @IBOutlet weak var btnIndustriesCategory: UIButton!
    @IBAction func btnIndustriesCategoryTap(_ sender: UIButton) {
        var arrTempIndustriesCategory: [String] = self.arrIndustriesCategory ?? []
        arrTempIndustriesCategory.insert("Select Industries Category", at: 0)
        
        if arrTempIndustriesCategory.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.BPIndustriesCategoryTitle
            popupVC.value = arrTempIndustriesCategory
            popupVC.selectedValue = self.lblIndustriesCategory.text ?? "Select Industries Category"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.lblIndustriesCategory.text = strValue
                self.lblErrorIndustriesCategory.text = ""
            }
            popupVC.onClose = { strValue in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    @IBOutlet weak var lblErrorIndustriesCategory: UILabel!
    
    @IBOutlet weak var viewMBusinessType: UIView!
    @IBOutlet weak var viewBusinessType: UIView!
    @IBOutlet weak var lblBusinessType: UILabel!
    @IBOutlet weak var btnBusinessType: UIButton!
    @IBAction func btnBusinessTypeTap(_ sender: UIButton) {
        let arrBusinessType: [String] = AddBusinessPartner.getBusinessType()
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = Title.BPBusinessTypeTitle
        popupVC.value = arrBusinessType
        popupVC.selectedValue = self.lblBusinessType.text ?? "Select Business Type"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strValue in
            self.lblBusinessType.text = strValue
            self.lblErrorBusinessType.text = ""
        }
        popupVC.onClose = { strValue in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblErrorBusinessType: UILabel!
    
    @IBOutlet weak var viewMTypeOfFirms: UIView!
    @IBOutlet weak var viewTypeOfFirms: UIView!
    @IBOutlet weak var lblTypeOfFirms: UILabel!
    @IBOutlet weak var btnTypeOfFirms: UIButton!
    @IBAction func btnTypeOfFirmsTap(_ sender: UIButton) {
        let arrTypesOfFirm: [String] = AddBusinessPartner.getTypesOfFirms()
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = Title.BPTypesOfFirmTitle
        popupVC.value = arrTypesOfFirm
        popupVC.selectedValue = self.lblTypeOfFirms.text ?? "Select Type Of Firm"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strValue in
            self.lblTypeOfFirms.text = strValue
            self.lblErrorTypeOfFirms.text = ""
        }
        popupVC.onClose = { strValue in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblErrorTypeOfFirms: UILabel!
    

    ///     View - 2
    
    @IBOutlet weak var viewTabContact: UIView!
    @IBOutlet weak var constraintBottomViewTabContact: NSLayoutConstraint!
    
    @IBOutlet weak var viewContactName: UIView!
    @IBOutlet weak var txtContactName: TLTextField!
    @IBOutlet weak var lblErrorContactName: UILabel!
    @IBOutlet weak var btnScanCard: UIButton!
    @IBAction func btnScanCardTap(_ sender: UIButton) {
        //Camera
        AVCaptureDevice.requestAccess(for: AVMediaType.video) { response in
            if response {
                //access granted
                DispatchQueue.main.async {
                    let cameraVC = CameraViewController()
                    cameraVC.captureImg = { image in
                        self.recognizeTextInImage(image)
                    }
                    self.present(cameraVC, animated: true, completion: nil)
                }
            }
            else {
                
            }
        }
    }
    
    @IBOutlet weak var viewPContactNo: UIView!
    @IBOutlet weak var txtPContactNo: TLTextField!
    @IBOutlet weak var lblErrorPContactNo: UILabel!
    
    @IBOutlet weak var viewSContactNo: UIView!
    @IBOutlet weak var txtSContactNo: TLTextField!
    @IBOutlet weak var lblErrorSContactNo: UILabel!
    
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var txtEmail: TLTextField!
    @IBOutlet weak var lblErrorEmail: UILabel!
    
    @IBOutlet weak var viewDesignation: UIView!
    @IBOutlet weak var txtDesignation: TLTextField!
    @IBOutlet weak var lblErrorDesignation: UILabel!
    
    @IBOutlet weak var viewNote: UIView!
    @IBOutlet weak var lblNote: UILabel!
    
    @IBOutlet weak var btnSave: UIButton!
    @IBAction func btnSaveTap(_ sender: UIButton) {
        if self.checkValidation(to: self.txtContactName.tag, from: self.txtDesignation.tag + 1) {
            print("validation Success -- Add to contact")
            let tempContact = AddBPContact( name: self.txtContactName.text!,
                                            pContact: self.txtPContactNo.text!,
                                            sContact: self.txtSContactNo.text!,
                                            email: self.txtEmail.text!,
                                            designation: self.txtDesignation.text!)
            self.arrContactList?.append(tempContact)
            
            self.txtContactName.text = ""
            self.txtPContactNo.text = ""
            self.txtSContactNo.text = ""
            self.txtEmail.text = ""
            self.txtDesignation.text = ""
            self.lblErrorBtnSave.text = ""
            
            self.constraintHeightTVContactList.constant = CGFloat((self.arrContactList?.count ?? 0) >= 2 ? (166 * 2) : 166 )
            
            if (self.arrContactList?.count ?? 0) >= 2 {
                self.tvContactList.isScrollEnabled = true
            }
            else {
                self.tvContactList.isScrollEnabled = false
            }
            
            self.tvContactList.reloadData()
        }
    }
    @IBOutlet weak var lblErrorBtnSave: UILabel!
    
    @IBOutlet weak var tvContactList: UITableView! {
        didSet {
            self.tvContactList.delegate = self
            self.tvContactList.dataSource = self
            self.tvContactList.register(UINib(nibName: "AddContactTVCell", bundle: nil), forCellReuseIdentifier: "AddContactTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVContactList: NSLayoutConstraint!
    
    ///     View - 3
    
    @IBOutlet weak var viewTabBilling: UIView!
    @IBOutlet weak var constraintBottomViewTabBilling: NSLayoutConstraint!
    
    @IBOutlet weak var viewBillingAddressType: UIView!
    @IBOutlet weak var btnWarehouse: UIButton!
    @IBAction func btnWarehouseTap(_ sender: UIButton) {
        self.btnWarehouse.isSelected = true
        self.btnWarehouse.tintColor = Colors.themeGreen.returnColor()
        self.isWareHouse = true
        self.isOffice = false
        self.btnOffice.isSelected = false
        self.btnOffice.tintColor = Colors.gray.returnColor()
    }
    @IBOutlet weak var btnOffice: UIButton!
    @IBAction func btnOfficeTap(_ sender: UIButton) {
        self.btnOffice.isSelected = true
        self.btnOffice.tintColor = Colors.themeGreen.returnColor()
        self.isOffice = true
        self.isWareHouse = false
        self.btnWarehouse.isSelected = false
        self.btnWarehouse.tintColor = Colors.gray.returnColor()
    }
    
    @IBOutlet weak var viewUseBillToAdd: UIView!
    @IBOutlet weak var btnUseBillToAdd: UIButton!
    @IBAction func btnUseBillToAddTap(_ sender: UIButton) {
        if self.btnUseBillToAdd.isSelected {
            self.btnUseBillToAdd.isSelected = false
            self.btnUseBillToAdd.tintColor = Colors.gray.returnColor()
            self.isUseBillToAdd = false
        }
        else {
            self.btnUseBillToAdd.isSelected = true
            self.btnUseBillToAdd.tintColor = Colors.themeGreen.returnColor()
            self.isUseBillToAdd = true
        }
    }
    
    @IBOutlet weak var viewAddressTitle: UIView!
    @IBOutlet weak var txtAddressTitle: TLTextField!
    @IBOutlet weak var lblErrorAddressTitle: UILabel!
    
    @IBOutlet weak var viewBlockNo: UIView!
    @IBOutlet weak var txtBlockNo: TLTextField!
    @IBOutlet weak var lblErrorBlockNo: UILabel!
    
    @IBOutlet weak var viewBuildingFloorRoom: UIView!
    @IBOutlet weak var txtBuildingFloorRoom: TLTextField!
    @IBOutlet weak var lblErrorBuildingFloorRoom: UILabel!
    
    @IBOutlet weak var viewStreetPOBox: UIView!
    @IBOutlet weak var txtStreetPOBox: TLTextField!
    @IBOutlet weak var lblErrorStreetPOBox: UILabel!
    
    @IBOutlet weak var viewStreetNo: UIView!
    @IBOutlet weak var txtStreetNo: TLTextField!
    @IBOutlet weak var lblErrorStreetNo: UILabel!
    
    @IBOutlet weak var viewZipCode: UIView!
    @IBOutlet weak var txtZipCode: TLTextField!
    @IBOutlet weak var lblErrorZipCode: UILabel!
    
    @IBOutlet weak var viewLandmark: UIView!
    @IBOutlet weak var txtLandmark: TLTextField!
    @IBOutlet weak var lblErrorLandmark: UILabel!
    
    @IBOutlet weak var viewCountry: UIView!
    @IBOutlet weak var txtCountry: TLTextField!
    @IBOutlet weak var lblErrorCountry: UILabel!
    
    @IBOutlet weak var viewMSelectState: UIView!
    @IBOutlet weak var viewSelectState: UIView!
    @IBOutlet weak var lblSelectState: UILabel!
    @IBOutlet weak var btnSelectState: UIButton!
    @IBAction func btnSelectStateTap(_ sender: UIButton) {
        let arrTempState: [String] = (self.arrState ?? []).map { $0.stateName! }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = Title.BPSelectStateTitle
        popupVC.value = arrTempState
        popupVC.selectedValue = self.lblSelectState.text ?? "Select State"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strValue in
            if strValue != self.lblSelectState.text! {
                self.lblSelectState.text = strValue
                self.lblErrorSelectState.text = ""
                
                let tempState = self.arrState?.filter { ($0.stateName! == strValue) }
                let tempStateId = tempState?[0].id ?? 0
                self.intStateId = tempStateId
                
                self.lblSelectCity.text = "Select City"
                self.isStateSelect = true
                self.getCities(intStateId: tempStateId)
            }
        }
        popupVC.onClose = { strValue in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblErrorSelectState: UILabel!
    
    @IBOutlet weak var viewMSelectCity: UIView!
    @IBOutlet weak var viewSelectCity: UIView!
    @IBOutlet weak var lblSelectCity: UILabel!
    @IBOutlet weak var btnSelectCity: UIButton!
    @IBAction func btnSelectCityTap(_ sender: UIButton) {
        if self.isStateSelect && !((self.arrCity ?? []).isEmpty) {
            let arrTempCity: [String] = (self.self.arrCity ?? []).map { $0.cityName! }
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.BPSelectCityTitle
            popupVC.value = arrTempCity
            popupVC.selectedValue = self.lblSelectCity.text ?? "Select City"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.lblSelectCity.text = strValue
                
                let tempCity = self.arrCity?.filter{ ($0.cityName! == strValue) }
                let tempCityId = tempCity?[0].id ?? 0
                self.intCityId = tempCityId
                
                self.lblErrorSelectCity.text = ""
            }
            popupVC.onClose = { strValue in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
        else {
            Utilities.showPopup(title: "Select the state first.", type: .error)
        }
    }
    @IBOutlet weak var lblErrorSelectCity: UILabel!
    
    @IBOutlet weak var switchGSTRequired: UISwitch!
    @IBAction func switchGSTRequiredTap(_ sender: UISwitch) {
        if sender.isOn {
            self.constraintBottomGSTRequired.priority = .defaultLow
            self.isGSTRequired = true
            self.viewGSTNo.isHidden = false
        }
        else {
            self.constraintBottomGSTRequired.priority = .required
            self.isGSTRequired = false
            self.viewGSTNo.isHidden = true
        }
    }
    @IBOutlet weak var constraintBottomGSTRequired: NSLayoutConstraint!
    
    @IBOutlet weak var viewGSTNo: UIView!
    @IBOutlet weak var txtGSTNo: TLTextField!
    @IBOutlet weak var lblErrorGSTNo: UILabel!
    
    ///     View - 4
    
    @IBOutlet weak var viewTabDelivery: UIView!
    @IBOutlet weak var constraintBottomViewTabDelivery: NSLayoutConstraint!
    
    @IBOutlet weak var viewDeliveryAddressType: UIView!
    @IBOutlet weak var btnDWarehouse: UIButton!
    @IBAction func btnDWarehouseTap(_ sender: UIButton) {
        self.btnDWarehouse.isSelected = true
        self.btnDWarehouse.tintColor = Colors.themeGreen.returnColor()
        self.isDWareHouse = true
        self.isDOffice = false
        self.btnDOffice.isSelected = false
        self.btnDOffice.tintColor = Colors.gray.returnColor()
    }
    @IBOutlet weak var btnDOffice: UIButton!
    @IBAction func btnDOfficeTap(_ sender: UIButton) {
        self.btnDOffice.isSelected = true
        self.btnDOffice.tintColor = Colors.themeGreen.returnColor()
        self.isDOffice = true
        self.isDWareHouse = false
        self.btnDWarehouse.isSelected = false
        self.btnDWarehouse.tintColor = Colors.gray.returnColor()
    }
    
    @IBOutlet weak var viewSameAsBillingInfo: UIView!
    @IBOutlet weak var btnSameAsBillingInfo: UIButton!
    @IBAction func btnSameAsBillingInfoTap(_ sender: UIButton) {
        
        if self.btnSameAsBillingInfo.isSelected {
            self.setDataAsBilling(isTrue: false)
        }
        else {
            // Billing
            var isBillingTabValid = self.checkValidation(to: 17, from: 26)
            if self.lblSelectState.text == "Select State" {
                self.lblErrorSelectState.setLeftArrow(title: Valid_AddBPSelectState)
                isBillingTabValid = false
            }
            
            if self.lblSelectCity.text == "Select City" {
                self.lblErrorSelectCity.setLeftArrow(title: Valid_AddBPSelectCity)
                isBillingTabValid = false
            }
            if isBillingTabValid {
                self.setDataAsBilling(isTrue: true)
            }
            else {
                Utilities.showPopup(title: "First fill proper billing address.", type: .warning)
                self.btnSameAsBillingInfo.isSelected = false
            }
        }
    }
    
    @IBOutlet weak var viewDAddressTitle: UIView!
    @IBOutlet weak var txtDAddressTitle: TLTextField!
    @IBOutlet weak var lblErrorDAddressTitle: UILabel!
    
    @IBOutlet weak var viewDBlockNo: UIView!
    @IBOutlet weak var txtDBlockNo: TLTextField!
    @IBOutlet weak var lblErrorDBlockNo: UILabel!
    
    @IBOutlet weak var viewDBuildingFloorRoom: UIView!
    @IBOutlet weak var txtDBuildingFloorRoom: TLTextField!
    @IBOutlet weak var lblErrorDBuildingFloorRoom: UILabel!
    
    @IBOutlet weak var viewDStreetPOBox: UIView!
    @IBOutlet weak var txtDStreetPOBox: TLTextField!
    @IBOutlet weak var lblErrorDStreetPOBox: UILabel!
    
    @IBOutlet weak var viewDStreetNo: UIView!
    @IBOutlet weak var txtDStreetNo: TLTextField!
    @IBOutlet weak var lblErrorDStreetNo: UILabel!
    
    @IBOutlet weak var viewDZipCode: UIView!
    @IBOutlet weak var txtDZipCode: TLTextField!
    @IBOutlet weak var lblErrorDZipCode: UILabel!
    
    @IBOutlet weak var viewDLandmark: UIView!
    @IBOutlet weak var txtDLandmark: TLTextField!
    @IBOutlet weak var lblErrorDLandmark: UILabel!
    
    @IBOutlet weak var viewDCountry: UIView!
    @IBOutlet weak var txtDCountry: TLTextField!
    @IBOutlet weak var lblErrorDCountry: UILabel!
    
    @IBOutlet weak var viewMDSelectState: UIView!
    @IBOutlet weak var viewDSelectState: UIView!
    @IBOutlet weak var lblDSelectState: UILabel!
    @IBOutlet weak var btnDSelectState: UIButton!
    @IBAction func btnDSelectStateTap(_ sender: UIButton) {
        let arrTempState: [String] = (self.arrState ?? []).map { $0.stateName! }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = Title.BPSelectStateTitle
        popupVC.value = arrTempState
        popupVC.selectedValue = self.lblDSelectState.text ?? "Select State"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strValue in
            if strValue != self.lblDSelectState.text! {
                self.lblDSelectState.text = strValue
                self.lblErrorDSelectState.text = ""
                
                let tempState = self.arrState?.filter{ ($0.stateName! == strValue) }
                let tempStateId = tempState?[0].id ?? 0
                self.intDStateId = tempStateId
                
                self.lblDSelectCity.text = "Select City"
                self.isDStateSelect = true
                self.getCities(intStateId: tempStateId, isDelivery: true)
            }
        }
        popupVC.onClose = { strValue in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblErrorDSelectState: UILabel!
    
    @IBOutlet weak var viewMDSelectCity: UIView!
    @IBOutlet weak var viewDSelectCity: UIView!
    @IBOutlet weak var lblDSelectCity: UILabel!
    @IBOutlet weak var btnDSelectCity: UIButton!
    @IBAction func btnDSelectCityTap(_ sender: UIButton) {
        if self.isDStateSelect && !((self.arrDCity ?? []).isEmpty) {
            let arrTempCity: [String] = (self.self.arrDCity ?? []).map { $0.cityName! }
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.BPSelectCityTitle
            popupVC.value = arrTempCity
            popupVC.selectedValue = self.lblDSelectCity.text ?? "Select City"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.lblDSelectCity.text = strValue
                
                let tempCity = self.arrDCity?.filter{ ($0.cityName! == strValue) }
                let tempCityId = tempCity?[0].id ?? 0
                self.intDCityId = tempCityId
                
                self.lblErrorDSelectCity.text = ""
            }
            popupVC.onClose = { strValue in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
        else {
            Utilities.showPopup(title: "Select the state first.", type: .error)
        }
    }
    @IBOutlet weak var lblErrorDSelectCity: UILabel!
    
    @IBOutlet weak var switchDGSTRequired: UISwitch!
    @IBAction func switchDGSTRequiredTap(_ sender: UISwitch) {
        if sender.isOn {
            self.constraintBottomDGSTRequired.priority = .defaultLow
            self.isDGSTRequired = true
            self.viewDGSTNo.isHidden = false
        }
        else {
            self.constraintBottomDGSTRequired.priority = .required
            self.isDGSTRequired = false
            self.viewDGSTNo.isHidden = true
        }
    }
    @IBOutlet weak var constraintBottomDGSTRequired: NSLayoutConstraint!
    
    @IBOutlet weak var viewDGSTNo: UIView!
    @IBOutlet weak var txtDGSTNo: TLTextField!
    @IBOutlet weak var lblErrorDGSTNo: UILabel!
    
    
    ///     View - 5
    
    @IBOutlet weak var viewTabTransport: UIView!
    @IBOutlet weak var constraintBottomViewTabTransport: NSLayoutConstraint!
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var btnOther: UIButton!
    @IBAction func btnOtherTap(_ sender: UIButton) {
        self.viewMain.isHidden = true
        self.viewTransport.isHidden = false
    }
    @IBOutlet weak var tvTransportList: UITableView! {
        didSet {
            self.tvTransportList.delegate = self
            self.tvTransportList.dataSource = self
            self.tvTransportList.register(UINib(nibName: "TransportTVCell", bundle: nil), forCellReuseIdentifier: "TransportTVCell")
        }
    }
    
    // Add Transport
    @IBOutlet weak var viewTransport: UIView!
    @IBOutlet weak var viewTransportBack: UIView!
    @IBOutlet weak var lblTransportScreenTitle: UILabel!
    @IBOutlet weak var btnTransportBack: UIButton!
    @IBAction func btnTransportBackTap(_ sender: UIButton) {
        self.viewMain.isHidden = false
        self.viewTransport.isHidden = true
        view.endEditing(true)
    }
    
    @IBOutlet weak var txtTransportTitle: TLTextField!
    @IBOutlet weak var lblErrorTransportTitle: UILabel!
    
    @IBOutlet weak var txtTransportEmail: TLTextField!
    @IBOutlet weak var lblErrorTransportEmail: UILabel!
    
    @IBOutlet weak var txtTransportTelNo: TLTextField!
    @IBOutlet weak var lblErrorTransportTelNo: UILabel!
    
    @IBOutlet weak var txtTransportMobile: TLTextField!
    @IBOutlet weak var lblErrorTransportMobile: UILabel!
    
    @IBOutlet weak var txtTransportGSTNo: TLTextField!
    @IBOutlet weak var lblErrorTransportGSTNo: UILabel!
    
    @IBOutlet weak var txtTransportAddress: TLTextField!
    @IBOutlet weak var lblErrorTransportAddress: UILabel!
    
    @IBOutlet weak var txtTransportDesc: TLTextField!
    @IBOutlet weak var lblErrorTransportDesc: UILabel!
    
    @IBOutlet weak var btnTransportSubmit: UIButton!
    @IBAction func btnTransportSubmitTap(_ sender: UIButton) {
        var isAddTransportValid: Bool = true
        isAddTransportValid = self.checkValidation(to: 35, from: 36)
        if isAddTransportValid {
            self.addTransporter()
        }
    }
    
    // MARK: - Variable
    
    var strScreenTitle = "Business Partner"
    var AddBPTab: [String] = AddBusinessPartner.getTab()
    var intSelectedTab: Int = 0
    var intPaymentInfo: Int = 0
    var isSalesPersonVisible: Bool = false
    var isAllValidationsPassed: Bool = true
    var arrMyTeamMember: [TeamMember]?
    var isStateSelect: Bool = false
    var arrState: [State]?
    var arrCity: [City]?
    var arrDCity: [City]?
    var arrIndustriesCategory: [String]? = []
    var arrMobileNo: [String]? = []
    var arrEmail: [String]? = []
    var arrBMList: [BmList]?
    var page: Int = 1
    var strSearchText: String?
    var hasMore: Bool = false
    var arrContactList: [AddBPContact]? = []
    
    var isWareHouse: Bool = false
    var isOffice: Bool = true
    var isUseBillToAdd: Bool = false
    var isGSTRequired: Bool = false
    var isDGSTRequired: Bool = false
    var isDWareHouse: Bool = false
    var isDOffice: Bool = true
    var isDStateSelect: Bool = false
    var isSameAsBillingInfo: Bool = false
    var arrTransporters: [Transporter]?
    var searchText: String = ""
    var arrSelectedTransporter: [String]? = []
    var intStateId: Int = 0
    var intCityId: Int = 0
    var intDStateId: Int = 0
    var intDCityId: Int = 0
    var isBillingAddVerify: Bool = false
    var isDeliveryAddVerify: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewCraditDays.isHidden = true
        self.viewCraditDays.clipsToBounds = true
        
        self.btnOtherMobileNo.corners(radius: 5)
        self.btnOtherEmail.corners(radius: 5)
        
        self.btnOtherMobileNo.backgroundColor = Colors.theme.returnColor()
        self.btnOtherEmail.backgroundColor = Colors.theme.returnColor()
        
        self.btnAdvancePayment.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnCreditDays.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnAgainstDelivery.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnAgainstPDC.setTitleColor(Colors.theme.returnColor(), for: .normal)
        
        self.intPaymentInfo = 1
        self.btnAdvancePayment.isSelected = true
        self.btnAdvancePayment.tintColor = Colors.themeGreen.returnColor()
        
        // Contact
        self.btnScanCard.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnScanCard.cornersWFullBorder(radius: 8, borderColor: .black, colorOpacity: 1.0)
        
        self.btnSave.cornersWFullBorder(radius: 10, borderColor: .black, colorOpacity: 1.0)
        
        // Billing
        self.btnWarehouse.tintColor = Colors.gray.returnColor()
        self.btnOffice.isSelected = true
        self.btnOffice.tintColor = Colors.themeGreen.returnColor()
        self.btnUseBillToAdd.tintColor = Colors.gray.returnColor()
        self.constraintBottomGSTRequired.priority = .required
        self.txtCountry.isEnabled = false
        
        // Delivery
        self.constraintBottomDGSTRequired.priority = .required
        
        // Transport
        self.searchBar.delegate = self
        self.searchBar.showsCancelButton = true
        self.searchBar.enablesReturnKeyAutomatically = true
        self.btnOther.setTitleColor(Colors.theme.returnColor(), for: .normal)
        
        // Add Traansport
        self.btnTransportSubmit.corners(radius: 15)
        
        self.viewTabCompany.isHidden = false
        self.viewTabContact.isHidden = true
        self.viewTabBilling.isHidden = true
        self.viewTabDelivery.isHidden = true
        self.viewTabTransport.isHidden = true
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))

        self.viewInScrollMain.addGestureRecognizer(tap)
        self.viewTransport.addGestureRecognizer(tap)
        self.viewTabCompany.addGestureRecognizer(tap)
        self.viewTabContact.addGestureRecognizer(tap)
        self.viewTabBilling.addGestureRecognizer(tap)
        self.viewTabDelivery.addGestureRecognizer(tap)
        self.viewTabTransport.addGestureRecognizer(tap)
        
        self.constraintHeightViewCompanyAlreadyExist.constant = 0
        self.lblCompanyType.text = (AddBusinessPartner.getCompanyType())[1]
        
        self.constraintHeightTVContactList.constant = 0
        
        //self.viewTabCompany.isHidden = true
        //self.constraintBottomViewTabCompany.priority = .defaultLow
        
        self.txtCompanyName.enablesReturnKeyAutomatically = true
        
        self.addSwipeGesture(view: self.viewInScrollMain)
        self.checkKeyboard()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        DispatchQueue.main.async {
            
            self.constraintBottomToSalesPAcc.priority = .required
            self.viewSalesPerson.isHidden = true
            self.viewSalesPerson.clipsToBounds = true
            
            if self.isSalesPersonVisible {
                self.constraintBottomToSalesPAcc.priority = .defaultLow
                self.viewSalesPerson.isHidden = false
                
                self.getMyTeam(intCompanyType: APIManager.sharedManager.companyType ?? 1)
            }
            self.getStates()
            self.getIndustriesCategoryList()
        }
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    // Swipe Gesture
    func addSwipeGesture(view: UIView) {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeRight.direction = .right
        self.viewInScrollMain.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeLeft.direction = .left
        view.addGestureRecognizer(swipeLeft)
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .left:
                if self.intSelectedTab < 4 {
                    self.intSelectedTab += 1
                    self.swipeTap(tab: self.intSelectedTab)
                }
            case .right:
                if self.intSelectedTab > 0 {
                    self.intSelectedTab -= 1
                    self.swipeTap(tab: self.intSelectedTab)
                }
            case .down:
                print("Swiped down")
            case .up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    func swipeTap(tab: Int) {
        self.setupTabView(intSelectedTab: self.intSelectedTab)
        self.colleTab.reloadData()
    }
    
    func setDataAsBilling(isTrue: Bool) {
        if isTrue {
            self.btnSameAsBillingInfo.isSelected = true
            self.btnSameAsBillingInfo.tintColor = Colors.themeGreen.returnColor()
            self.isSameAsBillingInfo = true
            
            self.btnDWarehouse.isSelected = self.btnWarehouse.isSelected
            self.btnDWarehouse.tintColor = self.btnWarehouse.tintColor
            
            self.btnDOffice.isSelected = self.btnOffice.isSelected
            self.btnDOffice.tintColor = self.btnOffice.tintColor
            
            self.isDWareHouse = self.isWareHouse
            self.isDOffice = self.isOffice
            
            self.txtDAddressTitle.text = self.txtAddressTitle.text
            self.txtDBlockNo.text = self.txtBlockNo.text
            self.txtDBuildingFloorRoom.text = self.txtBuildingFloorRoom.text
            self.txtDStreetPOBox.text = self.txtStreetPOBox.text
            self.txtDStreetNo.text = self.txtStreetNo.text
            self.txtDZipCode.text = self.txtZipCode.text
            self.txtDLandmark.text = self.txtLandmark.text
            
            self.lblDSelectState.text = self.lblSelectState.text
            self.lblDSelectCity.text = self.lblSelectCity.text
            
            self.isDGSTRequired = self.isGSTRequired
            self.switchDGSTRequired.isOn =  self.isDGSTRequired
            
            self.intDStateId = self.intStateId
            self.intDCityId = self.intCityId
            
            self.btnDWarehouse.isUserInteractionEnabled = false
            self.btnDOffice.isUserInteractionEnabled = false
            self.txtDAddressTitle.isUserInteractionEnabled = false
            self.txtDBlockNo.isUserInteractionEnabled = false
            self.txtDBuildingFloorRoom.isUserInteractionEnabled = false
            self.txtDStreetPOBox.isUserInteractionEnabled = false
            self.txtDStreetNo.isUserInteractionEnabled = false
            self.txtDZipCode.isUserInteractionEnabled = false
            self.txtDLandmark.isUserInteractionEnabled = false
            self.btnDSelectState.isUserInteractionEnabled = false
            self.btnDSelectCity.isUserInteractionEnabled = false
            self.switchDGSTRequired.isUserInteractionEnabled = false
            self.txtDGSTNo.isUserInteractionEnabled = false
            
            self.lblErrorDAddressTitle.text = ""
            self.lblErrorDBlockNo.text = ""
            self.lblErrorDBuildingFloorRoom.text = ""
            self.lblErrorDStreetPOBox.text = ""
            self.lblErrorDStreetNo.text = ""
            self.lblErrorDZipCode.text = ""
            self.lblErrorDSelectState.text = ""
            self.lblErrorDSelectCity.text = ""
            self.lblErrorDGSTNo.text = ""
            
            DispatchQueue.main.async {
                if self.switchDGSTRequired.isOn {
                    self.constraintBottomDGSTRequired.priority = .defaultLow
                    self.txtDGSTNo.text = self.txtGSTNo.text
                }
                else {
                    self.constraintBottomDGSTRequired.priority = .required
                    self.txtDGSTNo.text = ""
                }
            }
        }
        else {
            self.btnSameAsBillingInfo.isSelected = false
            self.btnSameAsBillingInfo.tintColor = Colors.gray.returnColor()
            self.isSameAsBillingInfo = false
            
            self.btnDWarehouse.isSelected = false
            self.btnDWarehouse.tintColor = Colors.gray.returnColor()
            
            self.btnDOffice.isSelected = false
            self.btnDOffice.tintColor = Colors.gray.returnColor()
            
            self.txtDAddressTitle.text = ""
            self.txtDBlockNo.text = ""
            self.txtDBuildingFloorRoom.text = ""
            self.txtDStreetPOBox.text = ""
            self.txtDStreetPOBox.text = ""
            self.txtDStreetNo.text = ""
            self.txtDZipCode.text = ""
            self.txtDLandmark.text = ""
            
            self.lblErrorDAddressTitle.text = ""
            self.lblErrorDBlockNo.text = ""
            self.lblErrorDBuildingFloorRoom.text = ""
            self.lblErrorDStreetPOBox.text = ""
            self.lblErrorDStreetNo.text = ""
            self.lblErrorDZipCode.text = ""
            self.lblErrorDSelectState.text = ""
            self.lblErrorDSelectCity.text = ""
            self.lblErrorDGSTNo.text = ""
            
            self.lblDSelectState.text = "Select State"
            self.lblDSelectCity.text = "Select City"
            
            self.isDGSTRequired = false
            self.switchDGSTRequired.isOn =  false
            self.txtDGSTNo.text = ""
            
            DispatchQueue.main.async {
                self.txtDGSTNo.text = ""
                self.constraintBottomDGSTRequired.priority = .required
            }
            
            self.btnDWarehouse.isUserInteractionEnabled = true
            self.btnDOffice.isUserInteractionEnabled = true
            self.txtDAddressTitle.isUserInteractionEnabled = true
            self.txtDBlockNo.isUserInteractionEnabled = true
            self.txtDBuildingFloorRoom.isUserInteractionEnabled = true
            self.txtDStreetPOBox.isUserInteractionEnabled = true
            self.txtDStreetNo.isUserInteractionEnabled = true
            self.txtDZipCode.isUserInteractionEnabled = true
            self.txtDLandmark.isUserInteractionEnabled = true
            self.btnDSelectState.isUserInteractionEnabled = true
            self.btnDSelectCity.isUserInteractionEnabled = true
            self.switchDGSTRequired.isUserInteractionEnabled = true
            self.txtDGSTNo.isUserInteractionEnabled = true
        }
    }
    
    //func checkAllValidation(to: Int, from: Int) {
    func checkAllValidation() {
        
        var isCompanyTabValid: Bool = true
        var isContactTabValid: Bool = true
        var isBillingTabValid: Bool = true
        var isDeliveryTabValid: Bool = true
        var isTransportTabValid: Bool = true
        var strValidMsg: String = ""
        
        // Contact
        isCompanyTabValid = self.checkValidation(to: 0, from: 12)
        if self.lblCompanyType.text == "Company Туре" {
            self.lblErrorCompanyType.setLeftArrow(title: Valid_CompanyType)
            isCompanyTabValid = false
        }
        
        if self.lblBranch.text == "Select Branch" {
            self.lblErrorBranch.setLeftArrow(title: Valid_SelectBranch)
            isCompanyTabValid = false
        }
        
        if self.lblIndustriesCategory.text == "Select Industries Category" {
            self.lblErrorIndustriesCategory.setLeftArrow(title: Valid_IndustriesCategory)
            isCompanyTabValid = false
        }
        
        if self.lblBusinessType.text == "Select Business Type" {
            self.lblErrorBusinessType.setLeftArrow(title: Valid_BusinessType)
            isCompanyTabValid = false
        }
        
        if self.lblTypeOfFirms.text == "Select Type Of Firm" {
            self.lblErrorTypeOfFirms.setLeftArrow(title: Valid_TypesOfFirms)
            isCompanyTabValid = false
        }
        
        // Contact
        //isContactTabValid = self.checkValidation(to: 12, from: 17)
        self.lblErrorBtnSave.text = ""
        if (self.arrContactList ?? []).isEmpty {
            isContactTabValid = false
            self.lblErrorBtnSave.text = "Please press \(self.btnSave.titleLabel?.text ?? "") button"
        }
        
        // Billing
        isBillingTabValid = self.checkValidation(to: 17, from: 26)
        if self.lblSelectState.text == "Select State" {
            self.lblErrorSelectState.setLeftArrow(title: Valid_AddBPSelectState)
            isBillingTabValid = false
        }
        
        if self.lblSelectCity.text == "Select City" {
            self.lblErrorSelectCity.setLeftArrow(title: Valid_AddBPSelectCity)
            isBillingTabValid = false
        }
        
        // Delivery
        //if !self.isSameAsBillingInfo {
        isDeliveryTabValid = self.checkValidation(to: 26, from: 35)
        if self.lblSelectState.text == "Select State" {
            self.lblErrorSelectState.setLeftArrow(title: Valid_AddBPSelectState)
            isDeliveryTabValid = false
        }
        
        if self.lblSelectCity.text == "Select City" {
            self.lblErrorSelectCity.setLeftArrow(title: Valid_AddBPSelectCity)
            isDeliveryTabValid = false
        }
        //}
        
        // Transport
        if self.arrSelectedTransporter?.count ?? 0 < 1 {
            isTransportTabValid = false
        }
        
        if !isCompanyTabValid {
            self.intSelectedTab = 0
            self.swipeTap(tab: self.intSelectedTab)
        }
        else if !isContactTabValid {
            self.intSelectedTab = 1
            self.swipeTap(tab: self.intSelectedTab)
        }
        else if !isBillingTabValid {
            self.intSelectedTab = 2
            self.swipeTap(tab: self.intSelectedTab)
        }
        else if !isDeliveryTabValid {
            self.intSelectedTab = 3
            self.swipeTap(tab: self.intSelectedTab)
        }
        else if !isTransportTabValid {
            self.intSelectedTab = 4
            self.swipeTap(tab: self.intSelectedTab)
        }
        
        if isCompanyTabValid && isContactTabValid && isBillingTabValid && isDeliveryTabValid && isTransportTabValid {
            if self.isGSTRequired {
                // 24AAACH7409R2Z6  -   GST No
                self.verifyGSTNumber(gstNo: self.txtGSTNo.text!, stateId: self.intStateId, cityId: self.intCityId, pincode: self.txtZipCode.text!, addressType: 1, isDelivery: false)
            }
            else if self.isDGSTRequired {
                self.verifyGSTNumber(gstNo: self.txtDGSTNo.text!, stateId: self.intDStateId, cityId: self.intDCityId, pincode: self.txtDZipCode.text!, addressType: 2, isDelivery: true)
            }
            else {
                self.addBusinessP(legalName: "")
            }
        }
        else {
            if isCompanyTabValid && isContactTabValid && isBillingTabValid && isDeliveryTabValid && !isTransportTabValid {
                Utilities.showPopup(title: "Please select at least one transporter.", type: .error)
            }
        }
    }
}

// MARK: - Keyboard

extension AddBusinessPVC {
    func checkKeyboard() {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        initializeHideKeyboard()
    }
    
    func initializeHideKeyboard(){
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        self.viewInScrollMain.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard(){
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomBSheet.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            if self.intSelectedTab == 0 {
                self.constraintBottomViewTabCompany.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            else if self.intSelectedTab == 1 {
                self.constraintBottomViewTabContact.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            else if self.intSelectedTab == 2 {
                self.constraintBottomViewTabBilling.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            else if self.intSelectedTab == 3 {
                self.constraintBottomViewTabDelivery.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            else if self.intSelectedTab == 4 {
                self.constraintBottomViewTabTransport.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}
