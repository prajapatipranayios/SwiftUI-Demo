//
//  BusinessPDetail_Extension.swift
//  GE Sales
//
//  Created by Auxano on 27/04/24.
//

import Foundation
import UIKit


// MARK: - UICollectionView Delegate, Datasource
extension BusinessPDetailVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return self.arrColleTitle?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return self.arrColleTitle?[section].count ?? 0
        }
        else if section == 1 {
            return self.arrColleTitle?[section].count ?? 0
        }
        else if section == 2 {
            return (self.arrColleTitle?[section].count ?? 0) + self.intAddVerifyRejctBtn
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCVCell", for: indexPath) as! CategoryCVCell
            
            cell.lblCategoryName.text = self.arrColleTitle?[indexPath.section][indexPath.item] ?? ""
            cell.imgCategory.image = UIImage(named: (self.arrColleTitle?[indexPath.section][indexPath.item] ?? "").replacingOccurrences(of: " ", with: "-"))
            
            if indexPath.item == 0 {
                cell.lblCount.text = "\((self.arrOrderDetail?.count ?? 0) == 0 ? "" : "\(self.arrOrderDetail?.count ?? 0)")"
            }
            else if indexPath.item == 1 {
                cell.lblCount.text = "\((self.arrSampleRequestList?.count ?? 0) == 0 ? "" : "\(self.arrSampleRequestList?.count ?? 0)")"
            }
            else if indexPath.item == 2 {
                cell.lblCount.text = "\((self.arrQiList?.count ?? 0) == 0 ? "" : "\(self.arrQiList?.count ?? 0)")"
            }
            else if indexPath.item == 3 {
                cell.lblCount.text = "\((self.arrPiList?.count ?? 0) == 0 ? "" : "\(self.arrPiList?.count ?? 0)")"
            }
            
            return cell
        }
        else if indexPath.section == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomTextCVCell", for: indexPath) as! CustomTextCVCell
            
            cell.lblName.text = self.arrColleTitle?[indexPath.section][indexPath.item] ?? ""
            cell.view.backgroundColor = .systemBackground
            cell.view.layer.borderWidth = 1
            cell.view.layer.borderColor = UIColor(hexString: "#000000", alpha: 0.09).cgColor
            cell.viewBtnVerifyReject.isHidden = true
            
            return cell
        }
        else if indexPath.section == 2 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomTextCVCell", for: indexPath) as! CustomTextCVCell
            
            //cell.lblName.text = self.arrColleTitle?[indexPath.section][indexPath.item] ?? ""
            //cell.view.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
            cell.view.layer.borderWidth = 0
            cell.view.layer.borderColor = UIColor.clear.cgColor
            
            if indexPath.row == 2 {
                cell.view.backgroundColor = .systemBackground
                cell.viewBtnVerifyReject.isHidden = false
                
                cell.onVerifyTap = { index in
                    self.verifyBPPopup(strValue: "Verify", msg: "Are you want to confirm verify business partner ?")
                }
                
                cell.onRejectTap = { index in
                    self.viewRejectBPReason.isHidden = false
                }
            }
            else {
                cell.lblName.text = self.arrColleTitle?[indexPath.section][indexPath.item] ?? ""
                cell.view.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
                cell.viewBtnVerifyReject.isHidden = true
            }
            
            return cell
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if indexPath.section == 0 {
            let width = (collectionView.frame.width - 60) / 2
            let height = 90.0
            return CGSize(width: width, height: height)
        }
        else if indexPath.section == 1 {
            let width = (collectionView.frame.width - 60) / 2
            let height = 50.0
            return CGSize(width: width, height: height)
        }
        else if indexPath.section == 2 {
            let width = (collectionView.frame.width - 40)
            let height = 50.0
            return CGSize(width: width, height: height)
        }
        else {
            return .zero
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            if self.isShowFullDetails {
                if indexPath.row == 0 {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "BusinessPSalesOrderVC") as! BusinessPSalesOrderVC
                    vc.salesOrder = self.arrOrderDetail
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                else if indexPath.row == 1 {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "BPSampleRequestVC") as! BPSampleRequestVC
                    vc.arrSampleReqList = self.arrSampleRequestList
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                else if indexPath.row == 2 {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "BPQiPiVC") as! BPQiPiVC
                    vc.strScreenTitle = "Quotation"
                    vc.isQI = true
                    vc.arrQiList = self.arrQiList
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                else if indexPath.row == 3 {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "BPQiPiVC") as! BPQiPiVC
                    vc.strScreenTitle = "Proforma Invoice"
                    vc.isPI = true
                    vc.arrPiList = self.arrPiList
                    print()
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
            else {
                self.showMsg(alertMsg: "\(Messages.NoPermission)\(self.arrColleTitle?[indexPath.section][indexPath.item] ?? "")!")
            }
        }
        else if indexPath.section == 1 {
            if indexPath.item == 0 {
                let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CompanyDetailVC") as! CompanyDetailVC
                popupVC.modalPresentationStyle = .overCurrentContext
                popupVC.modalTransitionStyle = .crossDissolve
                popupVC.businessPartnerDetail = self.businessPartnerDetail
                popupVC.onClose = { _ in
                }
                self.present(popupVC, animated: true)
            }
            else if indexPath.item == 1 {
                self.openDialog(isContectPerson: true)
            }
            else if indexPath.item == 2 {
                self.openDialog(isAddress: true)
            }
            else if indexPath.item == 3 {
                self.openDialog(isTransporter: true)
            }
        }
        else if indexPath.section == 2 {
            if indexPath.item == 0 {
                if self.isShowFullDetails {
                    let viewController = self.storyboard?.instantiateViewController(withIdentifier: "BPPurchasedProductsVC") as! BPPurchasedProductsVC
                    viewController.intBusinessPartnersId = self.intBusinessPartnersId ?? 0
                    self.navigationController?.pushViewController(viewController, animated: true)
                }
                else {
                    self.showMsg(alertMsg: "\(Messages.NoPermission)\(self.arrColleTitle?[indexPath.section][indexPath.item] ?? "")!")
                }
            }
            else if indexPath.item == 1 {
                self.openDialog(isClientHistory: true)
            }
        }
    }
    
    func openDialog(isContectPerson: Bool = false, isAddress: Bool = false, isTransporter: Bool = false, isClientHistory: Bool = false) {
        var isOpen: Bool = false
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithTableVC") as! PopupWithTableVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        if isContectPerson {
            popupVC.strTitle = "Contact Person"
            popupVC.isContectPerson = true
            popupVC.arrBusinessPartnerContactPerson = self.businessPartnerDetail?.businessPartnersContactPerson ?? []
            isOpen = true
        }
        else if isAddress {
            popupVC.strTitle = "Address"
            popupVC.isAddress = true
            popupVC.billingAddress = self.businessPartnerDetail?.billingAddress
            popupVC.deliveryAddress = self.businessPartnerDetail?.deliveryAddress
            isOpen = true
        }
        else if isTransporter {
            popupVC.strTitle = "Transporter (s)"
            popupVC.isTransporter = true
            popupVC.arrBusinessPartnersTransporter = self.businessPartnerDetail?.businessPartnersTransporters ?? []
            isOpen = true
        }
        else if isClientHistory {
            popupVC.strTitle = "Client History"
            popupVC.isClientHistory = true
            popupVC.arrBusinessPartnerHistory = self.businessPartnerDetail?.businessPartnerHistory ?? []
            isOpen = true
        }
        popupVC.onClose = { _ in
        }
        if isOpen {
            self.present(popupVC, animated: true)
        }
    }
    
    func verifyBPPopup(strValue: String, msg: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = msg
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            self.verifyRejectBP(strValue: "Verified")
        }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
    }
    
    func showMsg(alertMsg: String, alertType: AlertType = .error) {
        /// .error, .warning, .success
        Utilities.showPopup(title: alertMsg, type: .error)
    }
}

// MARK: - TextField Delegate

extension BusinessPDetailVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        
        
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
        }
        return value
    }
}

// MARK: - Webservices

extension BusinessPDetailVC {
    func getBusinessPaartnerDetail(intBusinessPartnersId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBusinessPaartnerDetail(intBusinessPartnersId: intBusinessPartnersId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partners_id": intBusinessPartnersId
//            "user_id": 85,
//            "business_partners_id": 7555    //37715   //
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_BUSINESS_PARTNER_DETAIL, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //self.arrEmployee = response?.result?.employees ?? []
                    self.businessPartnerDetail = response?.result?.businessPartnerDetail
                    self.arrOrderDetail = response?.result?.order_detail ?? []
                    self.arrQiList = response?.result?.qiList ?? []
                    self.arrPiList  = response?.result?.piList ?? []
                    self.arrSampleRequestList = response?.result?.sampleRequestList ?? []
                    
                    self.setDetails()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func generateGeneralLedger(strBusinessPartnerCode: String, SDate: String, EDate: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.generateGeneralLedger(strBusinessPartnerCode: strBusinessPartnerCode, SDate: SDate, EDate: EDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partner_code": strBusinessPartnerCode,
            "start_date": SDate,
            "end_date": EDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GENERATE_GENERAL_LEDGER, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    print("Item Url --> ")
                    guard let url = URL(string: (response?.result?.fileURL ?? "")) else { return }
                    UIApplication.shared.open(url)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func verifyRejectBP(strValue: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.verifyRejectBP(strValue: strValue)
                }
            }
            return
        }
        
        //{"user_id":85,"business_partners_id":8117,"verified_status":"Rejected","reason":"For Testing "}
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partners_id": self.intBusinessPartnersId ?? 0,
            "verified_status": strValue,
            "reason": self.txtRejectReason.text ?? ""
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.VERIFY_BUSINESS_PARTNER, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.popupWImg(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func popupWImg(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            APIManager.sharedManager.isRefreshData = true
            self.navigationController?.popViewController(animated: true)
        }
        self.present(popupVC, animated: true)
    }
}
