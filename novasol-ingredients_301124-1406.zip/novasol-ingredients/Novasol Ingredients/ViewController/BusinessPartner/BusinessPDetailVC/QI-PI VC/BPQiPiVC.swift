//
//  BPQuotationVC.swift
//  GE Sales
//
//  Created by Auxano on 02/05/24.
//

import UIKit

class BPQiPiVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var tvQI: UITableView! {
        didSet {
            self.tvQI.dataSource = self
            self.tvQI.delegate = self
            self.tvQI.register(UINib(nibName: "BPSampleReqTVCell", bundle: nil), forCellReuseIdentifier: "BPSampleReqTVCell")
        }
    }
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    // MARK: - Variables
    
    var strScreenTitle: String = ""
    var isQI: Bool = false
    var isPI: Bool = false
    var arrQiList: [BusinessPOrderDetail]?
    var arrPiList: [BusinessPOrderDetail]?
    var arrOrder: [BusinessPOrderDetail]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        if self.isQI {
            self.arrOrder = self.arrQiList
        }
        else {
            self.arrOrder = self.arrPiList
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.viewNoData.isHidden = true
        if self.arrOrder?.count ?? 0 == 0 {
            self.viewNoData.isHidden = false
        }
    }
}
