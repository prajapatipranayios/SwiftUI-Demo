//
//  BusinessPSalesOrderVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 01/05/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, Datasource

extension BusinessPSalesOrderVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.salesOrder?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BPSampleReqTVCell", for: indexPath) as! BPSampleReqTVCell
        
        cell.lblSampleId.text = self.salesOrder?[indexPath.row].orderCode ?? ""
        
        let price: String = "\(self.salesOrder?[indexPath.row].grandTotalAmount ?? 0.0)".curFormatAsRegion()
        cell.lblAmount.text = "₹ \(price)"
        cell.lblDate.text = Utilities.convertStrDateToString(date: self.salesOrder?[indexPath.row].orderDate ?? "",CurrentDateFormate: "dd-MMMM-yyyy HH:mm:ss" , NewDateFormate: "dd MMM, yyyy")
        cell.lblStatus.text = OrderStatus.getStatusTitle(status: self.salesOrder?[indexPath.row].orderStatus ?? 0)
        cell.lblStatus.textColor = OrderStatus.getStatusColor(status: self.salesOrder?[indexPath.row].orderStatus ?? 0)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "SalesOrderDetailsVC") as! SalesOrderDetailsVC
        /// Pass value.
        viewController.isSalesOrderDetail = true
        viewController.strScreenTitle = "Sales Order Details"
        viewController.intOrderId = self.salesOrder?[indexPath.row].orderID ?? 0
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}
