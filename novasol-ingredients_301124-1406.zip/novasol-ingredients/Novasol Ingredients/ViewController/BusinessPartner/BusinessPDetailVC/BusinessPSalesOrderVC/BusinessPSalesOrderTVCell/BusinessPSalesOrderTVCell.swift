//
//  BusinessPSalesOrderTVCell.swift
//  GE Sales
//
//  Created by Auxano on 30/04/24.
//

import UIKit

class BusinessPSalesOrderTVCell: UITableViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblOrderNo: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var lblTotalProduct: UILabel!
    @IBOutlet weak var lblOrderStatus: UILabel!
    @IBOutlet weak var lblRsSepaarator: UILabel!
    @IBOutlet weak var lblSepaarator: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.lblRsSepaarator.isHidden = true
        self.lblTotalProduct.isHidden = true
        
        self.lblTotal.textColor = Colors.theme.returnColor()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}
