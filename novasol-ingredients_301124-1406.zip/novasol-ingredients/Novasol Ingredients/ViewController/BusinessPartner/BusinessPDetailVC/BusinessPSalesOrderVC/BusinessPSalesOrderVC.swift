//
//  BusinessPSalesOrderVC.swift
//  GE Sales
//
//  Created by Auxano on 01/05/24.
//

import UIKit

class BusinessPSalesOrderVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var tvSalesOrder: UITableView! {
        didSet {
            self.tvSalesOrder.delegate = self
            self.tvSalesOrder.dataSource = self
            self.tvSalesOrder.estimatedRowHeight = UITableView.automaticDimension
            //self.tvSalesOrder.register(UINib(nibName: "BusinessPSalesOrderTVCell", bundle: nil), forCellReuseIdentifier: "BusinessPSalesOrderTVCell")
            self.tvSalesOrder.register(UINib(nibName: "BPSampleReqTVCell", bundle: nil), forCellReuseIdentifier: "BPSampleReqTVCell")
        }
    }
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    // MARK: - Vaariable
    
    var strScreenTitle: String = "Sales Order"
    var salesOrder: [BusinessPOrderDetail]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if self.salesOrder?.count ?? 0 == 0 {
            self.viewNoData.isHidden = false
        }
    }
}
