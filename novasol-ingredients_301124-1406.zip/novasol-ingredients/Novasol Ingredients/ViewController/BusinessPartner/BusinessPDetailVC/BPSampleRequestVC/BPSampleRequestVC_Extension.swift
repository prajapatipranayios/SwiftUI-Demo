//
//  BPSampleRequestVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 02/05/24.
//

import Foundation
import UIKit


// MARK: - TableView DataSourse, Delegate

extension BPSampleRequestVC: UITableViewDelegate, UITableViewDataSource  {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrSampleReqList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BPSampleReqTVCell", for: indexPath) as! BPSampleReqTVCell
        
        cell.lblSampleId.text = self.arrSampleReqList?[indexPath.row].orderCode ?? ""
        
        let price: String = "\(self.arrSampleReqList?[indexPath.row].grandTotalAmount ?? 0.0)".curFormatAsRegion()
        cell.lblAmount.text = " ₹ \(price)"
        cell.lblDate.text = Utilities.convertStrDateToString(date: self.arrSampleReqList?[indexPath.row].orderDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy HH:mm:ss", NewDateFormate: "dd MMM, yyyy")
        cell.lblStatus.text = "(\(OrderStatus.getStatusTitle(status: self.arrSampleReqList?[indexPath.row].orderStatus ?? 0)))"
        cell.lblStatus.textColor = OrderStatus.getStatusColor(status: self.arrSampleReqList?[indexPath.row].orderStatus ?? 0)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "SalesOrderDetailsVC") as! SalesOrderDetailsVC
        /// Pass value.
        viewController.isSampleOrderDetail = true
        viewController.strScreenTitle = "Sample Order Details"
        viewController.intOrderId = self.arrSampleReqList?[indexPath.row].orderID ?? 0
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}
