//
//  BPSampleRequestVC.swift
//  GE Sales
//
//  Created by Auxano on 02/05/24.
//

import UIKit

class BPSampleRequestVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var tvSampleReq: UITableView! {
        didSet {
            self.tvSampleReq.dataSource = self
            self.tvSampleReq.delegate = self
            self.tvSampleReq.register(UINib(nibName: "BPSampleReqTVCell", bundle: nil), forCellReuseIdentifier: "BPSampleReqTVCell")
        }
    }
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    // MARK: - Variables
    
    var arrSampleReqList: [BusinessPOrderDetail]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.viewNoData.isHidden = true
        if self.arrSampleReqList?.count ?? 0 == 0 {
            self.viewNoData.isHidden = false
        }
    }
}
