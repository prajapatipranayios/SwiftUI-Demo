//
//  ViewPdfVC.swift
//  GE Sales
//
//  Created by Auxano on 02/05/24.
//

import UIKit

class ViewPdfPopupVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBottomSheet: UIView!
    @IBOutlet weak var lblChooseDate: UILabel!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var imgCalSDate: UIImageView!
    @IBOutlet weak var btnSDate: UIButton!
    @IBAction func btnSDateTap(_ sender: UIButton) {
        self.lblStartDate.text = "Start Date"
        self.lblEndDate.text = "End Date"
        self.imgCalSDate.isHidden = false
        self.imgCalEDate.isHidden = false
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = self.dateFormat
        popupVC.isMaxDateLimit = false
        popupVC.didSelectDate = { date in
            self.imgCalSDate.isHidden = true
            
            self.lblStartDate.text = date
        }
        popupVC.onClose = {
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var imgCalEDate: UIImageView!
    @IBOutlet weak var btnEDate: UIButton!
    @IBAction func btnEDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = self.dateFormat
        popupVC.isMaxDateLimit = false
        if self.lblStartDate.text ?? "" != "Start Date" && self.lblStartDate.text ?? "" != "" {
            popupVC.minStartDate = self.lblStartDate.text ?? ""
        }
        popupVC.didSelectDate = { date in
            self.imgCalEDate.isHidden = true
            
            self.lblEndDate.text = date
            //self.lblStartDate.text = "Start Date"
            //self.lblEndDate.text = "End Date"
            if self.lblStartDate.text ?? "" == "" || self.lblStartDate.text ?? "" == "Start Date" {
                self.lblStartDate.text = date
                self.imgCalSDate.isHidden = true
            }
            self.isBothDateSelected = true
        }
        popupVC.onClose = {
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var btnViewPdf: UIButton!
    @IBAction func btnViewPdfTap(_ sender: UIButton) {
        if self.isBothDateSelected {
            self.dismiss(animated: true) {
                if self.didSelect != nil {
                    self.didSelect!((self.lblStartDate.text ?? "").replacingOccurrences(of: "-", with: ""),
                                    (self.lblEndDate.text ?? "").replacingOccurrences(of: "-", with: ""))
                }
            }
        }
        else {
            Utilities.showPopup(title: Messages.PleaseSelectSEDate, type: .error)
        }
    }
    @IBOutlet weak var btnCancel: UIButton!
    @IBAction func btnCancelTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onClose != nil {
                self.onClose!()
            }
        }
    }
    
    // MARK: - Variable
    
    var didSelect: ((String, String)->Void)?
    var onClose: (()->Void)?
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    var dateFormat: String = "yyyy-MM-dd"
    private var isBothDateSelected: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblChooseDate.tintColor = Colors.theme.returnColor()
        
        self.viewBottomSheet.corners([.topLeft, .topRight], radius: 25)
        self.btnViewPdf.corners(radius: 10)
        self.btnCancel.corners(radius: 10)
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
        self.viewMain.backgroundColor = .clear
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
}
