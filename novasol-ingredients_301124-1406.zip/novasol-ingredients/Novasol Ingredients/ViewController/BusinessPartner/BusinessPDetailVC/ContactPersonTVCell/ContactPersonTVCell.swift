//
//  ContactPersonTVCell.swift
//  GE Sales
//
//  Created by Cpt n3m0 on 29/04/24.
//

import UIKit

class ContactPersonTVCell: UITableViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblNameTitle: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblMobileTitle: UILabel!
    @IBOutlet weak var lblMobile: UILabel!
    @IBOutlet weak var lblDesignationTitle: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    @IBOutlet weak var lblEmailTitle: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.lblSeparator.backgroundColor = UIColor(hexString: "#C4C4C4", alpha: 0.2)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
