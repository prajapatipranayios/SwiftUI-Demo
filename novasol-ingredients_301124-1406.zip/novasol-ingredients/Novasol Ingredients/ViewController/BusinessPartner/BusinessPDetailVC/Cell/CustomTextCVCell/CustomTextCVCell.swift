//
//  CustomTextCVCell.swift
//  GE Sales
//
//  Created by Auxano on 29/04/24.
//

import UIKit

class CustomTextCVCell: UICollectionViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgArrow: UIImageView!
    
    @IBOutlet weak var viewBtnVerifyReject: UIView!
    @IBOutlet weak var btnVerify: UIButton!
    @IBAction func btnVerifyTap(_ sender: UIButton) {
        if self.onVerifyTap != nil {
            self.onVerifyTap!(index)
        }
    }
    @IBOutlet weak var btnReject: UIButton!
    @IBAction func btnRejctTap(_ sender: UIButton) {
        if self.onRejectTap != nil {
            self.onRejectTap!(index)
        }
    }
    
    
    // MARK: - Outlet
    
    var index: Int = 0
    var onVerifyTap: ((Int)->Void)?
    var onRejectTap: ((Int)->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.view.layer.cornerRadius = 15
        self.view.layer.borderWidth = 1
        self.view.layer.borderColor = UIColor(hexString: "#000000", alpha: 0.09).cgColor
        
        self.viewBtnVerifyReject.isHidden = true
        self.viewBtnVerifyReject.corners(radius: 15.0)
        self.btnVerify.corners(radius: 15.0)
        self.btnReject.corners(radius: 15.0)
    }
}
