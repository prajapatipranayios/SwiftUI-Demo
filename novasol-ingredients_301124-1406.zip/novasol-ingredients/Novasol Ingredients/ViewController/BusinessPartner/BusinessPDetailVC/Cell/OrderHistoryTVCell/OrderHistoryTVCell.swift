//
//  OrderHistoryTVCell.swift
//  GE Sales
//
//  Created by Auxano on 09/05/24.
//

import UIKit

class OrderHistoryTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var lblStatusChangeDateTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblStatusTitle: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblBy: UILabel!
    
    @IBOutlet weak var viewReason: UIView!
    @IBOutlet weak var lblReasonTitle: UILabel!
    @IBOutlet weak var lblReason: UILabel!
    @IBOutlet weak var constraintHeightViewReason: NSLayoutConstraint!
    
    @IBOutlet weak var viewEmpAns: UIView!
    @IBOutlet weak var lblEmpAnsTitle: UILabel!
    @IBOutlet weak var lblEmpAns: UILabel!
    @IBOutlet weak var constraintHeightViewEmpAns: NSLayoutConstraint!
    
    @IBOutlet weak var txtReply: UITextField!
    @IBOutlet weak var btnSend: UIButton!
    @IBAction func btnSendTap(_ sender: UIButton) {
        if onTapSend != nil {
            onTapSend!(self.index, self.txtReply.text!)
        }
    }
    
    @IBOutlet weak var btnReply: UIButton!
    @IBAction func btnReplyTap(_ sender: UIButton) {
        if onTapReply != nil {
            onTapReply!(index)
        }
    }
    //@IBOutlet weak var constraintHeightBtnReply: NSLayoutConstraint!
    
    @IBOutlet weak var lblSeparator: UILabel!
    
    // MARK: - Variable
    var onTapReply: ((Int)->Void)?
    var onTapSend: ((Int, String)->Void)?
    var index: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.lblStatusChangeDateTitle.textColor = UIColor(hexString: "#007AFF", alpha: 1.0)
        self.lblDate.textColor = UIColor(hexString: "#007AFF", alpha: 1.0)
        self.lblStatusTitle.textColor = UIColor(hexString: "#007AFF", alpha: 1.0)
        self.lblReasonTitle.textColor = UIColor(hexString: "#007AFF", alpha: 1.0)
        self.lblEmpAnsTitle.textColor = UIColor(hexString: "#007AFF", alpha: 1.0)
        self.lblSeparator.backgroundColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)
        
        self.btnReply.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        self.btnReply.setTitleColor(Colors.theme.returnColor(), for: .normal)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
