//
//  TrialHistoryTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/05/24.
//

import UIKit

class TrialHistoryTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewProductName: UIView!
    @IBOutlet weak var lblProductName: UILabel!
    
    @IBOutlet weak var viewStatus: UIView!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var constraintHeightViewStatus: NSLayoutConstraint!
    @IBOutlet weak var btnChangeStatusNView: UIButton!
    @IBAction func btnChangeStatusNViewTap(_ sender: UIButton) {
    }
    @IBOutlet weak var constraintTrailStatus: NSLayoutConstraint!
    
    @IBOutlet weak var viewReason: UIView!
    @IBOutlet weak var lblReason: UILabel!
    @IBOutlet weak var constraintHeightViewReason: NSLayoutConstraint!
    
    @IBOutlet weak var lblSeparator: UILabel!
    
    // MARK: - Variable
    
    var index: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
