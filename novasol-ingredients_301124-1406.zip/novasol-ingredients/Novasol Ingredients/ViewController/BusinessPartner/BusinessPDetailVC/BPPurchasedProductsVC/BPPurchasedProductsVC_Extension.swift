//
//  BPPurchasedProductsVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 01/05/24.
//

import Foundation
import UIKit


// MARK: - TableView DataSource, Delegate

extension BPPurchasedProductsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrProductList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BPPurchasedProductsTVCell", for: indexPath) as! BPPurchasedProductsTVCell
        
        cell.lblName.text = self.arrProductList?[indexPath.row].productName ?? ""
        cell.lblCount.text = "\(self.arrProductList?[indexPath.row].products?.count ?? 0)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboaard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboaard.instantiateViewController(withIdentifier: "BPProductsDetailsVC") as! BPProductsDetailsVC
        viewController.arrBPProduct = self.arrProductList?[indexPath.row].products ?? []
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}

// MARK: - Webservices

extension BPPurchasedProductsVC {
    func getProductListForBP(intBusinessPartnersId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getProductListForBP(intBusinessPartnersId: intBusinessPartnersId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partners_id": intBusinessPartnersId
//            "user_id": 91,
//            "business_partners_id": 7555
        ]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_PRODUCT_LIST_FOR_BUSINESS_PARTNRE, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            DispatchQueue.main.async {
                if response?.status == 1 {
                    self.arrProductList = response?.result?.productList
                    
                    self.viewNoData.isHidden = true
                    if self.arrProductList?.count ?? 0 == 0 {
                        self.viewNoData.isHidden = false
                    }
                    else {
                        self.tvPurchasedProducts.reloadData()
                    }
                }
                else {
                    self.viewNoData.isHidden = false
                    Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }
}
