//
//  BPProductsDetailsVC.swift
//  GE Sales
//
//  Created by Auxano on 01/05/24.
//

import UIKit

class BPProductsDetailsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var tvSalesOrder: UITableView! {
        didSet {
            self.tvSalesOrder.delegate = self
            self.tvSalesOrder.dataSource = self
            self.tvSalesOrder.estimatedRowHeight = UITableView.automaticDimension
            self.tvSalesOrder.register(UINib(nibName: "BPProductsDetailsTVCell", bundle: nil), forCellReuseIdentifier: "BPProductsDetailsTVCell")
            if #available(iOS 15.0, *) {
                self.tvSalesOrder.sectionHeaderTopPadding = 0
            } else { }
        }
    }
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    @IBOutlet weak var viewTotalQtyAmountP: UIView!
    @IBOutlet weak var viewTotalQtyAmount: UIView!
    @IBOutlet weak var lblTotalQtyTitle: UILabel!
    @IBOutlet weak var lblTotalQty: UILabel!
    @IBOutlet weak var lblTotalAmountTitle: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    
    // MARK: - Variable
    
    var arrTableTitle: [[String]] = []
    var arrBPProduct: [BPProduct]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = "Products Details".capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.arrTableTitle = TableColleTitle.getTitles(key: "BPProductDetails")
        
        //self.tvSalesOrder.backgroundColor = .systemPink
    }
    
    override func viewWillAppear(_ animated: Bool) {
        DispatchQueue.main.async {
            self.viewTotalQtyAmountP.clipsToBounds = true
            self.viewTotalQtyAmount.corners([.topLeft, .topRight], radius: 25)
            self.viewTotalQtyAmount.addShadow()
            
            let tempQty = self.arrBPProduct?.map { $0.productQty }
            let totalQty = tempQty?.reduce(0, {$0 + ($1 ?? 0)})
            self.lblTotalQty.text = "\(totalQty ?? 0)"
            
            let tempAmount = self.arrBPProduct?.map { $0.productTotal }
            let totalAmount = tempAmount?.reduce(0, {$0 + ($1 ?? 0)})
            self.lblTotalAmount.text = "₹ \(totalAmount ?? 0)"
        }
    }
}
