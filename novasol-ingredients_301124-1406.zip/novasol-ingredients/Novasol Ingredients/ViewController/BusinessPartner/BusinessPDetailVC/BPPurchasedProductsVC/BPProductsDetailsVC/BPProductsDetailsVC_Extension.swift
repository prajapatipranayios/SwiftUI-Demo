//
//  BPProductsDetailsVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 01/05/24.
//

import Foundation
import UIKit

// MARK: - TableView Delegate, DataSource
extension BPProductsDetailsVC: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let viewHeader = UIView()//UIView(frame: CGRect.zero)
        viewHeader.frame = CGRect(x: 0, y: 0, width: tableView.frame.width, height: 37)
        viewHeader.backgroundColor = .systemBackground
        
        // 12 - 8 - 10 - 12
        let width = tableView.frame.width - 42
        
        let width1: CGFloat = (width / 2) - ((width / 2)/5)
        let width2: CGFloat = ((width / 2)/5) * 2
        
        let lblDate : UILabel = UILabel()    //(frame: CGRect.zero)
        lblDate.frame = CGRect(x: 12, y: 0, width: width1, height: 35)
        lblDate.clipsToBounds = true
        lblDate.text = "Date"
        lblDate.font = .boldSystemFont(ofSize: 17)
        lblDate.textColor = UIColor(red: 84/255, green: 101/255, blue: 111/255, alpha: 1)
        
        let lblQty : UILabel = UILabel()    //(frame: CGRect.zero)
        lblQty.frame = CGRect(x: 24 + width1, y: 0, width: width2, height: 35)
        lblQty.clipsToBounds = true
        lblQty.text = "Qty"
        lblQty.font = .boldSystemFont(ofSize: 17)
        lblQty.textColor = UIColor(red: 84/255, green: 101/255, blue: 111/255, alpha: 1)
        
        let lblAmount : UILabel = UILabel()    //(frame: CGRect.zero)
        lblAmount.frame = CGRect(x: 24 + width1 + width2, y: 0, width: width1, height: 35)
        lblAmount.clipsToBounds = true
        lblAmount.text = "Amount"
        lblAmount.font = .boldSystemFont(ofSize: 17)
        lblAmount.textColor = UIColor(red: 84/255, green: 101/255, blue: 111/255, alpha: 1)
        
        let lblSeparator : UILabel = UILabel()    //(frame: CGRect.zero)
        lblSeparator.frame = CGRect(x: 12, y: 36, width: width + 20, height: 1)
        lblSeparator.clipsToBounds = true
        lblSeparator.backgroundColor = Colors.separator.returnColor()
        
        viewHeader.addSubview(lblDate)
        viewHeader.addSubview(lblQty)
        viewHeader.addSubview(lblAmount)
        viewHeader.addSubview(lblSeparator)
        return viewHeader
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 38
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrBPProduct?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BPProductsDetailsTVCell", for: indexPath) as! BPProductsDetailsTVCell
        cell.lblDate.text = self.arrBPProduct?[indexPath.row].createdAt ?? ""
        cell.lblQty.text = "\(self.arrBPProduct?[indexPath.row].productQty ?? 0)"
        cell.lblPrice.text = "₹ \(self.arrBPProduct?[indexPath.row].productTotal ?? 0)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}
