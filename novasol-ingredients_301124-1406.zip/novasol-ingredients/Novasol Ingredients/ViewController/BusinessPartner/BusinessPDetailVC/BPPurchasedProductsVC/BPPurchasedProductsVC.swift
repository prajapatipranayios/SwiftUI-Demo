//
//  BPPurchasedProductsVC.swift
//  GE Sales
//
//  Created by Auxano on 01/05/24.
//

import UIKit

class BPPurchasedProductsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var tvPurchasedProducts: UITableView! {
        didSet {
            self.tvPurchasedProducts.delegate = self
            self.tvPurchasedProducts.dataSource = self
            self.tvPurchasedProducts.estimatedRowHeight = UITableView.automaticDimension
            self.tvPurchasedProducts.register(UINib(nibName: "BPPurchasedProductsTVCell", bundle: nil), forCellReuseIdentifier: "BPPurchasedProductsTVCell")
        }
    }
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    // MARK: - Variable
    
    var intBusinessPartnersId: Int = 0
    var arrProductList: [BPProductList]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = "Purchased History".capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.getProductListForBP(intBusinessPartnersId: self.intBusinessPartnersId)
    }
}
