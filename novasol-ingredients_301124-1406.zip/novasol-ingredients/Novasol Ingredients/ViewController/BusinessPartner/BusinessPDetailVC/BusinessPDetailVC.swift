//
//  BusinessPDetailVC.swift
//  GE Sales
//
//  Created by Auxano on 26/04/24.
//

import UIKit

class BusinessPDetailVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var btnShowPdf: UIButton!
    @IBAction func btnShowPdfTap(_ sender: UIButton) {
        if self.isShowFullDetails {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewPdfPopupVC") as! ViewPdfPopupVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelect = { SDate, EDate in
                self.generateGeneralLedger(strBusinessPartnerCode: self.businessPartnerDetail?.sapID ?? "", SDate: SDate, EDate: EDate)
            }
            popupVC.onClose = {
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
        else {
            self.showMsg(alertMsg: "\(Messages.NoPermission)View General Ledger PDF!")
        }
    }
    @IBOutlet weak var viewImgNName: UIView!
    @IBOutlet weak var imgBusinessP: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    @IBOutlet weak var lblCBalance: UILabel!
    @IBOutlet weak var lblCBalanceValue: UILabel!
    @IBOutlet weak var lblGTotal: UILabel!
    @IBOutlet weak var lblGTotalValue: UILabel!
    @IBOutlet weak var viewAmount: UIView!
    @IBOutlet weak var colleBusinessPDetails: UICollectionView! {
        didSet {
            self.colleBusinessPDetails.delegate = self
            self.colleBusinessPDetails.dataSource = self
            self.colleBusinessPDetails.register(UINib(nibName: "CategoryCVCell", bundle: nil), forCellWithReuseIdentifier: "CategoryCVCell")
            self.colleBusinessPDetails.register(UINib(nibName: "CustomTextCVCell", bundle: nil), forCellWithReuseIdentifier: "CustomTextCVCell")
        }
    }
    @IBOutlet weak var constraintHeightColle: NSLayoutConstraint!
    
    @IBOutlet weak var viewRejectBPReason: UIView!
    @IBOutlet weak var lblRejectReasonTitle: UILabel!
    @IBOutlet weak var btnCloseRejectReason: UIButton!
    @IBAction func btnCloseRejectReasonTap(_ sender: UIButton) {
        self.viewRejectBPReason.isHidden = true
    }
    @IBOutlet weak var txtRejectReason: TLTextField!
    @IBOutlet weak var lblErrorRejectReason: UILabel!
    @IBOutlet weak var btnDoneRejectReason: UIButton!
    @IBAction func btnDoneRejectReasonTap(_ sender: UIButton) {
        var isValid: Bool = true
        
        self.txtRejectReason.resignFirstResponder()
        
        if self.txtRejectReason.text == "" {
            isValid = false
            self.lblErrorRejectReason.setEmptyValidationStringNoPrefix("Please \((self.txtRejectReason?.placeholder ?? "").lowercased())")
        }
        
        if isValid {
            //getEmptyValidationString
            self.verifyRejectBP(strValue: "Rejected")
        }
    }
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Business Partner Detail"
    var intBusinessPartnersId: Int?
    var businessPartnerDetail: BusinessPartnerDetail?
    var arrOrderDetail: [BusinessPOrderDetail]?
    var arrQiList: [BusinessPOrderDetail]?
    var arrPiList: [BusinessPOrderDetail]?
    var arrSampleRequestList: [BusinessPOrderDetail]?
    var arrColleTitle: [[String]]?
    var isShowFullDetails: Bool = false
    var intAddVerifyRejctBtn: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.btnDoneRejectReason.corners(radius: 10.0)
        
        self.arrColleTitle = TableColleTitle.getTitles(key: "BusinessPDetails")
        
        self.viewRejectBPReason.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.getBusinessPaartnerDetail(intBusinessPartnersId: self.intBusinessPartnersId ?? 0)
    }
    
    func setDetails() {
        
        /// 313 - Show/Hide Verify n Reject btn.
        if (self.businessPartnerDetail?.verifiedStatus == "Pending") && (APIManager.sharedManager.userId == 147) && (self.businessPartnerDetail?.companyType == 2) {
            self.intAddVerifyRejctBtn = 1
        }
        else if (self.businessPartnerDetail?.verifiedStatus == "Pending") && ((APIManager.sharedManager.userDetail?.roleId ?? 0) == 3) {
            if (APIManager.sharedManager.userId == self.businessPartnerDetail?.userID ?? 0) {
                self.intAddVerifyRejctBtn = 0
            }
            else {
                if (APIManager.sharedManager.userId == 147) && (self.businessPartnerDetail?.companyType == 2) {
                    self.intAddVerifyRejctBtn = 1
                }
                else if (self.businessPartnerDetail?.companyType == 1) {
                    self.intAddVerifyRejctBtn = 1
                }
                else {
                    self.intAddVerifyRejctBtn = 0
                }
            }
        }
        else if (self.businessPartnerDetail?.verifiedStatus == "ZM_Verified") && ((APIManager.sharedManager.userDetail?.roleId ?? 0) == 4) && (self.businessPartnerDetail?.companyType == 2) {
            self.intAddVerifyRejctBtn = 1
        }
        else if (self.businessPartnerDetail?.verifiedStatus == "ZM_Verified") && (APIManager.sharedManager.userId == self.businessPartnerDetail?.rajanDalalID ?? 0) {
            self.intAddVerifyRejctBtn = 1
        }
        else if (self.businessPartnerDetail?.verifiedStatus == "ZM_Verified") && (((self.businessPartnerDetail?.roleID ?? 0) == 4) || ((APIManager.sharedManager.userDetail?.roleId ?? 0) == 4)) {
            
            if ((self.businessPartnerDetail?.userID ?? 0) == APIManager.sharedManager.userId) {
                self.intAddVerifyRejctBtn = 0
            }
            else {
                if (self.businessPartnerDetail?.verifiedStatus == "Pending") && ((APIManager.sharedManager.userDetail?.roleId ?? 0) == 4) {
                    self.intAddVerifyRejctBtn = 1
                }
                else if (APIManager.sharedManager.userId == 147) && (self.businessPartnerDetail?.companyType == 2) {
                    self.intAddVerifyRejctBtn = 1
                }
                else if (self.businessPartnerDetail?.companyType == 1) {
                    self.intAddVerifyRejctBtn = 1
                }
                else {
                    self.intAddVerifyRejctBtn = 0
                }
            }
        }
        else {
            self.intAddVerifyRejctBtn = 0
        }
        /// - 313
        
        self.lblName.text = self.businessPartnerDetail?.name ?? ""
        self.lblCode.text = self.businessPartnerDetail?.codeID ?? ""
        
        let cBal = "\(self.businessPartnerDetail?.currentBalance ?? 0)".curFormatAsRegion()
        self.lblCBalanceValue.text = "₹\(cBal)"
        
        let gTotal = "\(self.businessPartnerDetail?.grandTotal ?? 0)".curFormatAsRegion()
        self.lblGTotalValue.text = "₹\(gTotal)"
        
        self.lblCBalanceValue.textColor = (self.businessPartnerDetail?.currentBalance ?? 0) < 0 ? Colors.themeGreen.returnColor() : Colors.themeRed.returnColor()
        
        self.isShowFullDetails = self.businessPartnerDetail?.showBmFullDetails ?? 0 == 1 ? true : false
        
        //self.imgBusinessP.image = self.lblName.createImage()
        self.imgBusinessP.layer.cornerRadius = self.imgBusinessP.frame.height / 2
        
        self.setCollectionHeight()
        self.colleBusinessPDetails.reloadData()
    }
    
    func setCollectionHeight() {
        DispatchQueue.main.async {
            var height: Double = 0.0
            height = height + (ceil(Double(self.arrColleTitle?[0].count ?? 0)/2) * 90.0) + (ceil(Double(self.arrColleTitle?[0].count ?? 0)/2) * 20)
            height = height + ceil(Double(self.arrColleTitle?[1].count ?? 0)/2) * 50.0 + (ceil(Double(self.arrColleTitle?[1].count ?? 0)/2) * 20)
            height = height + Double((self.arrColleTitle?[2].count ?? 0) + self.intAddVerifyRejctBtn) * 50.0 + Double((self.arrColleTitle?[2].count ?? 0) + self.intAddVerifyRejctBtn) * 20
            
            self.constraintHeightColle.constant = height
        }
    }
}
