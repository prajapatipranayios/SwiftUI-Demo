//
//  TransporterTVCell.swift
//  GE Sales
//
//  Created by Auxano on 30/04/24.
//

import UIKit

class TransporterTVCell: UITableViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblTransporterTitle: UILabel!
    @IBOutlet weak var lblTransporter: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
        
    }
}
