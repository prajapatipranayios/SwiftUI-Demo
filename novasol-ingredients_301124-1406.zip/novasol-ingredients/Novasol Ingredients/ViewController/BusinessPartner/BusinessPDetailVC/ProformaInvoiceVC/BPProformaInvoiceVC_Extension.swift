//
//  ProformaInvoiceVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 02/05/24.
//

import Foundation
import UIKit


// MARK: - TableView DataSourse, Delegate

extension BPProformaInvoiceVC: UITableViewDelegate, UITableViewDataSource  {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BPSampleReqTVCell", for: indexPath) as! BPSampleReqTVCell
        return cell
    }
}


//"(\(OrderStatus.getStatusTitle(status: self.productData?[indexPath.row].orderStatus ?? 0)))"
//cell.lblOrderStatus.textColor = OrderStatus.getStatusColor(status: self.productData?[indexPath.row].orderStatus ?? 0)
