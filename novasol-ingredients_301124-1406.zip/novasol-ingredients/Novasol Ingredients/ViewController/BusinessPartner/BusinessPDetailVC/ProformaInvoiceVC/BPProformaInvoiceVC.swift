//
//  BPProformaInvoiceVC.swift
//  GE Sales
//
//  Created by Auxano on 02/05/24.
//

import UIKit

class BPProformaInvoiceVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var tvPI: UITableView! {
        didSet {
            self.tvPI.dataSource = self
            self.tvPI.delegate = self
            self.tvPI.register(UINib(nibName: "BPSampleReqTVCell", bundle: nil), forCellReuseIdentifier: "BPSampleReqTVCell")
        }
    }
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    // MARK: - Variables
    
    var arrPiList: [BusinessPOrderDetail]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
}
