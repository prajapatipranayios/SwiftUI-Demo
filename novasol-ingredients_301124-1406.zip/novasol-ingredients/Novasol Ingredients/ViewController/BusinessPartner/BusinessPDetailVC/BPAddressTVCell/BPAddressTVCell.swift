//
//  BPAddressTVCell.swift
//  GE Sales
//
//  Created by Auxano on 30/04/24.
//

import UIKit

class BPAddressTVCell: UITableViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblWarehouse: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
