//
//  CompanyDetailVC.swift
//  GE Sales
//
//  Created by Auxano on 29/04/24.
//

import UIKit

class CompanyDetailVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewCDetail: UIView!
    @IBOutlet weak var viewPopupImg: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBAction func btnCloseTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onClose != nil {
                self.onClose!("")
            }
        }
    }
    @IBOutlet weak var lblCompanyNameTitle: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblBranchTitle: UILabel!
    @IBOutlet weak var lblBranch: UILabel!
    @IBOutlet weak var lblIndustryTypeTitle: UILabel!
    @IBOutlet weak var lblIndustryType: UILabel!
    @IBOutlet weak var lblBusiTypeTitle: UILabel!
    @IBOutlet weak var lblBusiType: UILabel!
    @IBOutlet weak var lblMobileTitle: UILabel!
    @IBOutlet weak var lblMobile: UILabel!
    @IBOutlet weak var lblPhoneNoTitle: UILabel!
    @IBOutlet weak var lblPhoneNo: UILabel!
    @IBOutlet weak var lblCreditLimitTitle: UILabel!
    @IBOutlet weak var lblCreditLimit: UILabel!
    @IBOutlet weak var lblAnnualTurnoverTitle: UILabel!
    @IBOutlet weak var lblAnnualTurnover: UILabel!
    @IBOutlet weak var lblFirmTypeTitle: UILabel!
    @IBOutlet weak var lblFirmType: UILabel!
    @IBOutlet weak var lblEstablishedYearTitle: UILabel!
    @IBOutlet weak var lblEstablishedYear: UILabel!
    @IBOutlet weak var lblGSTNoTitle: UILabel!
    @IBOutlet weak var lblGSTNo: UILabel!
    @IBOutlet weak var lblPaymentInfoTitle: UILabel!
    @IBOutlet weak var lblPaymentInfo: UILabel!
    @IBOutlet weak var lblPANNoTitle: UILabel!
    @IBOutlet weak var lblPANNo: UILabel!
    @IBOutlet weak var lblEmailTitle: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblAPersonTitle: UILabel!
    @IBOutlet weak var lblAPerson: UILabel!
    
    // MARK: - Variable
    
    var didSelectItem: ((String)->Void)?
    var onClose: ((String)->Void)?
    var strTitle: String = "Company Details"
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    var businessPartnerDetail: BusinessPartnerDetail?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewPopupImg.clipsToBounds = true
        self.lblScreenTitle.text = strTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.viewCDetail.layer.cornerRadius = 25
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setDetails(businessPartnerDetail: self.businessPartnerDetail)
    }
    
    func setDetails(businessPartnerDetail: BusinessPartnerDetail?) {
        var mobileNo = "-"
        if businessPartnerDetail?.mobileNo?.count ?? 0 > 0 {
            mobileNo = businessPartnerDetail?.mobileNo?[0] ?? ""
        }
        
        var email = "-"
        if businessPartnerDetail?.mobileNo?.count ?? 0 > 0 {
            email = businessPartnerDetail?.email?[0] ?? ""
        }
        
        self.lblCompanyName.text = (businessPartnerDetail?.name ?? "") == "" ? "-" : businessPartnerDetail?.name ?? ""
        self.lblBranch.text = (businessPartnerDetail?.branchName ?? "") == "" ? "-" : businessPartnerDetail?.branchName ?? ""
        self.lblIndustryType.text = (businessPartnerDetail?.industryType ?? "") == "" ? "-" : businessPartnerDetail?.industryType ?? ""
        self.lblBusiType.text = (businessPartnerDetail?.businessType ?? "") == "" ? "-" : businessPartnerDetail?.businessType ?? ""
        self.lblMobile.text = mobileNo
        self.lblPhoneNo.text = (businessPartnerDetail?.telephoneNo ?? "") == "" ? "-" : businessPartnerDetail?.telephoneNo ?? ""
        
        var price = "\(businessPartnerDetail?.annualTurnover ?? 0.0)"
        if price == "" {
            price = "-"
        }
        else {
            price = price.curFormatAsRegion()
        }
        self.lblAnnualTurnover.text = "\(price) \(businessPartnerDetail?.currencyType ?? "")"
        self.lblFirmType.text = (businessPartnerDetail?.firmType ?? "") == "" ? "-" : businessPartnerDetail?.firmType ?? ""
        self.lblEstablishedYear.text = (businessPartnerDetail?.establishmentYear ?? "") == "" ? "-" : businessPartnerDetail?.establishmentYear ?? ""
        self.lblGSTNo.text = (businessPartnerDetail?.businessPartnerGstIn ?? "") == "" ? "-" : businessPartnerDetail?.businessPartnerGstIn ?? ""
        self.lblPaymentInfo.text = (businessPartnerDetail?.payTerm ?? "") == "" ? "-" : businessPartnerDetail?.payTerm ?? ""
        self.lblPANNo.text = (businessPartnerDetail?.businessPartnerPanNo ?? "") == "" ? "-" : businessPartnerDetail?.businessPartnerPanNo ?? ""
        self.lblEmail.text = email
        self.lblAPerson.text = (businessPartnerDetail?.businessPartnerSalesPersonAccountable ?? "") == "" ? "-" : businessPartnerDetail?.businessPartnerSalesPersonAccountable ?? ""
    }
}
