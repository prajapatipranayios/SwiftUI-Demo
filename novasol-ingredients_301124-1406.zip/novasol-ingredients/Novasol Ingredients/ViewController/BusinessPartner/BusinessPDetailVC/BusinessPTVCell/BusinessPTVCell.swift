//
//  BusinessPTVCell.swift
//  GE Sales
//
//  Created by Auxano on 25/04/24.
//

import UIKit

class BusinessPTVCell: UITableViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewStatus: UIView!
    @IBOutlet weak var constraintHeightStatus: NSLayoutConstraint!
    @IBOutlet weak var viewZM: UIView!
    @IBOutlet weak var lblZMBar: UILabel!
    @IBOutlet weak var lblZM: UILabel!
    
    @IBOutlet weak var viewPAN: UIView!
    @IBOutlet weak var lblPANBar: UILabel!
    @IBOutlet weak var lblPAN: UILabel!
    
    @IBOutlet weak var viewAdmin: UIView!
    @IBOutlet weak var lblAdminBar: UILabel!
    @IBOutlet weak var lblAdmin: UILabel!
    
    @IBOutlet weak var viewSuper: UIView!
    @IBOutlet weak var lblSuperBar: UILabel!
    @IBOutlet weak var lblSuper: UILabel!
    
    @IBOutlet weak var constraintTop: NSLayoutConstraint!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    @IBOutlet weak var lblAdd: UILabel!
    @IBOutlet weak var lblSalesPersonName: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.lblName.textColor = Colors.theme.returnColor()
        self.lblCode.textColor = Colors.theme.returnColor()
        self.lblAdd.textColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)
        
        self.lblZMBar.layer.cornerRadius = self.lblZMBar.frame.height / 2
        self.lblPANBar.layer.cornerRadius = self.lblPANBar.frame.height / 2
        self.lblAdminBar.layer.cornerRadius = self.lblAdminBar.frame.height / 2
        self.lblSuperBar.layer.cornerRadius = self.lblSuperBar.frame.height / 2
        
        self.lblZMBar.clipsToBounds = true
        self.lblPANBar.clipsToBounds = true
        self.lblAdminBar.clipsToBounds = true
        self.lblSuperBar.clipsToBounds = true
        
        self.lblZM.textColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)        //Colors.disableButton.returnColor()
        self.lblPAN.textColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)       //Colors.disableButton.returnColor()
        self.lblAdmin.textColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)     //Colors.disableButton.returnColor()
        self.lblSuper.textColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)     //Colors.disableButton.returnColor()
        
        self.lblZMBar.backgroundColor = Colors.theme.returnColor()      //UIColor(hexString: "#A1A1A1", alpha: 1.0)
        self.lblPANBar.backgroundColor = Colors.theme.returnColor()     //UIColor(hexString: "#A1A1A1", alpha: 1.0)
        self.lblAdminBar.backgroundColor = Colors.theme.returnColor()   //UIColor(hexString: "#A1A1A1", alpha: 1.0)
        self.lblSuperBar.backgroundColor = Colors.theme.returnColor()   //UIColor(hexString: "#A1A1A1", alpha: 1.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
