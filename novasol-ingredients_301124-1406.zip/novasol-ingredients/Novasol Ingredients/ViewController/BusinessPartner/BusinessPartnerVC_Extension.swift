//
//  BusinessPartnerVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 25/04/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, Datasourse

extension BusinessPartnerVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.businessPartners?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BusinessPTVCell", for: indexPath) as! BusinessPTVCell
        
        cell.lblName.text = self.businessPartners?[indexPath.row].name ?? ""
        cell.lblCode.text = self.businessPartners?[indexPath.row].code ?? ""
        cell.lblAdd.text = self.businessPartners?[indexPath.row].deliveryTo ?? ""
        cell.lblSalesPersonName.text = self.businessPartners?[indexPath.row].salesPersonName ?? ""
        cell.lblTime.text = self.businessPartners?[indexPath.row].createdAt ?? ""
        
        if self.businessPartners?[indexPath.row].isVerified == 1 {
            cell.constraintTop.priority = .required
        }
        else {
            var isVisible: Bool = false
            var statusBarColor: [UIColor] = []
            var statusColor: [UIColor] = []
            
            (isVisible, statusBarColor, statusColor) = self.verifyOrderStatus(status: self.businessPartners?[indexPath.row].verifiedStatus ?? "", designationId: self.businessPartners?[indexPath.row].salesPersonDesignationId ?? 0)
            if isVisible {
                cell.constraintTop.priority = .defaultLow
                
                cell.lblZMBar.backgroundColor = statusBarColor[0]
                cell.lblZM.textColor = statusColor[0]
                
                cell.lblPANBar.backgroundColor = statusBarColor[1]
                cell.lblPAN.textColor = statusColor[1]
                
                cell.lblAdminBar.backgroundColor = statusBarColor[2]
                cell.lblAdmin.textColor = statusColor[2]
                
                cell.lblSuperBar.backgroundColor = statusBarColor[3]
                cell.lblSuper.textColor = statusColor[3]
            }
            else {
                cell.constraintTop.priority = .required
            }
        }
        
        if self.hasMore ?? false {
            if (indexPath.row >= (self.businessPartners?.count ?? 0) - 3) && !self.isLoadMore {
                self.isLoadMore = true
                self.page += 1
                self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.isFromAddOrder {
            if self.businessPartners?[indexPath.row].isVerified ?? 0 == 1 {
                self.dismiss(animated: true) {
                    if self.onCellTap != nil {
                        self.onCellTap!(true, self.businessPartners?[indexPath.row])
                    }
                }
            }
            else {
                Utilities.showPopup(title: Messages.SelectVerifiedBP, type: .error)
            }
        }
        else {
            let viewController = self.storyboard?.instantiateViewController(withIdentifier: "BusinessPDetailVC") as! BusinessPDetailVC
            viewController.intBusinessPartnersId = self.businessPartners?[indexPath.row].id ?? 0
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    func verifyOrderStatus(status: String, designationId: Int) -> (isVisible: Bool, statusBarColor: [UIColor], statusColor: [UIColor]) {
        /// 0 - ZM, 1 - PAN, 2 - Admin, 3 - S.Admin
        var isVisible: Bool = true
        
        //var statusBarColor : [UIColor] = [Colors.theme.returnColor(),
          //                                Colors.theme.returnColor(),
            //                              Colors.theme.returnColor(),
              //                            Colors.theme.returnColor()]
        var statusBarColor : [UIColor] = [UIColor(hexString: "#A1A1A1", alpha: 1.0),
                                          UIColor(hexString: "#A1A1A1", alpha: 1.0),
                                          UIColor(hexString: "#A1A1A1", alpha: 1.0),
                                          UIColor(hexString: "#A1A1A1", alpha: 1.0)]
        
        var statusColor : [UIColor] = [UIColor(hexString: "#A1A1A1", alpha: 1.0),
                                       UIColor(hexString: "#A1A1A1", alpha: 1.0),
                                       UIColor(hexString: "#A1A1A1", alpha: 1.0),
                                       UIColor(hexString: "#A1A1A1", alpha: 1.0)]
        
        if status.contains("Verified") {    /// #0BA100 - Green
            if status == "ZM_Verified" {
                if designationId == 2 {
                    //statusBarColor[0] = Colors.theme.returnColor()
                    //statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
                else {
                    statusBarColor[0] = UIColor(hexString: "#0BA100", alpha: 1.0)
                    statusColor[0] = UIColor(hexString: "#0BA100", alpha: 1.0)
                }
            }
            else if status == "PAN_Verified" {
                statusBarColor[0] = UIColor(hexString: "#0BA100", alpha: 1.0)
                statusBarColor[1] = UIColor(hexString: "#0BA100", alpha: 1.0)
                
                statusColor[0] = UIColor(hexString: "#0BA100", alpha: 1.0)
                statusColor[1] = UIColor(hexString: "#0BA100", alpha: 1.0)
                
                if designationId == 2 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
                else if designationId == 1 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    statusBarColor[1] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                    statusColor[1] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
            }
            else if status == "Admin_Verified" {
                statusBarColor[0] = UIColor(hexString: "#0BA100", alpha: 1.0)
                statusBarColor[1] = UIColor(hexString: "#0BA100", alpha: 1.0)
                statusBarColor[2] = UIColor(hexString: "#0BA100", alpha: 1.0)
                
                statusColor[0] = UIColor(hexString: "#0BA100", alpha: 1.0)
                statusColor[1] = UIColor(hexString: "#0BA100", alpha: 1.0)
                statusColor[2] = UIColor(hexString: "#0BA100", alpha: 1.0)
                
                if designationId == 2 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
                else if designationId == 1 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    statusBarColor[1] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                    statusColor[1] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
            }
            else if status == "Super_Admin_Verified" {
                isVisible = false
            }
        }
        else if status.contains("Rejected") {   ///  #FF0800 - Red
            if status == "ZM_Rejected" {
                statusBarColor[0] = UIColor(hexString: "#FF0800", alpha: 1.0)
                
                statusColor[0] = UIColor(hexString: "#FF0800", alpha: 1.0)
            }
            else if status == "PAN_Rejected" {
                statusBarColor[0] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusBarColor[1] = UIColor(hexString: "#FF0800", alpha: 1.0)
                
                statusColor[0] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusColor[1] = UIColor(hexString: "#FF0800", alpha: 1.0)
                
                if designationId == 2 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
            }
            else if status == "Admin_Rejected" {
                statusBarColor[0] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusBarColor[1] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusBarColor[2] = UIColor(hexString: "#FF0800", alpha: 1.0)
                
                statusColor[0] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusColor[1] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusColor[2] = UIColor(hexString: "#FF0800", alpha: 1.0)
                
                if designationId == 2 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
                else if designationId == 1 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    statusBarColor[1] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                    statusColor[1] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
            }
            else if status == "Super_Admin_Rejected" {
                statusBarColor[0] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusBarColor[1] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusBarColor[2] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusBarColor[3] = UIColor(hexString: "#FF0800", alpha: 1.0)
                
                statusColor[0] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusColor[1] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusColor[2] = UIColor(hexString: "#FF0800", alpha: 1.0)
                statusColor[3] = UIColor(hexString: "#FF0800", alpha: 1.0)
                
                if designationId == 2 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
                else if designationId == 1 {
                    statusBarColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    statusBarColor[1] = UIColor(hexString: "#A1A1A1", alpha: 1.0)   //Colors.theme.returnColor()
                    
                    statusColor[0] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                    statusColor[1] = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                }
            }
        }
        else if status == "Pending" {  }
        else { isVisible = false }
        return (isVisible, statusBarColor, statusColor)
    }
}

// MARK: - Webservices

extension BusinessPartnerVC {
    
    func getEmployeeList() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployeeList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.EMPLOYEES_LIST, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrEmployee = response?.result?.employees ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getBusinessP(page: Int, employeeId: Int, searchText: String, startDate: String, endDate: String, orderBy: String) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBusinessP(page: page, employeeId: employeeId, searchText: searchText, startDate: startDate, endDate: endDate, orderBy: orderBy)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": APIManager.sharedManager.companyType ?? 1,
            "employeeId": employeeId,
            "search_value": searchText,
            "page": page,
            "start_date": startDate,
            "end_date": endDate,
            "order_by": orderBy
        ] as? [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_BUSINESS_PARTNER_LIST, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //print("Get response. -- \(response?.result?.productList ?? [])")
                    //self.businessPartners = response?.result?.businessPartners ?? []
                    let tempBusinessPartners = response?.result?.businessPartners ?? []
                    self.hasMore = response?.result?.hasMore ?? false
                    
                    if !self.isLoadMore {
                        self.businessPartners = tempBusinessPartners
                    }
                    else {
                        self.businessPartners?.append(contentsOf: tempBusinessPartners)
                    }
                    self.isLoadMore = false
                    self.tvBusinessP.reloadData()
                }
            }
            else {
                self.isLoadMore = self.isLoadMore ? false : false
                self.page -= 1
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}

// MARK: - SearchBar Delegate

extension BusinessPartnerVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchText = searchText
        self.page = 1
        
        self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        self.searchBar.text = ""
        self.searchText = ""
        self.page = 1
        
        self.getBusinessP(page: self.page, employeeId: self.intEmployeeId, searchText: self.searchText, startDate: self.strStartDate, endDate: self.strEndDate, orderBy: self.strOrderBy)
    }
}
