//
//  DraftOrderVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 16/07/24.
//

import UIKit

class DraftOrderVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnMenu: UIButton!
    @IBAction func btnMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    
    @IBOutlet weak var viewTVDraftOrders: UIView!
    @IBOutlet weak var tvDraftOrders: UITableView! {
        didSet {
            self.tvDraftOrders.delegate = self
            self.tvDraftOrders.dataSource = self
            self.tvDraftOrders.register(UINib(nibName: "DraftOrdersTVCell", bundle: nil), forCellReuseIdentifier: "DraftOrdersTVCell")
        }
    }
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Draft Sales Order"
    var page: Int = 1
    var hasMore: Bool = false
    var isLoadMore: Bool = false
    var isRefreshData: Bool = false
    
    var arrDraftOrders: [DraftOrder]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.viewTVDraftOrders.isHidden = false
        self.viewNoData.isHidden = true
        
//        self.viewStepCount.backgroundColor = UIColor(hexString: "#E9E9FF", alpha: 1.0)
//        self.viewStepCount.color = Colors.theme.returnColor()
//        self.lblStepCount.text = "1 of \(self.intTotalStep)"
//        self.intCurrentStep = 1
//        self.viewStepCount.progress = (1 / CGFloat(self.intTotalStep)) * CGFloat(self.intCurrentStep)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        self.getDraftOrders()
    }
}
