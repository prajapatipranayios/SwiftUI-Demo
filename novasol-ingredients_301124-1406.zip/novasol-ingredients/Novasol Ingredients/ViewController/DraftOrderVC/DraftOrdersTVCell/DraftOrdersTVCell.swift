//
//  DraftOrdersTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 16/07/24.
//

import UIKit

class DraftOrdersTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblBPName: UILabel!
    @IBOutlet weak var btnDiscard: UIButton!
    @IBAction func btnDiscardTap(_ sender: UIButton) {
        if self.onDiscardTap != nil {
            self.onDiscardTap!(index)
        }
    }
    @IBOutlet weak var lblSeparator: UILabel!
    
    // MARK: - Variable
    
    var index: Int = 0
    var onDiscardTap: ((Int)->Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.btnDiscard.cornersWFullBorder(radius: self.btnDiscard.frame.height / 2, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        self.lblSeparator.backgroundColor = Colors.separator.returnColor()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}
