//
//  DraftOrderVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 16/07/24.
//

import Foundation
import UIKit

// MARK: - UITableView Delegate, DataSource

extension DraftOrderVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.arrDraftOrders?.count ?? 0)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DraftOrdersTVCell", for: indexPath) as! DraftOrdersTVCell
        
        cell.lblBPName.text = self.arrDraftOrders?[indexPath.row].businessPartnersName ?? ""
        cell.lblDate.text = self.arrDraftOrders?[indexPath.row].orderDate ?? ""
        
        if indexPath.row > 0 {
            if (self.arrDraftOrders?[indexPath.row].orderDate ?? "") == self.arrDraftOrders?[indexPath.row - 1].orderDate ?? "" {
                cell.lblDate.text = ""
            }
        }
        
        cell.onDiscardTap = { index in
            self.deleteDraftOrder(draftId: self.arrDraftOrders?[indexPath.row].id ?? 0)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "AddOrderVC") as! AddOrderVC
        viewController.isFromSalesOrder = true
        viewController.isFromDraftOrder = true
        viewController.strScreenTitle = "Add SALES ORDER".capitalized
        viewController.strJsonData = self.arrDraftOrders?[indexPath.row].jsonData ?? ""
        viewController.intDraftId = self.arrDraftOrders?[indexPath.row].id ?? 0
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func deleteDraftOrder(draftId: Int) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = "Are you sure to discard this draft order?"
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            self.removeDraftOrder(draftId: draftId)
         }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
    }
}

// MARK: Webservices

extension DraftOrderVC {
    func getDraftOrders() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getDraftOrders()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_DRAFT_ORDER_LIST, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            DispatchQueue.main.async {
                if response?.status == 1 {
                    self.arrDraftOrders = response?.result?.draftOrders ?? []
                    self.tvDraftOrders.reloadData()
                    
                    self.viewNoData.isHidden = true
                    if (self.arrDraftOrders?.count ?? 0) < 1 {
                        self.viewNoData.isHidden = false
                        self.lblNoData.text = response?.message ?? ""
                    }
                }
                else {
                    //Utilities.showPopup(title: response?.message ?? "", type: .error)
                    self.viewNoData.isHidden = false
                    self.lblNoData.text = response?.message ?? ""
                }
            }
        }
    }
    
    func removeDraftOrder(draftId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getDraftOrders()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "draft_id": draftId
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.REMOVE_DRAFT_ORDER, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            DispatchQueue.main.async {
                if response?.status == 1 {
                    //Utilities.showPopup(title: response?.message ?? "", type: .success)
                    self.getDraftOrders()
                }
                else {
                    Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }
}
