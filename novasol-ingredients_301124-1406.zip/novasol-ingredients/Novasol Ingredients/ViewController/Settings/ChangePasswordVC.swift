//
//  ChangePasswordVC.swift
//  GE Sales
//
//  Created by Auxano on 22/05/24.
//

import UIKit

class ChangePasswordVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBaackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var viewOldPassword: UIView!
    @IBOutlet weak var txtOldPassword: TLTextField!
    @IBOutlet weak var lblErrorOldPassword: UILabel!
    @IBOutlet weak var btnOldP: UIButton!
    @IBAction func btnOldP(_ sender: UIButton) {
        if self.btnOldP.isSelected {
            self.btnOldP.isSelected = false
            self.txtOldPassword.isSecureTextEntry = true
        }
        else {
            self.btnOldP.isSelected = true
            self.txtOldPassword.isSecureTextEntry = false
        }
    }
    
    @IBOutlet weak var viewNewPassword: UIView!
    @IBOutlet weak var txtNewPassword: TLTextField!
    @IBOutlet weak var lblErrorNewPassword: UILabel!
    @IBOutlet weak var btnNewP: UIButton!
    @IBAction func btnNewP(_ sender: UIButton) {
        if self.btnNewP.isSelected {
            self.btnNewP.isSelected = false
            self.txtNewPassword.isSecureTextEntry = true
        }
        else {
            self.btnNewP.isSelected = true
            self.txtNewPassword.isSecureTextEntry = false
        }
    }
    
    @IBOutlet weak var viewCNewPassword: UIView!
    @IBOutlet weak var txtCNewPassword: TLTextField!
    @IBOutlet weak var lblErrorCNewPassword: UILabel!
    @IBOutlet weak var btnCNewP: UIButton!
    @IBAction func btnCNewP(_ sender: UIButton) {
        if self.btnCNewP.isSelected {
            self.btnCNewP.isSelected = false
            self.txtCNewPassword.isSecureTextEntry = true
        }
        else {
            self.btnCNewP.isSelected = true
            self.txtCNewPassword.isSecureTextEntry = false
        }
    }
    
    @IBOutlet weak var btnSubmit: UIButton!
    @IBAction func btnSubmitTap(_ sender: UIButton) {
        if self.checkValidation(to: 0, from: 3) {
            self.changePassword()
        }
    }
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Change Password"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.btnSubmit.corners(radius: 10.0)
        self.btnSubmit.setTitleColor(.white, for: .normal)
        self.btnSubmit.backgroundColor = Colors.theme.returnColor()
        
        self.btnOldP.isSelected = false
        self.btnNewP.isSelected = false
        self.btnCNewP.isSelected = false
        
        self.txtOldPassword.isSecureTextEntry = true
        self.txtNewPassword.isSecureTextEntry = true
        self.txtCNewPassword.isSecureTextEntry = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
    }
}

// MARK: - Webservices

extension ChangePasswordVC {
    func changePassword() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.changePassword()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "current_password": self.txtOldPassword.text!,
            "password": self.txtNewPassword.text!,
            "password_confirmation": self.txtCNewPassword.text!
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CHANGE_PASSWORD, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    Utilities.showPopup(title: response?.message ?? "", type: .success)
                    
                    self.txtOldPassword.text = ""
                    self.txtNewPassword.text = ""
                    self.txtCNewPassword.text = ""
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}

// MARK: - UITextFieldDelegate

extension ChangePasswordVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        return true
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //self.txtCompanyName.resignFirstResponder()
        textField.resignFirstResponder()
           
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        if self.checkValidation(to: textField.tag, from: textField.tag + 1) {
        }
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            
            if i == 0 {
                if self.txtOldPassword.text == "" {
                    self.lblErrorOldPassword.getEmptyValidationString((self.txtOldPassword.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorOldPassword.text = ""
                }
            }
            else if i == 1 {
                if self.txtNewPassword.text == "" {
                    self.lblErrorNewPassword.getEmptyValidationString((self.txtNewPassword.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorNewPassword.text = ""
                }
            }
            else if i == 2 {
                if self.txtCNewPassword.text == "" {
                    self.lblErrorCNewPassword.getEmptyValidationString((self.txtCNewPassword.placeholder ?? "").lowercased())
                    value = false
                }
                else if self.txtNewPassword.text != self.txtCNewPassword.text {
                    self.lblErrorCNewPassword.setLeftArrow(title: "Your password and confirmation password do not match.")
                }
                else {
                    self.lblErrorCNewPassword.text = ""
                }
            }
        }
        return value
    }
}
