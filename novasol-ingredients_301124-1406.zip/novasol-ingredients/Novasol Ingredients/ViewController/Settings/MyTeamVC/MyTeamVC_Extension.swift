//
//  MyTeamVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 22/05/24.
//

import Foundation
import UIKit

// MARK: - UITableView Delegate, DataSource

extension MyTeamVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrMyTeam?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyTeamTVCell", for: indexPath) as! MyTeamTVCell
        
        cell.lblName.text = self.arrMyTeam?[indexPath.row].name ?? ""
        cell.lblDesignation.text = self.arrMyTeam?[indexPath.row].userDesignation ?? ""
        cell.lblSeparator.backgroundColor = Colors.separator.returnColor()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewC = storyBoard.instantiateViewController(withIdentifier: "MemberDetailVC") as! MemberDetailVC
        viewC.teamMember = self.arrMyTeam?[indexPath.row]
        self.navigationController?.pushViewController(viewC, animated: true)
    }
}

// MARK: - Webservices

extension MyTeamVC {
    func getMyTeam() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getMyTeam()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": APIManager.sharedManager.companyType ?? 1
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_MY_TEAM, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrMyTeam = response?.result?.teamMembers ?? []
                    self.tvMyTeam.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getCategoryList() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getCategoryList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": APIManager.sharedManager.companyType ?? 1
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_CATEGORY_LIST, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrMyTeam = response?.result?.teamMembers ?? []
                    self.tvMyTeam.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
