//
//  MyTeamVC.swift
//  GE Sales
//
//  Created by Auxano on 22/05/24.
//

import UIKit

class MyTeamVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBaackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var viewBody: UIView!
    @IBOutlet weak var constraintTopTV: NSLayoutConstraint!
    
    @IBOutlet weak var viewSearchBar: UIView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var tvMyTeam: UITableView! {
        didSet {
            self.tvMyTeam.delegate = self
            self.tvMyTeam.dataSource = self
            self.tvMyTeam.register(UINib(nibName: "MyTeamTVCell", bundle: nil), forCellReuseIdentifier: "MyTeamTVCell")
        }
    }
    
    // MARK: - Variable
    
    var strScreenTitle: String = "MY TEAM"
    var arrMyTeam: [TeamMember]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.getMyTeam()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        
        self.constraintTopTV.priority = .required
    }
}
