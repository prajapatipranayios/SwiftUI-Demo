//
//  MemberDetailVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 23/05/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, DataSource

extension MemberDetailVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tvItemGrp {
            return self.arrItemCategory?.count ?? 0
        }
        else if tableView == self.tvZone {
            return self.arrMyZone?.count ?? 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.tvItemGrp {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ItemGrpTVCell", for: indexPath) as! ItemGrpTVCell
            cell.index = indexPath.row
            cell.btnItemGrp.setTitle(self.arrItemCategory?[indexPath.row].name, for: .normal)
            
            cell.btnItemGrp.isSelected = false
            cell.tintColor = Colors.gray.returnColor()
            if (self.arrSelectedCategory ?? []).contains("\(self.arrItemCategory?[indexPath.row].id ?? 0)") {
                cell.btnItemGrp.isSelected = true
                cell.tintColor = Colors.themeGreen.returnColor()
            }
            
            cell.lblSeparator.backgroundColor = Colors.theme.returnColor()
            
            //cell.onTap = { index in
            //}
            
            return cell
        }
        else if tableView == self.tvZone {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ZoneTVCell", for: indexPath) as! ZoneTVCell
            cell.index = indexPath.row
            cell.btnZone.setTitle(self.arrMyZone?[indexPath.row], for: .normal)
            
            cell.btnZone.isSelected = false
            cell.tintColor = Colors.theme.returnColor()
            if (self.arrEmpZone ?? []).contains(self.arrMyZone?[indexPath.row] ?? "") {
                cell.btnZone.isSelected = true
            }
            
            cell.lblSeparator.backgroundColor = .clear
            
            cell.onTap = { index in
            }
            
            return cell
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

// MARK: - Webservices

extension MemberDetailVC {
    func getCategoryList() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getCategoryList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": APIManager.sharedManager.companyType ?? 1
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_CATEGORY_LIST, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrItemCategory = response?.result?.categories ?? []
                    self.tvItemGrp.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
