//
//  ZoneTVCell.swift
//  GE Sales
//
//  Created by Auxano on 23/05/24.
//

import UIKit

class ZoneTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnZone: UIButton!
    @IBAction func btnZoneTap(_ sender: UIButton) {
        if self.onTap != nil {
            self.onTap!(self.index)
        }
    }
    @IBOutlet weak var lblSeparator: UILabel!
    
    // MARK: - Variable
    
    var index: Int = 0
    var onTap: ((Int)->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
