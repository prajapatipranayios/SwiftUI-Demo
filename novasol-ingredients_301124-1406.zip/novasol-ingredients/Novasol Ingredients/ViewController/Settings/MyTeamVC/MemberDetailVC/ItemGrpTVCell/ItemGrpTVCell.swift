//
//  ItemGrpTVCell.swift
//  GE Sales
//
//  Created by Auxano on 23/05/24.
//

import UIKit

class ItemGrpTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnItemGrp: UIButton!
    @IBAction func btnItemGrpTap(_ sender: UIButton) {
        if self.onTap != nil {
            self.onTap!(self.index)
        }
    }
    @IBOutlet weak var lblSeparator: UILabel!
    
    // MARK: - Variable
    
    var index: Int = 0
    var onTap: ((Int)->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.lblSeparator.backgroundColor = Colors.separator.returnColor()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
