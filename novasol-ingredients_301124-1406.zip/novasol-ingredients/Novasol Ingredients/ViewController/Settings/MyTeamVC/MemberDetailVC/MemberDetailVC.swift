//
//  MemberDetailVC.swift
//  GE Sales
//
//  Created by Auxano on 23/05/24.
//

import UIKit

class MemberDetailVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBaackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var viewScrollView: UIView!
    
    @IBOutlet weak var viewName: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblSeparatorName: UILabel!
    
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblSeparatorEmail: UILabel!
    
    @IBOutlet weak var viewMobileNo: UIView!
    @IBOutlet weak var lblMobileNo: UILabel!
    @IBOutlet weak var lblSeparatorMobileNo: UILabel!
    
    @IBOutlet weak var viewDesignation: UIView!
    @IBOutlet weak var lblDesignation: UILabel!
    @IBOutlet weak var lblSeparatorDesignation: UILabel!
    
    @IBOutlet weak var viewItemGroup: UIView!
    @IBOutlet weak var lblItemGrpTitle: UILabel!
    @IBOutlet weak var tvItemGrp: UITableView! {
        didSet {
            self.tvItemGrp.delegate = self
            self.tvItemGrp.dataSource = self
            self.tvItemGrp.register(UINib(nibName: "ItemGrpTVCell", bundle: nil), forCellReuseIdentifier: "ItemGrpTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVTItemGrp: NSLayoutConstraint!
    
    @IBOutlet weak var viewZone: UIView!
    @IBOutlet weak var tvZone: UITableView! {
        didSet {
            self.tvZone.delegate = self
            self.tvZone.dataSource = self
            self.tvZone.register(UINib(nibName: "ZoneTVCell", bundle: nil), forCellReuseIdentifier: "ZoneTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVZone: NSLayoutConstraint!
    
    @IBOutlet weak var viewBtnSave: UIView!
    @IBOutlet weak var btnSave: UIButton!
    @IBAction func btnSaveTap(_ sender: UIButton) {
    }
    
    //MARK: - Variable
    
    var teamMember: TeamMember?
    var arrItemCategory: [Category]?
    var arrSelectedCategory: [String]?
    var arrMyZone: [String]? = []
    var arrEmpZone: [String]? = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.arrSelectedCategory = (self.teamMember?.categoryId ?? "").components(separatedBy: ",")
        self.arrMyZone = (APIManager.sharedManager.userDetail?.zone ?? "").components(separatedBy: ",")
        self.arrEmpZone = (self.teamMember?.zone ?? "").components(separatedBy: ",")
        
        self.btnSave.isUserInteractionEnabled = false
        
        self.lblName.text = self.teamMember?.name ?? ""
        self.lblEmail.text = self.teamMember?.email ?? ""
        self.lblMobileNo.text = self.teamMember?.mobileNo ?? ""
        self.lblDesignation.text = self.teamMember?.userDesignation ?? ""
        
        self.lblSeparatorName.backgroundColor = Colors.separator.returnColor()
        self.lblSeparatorEmail.backgroundColor = Colors.separator.returnColor()
        self.lblSeparatorMobileNo.backgroundColor = Colors.separator.returnColor()
        self.lblSeparatorDesignation.backgroundColor = Colors.separator.returnColor()
        
        self.btnSave.corners(radius: 15.0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tvItemGrp.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        DispatchQueue.main.async {
            self.getCategoryList()
        }
        
        self.constraintHeightTVZone.constant = CGFloat((self.arrMyZone?.count ?? 0) * 36)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tvItemGrp.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if (keyPath == "contentSize") {
            if let newvalue = change?[.newKey] {
                let newsize  = newvalue as! CGSize
                //self.constraintHeightTVTItemGrp.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                self.constraintHeightTVTItemGrp.constant = newsize.height
                self.updateViewConstraints()
            }
        }
    }
}
