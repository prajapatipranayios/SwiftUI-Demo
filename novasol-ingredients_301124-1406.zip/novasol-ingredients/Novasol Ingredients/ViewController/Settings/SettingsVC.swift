//
//  SettingsVC.swift
//  GE Sales
//
//  Created by Auxano on 22/05/24.
//

import UIKit

class SettingsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    @IBOutlet weak var lblScreenTitle: UILabel!
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var viewProfileImg: UIView!
    @IBOutlet weak var lblAccDetailTitle: UILabel!
    @IBOutlet weak var imgProfile: UIImageView!
    
    @IBOutlet weak var viewName: UIView!
    @IBOutlet weak var lblNameTitle: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblNameSeparator: UILabel!
    
    @IBOutlet weak var viewDesignation: UIView!
    @IBOutlet weak var lblDesignationTitle: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    @IBOutlet weak var lblDesignationSeparator: UILabel!
    
    @IBOutlet weak var viewMyTeam: UIView!
    @IBOutlet weak var lblMyTeamTitle: UILabel!
    @IBOutlet weak var imgMyTeamRightArrow: UIImageView!
    @IBOutlet weak var lblMyTeamSeparator: UILabel!
    @IBOutlet weak var btnMyTeam: UIButton!
    @IBAction func btnMyTeam(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewC = storyBoard.instantiateViewController(withIdentifier: "MyTeamVC") as! MyTeamVC
        self.navigationController?.pushViewController(viewC, animated: true)
    }
    @IBOutlet weak var constraintHeightViewMyTeam: NSLayoutConstraint!
    
    @IBOutlet weak var viewPassword: UIView!
    @IBOutlet weak var lblPasswordTitle: UILabel!
    @IBOutlet weak var imgPasswordRightArrow: UIImageView!
    @IBOutlet weak var lblPasswordSeparator: UILabel!
    @IBOutlet weak var btnPassword: UIButton!
    @IBAction func btnPasswordTap(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewC = storyBoard.instantiateViewController(withIdentifier: "ChangePasswordVC") as! ChangePasswordVC
        self.navigationController?.pushViewController(viewC, animated: true)
    }
    
    @IBOutlet weak var viewNotification: UIView!
    @IBOutlet weak var lblNotificationTitle: UILabel!
    @IBOutlet weak var switchNotificationSound: UISwitch!
    @IBAction func switchNotificationSoundTap(_ sender: UISwitch) {
    }
    @IBOutlet weak var lblNotificationSeparator: UILabel!
    @IBOutlet weak var constraintHeightViewNotificationSound: NSLayoutConstraint!
    
    @IBOutlet weak var viewSignOut: UIView!
    @IBOutlet weak var btnSignOut: UIButton!
    @IBAction func btnSignOutTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = "Are you sure you want to sign out ?"
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            self.logout()
        }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblSignOutSeparator: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = "Settings".capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.lblNameTitle.textColor = Colors.theme.returnColor()
        self.lblDesignationTitle.textColor = Colors.theme.returnColor()
        self.lblMyTeamTitle.textColor = Colors.theme.returnColor()
        self.lblPasswordTitle.textColor = Colors.theme.returnColor()
        self.lblNotificationTitle.textColor = Colors.theme.returnColor()
        
        self.lblNameSeparator.backgroundColor = Colors.separator.returnColor()
        self.lblDesignationSeparator.backgroundColor = Colors.separator.returnColor()
        self.lblMyTeamSeparator.backgroundColor = Colors.separator.returnColor()
        self.lblPasswordSeparator.backgroundColor = Colors.separator.returnColor()
        self.lblNotificationSeparator.backgroundColor = Colors.separator.returnColor()
        
        self.imgPasswordRightArrow.tintColor = UIColor(hexString: "#757575", alpha: 1.0)
        self.imgMyTeamRightArrow.tintColor = UIColor(hexString: "#757575", alpha: 1.0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        self.constraintHeightViewMyTeam.constant = 0
        if Settings.myTeamVisible(role: APIManager.sharedManager.userDetail?.roleId ?? 0) {
            self.constraintHeightViewMyTeam.constant = 44
        }
        
        self.imgProfile.setImage(imageUrl: APIManager.sharedManager.userDetail?.image ?? "")
        self.lblName.text = APIManager.sharedManager.userDetail?.firstname ?? ""
        self.lblDesignation.text = APIManager.sharedManager.userDetail?.userDesignation ?? ""
    }
}

// MARK: - Webservices

extension SettingsVC {
    
    func logout() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.logout()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.LOGOUT, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //Utilities.showPopup(title: response?.message ?? "", type: .success)
                    UserDefaults.standard.set(0, forKey: UserDefaultType.userId)
                    UserDefaults.standard.set(0, forKey: UserDefaultType.userRole)
                    
                    //self.restartApplication()
                    self.messagePopup(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func messagePopup(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.restartApplication()
        }
        self.present(popupVC, animated: true)
    }
}
