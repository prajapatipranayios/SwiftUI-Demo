//
//  NotificationListTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/09/24.
//

import UIKit

class NotificationListTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblBody: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
