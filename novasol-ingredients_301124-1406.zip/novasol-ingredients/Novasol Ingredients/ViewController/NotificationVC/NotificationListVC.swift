//
//  NotificationListVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/09/24.
//

import UIKit

class NotificationListVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnMenu: UIButton!
    @IBAction func btnMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var viewTVNotification: UIView!
    @IBOutlet weak var constraintBottomViewTVNotificationToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var tvNotification: UITableView! {
        didSet {
            self.tvNotification.dataSource = self
            self.tvNotification.delegate = self
            self.tvNotification.register(UINib(nibName: "NotificationListTVCell", bundle: nil), forCellReuseIdentifier: "NotificationListTVCell")
            //self.tvNotification.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
            if #available(iOS 15.0, *) {
                self.tvNotification.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    @IBOutlet weak var btnClearAll: UIButton!
    @IBAction func btnClearAllTap(_ sender: UIButton) {
        self.clearAllNotification()
    }
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Notifications"
    
    var arrNotification: [NotificationList]? = []
    var arrDisplayNotifications: [[NotificationList]]? = []
    var arrNotificationDates: [String] = []
    
    //var hasMore: Bool = false
    var hasMore: Bool = false
    var isLoadMore: Bool = false
    var intPage: Int = 1
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.constraintBottomViewTVNotificationToSuper.priority = .required
        
        self.getNotificationList(page: self.intPage)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }

}


// MARK: - UITableView Delegate, DataSource

extension NotificationListVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.arrDisplayNotifications?.count ?? 0
    }
    
    // Customize the section header view
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView()
        headerView.backgroundColor = UIColor(hexString: "#F7F7F7")
        
        let label = UILabel()
        label.text = self.arrNotificationDates[section]   //  Utilities.categorizeDate(from: self.arrNotificationDates[section])
        label.textColor = .black
        label.textAlignment = .left
        label.font = Fonts.Medium.returnFont(size: 14) //UIFont.boldSystemFont(ofSize: 19)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        headerView.addSubview(label)
        
        // Set constraints to center the label in the header
        NSLayoutConstraint.activate([
            // Set the leading constraint
            label.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 8),
            // Set the trailing constraint
            label.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: 8),
            // Set the top constraint
            label.topAnchor.constraint(equalTo: headerView.topAnchor, constant: 0),
            // Set the bottom constraint
            label.bottomAnchor.constraint(equalTo: headerView.bottomAnchor, constant: 0)
        ])
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 35
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrDisplayNotifications?[section].count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationListTVCell", for: indexPath) as! NotificationListTVCell
        
        /*if #available(iOS 14.0, *) {
            var cellContentConfig = cell.defaultContentConfiguration()
            cellContentConfig.text = (self.arrDisplayNotifications ?? [])[indexPath.section][indexPath.row].title ?? ""
            cellContentConfig.secondaryText = (self.arrDisplayNotifications ?? [])[indexPath.section][indexPath.row].body ?? ""
            cell.contentConfiguration = cellContentConfig
            
            return cell
        } else {
            // Fallback on earlier versions
        }   ///  */
        
        cell.lblTitle.textColor = UIColor(hexString: "#595959")
        cell.lblSeparator.backgroundColor = Colors.gray.returnColor()
        
        cell.lblTitle.text = (self.arrDisplayNotifications ?? [])[indexPath.section][indexPath.row].title ?? ""
        cell.lblBody.text = (self.arrDisplayNotifications ?? [])[indexPath.section][indexPath.row].body ?? ""
        
        if self.hasMore {
            var isApiCall: Bool = false
            
            if self.arrNotificationDates.count > 1 {
                if (self.arrDisplayNotifications?[(self.arrDisplayNotifications?.count ?? 0) - 1].count ?? 0) > 3
                {
                    if (indexPath.section == ((self.arrDisplayNotifications?.count ?? 0) - 1)) &&
                        (indexPath.row >= (self.arrDisplayNotifications?[(self.arrDisplayNotifications?.count ?? 0) - 1].count ?? 0) - 3) &&
                        self.isLoadMore
                    {   // From 1
                        isApiCall = !isApiCall
                        self.isLoadMore = !self.isLoadMore
                        print("Api call --- From 1")
                    }
                }
                else {
                    if self.isLoadMore &&
                        (indexPath.section == ((self.arrDisplayNotifications?.count ?? 0) - 2)) &&
                            (indexPath.row >= ((self.arrDisplayNotifications?[(self.arrDisplayNotifications?.count ?? 0) - 2].count ?? 0) - 1))
                    {   // From 2
                        isApiCall = !isApiCall
                        self.isLoadMore = !self.isLoadMore
                        print("Api call --- From 2")
                    }
                }
            }
            else {
                if (indexPath.section == ((self.arrDisplayNotifications?.count ?? 0) - 1)) &&
                    (indexPath.row >= (self.arrDisplayNotifications?[(self.arrDisplayNotifications?.count ?? 0) - 1].count ?? 0) - 3) &&
                    self.isLoadMore
                {   // From 3
                    isApiCall = !isApiCall
                    self.isLoadMore = !self.isLoadMore
                    print("Api call --- From 3")
                }
            }
            
            if isApiCall {
                self.intPage += 1
                self.getNotificationList(page: self.intPage)
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func setupNotifications() {
        
        if intPage == 1 {
            self.arrDisplayNotifications?.removeAll()
            self.arrNotificationDates.removeAll()
        }
        
        for (_, value) in (self.arrNotification ?? []).enumerated() {
            if self.arrNotificationDates.contains(value.notificationDate ?? "") {
                for j in 0 ..< self.arrNotificationDates.count {
                    if self.arrNotificationDates[j] == (value.notificationDate ?? "") {
                        self.arrDisplayNotifications?[j].append(value)
                    }
                }
            }
            else {
                self.arrNotificationDates.append(value.notificationDate ?? "")
                var tempNotification : [NotificationList] = []
                tempNotification.append(value)
                self.arrDisplayNotifications?.append(tempNotification)
            }
        }
        
        if self.arrNotificationDates.count > 0 {
            self.constraintBottomViewTVNotificationToSuper.priority = .defaultLow
        }
        
        self.isLoadMore = self.hasMore
        self.tvNotification.reloadData()
    }
    
}



// MARK: - WebServices

extension NotificationListVC {
    
    func getNotificationList(page: Int) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getNotificationList(page: page)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": APIManager.sharedManager.companyType ?? 1,
            "page": page
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_NOTIFICATION_LIST, parameters: param) { (response: ApiResponseNotification?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    
                    let arrTempNotification = response?.result?.notification ?? []
                    self.hasMore = response?.result?.hasMore ?? false
                    
                    if page == 1 {
                        self.arrNotification = arrTempNotification
                    }
                    else {
                        self.arrNotification?.append(contentsOf: arrTempNotification)
                    }
                    
                    self.viewNoData.isHidden = true
                    if self.arrNotification?.count ?? 0 == 0 {
                        self.viewNoData.isHidden = false
                    }
                    
                    self.setupNotifications()
                }
            }
            else {
                //Utilities.showPopup(title: response?.message ?? "", type: .error)
                DispatchQueue.main.async {
                    self.viewNoData.isHidden = false
                }
            }
        }
    }
    
    func clearAllNotification() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.clearAllNotification()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CLEAR_ALL_NOTIFICATION, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.constraintBottomViewTVNotificationToSuper.priority = .required
                    self.arrNotificationDates.removeAll()
                    self.arrDisplayNotifications?.removeAll()
                    self.tvNotification.reloadData()
                    
                    self.viewNoData.isHidden = false
                    self.lblNoData.text = "No Notifications available"
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
}
