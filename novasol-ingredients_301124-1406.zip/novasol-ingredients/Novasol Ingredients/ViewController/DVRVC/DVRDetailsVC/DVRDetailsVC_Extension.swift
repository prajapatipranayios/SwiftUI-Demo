//
//  DVRDetailsVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 20/08/24.
//

import Foundation
import UIKit



// MARK: - UITableView Delegate, Datasource

extension DVRDetailsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tvContactPersons {
            return self.dvrUsersDetails?.contacts?.count ?? 0
        }
        else if tableView == self.tvClientProducts {
            return self.dvrUsersDetails?.products?.count ?? 0
        }
        else if tableView == self.tvWithWhom {
            return self.dvrUsersDetails?.whoms?.count ?? 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.tvContactPersons {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddContactTVCell", for: indexPath) as! AddContactTVCell
            
            cell.btnDelete.isHidden = true
            cell.lblName.text = self.dvrUsersDetails?.contacts?[indexPath.row].name ?? ""
            cell.lblMobileNo.text = self.dvrUsersDetails?.contacts?[indexPath.row].mobileNo ?? ""
            cell.lblTeleNo.text = self.dvrUsersDetails?.contacts?[indexPath.row].telNo ?? ""
            cell.lblDesignation.text = self.dvrUsersDetails?.contacts?[indexPath.row].designation ?? ""
            cell.lblEmail.text = self.dvrUsersDetails?.contacts?[indexPath.row].emailID ?? ""
            
            cell.constraintHeightviewTeleNo.priority = .defaultLow
            cell.constraintHeightviewDesignation.priority = .defaultLow
            if self.dvrUsersDetails?.contacts?[indexPath.row].telNo ?? "" == "" {
                cell.constraintHeightviewTeleNo.priority = .required
            }
            if self.dvrUsersDetails?.contacts?[indexPath.row].designation ?? "" == "" {
                cell.constraintHeightviewDesignation.priority = .required
            }
            
            return cell
        }
        else if tableView == self.tvClientProducts {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DvrDetailClientProductTVCell", for: indexPath) as! DvrDetailClientProductTVCell
            
            cell.lblProductName.text = self.dvrUsersDetails?.products?[indexPath.row].clientProduct ?? ""
            cell.lblApproachedProductName.text = self.dvrUsersDetails?.products?[indexPath.row].name ?? ""
            cell.viewMain.cornersWFullBorder(radius: 6.0, borderColor: .black, colorOpacity: 1.0)
            
            return cell
        }
        else if tableView == self.tvWithWhom {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TransporterTVCell", for: indexPath) as! TransporterTVCell
            
            cell.lblTransporter.text = self.dvrUsersDetails?.whoms?[indexPath.row].otherName ?? ""
            cell.lblTransporter.font = Fonts.Regular.returnFont(size: 17.0)
            cell.lblTransporter.cornersWFullBorder(radius: 3.0, borderColor: .black, colorOpacity: 1.0)
            return cell
        }
        
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}


// MARK: - Webservices

extension DVRDetailsVC {
    
    func viewPDF(startDate: String, endDate: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.viewPDF(startDate: startDate, endDate: endDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.REPORT_URL, parameters: param) { (response: ApiResponseDVR?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    
                }
            }
            else {
                
            }
        }
    }
    
    func displayMessage(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.navigationController?.popViewController(animated: true)
        }
        self.present(popupVC, animated: true)
    }
}
