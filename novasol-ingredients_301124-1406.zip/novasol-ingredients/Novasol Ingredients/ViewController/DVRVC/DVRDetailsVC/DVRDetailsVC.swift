//
//  DVRDetailsVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 20/08/24.
//

import UIKit

class DVRDetailsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var viewScrollMOut: UIView!
    @IBOutlet weak var viewScrollMIn: UIView!
    
    @IBOutlet weak var viewVisitFor: UIView!
    @IBOutlet weak var lblVisitForTitle: UILabel!
    @IBOutlet weak var lblVisitFor: UILabel!
    @IBOutlet weak var constraintHeightViewVisitFor: NSLayoutConstraint!
    
    @IBOutlet weak var viewDVRDate: UIView!
    @IBOutlet weak var lblDVRDateTitle: UILabel!
    @IBOutlet weak var lblDVRDate: UILabel!
    @IBOutlet weak var constraintHeightViewDVRDate: NSLayoutConstraint!
    
    @IBOutlet weak var viewBMName: UIView!
    @IBOutlet weak var lblBMNameTitle: UILabel!
    @IBOutlet weak var lblBMName: UILabel!
    @IBOutlet weak var constraintHeightViewBMName: NSLayoutConstraint!
    
    @IBOutlet weak var viewIndustryType: UIView!
    @IBOutlet weak var lblIndustryTypeTitle: UILabel!
    @IBOutlet weak var lblIndustryType: UILabel!
    @IBOutlet weak var constraintHeightViewIndustryType: NSLayoutConstraint!
    
    @IBOutlet weak var viewBusinessType: UIView!
    @IBOutlet weak var lblBusinessTypeTitle: UILabel!
    @IBOutlet weak var lblBusinessType: UILabel!
    @IBOutlet weak var constraintHeightViewBusinessType: NSLayoutConstraint!
    
    @IBOutlet weak var viewTradersType: UIView!
    @IBOutlet weak var lblTradersTypeTitle: UILabel!
    @IBOutlet weak var lblTradersType: UILabel!
    @IBOutlet weak var constraintHeightViewTradersType: NSLayoutConstraint!
    
    @IBOutlet weak var viewContactPersons: UIView!
    @IBOutlet weak var viewContactPersonsTitle: UIView!
    @IBOutlet weak var lblContactPersonsTitle: UILabel!
    @IBOutlet weak var tvContactPersons: UITableView! {
        didSet {
            self.tvContactPersons.delegate = self
            self.tvContactPersons.dataSource = self
            self.tvContactPersons.register(UINib(nibName: "AddContactTVCell", bundle: nil), forCellReuseIdentifier: "AddContactTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVContactPersons: NSLayoutConstraint!
    @IBOutlet weak var constraintHeightViewContactPersons: NSLayoutConstraint!
    
    @IBOutlet weak var viewClientProducts: UIView!
    @IBOutlet weak var viewClientProductsTitle: UIView!
    @IBOutlet weak var lblClientProductsTitle: UILabel!
    @IBOutlet weak var tvClientProducts: UITableView! {
        didSet {
            self.tvClientProducts.delegate = self
            self.tvClientProducts.dataSource = self
            self.tvClientProducts.register(UINib(nibName: "DvrDetailClientProductTVCell", bundle: nil), forCellReuseIdentifier: "DvrDetailClientProductTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVClientProducts: NSLayoutConstraint!
    @IBOutlet weak var constraintHeightViewClientProducts: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewPaymentRceivedDetail: UIView!
    @IBOutlet weak var viewPaymentRceivedDetailTitle: UIView!
    @IBOutlet weak var lblPaymentRceivedDetailTitle: UILabel!
    
    @IBOutlet weak var viewPaymentRceivedDetailBorder: UIView!
    @IBOutlet weak var lblPaymentRceivedDetailModeTitle: UILabel!
    @IBOutlet weak var lblPaymentRceivedDetailMode: UILabel!
    @IBOutlet weak var viewAmount: UIView!
    @IBOutlet weak var lblAmountTitle: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var constraintHeightViewAmount: NSLayoutConstraint!
    
    @IBOutlet weak var viewPaymentRemark: UIView!
    @IBOutlet weak var lblPaymentRemarkTitle: UILabel!
    @IBOutlet weak var lblPaymentRemark: UILabel!
    @IBOutlet weak var constraintHeightViewPaymentRemark: NSLayoutConstraint!
    
    @IBOutlet weak var viewPaymentRemarkCheqImg: UIView!
    @IBOutlet weak var lblPaymentChequeImgTitle: UILabel!
    @IBOutlet weak var ivChequeImg: UIImageView!
    @IBOutlet weak var constraintHeightViewPaymentRemarkCheqImg: NSLayoutConstraint!
    @IBOutlet weak var constraintHeightViewPaymentRceivedDetail: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewWorkFromOffice: UIView!
    @IBOutlet weak var viewWorkFromOfficeTitle: UIView!
    @IBOutlet weak var lblWorkFromOfficeTitle: UILabel!
    
    @IBOutlet weak var viewWorkFromOfficeBorder: UIView!
    @IBOutlet weak var lblWFORemarksTitle: UILabel!
    @IBOutlet weak var lblWFORemarks: UILabel!
    @IBOutlet weak var constraintHeightViewWorkFromOffice: NSLayoutConstraint!
    
    @IBOutlet weak var viewAttendedExhibition: UIView!
    @IBOutlet weak var viewAttendedExhibitionTitle: UIView!
    @IBOutlet weak var lblAttendedExhibitionTitle: UILabel!
    @IBOutlet weak var viewAttendedExhibitionBorder: UIView!
    @IBOutlet weak var lblExhibitionnNameTitle: UILabel!
    @IBOutlet weak var lblExhibitionnName: UILabel!
    @IBOutlet weak var lblExhibitionnCityTitle: UILabel!
    @IBOutlet weak var lblExhibitionnCity: UILabel!
    @IBOutlet weak var lblWithWhomTitle: UILabel!
    @IBOutlet weak var lblWithWhom: UILabel!
    @IBOutlet weak var tvWithWhom: UITableView! {
        didSet {
            self.tvWithWhom.delegate = self
            self.tvWithWhom.dataSource = self
            self.tvWithWhom.register(UINib(nibName: "TransporterTVCell", bundle: nil), forCellReuseIdentifier: "TransporterTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVWithWhom: NSLayoutConstraint!
    @IBOutlet weak var constraintHeightViewAttendedExhibition: NSLayoutConstraint!
    
    @IBOutlet weak var viewLeaves: UIView!
    @IBOutlet weak var viewLeavesTitle: UIView!
    @IBOutlet weak var lblLeavesTitle: UILabel!
    @IBOutlet weak var viewBorderLeavesType: UIView!
    @IBOutlet weak var lblLeavesTypeTitle: UILabel!
    @IBOutlet weak var lblLeavesType: UILabel!
    @IBOutlet weak var constraintHeightViewLeaves: NSLayoutConstraint!
    
    @IBOutlet weak var viewCity: UIView!
    @IBOutlet weak var lblCityTitle: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var constraintHeightViewCity: NSLayoutConstraint!
    
    @IBOutlet weak var viewRemarks: UIView!
    @IBOutlet weak var lblRemarksTitle: UILabel!
    @IBOutlet weak var lblRemarks: UILabel!
    @IBOutlet weak var constraintHeightViewRemarks: NSLayoutConstraint!
    
    @IBOutlet weak var viewFollowUpType: UIView!
    @IBOutlet weak var lblFollowUpTypeTitle: UILabel!
    @IBOutlet weak var lblFollowUpType: UILabel!
    @IBOutlet weak var constraintHeightViewFollowUpType: NSLayoutConstraint!
    
    @IBOutlet weak var viewFollowUpMode: UIView!
    @IBOutlet weak var lblFollowUpModeTitle: UILabel!
    @IBOutlet weak var lblFollowUpMode: UILabel!
    @IBOutlet weak var constraintHeightViewFollowUpMode: NSLayoutConstraint!
    
    @IBOutlet weak var viewFollowUpDate: UIView!
    @IBOutlet weak var lblFollowUpDateTitle: UILabel!
    @IBOutlet weak var lblFollowUpDate: UILabel!
    @IBOutlet weak var constraintHeightViewFollowUpDate: NSLayoutConstraint!
    
    @IBOutlet weak var viewBtnViewPdf: UIView!
    @IBOutlet weak var btnViewPdf: UIButton!
    @IBAction func btnViewPdfTap(_ sender: UIButton) {
        if self.dvrUsersDetails?.reportURL ?? "" != "" {
            guard let url = URL(string: self.dvrUsersDetails?.reportURL ?? "") else { return }
            UIApplication.shared.open(url)
        }
    }
    
    
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "DVR DETAILS"
    var dvrUsersDetails: DVRUserList?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.viewPaymentRceivedDetailBorder.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        self.viewWorkFromOfficeBorder.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        self.viewAttendedExhibitionBorder.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        self.viewBorderLeavesType.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        
        self.constraintHeightViewAmount.priority = .required
        self.constraintHeightViewPaymentRemark.priority = .required
        self.constraintHeightViewPaymentRemarkCheqImg.priority = .required
        
        var constant = (self.dvrUsersDetails?.contacts?.count ?? 0) * 155
        for (_, value) in (self.dvrUsersDetails?.contacts ?? []).enumerated() {
            if (value.designation ?? "") == "" {
                constant = constant - 28
            }
            if (value.telNo ?? "") == "" {
                constant = constant - 28
            }
        }
        
        self.constraintHeightTVContactPersons.constant = CGFloat(constant)
        self.constraintHeightTVClientProducts.constant = CGFloat((self.dvrUsersDetails?.products?.count ?? 0) * 70)
        self.constraintHeightTVWithWhom.constant = CGFloat((self.dvrUsersDetails?.whoms?.count ?? 0) * 41)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        var strVisitFor = DVR.getVisitFor(arrVisitFor: (self.dvrUsersDetails?.visitFor?.components(separatedBy: ",") ?? []))
        if !(self.dvrUsersDetails?.visitFor?.components(separatedBy: ",") ?? []).contains("LV") {
            strVisitFor = strVisitFor + " (Office Work)"
        }
        self.lblVisitFor.text = strVisitFor
        
        self.lblDVRDate.text = self.dvrUsersDetails?.dvrDate ?? ""
        
        var name = self.dvrUsersDetails?.name ?? ""
        name = name == "" ? self.dvrUsersDetails?.businessPartnerName ?? "" : "\(name) \(self.dvrUsersDetails?.businessPartnerName ?? "")"
        self.lblBMName.text = name
        self.constraintHeightViewBMName.priority = (name == "" ? .required : .defaultLow)
        
        self.lblIndustryType.text = self.dvrUsersDetails?.industriesType ?? ""
        self.constraintHeightViewIndustryType.priority = ((self.dvrUsersDetails?.industriesType ?? "") == "" ? .required : .defaultLow)
        
        self.lblBusinessType.text = self.dvrUsersDetails?.bmType ?? ""
        self.constraintHeightViewBusinessType.priority = ((self.dvrUsersDetails?.bmType ?? "") == "" ? .required : .defaultLow)
        
        self.lblTradersType.text = self.dvrUsersDetails?.tradersType ?? ""
        self.constraintHeightViewTradersType.priority = ((self.dvrUsersDetails?.tradersType ?? "") == "" ? .required : .defaultLow)
        
        self.constraintHeightViewContactPersons.priority = ((self.dvrUsersDetails?.contacts?.count ?? 0) == 0) ? .required : .defaultLow
        
        self.constraintHeightViewClientProducts.priority = ((self.dvrUsersDetails?.products?.count ?? 0) == 0) ? .required : .defaultLow
        
        
        if (self.dvrUsersDetails?.visitFor?.components(separatedBy: ",") ?? []).contains("PC") {
            self.constraintHeightViewPaymentRceivedDetail.priority = .defaultLow
            
            self.lblPaymentRceivedDetailMode.text = self.dvrUsersDetails?.paymentMode ?? ""
            self.lblAmount.text = self.dvrUsersDetails?.amount ?? ""    //(self.dvrUsersDetails?.amount ?? "").curFormatAsRegion()
            
            if ["Cash", "NEFT"].contains(self.dvrUsersDetails?.paymentMode ?? "") {
                self.constraintHeightViewPaymentRemark.priority = .required
                self.constraintHeightViewPaymentRemarkCheqImg.priority = .required
            }
            else if ["Cheque", "Other"].contains(self.dvrUsersDetails?.paymentMode ?? "") {
                
                self.lblPaymentRemark.text = self.dvrUsersDetails?.paymentRemarks ?? ""
                
                self.constraintHeightViewPaymentRemarkCheqImg.priority = .required
                self.constraintHeightViewPaymentRemark.priority = .required
                
                if self.dvrUsersDetails?.paymentMode ?? "" == "Other" {
                    self.constraintHeightViewPaymentRemark.priority = .defaultLow
                }
                if self.dvrUsersDetails?.paymentMode ?? "" == "Cheque" {
                    self.ivChequeImg.setImage(imageUrl: self.dvrUsersDetails?.chequeImage ?? "")
                    self.constraintHeightViewPaymentRemarkCheqImg.priority = .defaultLow
                }
            }
        }
        else {
            self.constraintHeightViewPaymentRceivedDetail.priority = .required
        }
            
        
        self.constraintHeightViewWorkFromOffice.priority = .required
        if (self.dvrUsersDetails?.visitFor?.components(separatedBy: ",") ?? []).contains("WO") {
            self.lblWFORemarks.text = self.dvrUsersDetails?.wfoRemarks ?? ""
            self.constraintHeightViewWorkFromOffice.priority = .defaultLow
        }
        
        
        self.constraintHeightViewAttendedExhibition.priority = .required
        if (self.dvrUsersDetails?.visitFor?.components(separatedBy: ",") ?? []).contains("AE") {
            self.lblExhibitionnName.text = self.dvrUsersDetails?.aeName ?? ""
            self.lblExhibitionnCity.text = self.dvrUsersDetails?.aeCity ?? ""
            // Need to load emp list to tv.
            
            self.constraintHeightViewAttendedExhibition.priority = .defaultLow
        }
        
        
        self.constraintHeightViewLeaves.priority = .required
        if (self.dvrUsersDetails?.visitFor?.components(separatedBy: ",") ?? []).contains("LV") {
            self.lblLeavesType.text = self.dvrUsersDetails?.leaveType ?? ""
            self.constraintHeightViewLeaves.priority = .defaultLow
        }
        
        
        self.lblCity.text = self.dvrUsersDetails?.city ?? ""
        self.constraintHeightViewCity.priority = (self.dvrUsersDetails?.city ?? "" == "") ? .required : .defaultLow
        
        self.lblRemarks.text = self.dvrUsersDetails?.remark ?? ""
        
        self.constraintHeightViewFollowUpType.priority = (self.dvrUsersDetails?.meetingStatus ?? "" == "") ? .required : .defaultLow
        //self.lblFollowUpType.text = self.dvrUsersDetails?.followUpType ?? ""
        self.lblFollowUpType.text = "-"
        if self.dvrUsersDetails?.meetingStatus != "Select Follow Up Typ" {
            self.lblFollowUpType.text = self.dvrUsersDetails?.meetingStatus ?? ""
        }
        
        self.constraintHeightViewFollowUpMode.priority = .required
        if self.dvrUsersDetails?.followUpType ?? "" != "" {
            self.constraintHeightViewFollowUpMode.priority = .defaultLow
        }
        self.lblFollowUpType.text = "-"
        if self.dvrUsersDetails?.meetingStatus != "Select Follow Up Mode" {
            self.lblFollowUpType.text = self.dvrUsersDetails?.followUpType ?? ""
        }
        
        //Follow up date
        self.constraintHeightViewFollowUpDate.priority = .required
        if self.dvrUsersDetails?.followUpDate ?? "" != "" {
            self.lblFollowUpDate.text = self.dvrUsersDetails?.followUpDate ?? ""
            self.constraintHeightViewFollowUpDate.priority = .defaultLow
        }
    }
}
