//
//  TVDvrListHFView.swift
//  Novasol Ingredients
//
//  Created by Auxano on 14/08/24.
//

import UIKit

class TVDvrListHFView: UITableViewHeaderFooterView {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var ivArrow: UIImageView!
    @IBOutlet weak var btnExpand: UIButton!
    
    @IBOutlet weak var lblSeparatorTop: UILabel!
    @IBOutlet weak var lblSeparatorBottom: UILabel!
}
