//
//  DvrProductDetailsTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 31/08/24.
//

import UIKit

class DvrProductDetailsTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblProductNameTitle: UILabel!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblApproachedProductNameTitle: UILabel!
    @IBOutlet weak var lblApproachedProductName: UILabel!
    
    @IBOutlet weak var btnDelete: UIButton!
    @IBAction func btnDleteTap(_ sender: UIButton) {
        if self.onDeleteTap != nil {
            self.onDeleteTap!(index)
        }
    }
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onDeleteTap: ((Int)->Void)?
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewMain.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
