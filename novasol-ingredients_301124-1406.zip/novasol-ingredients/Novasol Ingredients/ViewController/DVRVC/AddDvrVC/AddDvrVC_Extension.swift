//
//  AddDvrVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 23/08/24.
//

import Foundation
import UIKit
import Vision


// MARK: - UITableView Delegate, Datasource

extension AddDvrVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tvContactDetails {
            return self.arrSelectedContactDetail?.count ?? 0
        }
        else if tableView == self.tvWithWhom {
            return self.arrSelectedEmployee.count
        }
        else if tableView == self.tvProductDetails {
            return self.arrSelectedProduct?.count ?? 0
        }
        else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.tvContactDetails {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddContactTVCell", for: indexPath) as! AddContactTVCell
            
            cell.viewMain.cornersWFullBorder(radius: 5, borderColor: .black, colorOpacity: 1.0)
            
            cell.index = indexPath.row
            cell.lblName.text = self.arrSelectedContactDetail?[indexPath.row].name ?? ""
            cell.lblMobileNo.text = self.arrSelectedContactDetail?[indexPath.row].pContact ?? ""
            cell.lblTeleNo.text = self.arrSelectedContactDetail?[indexPath.row].sContact ?? ""
            cell.lblDesignation.text = self.arrSelectedContactDetail?[indexPath.row].designation ?? ""
            cell.lblEmail.text = self.arrSelectedContactDetail?[indexPath.row].email ?? ""
            
            cell.constraintHeightviewTeleNo.priority = .defaultLow
            cell.constraintHeightviewDesignation.priority = .defaultLow
            if self.arrSelectedContactDetail?[indexPath.row].sContact ?? "" == "" {
                cell.constraintHeightviewTeleNo.priority = .required
            }
            if self.arrSelectedContactDetail?[indexPath.row].designation ?? "" == "" {
                cell.constraintHeightviewDesignation.priority = .required
            }
            
            //cell.btnDelete.isHidden = true
            cell.onDeleteTap = { index in
                self.arrSelectedContactDetail?.remove(at: index)
                self.tvContactDetails.reloadData()
            }   ///  */
            return cell
        }
        else if tableView == self.tvWithWhom {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MobileEmailTVCell", for: indexPath) as! MobileEmailTVCell
            
            cell.viewMain.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
            cell.costraintBottomViewMainToSuper.constant = 4.0
            
            cell.index = indexPath.row
            cell.lblValue.text = self.arrSelectedEmployee[indexPath.row]
            
            //cell.btnDelete.isHidden = true
            cell.onDeleteTap = { index in
                self.arrSelectedEmployee.remove(at: index)
                self.tvWithWhom.reloadData()
            }
            return cell
        }
        else if tableView == self.tvProductDetails {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DvrProductDetailsTVCell", for: indexPath) as! DvrProductDetailsTVCell
            
            cell.index = indexPath.row
            cell.lblProductName.text = self.arrSelectedProduct?[indexPath.row].name ?? ""
            cell.lblApproachedProductName.text = self.arrSelectedProduct?[indexPath.row].approachedProduct?.name ?? ""
            
            //cell.btnDelete.isHidden = true
            cell.onDeleteTap = { index in
                self.arrSelectedProduct?.remove(at: index)
                self.tvProductDetails.reloadData()
            }   ///  */
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == self.tvWithWhom {
            return 32
        }
        return UITableView.automaticDimension
    }
    
}


// MARK: - UITextFieldDelegate

extension AddDvrVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
//        if textField == self.txtCompanyName {
//            self.page = 1
//            self.strSearchText = newString as String
//            self.getExistBusinessPaartner(searchText: self.strSearchText ?? "", page: self.page)
//            return true
//        }
        if (textField == self.txtContactPersonTeleNo) {
            if (self.txtContactPersonTeleNo.text?.isNumber)! {
                return newString.length <= MAX_TELE_LENGTH
            }
            else {
                return true
            }
        }
        else if (textField == self.txtContactPersonMobileNo) {
            if (self.txtContactPersonMobileNo.text?.isNumber)! {
                return newString.length <= MAX_MOBILE_LENGTH
            }
            else {
                return true
            }
        }
//        else if (textField == self.txtZipCode) || (textField == self.txtDZipCode) {
//            if (self.txtZipCode.text?.isNumber)! || (self.txtDZipCode.text?.isNumber)! {
//                return newString.length <= MAX_ZIP_LENGTH
//            }
//            else {
//                return true
//            }
//        }
//        else if textField == self.txtAnnualTurnover {
//            switch string {
//            case "0","1","2","3","4","5","6","7","8","9":
//                return true
//            case ".":
//                let array = (textField.text)!.map { String($0) }
//                var decimalCount = 0
//                for character in array {
//                    if character == "." {
//                        decimalCount += 1
//                    }
//                }
//                
//                if decimalCount == 1 {
//                    return false
//                } else {
//                    return true
//                }
//            default:
//                let array = Array(string)
//                if array.count == 0 {
//                    return true
//                }
//                return false
//            }
//        }
//        else if textField == self.txtPAN {
//            return newString.length <= MAX_MOBILE_LENGTH
//        }
//        else {
            return true
//        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //self.txtCompanyName.resignFirstResponder()
        textField.resignFirstResponder()
           
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        //if self.checkValidation(to: textField.tag, from: textField.tag + 1) {
        //}
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            
            // Company 0 - 11
            if i == 0 {
                self.txtContactPersonName.text = self.txtContactPersonName.text?.trimmingCharacters(in: .whitespaces)
                
                if self.txtContactPersonName.text == "" {
                    //self.lblErrorCompanyName.getEmptyValidationString("Enter contact person name")
                    value = false
                    Utilities.showPopup(title: "Enter contact person name", type: .error)
                    break
                }
                else {
                    //self.lblErrorCompanyName.text = ""
                }
            }
            else if i == 1 {
                self.txtContactPersonMobileNo.text = self.txtContactPersonMobileNo.text?.trimmingCharacters(in: .whitespaces)
                
                if self.txtContactPersonMobileNo.text == "" {
                    //self.lblErrorCompanyName.getEmptyValidationString("Enter contact person name")
                    value = false
                    Utilities.showPopup(title: "Enter mobile number", type: .error)
                    break
                }
                else {
                    if (txtContactPersonMobileNo.text?.isNumber)! {
                        if !((txtContactPersonMobileNo.text?.count)! >= MIN_MOBILE_LENGTH) {
                            Utilities.showPopup(title: "Enter valid mobile number", type: .error)
                            value = false
                            break
                        }
                        else if !((txtContactPersonMobileNo.text?.count)! <= MAX_MOBILE_LENGTH) {
                            Utilities.showPopup(title: "Enter valid mobile number", type: .error)
                            value = false
                            break
                        }
                        else {
                            //self.lblErrorMobileNo.text = ""
                        }
                    }
                    else {
                        value = false
                        Utilities.showPopup(title: "Enter valid mobile number", type: .error)
                        break
                    }
                }
            }
            else if i == 2 {
            }
            else if i == 3 {
                self.txtContactPersonEmail.text = self.txtContactPersonEmail.text?.trimmingCharacters(in: .whitespaces)
                if self.txtContactPersonEmail.text == "" {
                    Utilities.showPopup(title: "Enter email", type: .error)
                    value = false
                    break
                }
                else if !Validations.isValid(email: self.txtContactPersonEmail.text!) {
                    Utilities.showPopup(title: Valid_Email, type: .error)
                    value = false
                    break
                }
                else {
                    //self.lblErrorEmailId.text = ""
                }
            }
            else if i == 4 {
            }
        }
        return value
    }
}



// MARK: - Keyboard

extension AddDvrVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            self.constraintBottomViewScrollMOutSuper.constant = keyboardOverlap > 0 ? keyboardOverlap : 0
            //self.constraintBottomTVProductList.constant = keyboardOverlap > 0 ? (keyboardOverlap - 85) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}


// MARK: - Get Text from Image.

extension AddDvrVC {
    func recognizeTextInImage(_ image: UIImage?) {
        self.showLoading()
        
        guard let cgImage = image?.cgImage else { return }
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        let request = VNRecognizeTextRequest { (request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            let recognizedStrings = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }
            
            // Process the recognized text as needed
            print("Add BUsiness P")
            print(recognizedStrings.joined(separator: "\n"))
            let lettersAndSpacesCharacterSet = CharacterSet.letters.union(.whitespaces).inverted
            //let numberAndSpacesCharacterSet = CharacterSet.
            //let testValid1 = "Jon Doe".rangeOfCharacter(from: lettersAndSpacesCharacterSet) == nil // true
            //let testInvalid1 = "Ben&Jerry".rangeOfCharacter(from: lettersAndSpacesCharacterSet) == nil // false
            //let testInvalid2 = "Peter2".rangeOfCharacter(from: lettersAndSpacesCharacterSet) == nil // false
            
            for i in 0 ..< recognizedStrings.count {
                if Validations.isValid(email: recognizedStrings[i]) {
                    self.txtContactPersonEmail.text = recognizedStrings[i]
                }
                else if recognizedStrings[i].rangeOfCharacter(from: lettersAndSpacesCharacterSet) == nil {
                    self.txtContactPersonName.text = recognizedStrings[i]
                }
                else if Validations.isValidScanNo(recognizedStrings[i]) {
                    self.txtContactPersonMobileNo.text = recognizedStrings[i]
                }
            }
            self.hideLoading()
        }
        request.recognitionLevel = .accurate
        do {
            try requestHandler.perform([request])
        } catch {
            print(error)
        }
    }
}



// MARK: - WebServices

extension AddDvrVC {
    
    func getBusinessPartnerList() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBusinessPartnerList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_TADA_BUSINESS_PARTNER_LIST, parameters: param) { (response: ApiResponseDVR?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrClientName = response?.result?.contacts ?? []
                    
                    if self.isRepeatDVR {
                        self.setUpRepeatData(repeatDvrDetail: self.repeatDvrUsersDetails)
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getIndustriesCategoryList() {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getIndustriesCategoryList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_INDUSTRIES_CATEGORY_LIST, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrIndustriesCategory = response?.result?.industriesCategory ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getEmpList() {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmpList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EMPLOYEES, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    let arrTempEmployee = response?.result?.employees ?? []
                    self.arrEmployee = arrTempEmployee.map { $0.employeeName! }
                    self.arrEmployee?.insert("Other", at: 0)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getApproachedProductList() {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getApproachedProductList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_TADA_PRODUCT_LIST, parameters: param) { (response: ApiResponseDVR?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrApproachedProduct = response?.result?.products ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getDvrOtherContact() {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getDvrOtherContact()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_DVR_CONTACT, parameters: param) { (response: ApiResponseDVR?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrOtherClientName = response?.result?.contacts ?? []
                    self.configureCitySearchTextField()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func checkDvrDate(strDate: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.checkDvrDate(strDate: strDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "dvr_date": strDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CHECK_DVR_DATE, parameters: param) { (response: ApiResponseDVR?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    if response?.result?.dateValid ?? 0 == 0 {
                        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
                        popupVC.modalPresentationStyle = .overCurrentContext
                        popupVC.modalTransitionStyle = .crossDissolve
                        popupVC.titleTxt = "Alert"
                        popupVC.strImgName = "InfoWLightRed"
                        popupVC.strMessage = response?.message ?? ""
                        popupVC.onTapOk = { str in
                            self.lblDailyVisitReportDate.text = "Select Date"
                            self.strDailyVisitReportDate = ""
                        }
                        self.present(popupVC, animated: true)
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func addDvr() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addDvr()
                }
            }
            return
        }
        
        var dvrContact: [[String: Any]] = []
        for (_, value) in (self.arrSelectedContactDetail ?? []).enumerated() {
            let tempObj = [
                "name": value.name ?? "",
                "mobile_no": value.pContact ?? "",
                "tel_no": value.sContact ?? "",
                "designation": value.designation ?? "",
                "email_id": value.email ?? ""
            ] as [String : Any]
            dvrContact.append(tempObj)
        }
        
        var dvrProduct: [[String: Any]] = []
        for (_, value) in (self.arrSelectedProduct ?? []).enumerated() {
            let tempObj = [
                "client_product": value.name ?? "",
                "client_product_capacity": "",
                "unit": "",
                "timeInterval": "DAILY",
                "product_id": value.approachedProduct?.productID ?? 0
            ] as [String : Any]
            dvrProduct.append(tempObj)
        }
        
        var dvrWithWhooms: [[String: Any]] = []
        for (_, value) in (self.arrSelectedEmployee ?? []).enumerated() {
            let tempObj = [
                "user_id": 0,
                "other_name": value,
                "company_name": ""
            ] as [String : Any]
            dvrWithWhooms.append(tempObj)
        }
        
        var strLeave: String = ""
        if self.isLeaveFDay {
            strLeave = "Full Day"
        }
        else if self.isLeaveHDay {
            strLeave = "Half Day"
        }
        
        let isSelectOtherClient = (self.lblClientName.text ?? "") == "Other" ? true : false
        
//        {
//            "industries_type":"Confectionerie",
//            "bm_type":"Exporter",
//            "city":"Ahmedabad",
//            "dvr_contacts":[
//                {
//                    "name":"mitesh",
//                    "mobile_no":"8799484894",
//                    "tel_no":"",
//                    "designation":"Sr.Production Manager",
//                    "email_id":"test@gsh.ns"
//                }
//            ],
//            "is_personal_visit":1,
//            "meeting_status":"Meeting",
//            "follow_up_type":"Mail",
//            "dvr_products":[
//                {
//                    "client_product":"Buttermilk",
//                    "client_product_capacity":"",
//                    "unit":"",
//                    "timeInterval":"DAILY",
//                    "product_id":38
//                },
//                {
//                    "client_product":"Bakery",
//                    "client_product_capacity":"",
//                    "unit":"",
//                    "timeInterval":"DAILY",
//                    "product_id":40
//                }
//            ],
//            "payment_mode":"Cash",
//            "amount":"456",
//            "wfo_remarks":"Test Wfo",
//            "ae_name":"ae test",
//            "ae_city":"ae test city",
//            "with_whooms":[
//                {
//                    "user_id":0,
//                    "other_name":"Raja Beg",
//                    "company_name":"Novasol"
//                },
//                {
//                    "user_id":0,
//                    "other_name":"Prasanna Kumar",
//                    "company_name":"Novasol"
//                }
//            ],
//            "leave_type":"Full Day"
//        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "visit_for": DVR.getVisitForInitials(arrVisitFor: self.arrSelectedVisitFor),
            "dvr_date": self.strDailyVisitReportDate,
            "remark": self.txtRemark.text ?? "",
            "business_partner_id": isSelectOtherClient ? 0 : self.objSelectedClientName?.bID ?? 0,
            "business_partner_name": isSelectOtherClient ? (self.txtClientName.text ?? "") : "",
            "industries_type": self.strSelectedIndustriesType,
            "bm_type": self.strSelectedBusinessType,
            "dvr_contacts": dvrContact,
            "city": self.txtCityName.text ?? "",
            "is_personal_visit": self.isPersonalVisit ? 1 : 0,
            "meeting_status": self.strSelectedFollowUpType,
            "follow_up_type": self.strSelectedFollowUpMode,
            "dvr_products": dvrProduct,
            "leave_type": strLeave,
            "payment_mode": self.lblSelectedPaymentReceivedMode.text ?? "",
            "amount": self.txtPaymentAmount.text ?? "",
            "wfo_remarks": self.txtWFORemarks.text ?? "",
            "ae_name": self.txtExhibitionName.text ?? "",
            "ae_city": self.txtExhibitionCity.text ?? "",
            "with_whooms": dvrWithWhooms
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_DVR, parameters: param) { (response: ApiResponseDVR?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.displaySuccessMsg(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func uploadImage(id: Int, index: Int = 0, strMessage: String, arrUploadImg: [String]?) {
        var imgFileName: String = ""
        imgFileName = imgFileName == "" ? (URL(string: arrUploadImg?[index] ?? "")?.lastPathComponent)! : imgFileName
        imgFileName = imgFileName != "" ? imgFileName : "\(Utilities.fileName()).png"
        let ivUploadImg = UIImageView()
        ivUploadImg.setImage(imageUrl: arrUploadImg?[index] ?? "")
        
        //showLoading()
        APIManager.sharedManager.uploadImage(url: APIManager.sharedManager.UPLOAD_EXPENSE_ATTACHMENT,
                                             dictiParam: [ "user_id": APIManager.sharedManager.userId,
                                                           "expense_id": id,
                                                           "image": imgFileName
                                                         ],
                                             image: ivUploadImg.image as Any,
                                             type: "image",
                                             contentType: imgFileName.mimeType(),
                                             imageKey: "profile_image")
        { isValid, strValue in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                //self.hideLoading()
                if ((arrUploadImg?.count ?? 0) - 1) > index {
                    let i = index + 1
                    self.uploadImage(id: id, index: i, strMessage: strMessage, arrUploadImg: arrUploadImg)
                }
                else {
                    DispatchQueue.main.async {
                        self.hideLoadingWMsg()
                        self.displaySuccessMsg(message: strMessage)
                    }
                }
            }
        } errorCompletion: { isValid, strValue in
            print("Close with error")
            self.hideLoadingWMsg()
        }
    }
    
    func displaySuccessMsg(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.navigationController?.popViewController(animated: true)
        }
        self.present(popupVC, animated: true)
    }
    
}
