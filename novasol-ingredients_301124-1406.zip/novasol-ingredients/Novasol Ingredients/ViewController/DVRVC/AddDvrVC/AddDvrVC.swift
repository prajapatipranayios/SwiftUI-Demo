//
//  AddDvrVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 23/08/24.
//

import UIKit
import AVFoundation
import SearchTextField

class AddDvrVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = "Are you sure to discard DVR details?"
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            self.navigationController?.popViewController(animated: true)
        }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var btnDone: UIButton!
    @IBAction func btnDoneTap(_ sender: UIButton) {
        if self.arrSelectedVisitFor.count > 0 {
            self.checkAllValidation()
        }
        else {
            Utilities.showPopup(title: "Please select visit type", type: .error)
        }
    }
    
    @IBOutlet weak var viewScrollMOut: UIView!
    @IBOutlet weak var constraintBottomViewScrollMOutSuper: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIView!
    @IBOutlet weak var viewScrollMIn: UIView!
    
    
    // View Visit For
    
    @IBOutlet weak var viewMVisitFor: UIView!
    @IBOutlet weak var viewVisitFor: UIView!
    @IBOutlet weak var lblVisitFor: UILabel!
    @IBOutlet weak var btnSelectVisitFor: UIButton!
    @IBAction func btnSelectVisitForTap(_ sender: UIButton) {
        
        let arrTempVisitFor: [String] = DVR.getVisitFor()
        
        var arrTempSelectedValue: [String] = []
        for strValue in self.arrSelectedVisitFor.enumerated() {
            let tempValue = arrTempVisitFor.filter { $0 == strValue.element }
            if tempValue.count > 0 {
                arrTempSelectedValue.append("\(tempValue[0])")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Visit For"
        popupVC.value = arrTempVisitFor
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.didSelectItem = { arrValue in
            self.setUpViewArr(arrValue: arrValue)
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    
    // View Daily Visit Report Date
    
    @IBOutlet weak var viewMDailyVisitReportDate: UIView!
    
    @IBOutlet weak var lblDailyVisitReportDateTitle: UILabel!
    @IBOutlet weak var lblDailyVisitReportDate: UILabel!
    @IBOutlet weak var btnSelectDailyVisitReportDate: UIButton!
    @IBAction func btnSelectDailyVisitReportDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.didSelectDate = { date in
            self.lblDailyVisitReportDate.text = date
            self.strDailyVisitReportDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy-MM-dd")
            
            self.checkDvrDate(strDate: self.strDailyVisitReportDate)
        }
        popupVC.onClose = {
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    
    // View Client Details
    
    @IBOutlet weak var viewMClientDetails: UIView!
    @IBOutlet weak var constraintHeightViewMClientDetails: NSLayoutConstraint!
    @IBOutlet weak var viewBorderClientDetails: UIView!
    @IBOutlet weak var lblClientDetailsTitle: UILabel!
    
    @IBOutlet weak var viewClientName: UIView!
    @IBOutlet weak var lblClientName: UILabel!
    @IBOutlet weak var btnSelectClientName: UIButton!
    @IBAction func btnSelectClientNameTap(_ sender: UIButton) {
        
        var arrTempClientName: [String] = (self.arrClientName ?? []).map { $0.name ?? "" }
        arrTempClientName.insert("Other", at: 0)
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Select Client Name"
        popupVC.value = arrTempClientName
        popupVC.selectedValue = self.lblClientName.text ?? "Select Client Type"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.setUpClientData(strValue: strValue)
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewTxtClientName: UIView!
    @IBOutlet weak var constraintHeightViewTxtClientName: NSLayoutConstraint!
    //@IBOutlet weak var txtClientName: TLTextField!
    @IBOutlet weak var txtClientName: SearchTextField!
    
    @IBOutlet weak var viewIndustriesType: UIView!
    @IBOutlet weak var lblIndustriesType: UILabel!
    @IBOutlet weak var btnSelectIndustriesType: UIButton!
    @IBAction func btnSelectIndustriesTypeTap(_ sender: UIButton) {
        
        let arrTempIndustriesType: [String] = self.arrIndustriesCategory ?? []
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Select Industries Type"
        popupVC.value = arrTempIndustriesType
        popupVC.selectedValue = self.lblIndustriesType.text ?? "Select Industries Type"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.setUpIndustriesType(strValue: strValue)
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewBusinessType: UIView!
    @IBOutlet weak var lblBusinessType: UILabel!
    @IBOutlet weak var btnSelectBusinessType: UIButton!
    @IBAction func btnSelectBusinessTypeTap(_ sender: UIButton) {
        
        let arrTempBusinessType: [String] = self.arrBusinessType
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Business Type"
        popupVC.value = arrTempBusinessType
        popupVC.selectedValue = self.lblBusinessType.text ?? "Select Business Type"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.setUpBusinessType(strValue: strValue)
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewMTradersType: UIView!
    @IBOutlet weak var constraintHeightMTradersType: NSLayoutConstraint!
    @IBOutlet weak var viewTradersType: UIView!
    @IBOutlet weak var lblTradersType: UILabel!
    @IBOutlet weak var btnSelectTradersType: UIButton!
    @IBAction func btnSelectTradersTypeTap(_ sender: UIButton) {
        
        let arrTempTradersType: [String] = ["Wholesaler", "Semi Wholesaler", "Retailer"]
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Traders Type"
        popupVC.value = arrTempTradersType
        popupVC.selectedValue = self.lblTradersType.text ?? "Select Traders Type"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.setUpTradersType(strValue: strValue)
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    
    
    // View Contact Details
    
    @IBOutlet weak var viewMContactDetails: UIView!
    @IBOutlet weak var constraintHeightViewMContactDetails: NSLayoutConstraint!
    @IBOutlet weak var viewBorderContactDetails: UIView!
    @IBOutlet weak var lblContactDetailsTitle: UILabel!
    
    @IBOutlet weak var txtContactPersonName: TLTextField!
    @IBOutlet weak var txtContactPersonMobileNo: TLTextField!
    @IBOutlet weak var txtContactPersonTeleNo: TLTextField!
    @IBOutlet weak var txtContactPersonEmail: TLTextField!
    @IBOutlet weak var txtContactPersonDesignation: TLTextField!
    
    @IBOutlet weak var btnScanCard: UIButton!
    @IBAction func btnScanCardTap(_ sender: UIButton) {
        //Camera
        AVCaptureDevice.requestAccess(for: AVMediaType.video) { response in
            if response {
                //access granted
                DispatchQueue.main.async {
                    let cameraVC = CameraViewController()
                    cameraVC.captureImg = { image in
                        self.recognizeTextInImage(image)
                    }
                    self.present(cameraVC, animated: true, completion: nil)
                }
            }
            else {
                
            }
        }
    }
    
    @IBOutlet weak var btnAddAnotherPerson: UIButton!
    @IBAction func btnAddAnotherPersonTap(_ sender: UIButton) {
        if self.checkValidation(to: self.txtContactPersonName.tag, from: self.txtContactPersonDesignation.tag + 1) {
            print("validation Success -- Add to contact")
            let tempContact = AddBPContact( name: self.txtContactPersonName.text!,
                                            pContact: self.txtContactPersonMobileNo.text!,
                                            sContact: self.txtContactPersonTeleNo.text!,
                                            email: self.txtContactPersonEmail.text!,
                                            designation: self.txtContactPersonDesignation.text!)
            self.arrSelectedContactDetail?.append(tempContact)
            
            self.txtContactPersonName.text = ""
            self.txtContactPersonMobileNo.text = ""
            self.txtContactPersonTeleNo.text = ""
            self.txtContactPersonEmail.text = ""
            self.txtContactPersonDesignation.text = ""
            
            self.tvContactDetails.reloadData()
            //self.constraintHeightTVContactDetails.constant = 10
        }
    }
    
    @IBOutlet weak var tvContactDetails: UITableView! {
        didSet {
            self.tvContactDetails.delegate = self
            self.tvContactDetails.dataSource = self
            self.tvContactDetails.register(UINib(nibName: "AddContactTVCell", bundle: nil), forCellReuseIdentifier: "AddContactTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVContactDetails: NSLayoutConstraint!
    
    
    
    // View Work from office
    
    @IBOutlet weak var viewMWFO: UIView!
    @IBOutlet weak var constraintHeightViewMWFO: NSLayoutConstraint!
    @IBOutlet weak var viewBorderWFO: UIView!
    @IBOutlet weak var lblWFOTitle: UILabel!
    
    @IBOutlet weak var txtWFORemarks: TLTextField!
    
    
    
    // View Work from office
    
    @IBOutlet weak var viewMAttendedExhibition: UIView!
    @IBOutlet weak var constraintHeightViewMAttendedExhibition: NSLayoutConstraint!
    @IBOutlet weak var viewBorderAttendedExhibition: UIView!
    @IBOutlet weak var lblAttendedExhibitionTitle: UILabel!
    
    @IBOutlet weak var txtExhibitionName: TLTextField!
    @IBOutlet weak var txtExhibitionCity: TLTextField!
    
    @IBOutlet weak var lblWithWhomTitle: UILabel!
    @IBOutlet weak var viewSelectEmpName: UIView!
    @IBOutlet weak var lblSelectedEmpName: UILabel!
    @IBOutlet weak var btnSelectEmpName: UIButton!
    @IBAction func btnSelectEmpNameTap(_ sender: UIButton) {
        
        let arrTempEmployee: [String] = self.arrEmployee ?? []
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Select Employee Name"
        popupVC.value = arrTempEmployee
        popupVC.selectedValue = self.lblSelectedEmpName.text ?? "Select Employee Name"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.lblSelectedEmpName.text = strValue
            
            self.constraintHeightViewTxtEmpName.priority = .required
            if strValue == "Other" {
                self.constraintHeightViewTxtEmpName.priority = .defaultLow
            }
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewTxtEmpName: UIView!
    @IBOutlet weak var constraintHeightViewTxtEmpName: NSLayoutConstraint!
    @IBOutlet weak var txtWithWhomEmployeeName: TLTextField!
    
    @IBOutlet weak var btnAddPerson: UIButton!
    @IBAction func btnAddPersonTap(_ sender: UIButton) {
        var isValid: Bool = true
        var strValue: String = self.lblSelectedEmpName.text ?? ""
        
        if self.lblSelectedEmpName.text ?? "" == "Select Employee Name" {
            isValid = false
            Utilities.showPopup(title: "Please select employee name", type: .error)
        }
        else {
            if self.lblSelectedEmpName.text ?? "" == "Other" {
                strValue = self.txtWithWhomEmployeeName.text ?? ""
                if self.txtWithWhomEmployeeName.text == "" {
                    isValid = false
                    Utilities.showPopup(title: "Please enter employee name", type: .error)
                }
            }
        }
        
        if isValid {
            self.arrSelectedEmployee.append(strValue)
            self.tvWithWhom.reloadData()
            self.lblSelectedEmpName.text = "Select Employee Name"
            self.txtWithWhomEmployeeName.text = ""
            self.constraintHeightViewTxtEmpName.priority = .required
        }
    }
    @IBOutlet weak var tvWithWhom: UITableView! {
        didSet {
            self.tvWithWhom.delegate = self
            self.tvWithWhom.dataSource = self
            self.tvWithWhom.register(UINib(nibName: "MobileEmailTVCell", bundle: nil), forCellReuseIdentifier: "MobileEmailTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVWithWhom: NSLayoutConstraint!
    
    
    // View Leave
    
    @IBOutlet weak var viewMLeave: UIView!
    @IBOutlet weak var constraintHeightViewMLeave: NSLayoutConstraint!
    @IBOutlet weak var viewBorderLeave: UIView!
    @IBOutlet weak var lblLeaveTitle: UILabel!
    
    @IBOutlet weak var lblLeaveTypeTitle: UILabel!
    @IBOutlet weak var btnLeaveFullDay: UIButton!
    @IBAction func btnLeaveFullDayTap(_ sender: UIButton) {
        self.isLeaveFDay = true
        self.btnLeaveFullDay.isSelected = self.isLeaveFDay
        
        self.isLeaveHDay = false
        self.btnLeaveHalfDay.isSelected = self.isLeaveHDay
    }
    
    @IBOutlet weak var btnLeaveHalfDay: UIButton!
    @IBAction func btnLeaveHalfDayTap(_ sender: UIButton) {
        self.isLeaveFDay = false
        self.btnLeaveFullDay.isSelected = self.isLeaveFDay
        
        self.isLeaveHDay = true
        self.btnLeaveHalfDay.isSelected = self.isLeaveHDay
    }
    
    
    // View Product Details
    
    @IBOutlet weak var viewMProductDetails: UIView!
    @IBOutlet weak var constraintHeightViewMProductDetails: NSLayoutConstraint!
    @IBOutlet weak var viewBorderProductDetails: UIView!
    @IBOutlet weak var lblProductDetailsTitle: UILabel!
    
    @IBOutlet weak var viewSelectClientProduct: UIView!
    @IBOutlet weak var lblSelectedClientProduct: UILabel!
    @IBOutlet weak var btnSelectClientProduct: UIButton!
    @IBAction func btnSelectClientProductTap(_ sender: UIButton) {
        
        let arrTempClintProduct: [String] = DVR.getClintProduct()
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Select Client Product"
        popupVC.value = arrTempClintProduct
        popupVC.selectedValue = self.lblSelectedClientProduct.text ?? "Select Client Product"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.lblSelectedClientProduct.text = strValue
            self.isClientProductSelected = true
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewSelectApproachedProduct: UIView!
    @IBOutlet weak var lblSelectedApproachedProduct: UILabel!
    @IBOutlet weak var btnSelectApproachedProduct: UIButton!
    @IBAction func btnSelectApproachedProductTap(_ sender: UIButton) {
        
        let arrTempApproachedProduct: [String] = (self.arrApproachedProduct ?? []).map { $0.name ?? "" }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Select Approached Product"
        popupVC.value = arrTempApproachedProduct
        popupVC.selectedValue = self.lblSelectedApproachedProduct.text ?? "Select Approached Product"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.lblSelectedApproachedProduct.text = strValue
            self.isApproachedProductSelected = true
            // Save selected product  and  id
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var btnAddAnotherProduct: UIButton!
    @IBAction func btnAddAnotherProductTap(_ sender: UIButton) {
        
        if self.isClientProductSelected && self.isApproachedProductSelected {
            
            let tempApproachedProduct = (self.arrApproachedProduct ?? []).filter { $0.name == self.lblSelectedApproachedProduct.text ?? "" }
            
            let tempObj: SelectedProductDtails = SelectedProductDtails(name: self.lblSelectedClientProduct.text ?? "", approachedProduct: tempApproachedProduct[0])
            
            self.arrSelectedProduct?.append(tempObj)
            self.tvProductDetails.reloadData()
            
            self.isClientProductSelected = false
            self.isApproachedProductSelected = false
            self.lblSelectedClientProduct.text = "Select Client Product"
            self.lblSelectedApproachedProduct.text = "Select Approached Product"
        }
        else {
            if !self.isClientProductSelected {
                Utilities.showPopup(title: "Please select client product", type: .error)
            }
            else if !self.isApproachedProductSelected {
                Utilities.showPopup(title: "Please select approached product", type: .error)
            }
        }
    }
    @IBOutlet weak var tvProductDetails: UITableView! {
        didSet {
            self.tvProductDetails.delegate = self
            self.tvProductDetails.dataSource = self
            self.tvProductDetails.register(UINib(nibName: "DvrProductDetailsTVCell", bundle: nil), forCellReuseIdentifier: "DvrProductDetailsTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVProductDetails: NSLayoutConstraint!
    
    
    // View Payment Details
    
    @IBOutlet weak var viewMPaymentDetails: UIView!
    @IBOutlet weak var constraintHeightViewMPaymentDetails: NSLayoutConstraint!
    @IBOutlet weak var viewBorderPaymentDetails: UIView!
    @IBOutlet weak var lblPaymentDetailsTitle: UILabel!
    
    @IBOutlet weak var viewSelectPaymentReceivedMode: UIView!
    @IBOutlet weak var constraintBottomViewSelectPaymentReceivedModeToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var lblSelectedPaymentReceivedMode: UILabel!
    @IBOutlet weak var btnSelectPaymentReceivedMode: UIButton!
    @IBAction func btnSelectPaymentReceivedModeTap(_ sender: UIButton) {
        
        let arrTempPaymentReceivedMode: [String] = ["Cash", "NEFT", "Cheque", "Other"]
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Payment Received Mode"
        popupVC.value = arrTempPaymentReceivedMode
        popupVC.selectedValue = self.lblSelectedPaymentReceivedMode.text ?? "Select Payment Received Mode"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            
            self.setUpPaymentReceivedMode(strValue: strValue)
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var viewTxtAmount: UIView!
    @IBOutlet weak var constraintHeightViewTxtAmount: NSLayoutConstraint!
    @IBOutlet weak var txtPaymentAmount: TLTextField!
    
    @IBOutlet weak var viewTxtPaymentRemark: UIView!
    @IBOutlet weak var constraintHeightViewTxtPaymentRemark: NSLayoutConstraint!
    @IBOutlet weak var txtPaymentRemarks: TLTextField!
    
    @IBOutlet weak var viewCheckImg: UIView!
    @IBOutlet weak var btnChequeImg: UIButton!
    @IBAction func btnChequeImgTap(_ sender: UIButton) {
        //Camera
        AVCaptureDevice.requestAccess(for: AVMediaType.video) { response in
            if response {
                //access granted
                DispatchQueue.main.async {
                    let cameraVC = CameraViewController()
                    cameraVC.captureImg = { image in
                        self.ivChequeImg.image = image
                        self.constraintBottomIVChequeImgToSuper.priority = .required
                        self.isChequeImgSelected = true
                    }
                    self.present(cameraVC, animated: true, completion: nil)
                }
            }
            else {
                
            }
        }
    }
    @IBOutlet weak var ivChequeImg: UIImageView!
    @IBOutlet weak var constraintBottomIVChequeImgToSuper: NSLayoutConstraint!
    
    
    
    // City Name
    
    @IBOutlet weak var viewMCityName: UIView!
    @IBOutlet weak var constraintHeightViewMCityName: NSLayoutConstraint!
    
    //@IBOutlet weak var txtCityName: TLTextField!
    @IBOutlet weak var txtCityName: SearchTextField!
    
    
    // Personal Visit
    
    @IBOutlet weak var viewMPersonalVisit: UIView!
    @IBOutlet weak var constraintHeightViewMPersonalVisit: NSLayoutConstraint!
    
    @IBOutlet weak var lblPersonalVisitTitle: UILabel!
    
    @IBOutlet weak var btnPersonalVisitYes: UIButton!
    @IBAction func btnPersonalVisitYesTap(_ sender: UIButton) {
        self.btnPersonalVisitYes.isSelected = true
        self.isPersonalVisit = true
        self.btnPersonalVisitNo.isSelected = false
    }
    
    @IBOutlet weak var btnPersonalVisitNo: UIButton!
    @IBAction func btnbtnPersonalVisitNoTap(_ sender: UIButton) {
        self.btnPersonalVisitYes.isSelected = false
        self.isPersonalVisit = false
        self.btnPersonalVisitNo.isSelected = true
    }
    
    
    // Remarks
    
    @IBOutlet weak var viewMRemark: UIView!
    @IBOutlet weak var constraintHeightViewMRemark: NSLayoutConstraint!
    
    @IBOutlet weak var txtRemark: TLTextField!
    
    
    
    // View FollowUp Type
    
    @IBOutlet weak var viewMSelectFollowUpType: UIView!
    @IBOutlet weak var constraintHeightViewMSelectFollowUpType: NSLayoutConstraint!
    
    @IBOutlet weak var viewSelectFollowUpType: UIView!
    @IBOutlet weak var lblSelectedFollowUpType: UILabel!
    @IBOutlet weak var btnSelectFollowUpType: UIButton!
    @IBAction func btnSelectFollowUpTypeTap(_ sender: UIButton) {
        
        let arrTempFollowUpType: [String] = ["Meeting", "Trial", "Low Potential", "Deal Closed", "Call"]
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Follow Up Type"
        popupVC.value = arrTempFollowUpType
        popupVC.selectedValue = self.lblSelectedFollowUpType.text ?? "Select Follow Up Type"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.lblSelectedFollowUpType.text = strValue
            self.strSelectedFollowUpType = strValue
            self.isFollowUpTypeSelected = true
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    
    // View FollowUp Mode
    
    @IBOutlet weak var viewMSelectFollowUpMode: UIView!
    @IBOutlet weak var constraintHeightViewMSelectFollowUpMode: NSLayoutConstraint!
    
    @IBOutlet weak var viewSelectFollowUpMode: UIView!
    @IBOutlet weak var lblSelectedFollowUpMode: UILabel!
    @IBOutlet weak var btnSelectFollowUpMode: UIButton!
    @IBAction func btnSelectFollowUpModeTap(_ sender: UIButton) {
        
        let arrTempFollowUpMode: [String] = ["Mail", "Call", "Personal Visit"]
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Follow Up Mode"
        popupVC.value = arrTempFollowUpMode
        popupVC.selectedValue = self.lblSelectedFollowUpMode.text ?? "Select Follow Up Mode"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.lblSelectedFollowUpMode.text = strValue
            self.strSelectedFollowUpMode = strValue
            self.isFollowUpModeSelected = true
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    
    // Follow Up Date
    
    @IBOutlet weak var viewMFollowUpDate: UIView!
    @IBOutlet weak var constraintHeightViewMFollowUpDate: NSLayoutConstraint!
    
    @IBOutlet weak var lblFollowUpDateTitle: UILabel!
    @IBOutlet weak var lblFollowUpDate: UILabel!
    @IBOutlet weak var btnSelectFollowUpDate: UIButton!
    @IBAction func btnSelectFollowUpDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.isMaxDateLimit = false
        popupVC.minStartDate = Utilities.convertDateToString(date: Date(), NewDateFormate: "dd-MMM-yyyy")
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.didSelectDate = { date in
            self.lblFollowUpDate.text = date
            self.strFollowUpDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy-MM-dd")
        }
        popupVC.onClose = {
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    
    
    
    // MARK: - Outlet
    
    var strScreenTitle: String = "DAILY VISIT REPORT".capitalized
    
    var isClientDetailActive: Bool = false
    var isContactDetailActive: Bool = false
    var isWFOActive: Bool = false
    var isAttendedExhibitionActive: Bool = false
    var isLeaveActive: Bool = false
    var isProductDetailsActive: Bool = false
    var isPaymentDetailsActive: Bool = false
    var isCityNameActive: Bool = false
    var isPersonalVisitActive: Bool = false
    var isFollowUpTypeActive: Bool = false
    var isFollowUpModeActive: Bool = false
    var isFollowUpDateActive: Bool = false
    
    // Visit For
    var isVFApproachedForProducts: Bool = false
    var isVFPaymentCollection: Bool = false
    var isVFMeeting: Bool = false
    var isVFTrial: Bool = false
    var isVFWFO: Bool = false
    var isVFAttendedExhibition: Bool = false
    var isVFLeave: Bool = false
    var isVFPhoneCall: Bool = false
    
    
    
    var isDVRDateSelected: Bool = false
    var isClientNameSelected: Bool = false
    var isIndustryTypeSelected: Bool = false
    var isBusinssTypeSelected: Bool = false
    var isTradersTypeSelected: Bool = false
    var isEmployeeNameSelected: Bool = false
    var isClientProductSelected: Bool = false
    var isApproachedProductSelected: Bool = false
    var isPaymentReceiveModeSelected: Bool = false
    
    
    var isFollowUpTypeSelected: Bool = false
    var isFollowUpModeSelected: Bool = false
    var isFollowUpDateSelected: Bool = false
    
    
    var arrClientName: [ClientContact]? = []
    var arrOtherClientName: [ClientContact]? = []
    var arrIndustriesCategory: [String]? = []
    var arrBusinessType: [String] = ["Manufacture", "Traders", "Exporter"]
    var arrSelectedContactDetail: [AddBPContact]? = []
    
    var arrEmployee: [String]? = []
    var arrSelectedEmployee: [String] = []
    
    var isLeaveFDay: Bool = false
    var isLeaveHDay: Bool = false
    var arrApproachedProduct: [DvrProduct]? = []
    var arrCities: [CityInfo]? = []
    var arrCityType: [CityType]? = []
    var isChequeImgSelected: Bool = false
    var isPersonalVisit: Bool = false
    
    var arrSelectedVisitFor: [String] = []
    var strDailyVisitReportDate: String = ""
    var objSelectedClientName: ClientContact?
    var strSelectedIndustriesType: String = ""
    var strSelectedBusinessType: String = ""
    var strSelectedTradersType: String = ""
    var strSelectedPaymentReceivedMode: String = ""
    var strSelectedFollowUpType: String = ""
    var strSelectedFollowUpMode: String = ""
    var strFollowUpDate: String = ""
    
    
    
    struct SelectedProductDtails {
        var name: String?
        var approachedProduct: DvrProduct?
        var productId: Int? = 0
    }
    var arrSelectedProduct: [SelectedProductDtails]? = []
    
    let tvKeyPath = "contentSize"
    
    var isRepeatDVR: Bool = false
    var repeatDvrUsersDetails: DVRUserList?
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        
        self.viewBorderClientDetails.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.viewBorderContactDetails.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.viewBorderWFO.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.viewBorderAttendedExhibition.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.viewBorderLeave.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.viewBorderProductDetails.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.viewBorderPaymentDetails.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        
        self.lblClientDetailsTitle.textColor = Colors.theme.returnColor()
        self.lblContactDetailsTitle.textColor = Colors.theme.returnColor()
        self.lblWFOTitle.textColor = Colors.theme.returnColor()
        self.lblAttendedExhibitionTitle.textColor = Colors.theme.returnColor()
        self.lblLeaveTitle.textColor = Colors.theme.returnColor()
        self.lblProductDetailsTitle.textColor = Colors.theme.returnColor()
        self.lblPaymentDetailsTitle.textColor = Colors.theme.returnColor()
        
        self.btnScanCard.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.btnAddAnotherPerson.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.btnAddPerson.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.btnAddAnotherProduct.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        self.btnChequeImg.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        
        self.constraintHeightViewTxtClientName.priority = .required
        self.constraintHeightMTradersType.priority = .required
        self.constraintHeightViewTxtEmpName.priority = .required
        self.constraintBottomViewSelectPaymentReceivedModeToSuper.priority = .required
        
        self.constraintHeightTVContactDetails.constant = 0
        self.constraintHeightTVWithWhom.constant = 0
        self.constraintHeightTVProductDetails.constant = 0
        
        self.arrCities = self.loadDataFromJson(fileName: "Cities", as: [CityInfo].self)
        self.arrCityType = self.loadDataFromJson(fileName: "CityType", as: [CityType].self)
        
        
        //self.getDvrOtherContact()
        self.getIndustriesCategoryList()
        self.getEmpList()
        self.getApproachedProductList()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.getBusinessPartnerList()
        }
        
        self.setUPView()
        self.configureCitySearchTextField()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.tvContactDetails.addObserver(self, forKeyPath: tvKeyPath, options: .new, context: nil)
        self.tvWithWhom.addObserver(self, forKeyPath: tvKeyPath, options: .new, context: nil)
        self.tvProductDetails.addObserver(self, forKeyPath: tvKeyPath, options: .new, context: nil)
        
        self.checkKeyboard(kView: self.viewMClientDetails)
        self.checkKeyboard(kView: self.viewMContactDetails)
        self.checkKeyboard(kView: self.viewMWFO)
        self.checkKeyboard(kView: self.viewMAttendedExhibition)
        self.checkKeyboard(kView: self.viewMLeave)
        self.checkKeyboard(kView: self.viewMProductDetails)
        self.checkKeyboard(kView: self.viewMPaymentDetails)
        self.checkKeyboard(kView: self.viewMCityName)
        self.checkKeyboard(kView: self.viewMPersonalVisit)
        self.checkKeyboard(kView: self.viewMRemark)
        self.checkKeyboard(kView: self.viewMSelectFollowUpType)
        self.checkKeyboard(kView: self.viewMSelectFollowUpMode)
        self.checkKeyboard(kView: self.viewMFollowUpDate)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.tvContactDetails.removeObserver(self, forKeyPath: tvKeyPath)
        self.tvWithWhom.removeObserver(self, forKeyPath: tvKeyPath)
        self.tvProductDetails.removeObserver(self, forKeyPath: tvKeyPath)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            let changedTableView = object as? UITableView
            
            if changedTableView == self.tvContactDetails {
                if let newvalue = change?[.newKey] {
                    let newsize  = newvalue as! CGSize
                    self.constraintHeightTVContactDetails.constant = newsize.height
                }
            }
            else if changedTableView == self.tvWithWhom {
                if let newvalue = change?[.newKey] {
                    let newsize  = newvalue as! CGSize
                    self.constraintHeightTVWithWhom.constant = newsize.height
                }
            }
            else if changedTableView == self.tvProductDetails {
                if let newvalue = change?[.newKey] {
                    let newsize  = newvalue as! CGSize
                    self.constraintHeightTVProductDetails.constant = newsize.height
                }
            }
        }
    }
    
    func configureCitySearchTextField() {
        // Start visible even without user's interaction as soon as created - Default: false
        self.txtCityName.startVisibleWithoutInteraction = false
        self.txtCityName.theme = SearchTextFieldTheme.defaultTheme(font: Fonts.Regular.returnFont(size: 17.0))
        self.txtCityName.theme.bgColor = UIColor(hexString: "#FEFEFE", alpha: 1.0)
        self.txtCityName.maxResultsListHeight = 200
        self.txtCityName.font = Fonts.Regular.returnFont(size: 19)
        
        self.txtClientName.startVisibleWithoutInteraction = false
        self.txtClientName.theme = SearchTextFieldTheme.defaultTheme(font: Fonts.Regular.returnFont(size: 17.0))
        self.txtClientName.theme.bgColor = UIColor(hexString: "#FEFEFE", alpha: 1.0)
        self.txtClientName.maxResultsListHeight = 200
        self.txtClientName.font = Fonts.Regular.returnFont(size: 19)
        
        // Set data source
        let cities = (self.arrCities ?? []).map { $0.name! }
        self.txtCityName.filterStrings(cities)
        
        let otherName = (self.arrOtherClientName ?? []).map { $0.businessPartnerName! }
        self.txtClientName.filterStrings(otherName)
        
        self.txtClientName.onValueSelect = { strValue in
            
            let tempObj = (self.arrOtherClientName ?? []).filter { $0.businessPartnerName! == strValue }
            self.isClientNameSelected = true
            
            self.lblIndustriesType.text = "Select Industries Type"
            self.lblBusinessType.text = "Select Business Type"
            
            self.arrSelectedContactDetail?.removeAll()
            if tempObj.count != 0 {
                self.objSelectedClientName = tempObj[0]
                
                self.lblIndustriesType.text = (self.arrIndustriesCategory ?? []).contains(tempObj[0].industriesType ?? "") ? (tempObj[0].industriesType ?? "") : "Select Industries Type"
                
                self.lblBusinessType.text = self.arrBusinessType.contains(tempObj[0].bmType ?? "") ? (tempObj[0].bmType ?? "") : "Select Business Type"
                
                
                for (_, value) in (tempObj[0].contacts ?? []).enumerated() {
                    let tempContact = AddBPContact( name: value.name,
                                                    pContact: value.mobileNo,
                                                    sContact: value.telNo,
                                                    email: value.emailID,
                                                    designation: value.designation)
                    self.arrSelectedContactDetail?.append(tempContact)
                }
                
                self.constraintHeightMTradersType.priority = .required
                if self.lblBusinessType.text ?? "" == "Traders" {
                    self.constraintHeightMTradersType.priority = .defaultLow
                }
                
                self.txtCityName.text = tempObj[0].city ?? ""
            }
            self.tvContactDetails.reloadData()
            
        }
    }
}



// MARK: - SetUp Data
extension AddDvrVC {
    
    func setUpClientData(strValue: String) {
        
        self.lblClientName.text = strValue
        
        let tempObj = (self.arrClientName ?? []).filter { $0.name! == strValue }
        self.isClientNameSelected = true
        self.constraintHeightViewTxtClientName.priority = .required
        
        self.lblIndustriesType.text = "Select Industries Type"
        self.lblBusinessType.text = "Select Business Type"
        self.txtClientName.text = ""
        
        self.arrSelectedContactDetail?.removeAll()
        if tempObj.count != 0 {
            self.objSelectedClientName = tempObj[0]
            
            self.lblIndustriesType.text = (self.arrIndustriesCategory ?? []).contains(tempObj[0].industriesType ?? "") ? (tempObj[0].industriesType ?? "") : "Select Industries Type"
            self.strSelectedIndustriesType = (self.arrIndustriesCategory ?? []).contains(tempObj[0].industriesType ?? "") ? (tempObj[0].industriesType ?? "") : ""
            self.isIndustryTypeSelected = (self.arrIndustriesCategory ?? []).contains(tempObj[0].industriesType ?? "")
            
            self.lblBusinessType.text = self.arrBusinessType.contains(tempObj[0].bmType ?? "") ? (tempObj[0].bmType ?? "") : "Select Business Type"
            self.strSelectedBusinessType = self.arrBusinessType.contains(tempObj[0].bmType ?? "") ? (tempObj[0].bmType ?? "") : ""
            self.isBusinssTypeSelected = self.arrBusinessType.contains(tempObj[0].bmType ?? "")
            
            for (_, value) in (tempObj[0].contacts ?? []).enumerated() {
                let tempContact = AddBPContact( name: value.name,
                                                pContact: value.mobileNo,
                                                sContact: value.telNo,
                                                email: value.emailID,
                                                designation: value.designation)
                self.arrSelectedContactDetail?.append(tempContact)
            }
            
            self.txtCityName.text = tempObj[0].city ?? ""
        }
        self.tvContactDetails.reloadData()
        
        if strValue == "Other" {
            self.constraintHeightViewTxtClientName.priority = .defaultLow
            self.getDvrOtherContact()
        }
    }
    
    func setUpIndustriesType(strValue: String) {
        self.lblIndustriesType.text = strValue
        
        self.strSelectedIndustriesType = strValue
        self.isIndustryTypeSelected = true
    }
    
    func setUpBusinessType(strValue: String) {
        self.lblBusinessType.text = strValue
        self.strSelectedBusinessType = strValue
        self.isBusinssTypeSelected = true
        
        self.lblTradersType.text = "Select Traders Type"
        if strValue == "Traders" {
            self.constraintHeightMTradersType.priority = .defaultLow
        }
        else {
            self.constraintHeightMTradersType.priority = .required
        }
    }
    
    func setUpTradersType(strValue: String) {
        self.lblTradersType.text = strValue
        self.strSelectedTradersType = strValue
        self.isTradersTypeSelected = true
    }
 
    func setUpPaymentReceivedMode(strValue: String, remark: String = "") {
        self.lblSelectedPaymentReceivedMode.text = strValue
        self.strSelectedPaymentReceivedMode = strValue
        self.isPaymentReceiveModeSelected = true
        
        self.constraintBottomViewSelectPaymentReceivedModeToSuper.priority = .defaultLow
        self.viewTxtAmount.isHidden = true
        self.viewTxtPaymentRemark.isHidden = true
        self.viewCheckImg.isHidden = true
        
        self.ivChequeImg.image = nil
        self.constraintBottomIVChequeImgToSuper.priority = .defaultLow
        self.isChequeImgSelected = false
        
        if (strValue == "Cash") || (strValue == "NEFT") {
            self.viewTxtAmount.isHidden = false
            
            if remark != "" {
                self.txtPaymentAmount.text = remark
            }
        }
        else if strValue == "Cheque" {
            self.viewCheckImg.isHidden = false
        }
        else if strValue == "Other" {
            self.viewTxtPaymentRemark.isHidden = false
            
            if remark != "" {
                self.txtPaymentRemarks.text = remark
            }
        }
    }
    
}


extension AddDvrVC {
    
    func setUpViewArr(arrValue: [String]) {
        
        self.arrSelectedVisitFor.removeAll()
        var  visitFor: String = ""
        for strValue in arrValue.enumerated() {
            let tempValue = DVR.getVisitFor().filter { $0 == strValue.element }
            if tempValue.count > 0 {
                self.arrSelectedVisitFor.append(tempValue[0])
                if visitFor != "" {
                    visitFor = visitFor + ", " + strValue.element
                }
                else {
                    visitFor = strValue.element
                }
            }
        }
        
        if visitFor != "" {
            self.lblVisitFor.text = visitFor
        }
        else {
            self.lblVisitFor.text = "Select Visit For"
        }
        
        self.isVFApproachedForProducts = false
        self.isVFPaymentCollection = false
        self.isVFMeeting = false
        self.isVFTrial = false
        self.isVFWFO = false
        self.isVFAttendedExhibition = false
        self.isVFLeave = false
        self.isVFPhoneCall = false
        
        if self.arrSelectedVisitFor.contains("Approached for Products") {
            //  AP
            self.isVFApproachedForProducts = true
        }
        if self.arrSelectedVisitFor.contains("Payment Collection") {
            //  PC
            self.isVFPaymentCollection = true
        }
        if self.arrSelectedVisitFor.contains("Meeting") {
            //  MT
            self.isVFMeeting = true
        }
        if self.arrSelectedVisitFor.contains("Trial") {
            //  TL
            self.isVFTrial = true
        }
        if self.arrSelectedVisitFor.contains("Work from Office") {
            // WO
            self.isVFWFO = true
        }
        if self.arrSelectedVisitFor.contains("Attended Exhibition") {
            //  AE
            self.isVFAttendedExhibition = true
        }
        if self.arrSelectedVisitFor.contains("Leave") {
            //  LV
            self.isVFLeave = true
            self.btnLeaveFullDayTap(UIButton())
        }
        if self.arrSelectedVisitFor.contains("Phone Call") {
            //  OC
            self.isVFPhoneCall = true
        }
        
        self.setUPView()
    }
    
    func setUPView() {
        self.hideAllView()
        
        //self.isClientDetailActive
        //self.isContactDetailActive
        //self.isWFOActive
        //self.isAttendedExhibitionActive
        //self.isLeaveActive
        //self.isProductDetailsActive
        //self.isPaymentDetailsActive
        //self.isCityNameActive
        //self.isPersonalVisitActive
        //self.isFollowUpTypeActive
        //self.isFollowUpModeActive
        //self.isFollowUpDateActive
        
        if self.isVFApproachedForProducts || self.isVFMeeting || self.isVFTrial || self.isVFPhoneCall {
            //  AP, MT, TL, OC
            self.constraintHeightViewMClientDetails.priority = .defaultLow
            self.isClientDetailActive = true
            
            self.constraintHeightViewMContactDetails.priority = .defaultLow
            self.isContactDetailActive = true
            
            self.constraintHeightViewMProductDetails.priority = .defaultLow
            self.isProductDetailsActive = true
            
            self.constraintHeightViewMCityName.priority = .defaultLow
            self.isCityNameActive = true
            
            self.constraintHeightViewMPersonalVisit.priority = .defaultLow
            self.isPersonalVisitActive = true
            self.btnPersonalVisitYesTap(UIButton())
            
            self.constraintHeightViewMSelectFollowUpType.priority = .defaultLow
            self.isFollowUpTypeActive = true
            
            self.constraintHeightViewMSelectFollowUpMode.priority = .defaultLow
            self.isFollowUpModeActive = true
            
            self.constraintHeightViewMFollowUpDate.priority = .defaultLow
            self.isFollowUpDateActive = true
        }
        
        if self.isVFPaymentCollection {
            //  PC
            self.constraintHeightViewMClientDetails.priority = .defaultLow
            self.isClientDetailActive = true
            
            self.constraintHeightViewMContactDetails.priority = .defaultLow
            self.isContactDetailActive = true
            
            self.constraintHeightViewMPaymentDetails.priority = .defaultLow
            self.isPaymentDetailsActive = true
            
            self.constraintHeightViewMCityName.priority = .defaultLow
            self.isCityNameActive = true
            
            self.constraintHeightViewMSelectFollowUpMode.priority = .defaultLow
            self.isFollowUpModeActive = true
        }
        
        if self.isVFMeeting { /*MT*/ }
        
        if self.isVFTrial { /*TL*/ }
        
        if self.isVFWFO {
            // WO
            self.constraintHeightViewMWFO.priority = .defaultLow
            self.isWFOActive = true
        }
        
        if self.isVFAttendedExhibition {
            //  AE
            self.constraintHeightViewMAttendedExhibition.priority = .defaultLow
            self.isAttendedExhibitionActive = true
        }
        
        if self.isVFLeave {
            //  LV
            self.constraintHeightViewMLeave.priority = .defaultLow
            self.isLeaveActive = true
        }
        
        if self.isVFPhoneCall { /*OC*/ }
        
    }
    
    func hideAllView() {
        self.isClientDetailActive = false
        self.isContactDetailActive = false
        self.isWFOActive = false
        self.isAttendedExhibitionActive = false
        self.isLeaveActive = false
        self.isProductDetailsActive = false
        self.isPaymentDetailsActive = false
        self.isCityNameActive = false
        self.isPersonalVisitActive = false
        self.isFollowUpTypeActive = false
        self.isFollowUpModeActive = false
        self.isFollowUpDateActive = false
        
        self.constraintHeightViewMClientDetails.priority = .required
        self.constraintHeightViewMContactDetails.priority = .required
        self.constraintHeightViewMWFO.priority = .required
        self.constraintHeightViewMAttendedExhibition.priority = .required
        self.constraintHeightViewMLeave.priority = .required
        self.constraintHeightViewMProductDetails.priority = .required
        self.constraintHeightViewMPaymentDetails.priority = .required
        self.constraintHeightViewMCityName.priority = .required
        self.constraintHeightViewMPersonalVisit.priority = .required
        self.constraintHeightViewMSelectFollowUpType.priority = .required
        self.constraintHeightViewMSelectFollowUpMode.priority = .required
        self.constraintHeightViewMFollowUpDate.priority = .required
    }
    
    func checkAllValidation() {
        var isValid: Bool = true
        var msg: String = ""
        
        if self.lblDailyVisitReportDate.text == "Select Date" {
            isValid = false
            msg = "Select DVR date"
        }
        
        if self.isClientDetailActive && isValid {
            if !self.isClientNameSelected {
                isValid = false
                msg = "Select client name"
            }
            else if !self.isIndustryTypeSelected {
                isValid = false
                msg = "Select industry type"
            }
            else if !self.isBusinssTypeSelected {
                isValid = false
                msg = "Select business type"
            }
            
            if  self.constraintHeightMTradersType.priority == .defaultLow {
                if !self.isTradersTypeSelected {
                    isValid = false
                    msg = "Select traders type"
                }
            }
        }
        
        if self.isContactDetailActive && isValid {
            /**if self.arrSelectedContactDetail?.count ?? 0 == 0 {
                isValid = false
                msg = "Please add contact detail"
            }   ///  */
        }
        
        if self.isWFOActive && isValid {
            if self.txtWFORemarks.text ?? "" == "" {
                isValid = false
                msg = "Please enter wfo remark"
            }
        }
        
        if self.isAttendedExhibitionActive && isValid {
            if self.txtExhibitionName.text ?? "" == "" {
                isValid = false
                msg = "Please enter exhibition name"
            }
            else if self.txtExhibitionCity.text ?? "" == "" {
                isValid = false
                msg = "Please enter exhibition city"
            }
            else {
                if self.lblSelectedEmpName.text == "Other" {
                    if self.txtWithWhomEmployeeName.text ?? "" == "" {
                        isValid = false
                        msg = "Please enter employee name"
                    }
                }
                
                if (self.arrSelectedEmployee.count == 0) && isValid {
                    isValid = false
                    msg = "Please select employee name"
                }
            }
        }
        
        if self.isLeaveActive && isValid {
            if !self.isLeaveFDay && !self.isLeaveHDay {
                isValid = false
                msg = "Please select leave type"
            }
        }
        
        if self.isProductDetailsActive && isValid {
            if !self.isClientProductSelected && self.isApproachedProductSelected {
                isValid = false
                //Utilities.showPopup(title: "Please select client product", type: .error)
                msg = "Please select client product"
            }
            else if self.isClientProductSelected && !self.isApproachedProductSelected {
                isValid = false
                //Utilities.showPopup(title: "Please select approached product", type: .error)
                msg = "Please select approached product"
            }
            else if self.isClientProductSelected && self.isApproachedProductSelected {
                self.btnAddAnotherProductTap(UIButton())
            }
            else if self.arrSelectedProduct?.count ?? 0 == 0 {
                isValid = false
                msg = "Please select client product"
            }
        }
        
        if self.isPaymentDetailsActive && isValid {
            if self.lblSelectedPaymentReceivedMode.text ?? "" == "Select Payment Received Mode" {
                isValid = false
                msg = "Please select payment received mode"
            }
            else if (self.lblSelectedPaymentReceivedMode.text ?? "" == "Cash") || (self.lblSelectedPaymentReceivedMode.text ?? "" == "NEFT") {
                if self.txtPaymentAmount.text ?? "" == "" {
                    isValid = false
                    msg = "Please enter payment amount"
                }
            }
            else if self.lblSelectedPaymentReceivedMode.text ?? "" == "Cheque" {
                if !self.isChequeImgSelected {
                    isValid = false
                    msg = "Please select cheque image"
                }
            }
            else if self.lblSelectedPaymentReceivedMode.text ?? "" == "Other" {
                if self.txtPaymentRemarks.text ?? "" == "" {
                    isValid = false
                    msg = "Please enter payment remark"
                }
            }
            
        }
        
        if self.isCityNameActive && isValid {
            if self.txtCityName.text ?? "" == "" {
                isValid = false
                msg = "Please enter city name"
            }
        }
        
        if self.isPersonalVisitActive && isValid {
            
        }
        
        if (self.txtRemark.text ?? "" == "") && isValid {
            isValid = false
            msg = "Please enter remark"
        }
        
        if self.isFollowUpTypeActive && isValid {
            
        }
        
        if self.isFollowUpModeActive && isValid {
            
        }
        
        if self.isFollowUpDateActive && isValid {
            
        }
        
        if isValid {
            self.addDvr()
        }
        else {
            Utilities.showPopup(title: msg, type: .error)
        }
    }
    
    func setUpRepeatData(repeatDvrDetail: DVRUserList?) {
        
        let tempValue: [String] = (repeatDvrDetail?.visitFor ?? "").components(separatedBy: ",")
        self.setUpViewArr(arrValue: (DVR.getVisitFor(arrVisitFor: tempValue)).components(separatedBy: ","))
        
        self.setUpClientData(strValue: repeatDvrDetail?.name ?? "")
        self.setUpIndustriesType(strValue: repeatDvrDetail?.industriesType ?? "")
        self.setUpBusinessType(strValue: repeatDvrDetail?.bmType ?? "")
        if repeatDvrDetail?.bmType ?? "" == "Traders" {
            self.setUpTradersType(strValue: repeatDvrDetail?.tradersType ?? "")
        }
        
        self.arrSelectedContactDetail = []
        for (_, value) in (repeatDvrDetail?.contacts ?? []).enumerated() {
            let tempContact = AddBPContact( name: value.name ?? "",
                                            pContact: value.mobileNo ?? "",
                                            sContact: value.telNo ?? "",
                                            email: value.emailID ?? "",
                                            designation: value.designation ?? "")
            self.arrSelectedContactDetail?.append(tempContact)
        }
        self.tvContactDetails.reloadData()
        
        self.txtWFORemarks.text = repeatDvrDetail?.wfoRemarks ?? ""
        
        self.txtExhibitionName.text = repeatDvrDetail?.aeName ?? ""
        self.txtExhibitionCity.text = repeatDvrDetail?.aeCity ?? ""
        
        self.arrSelectedEmployee.removeAll()
        for (_, value) in (repeatDvrDetail?.whoms ?? []).enumerated() {
            self.arrSelectedEmployee.append(value.otherName ?? "")
        }
        self.tvWithWhom.reloadData()
        
        if (repeatDvrDetail?.leaveType ?? "") == "Full Day" {
            self.btnLeaveFullDayTap(UIButton())
        }
        else if (repeatDvrDetail?.leaveType ?? "") == "Half Day" {
            self.btnLeaveHalfDayTap(UIButton())
        }
        
        if (repeatDvrDetail?.products?.count ?? 0) > 0 {
            let tempApproachedProduct = (self.arrApproachedProduct ?? []).filter { $0.name == self.lblSelectedApproachedProduct.text ?? "" }
            
            self.arrSelectedProduct?.removeAll()
            for (_, value) in (repeatDvrDetail?.products ?? []).enumerated() {
                let tempApproachedProduct = (self.arrApproachedProduct ?? []).filter { $0.productID! == value.productID ?? 0 }
                let tempObj: SelectedProductDtails = SelectedProductDtails(name: value.clientProduct ?? "", approachedProduct: tempApproachedProduct[0])
                
                self.arrSelectedProduct?.append(tempObj)
            }
            self.tvProductDetails.reloadData()
        }
        
        
        var remark: String = ""
        switch repeatDvrDetail?.paymentMode ?? "" {
        case "Cash", "NEFT":
            remark = repeatDvrDetail?.amount ?? ""
        case "Cheque":
            remark = ""
        case "Other":
            remark = repeatDvrDetail?.remark ?? ""
        default:
            remark = ""
        }
        self.setUpPaymentReceivedMode(strValue: repeatDvrDetail?.paymentMode ?? "", remark: remark)
        
        if (repeatDvrDetail?.isPersonalVisit ?? 0) == 1 {
            self.btnPersonalVisitYesTap(UIButton())
        }
        else if (repeatDvrDetail?.isPersonalVisit ?? 0) == 0 {
            self.btnbtnPersonalVisitNoTap(UIButton())
        }
        
        self.txtRemark.text = repeatDvrDetail?.remark ?? ""
        
        if (repeatDvrDetail?.meetingStatus ?? "") != ""  {
            self.lblSelectedFollowUpType.text = repeatDvrDetail?.meetingStatus ?? ""
        }
        
        if (repeatDvrDetail?.followUpType ?? "") != ""  {
            self.lblSelectedFollowUpMode.text = repeatDvrDetail?.followUpType ?? ""
        }
        
        if (repeatDvrDetail?.followUpDate ?? "") != "" {
            self.lblFollowUpDate.text = Utilities.convertStrDateToString(date: repeatDvrDetail?.followUpDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd-MMM-yyyy")
            self.strFollowUpDate = Utilities.convertStrDateToString(date: repeatDvrDetail?.followUpDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "yyyy-MM-dd")
        }
    }
}
