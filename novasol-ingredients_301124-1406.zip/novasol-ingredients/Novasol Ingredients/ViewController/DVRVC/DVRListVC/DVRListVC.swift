//
//  DVRListVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 13/08/24.
//

import UIKit

class DVRListVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    
    
    @IBOutlet weak var btnAddDvr: UIButton!
    @IBAction func btnAddDvrTap(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "AddDvrVC") as! AddDvrVC
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    @IBOutlet weak var viewDateSelectBP: UIView!
    
    @IBOutlet weak var viewSEDate: UIView!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var btnStartDate: UIButton!
    @IBAction func btnStartDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "yyyy-MM-dd"
        popupVC.didSelectDate = { date in
            self.lblStartDate.text = date
            self.strStartDate = date
            self.arrDvrUsersDetails?.removeAll()
            self.arrFilterDvrUsersDetails?.removeAll()
            self.arrStrBusinessPartner?.removeAll()
            self.getDvrUserList()
        }
        popupVC.onClose = {
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var btnEndDate: UIButton!
    @IBAction func btnEndDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "yyyy-MM-dd"
        popupVC.minStartDate = lblStartDate.text!
        popupVC.didSelectDate = { date in
            self.lblEndDate.text = date
            self.strEndDate = date
            self.arrDvrUsersDetails?.removeAll()
            self.arrFilterDvrUsersDetails?.removeAll()
            self.arrStrBusinessPartner?.removeAll()
            self.getDvrUserList()
        }
        popupVC.onClose = {
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewSelectBP: UIView!
    @IBOutlet weak var lblBusinessP: UILabel!
    @IBOutlet weak var btnSelectBP: UIButton!
    @IBAction func btnSelectBPTap(_ sender: UIButton) {
        var tempArrBP = self.arrStrBusinessPartner ?? []
        tempArrBP.insert("Select Business Partner", at: 0)
        tempArrBP = tempArrBP.uniqued()
        
        if tempArrBP.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.titleTxt = Title.SelectBP
            popupVC.value = tempArrBP
            popupVC.selectedValue = self.lblBusinessP.text ?? "Select Business Partner"
            popupVC.didSelectItem = { strValue in
                self.lblBusinessP.text = strValue
                if strValue == "Select Business Partner" {
                    self.arrFilterDvrUsersDetails = self.arrDvrUsersDetails
                }
                else {
                    self.arrFilterDvrUsersDetails = self.arrDvrUsersDetails?.filter { $0.name == strValue }
                }
                self.tvDvrList.reloadData()
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    
    @IBOutlet weak var viewTVDvrList: UIView!
    @IBOutlet weak var tvDvrList: UITableView! {
        didSet {
            self.tvDvrList.delegate = self
            self.tvDvrList.dataSource = self
            self.tvDvrList.register(UINib(nibName: "TVDvrListHFView", bundle: nil), forHeaderFooterViewReuseIdentifier: "TVDvrListHFView")
            self.tvDvrList.register(UINib(nibName: "DvrListDetailsTVCell", bundle: nil), forCellReuseIdentifier: "DvrListDetailsTVCell")
            if #available(iOS 15.0, *) {
                self.tvDvrList.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
    // View No Data
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblSeparator: UILabel!
    @IBOutlet weak var lblNoData: UILabel!
    
    
    
    // MARK: - Variable
    
    var strStartDate: String = ""
    var strEndDate: String = ""
    
    private lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter
    }()
    
    var arrDvrUsers: [DVRUserList]? = []
    var arrDvrUsersDetails: [DVRUserList]? = []
    var arrFilterDvrUsersDetails: [DVRUserList]? = []
    var intSelectedSection: Int = -1
    var arrStrBusinessPartner: [String]? = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.dateFormatter.calendar = .current
        let tempComponen = Calendar.current.dateComponents([.day, .month, .year], from: Date())
        strStartDate = "\(tempComponen.year ?? 0)-\(tempComponen.month ?? 0)-01"
        strEndDate = "\(tempComponen.year ?? 0)-\(tempComponen.month ?? 0)-\(tempComponen.day ?? 0)"
        
        self.lblStartDate.text = Utilities.convertStrDateToString(date: strStartDate, CurrentDateFormate: "yyyy-M-d", NewDateFormate: "yyyy-MM-dd")
        self.lblEndDate.text = Utilities.convertStrDateToString(date: strEndDate, CurrentDateFormate: "yyyy-M-d", NewDateFormate: "yyyy-MM-dd")
        
        self.getDvrUserList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
}

extension DVRListVC {
    func getDvrUserList() {
        self.getDvrUsers(startDate: self.strStartDate, endDate: self.strEndDate)
    }
}
