//
//  DVRListVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 13/08/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, Datasourse

extension DVRListVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.arrDvrUsers?.count ?? 0
    }
    
    /*func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
    }   //  */
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "TVDvrListHFView") as! TVDvrListHFView
        //headerView.viewMain.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
        if section == 0 {
            headerView.lblSeparatorTop.isHidden = false
            headerView.lblSeparatorBottom.isHidden = false
        }
        else {
            headerView.lblSeparatorTop.isHidden = true
            headerView.lblSeparatorBottom.isHidden = false
        }
        headerView.lblSeparatorTop.backgroundColor = UIColor(hexString: "#A1A1A1")
        headerView.lblSeparatorBottom.backgroundColor = UIColor(hexString: "#A1A1A1")
        headerView.lblName.text = "\(self.arrDvrUsers?[section].firstname ?? "") \(self.arrDvrUsers?[section].lastname ?? "")"
        headerView.lblDate.text = "\(self.arrDvrUsers?[section].startDateShow ?? "") to \(self.arrDvrUsers?[section].endDateShow ?? "")"
        
        let imgName: String = self.intSelectedSection == section ? "chevron.up" : "chevron.down"
        headerView.ivArrow.image = UIImage(systemName: imgName)
        
        headerView.btnExpand.tag = section
        headerView.btnExpand.addTarget(self, action: #selector(self.btnHeaderExpandTap), for: .touchUpInside)
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 42
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.intSelectedSection == section {
            return self.arrFilterDvrUsersDetails?.count ?? 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DvrListDetailsTVCell", for: indexPath) as! DvrListDetailsTVCell
        
        cell.index = indexPath.row
        cell.lblDvrDate.text = self.arrFilterDvrUsersDetails?[indexPath.row].dvrDate ?? ""
        cell.lblStatus.text = self.arrFilterDvrUsersDetails?[indexPath.row].meetingStatus  ?? ""
        var name = self.arrFilterDvrUsersDetails?[indexPath.row].name ?? ""
        name = (name == "") ? (self.arrFilterDvrUsersDetails?[indexPath.row].businessPartnerName ?? "") : (self.arrFilterDvrUsersDetails?[indexPath.row].name ?? "")
        cell.lblName.text = name
        cell.lblFollowUpDate.text = self.arrFilterDvrUsersDetails?[indexPath.row].followUpDate ?? ""
        //cell.lblStatus.text = self.arrFilterDvrUsersDetails?[indexPath.row].status ?? ""
        //cell.lblComment.text = self.arrFilterDvrUsersDetails?[indexPath.row].comment ?? ""
        
        cell.lblStatus.text = self.arrFilterDvrUsersDetails?[indexPath.row].status ?? ""
        cell.lblComment.text = self.arrFilterDvrUsersDetails?[indexPath.row].comment ?? ""
        
        cell.btnRepeatVisit.isHidden = false
        //cell.constraintBottomViewToSuper.priority = .defaultLow
        cell.btnAddExpense.isHidden = false
        cell.constraintBottomLblCommentToSuper.priority = .defaultLow
        
        if self.arrFilterDvrUsersDetails?[indexPath.row].status ?? "" == "Rejected" {
            //cell.constraintBottomViewToSuper.priority = .defaultLow
            cell.btnAddExpense.isHidden = true
            
            cell.lblStatus.isHidden = false
            cell.lblComment.isHidden = false
            cell.constraintBottomLblCommentToSuper.priority = .required
        }
        else {
            cell.lblStatus.isHidden = true
            cell.lblComment.isHidden = true
            cell.constraintBottomLblCommentToSuper.priority = .defaultLow
            
            if self.arrFilterDvrUsersDetails?[indexPath.row].userID ?? 0 == APIManager.sharedManager.userId {
                cell.btnRepeatVisit.isHidden = false
            }
            else {
                //cell.constraintBottomViewToSuper.priority = .required
                cell.btnAddExpense.isHidden = true
                
                cell.btnRepeatVisit.isHidden = true
            }
        }
        
        cell.onViewTap = { index in
            self.onCellButtonTap(index: index, isViewTap: true)
        }
        
        cell.onRepeatVisitTap = { index in
            self.onCellButtonTap(index: index, isRepearVisitTap: true)
        }
        
        cell.onAddExpenseTap = { index in
            self.onCellButtonTap(index: index, isAddExpenseTap: true)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    @objc func btnHeaderExpandTap(_ sendar: UIButton) {
        self.intSelectedSection = (self.intSelectedSection == sendar.tag) ? -1 : sendar.tag
        
        if self.intSelectedSection > -1 {
            self.lblBusinessP.text = "Select Business Partner"
            self.getDvrUsersDetails(userId: self.arrDvrUsers?[self.intSelectedSection].userID ?? 0, startDate: self.arrDvrUsers?[self.intSelectedSection].startDate ?? "", endDate: self.arrDvrUsers?[self.intSelectedSection].endDate ?? "")
        }
        else {
            self.arrDvrUsersDetails?.removeAll()
            self.arrFilterDvrUsersDetails?.removeAll()
            self.arrStrBusinessPartner?.removeAll()
            self.lblBusinessP.text = "Select Business Partner"
            self.tvDvrList.reloadData()
        }
    }
    
    func onCellButtonTap(index: Int, isViewTap: Bool = false, isRepearVisitTap: Bool = false, isAddExpenseTap: Bool = false) {
        if isViewTap {
            let storyboaard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboaard.instantiateViewController(withIdentifier: "DVRDetailsVC") as! DVRDetailsVC
            viewController.dvrUsersDetails = self.arrFilterDvrUsersDetails?[index]
            self.navigationController?.pushViewController(viewController, animated: true)
        }
        else if isRepearVisitTap {
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyBoard.instantiateViewController(withIdentifier: "AddDvrVC") as! AddDvrVC
            viewController.isRepeatDVR = true
            viewController.repeatDvrUsersDetails = self.arrFilterDvrUsersDetails?[index]
            self.navigationController?.pushViewController(viewController, animated: true)
        }
        else if isAddExpenseTap {
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyBoard.instantiateViewController(identifier: "AddExpensesVC") as! AddExpensesVC
            viewController.strDvrDate = self.arrFilterDvrUsersDetails?[index].dvrDate ?? ""
            viewController.strDvrCity = self.arrFilterDvrUsersDetails?[index].city ?? ""
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
}


// MARK: - WebServices

extension DVRListVC {
    func getDvrUsers(startDate: String, endDate: String) {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getDvrUsers(startDate: startDate, endDate: endDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "role_id": APIManager.sharedManager.userDetail?.roleId ?? 0,
            "start_date": startDate,
            "end_date": endDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_DVR_USERS, parameters: param) { (response: ApiResponseDVR?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrDvrUsers = response?.result?.dvr ?? []
                    self.tvDvrList.reloadData()
                    
                    self.viewNoData.isHidden = true
                    if !(self.arrDvrUsers?.count ?? 0 > 0) {
                        self.viewNoData.isHidden = false
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
                
                self.viewNoData.isHidden = true
                if !(self.arrDvrUsers?.count ?? 0 > 0) {
                    self.viewNoData.isHidden = false
                }
            }
        }
    }
    
    func getDvrUsersDetails(userId: Int, startDate: String, endDate: String) {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getDvrUsersDetails(userId: userId, startDate: startDate, endDate: endDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": userId,
            "start_date": startDate,
            "end_date": endDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_DVR, parameters: param) { (response: ApiResponseDVR?, error) in
            self.hideLoading()
            self.arrDvrUsersDetails?.removeAll()
            self.arrFilterDvrUsersDetails?.removeAll()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrDvrUsersDetails = response?.result?.dvr ?? []
                    self.arrFilterDvrUsersDetails = self.arrDvrUsersDetails
                    self.arrStrBusinessPartner?.removeAll()
                    
                    self.arrStrBusinessPartner = self.arrDvrUsersDetails?.map { $0.name! }
                    
                    self.tvDvrList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
