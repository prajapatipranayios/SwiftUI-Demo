//
//  DvrListDetailsTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 14/08/24.
//

import UIKit

class DvrListDetailsTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblDvrDate: UILabel!
    @IBOutlet weak var lblMeetingStatus: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblFollowUpDate: UILabel!
    @IBOutlet weak var lblComment: UILabel!
    @IBOutlet weak var constraintBottomLblCommentToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var btnView: UIButton!
    @IBAction func btnViewTap(_ sender: UIButton) {
        if self.onViewTap != nil {
            self.onViewTap?(index)
        }
    }
    //@IBOutlet weak var constraintBottomViewToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var btnRepeatVisit: UIButton!
    @IBAction func btnbtnRepeatVisitTap(_ sender: UIButton) {
        if self.onRepeatVisitTap != nil {
            self.onRepeatVisitTap?(index)
        }
    }
    
    @IBOutlet weak var btnAddExpense: UIButton!
    @IBAction func btnAddExpenseTap(_ sender: UIButton) {
        if self.onAddExpenseTap != nil {
            self.onAddExpenseTap?(index)
        }
    }
    
    @IBOutlet weak var lblSeparator: UILabel!
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onRepeatVisitTap:((Int)->Void)?
    var onViewTap:((Int)->Void)?
    var onAddExpenseTap:((Int)->Void)?
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.lblStatus.textColor = Colors.theme.returnColor()
        
        self.lblDvrDate.text = ""
        self.lblMeetingStatus.text = ""
        self.lblStatus.text = ""
        self.lblName.text = ""
        self.lblFollowUpDate.text = ""
        self.lblComment.text = ""
        
        self.btnView.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        self.btnRepeatVisit.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        self.btnAddExpense.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        
        self.lblSeparator.backgroundColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
