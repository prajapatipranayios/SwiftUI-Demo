//
//  DvrDetailClientProductTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 23/08/24.
//

import UIKit

class DvrDetailClientProductTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblProductNameTitle: UILabel!
    @IBOutlet weak var lblProductName: UILabel!
    
    @IBOutlet weak var lblApproachedProductNameTitle: UILabel!
    @IBOutlet weak var lblApproachedProductName: UILabel!
    @IBOutlet weak var constraintWidthLblApproachedProductNameTitle: NSLayoutConstraint!
    
    
    // MARK: - Variable
    var index: Int = 0
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
