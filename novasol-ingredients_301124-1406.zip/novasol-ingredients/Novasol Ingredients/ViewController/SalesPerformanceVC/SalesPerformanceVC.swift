//
//  SalesPerformanceVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 25/09/24.
//

import UIKit

class SalesPerformanceVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        
        revealViewController()?.revealSideMenu()
    }
    
    
    @IBOutlet weak var viewMainBody: UIView!
    
    @IBOutlet weak var viewFilters: UIView!
    
    @IBOutlet weak var viewFilters1: UIView!
    
    @IBOutlet weak var viewYears: UIView!
    @IBOutlet weak var lblSelectedYears: UILabel!
    @IBOutlet weak var btnSelectYears: UIButton!
    @IBAction func btnSelectYearsTap(_ sender: UIButton) {
        
        let currYear = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).year ?? 0
        
        let tempYear: [String] = [
            "\(currYear - 4)-\(currYear - 3)",
            "\(currYear - 3)-\(currYear - 2)",
            "\(currYear - 2)-\(currYear - 1)",
            "\(currYear - 1)-\(currYear)",
            "\(currYear)-\(currYear + 1)"
        ]
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Year"
        popupVC.value = tempYear
        popupVC.selectedValue = self.lblSelectedYears.text ?? "\(currYear)-\(currYear + 1)"
        popupVC.didSelectItem = { strValue in
            
            self.lblSelectedYears.text = strValue
            let arrTemp: [String] = strValue.components(separatedBy: "-")
            self.strSelectedYears = arrTemp[0]
                
            self.lblSelectedQuarter.text = "Quarter"
            self.arrSelectedQuarter.removeAll()
            
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewQuarter: UIView!
    @IBOutlet weak var lblSelectedQuarter: UILabel!
    @IBOutlet weak var btnSelectQuarter: UIButton!
    @IBAction func btnSelectQuarterTap(_ sender: UIButton) {
        
        let arrQuarter: [String] = ["Q1", "Q2", "Q3", "Q4"]
        
        let arrTempQuarter: [String] = arrQuarter
        
        let arrTempSelectedValue: [String] = self.arrSelectedQuarter
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Quarter"
        popupVC.isReturnValueInSeq = true
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.value = arrTempQuarter
        popupVC.didSelectItem = { arrValue in
            
            self.arrSelectedQuarter = arrValue
            
            let  strQuarter: String = arrValue.joined(separator: ",")
            
            self.lblSelectedQuarter.text = "Quarter"
            if strQuarter != "" {
                self.lblSelectedQuarter.text = strQuarter
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewFilters2: UIView!
    @IBOutlet weak var constraintHeightViewFilters2: NSLayoutConstraint!
    
    @IBOutlet weak var viewEmployee: UIView!
    @IBOutlet weak var lblSelectedEmployee: UILabel!
    @IBOutlet weak var btnSelectEmployee: UIButton!
    @IBAction func btnSelectEmployeeTap(_ sender: UIButton) {
        
        let arrTempEmp: [String] = self.arrEmp?.map { "\($0.firstname ?? "") \($0.lastname ?? "")" } ?? []
        
        var arrTempSelectedValue: [String] = []
        for strValue in (self.arrIdSelectedEmp ?? []).enumerated() {
            let tempValue = self.arrEmp?.filter { $0.id! == strValue.element }
            if tempValue?.count ?? 0 > 0 {
                arrTempSelectedValue.append("\(tempValue?[0].firstname ?? "") \(tempValue?[0].lastname ?? "")")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Quarter"
        popupVC.isReturnValueInSeq = true
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.value = arrTempEmp
        popupVC.didSelectItem = { arrValue in
            
            self.arrIdSelectedEmp?.removeAll()
            
            var  strSelectedEmp: String = ""    //arrValue.joined(separator: ",")
            
            for strValue in arrValue.enumerated() {
                let tempValue = self.arrEmp?.filter { "\($0.firstname!) \($0.lastname!)" == strValue.element }
                if tempValue?.count ?? 0 > 0 {
                    self.arrIdSelectedEmp?.append(tempValue?[0].id ?? 0)
                    if strSelectedEmp != "" {
                        strSelectedEmp = strSelectedEmp + ", " + strValue.element
                    }
                    else {
                        strSelectedEmp = strValue.element
                    }
                }
            }
            
            self.lblSelectedEmployee.text = "Employee"
            if strSelectedEmp != "" {
                self.lblSelectedEmployee.text = strSelectedEmp
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var btnSearch: UIButton!
    @IBAction func btnSearchTap(_ sender: UIButton) {
        
        if !(self.arrSelectedQuarter.isEmpty) {
            self.getUserKRA(employeeId: self.arrIdSelectedEmp ?? [], year: self.strSelectedYears, arrQuarter: self.arrSelectedQuarter)
        }
        else {
            Utilities.showPopup(title: "Please select quarter", type: .error)
        }
        
    }
    
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var lblSalesPerformanceYear: UILabel!
    @IBOutlet weak var viewKra: UIView!
    @IBOutlet weak var tvKra: UITableView! {
        didSet {
            self.tvKra.delegate = self
            self.tvKra.dataSource = self
            self.tvKra.register(UINib(nibName: "KraUserDetailTVCell", bundle: nil), forCellReuseIdentifier: "KraUserDetailTVCell")
            if #available(iOS 15.0, *) {
                self.tvKra.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    
    
    
    
    
    // MARK: - Variable
    
    var strScreenTitle = "Sales Performance"
    
    var strSelectedYears: String = ""
    var arrSelectedQuarter: [String] = []
    
    var arrEmp: [Employee]?
    var arrIdSelectedEmp: [Int]? = []
    
    var strKraYearMsg: String = "KRA cum SALES PERFORMANCE "
    var arrKra: [Kra]? = []
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        let currYear = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).year ?? 0
        self.strSelectedYears = "\(currYear)"
        
        self.lblSalesPerformanceYear.textColor = Colors.theme.returnColor()
        
        self.constraintHeightViewFilters2.priority = .required
        if [3, 4, 10].contains(APIManager.sharedManager.userDetail?.roleId ?? 0) {
            self.constraintHeightViewFilters2.priority = .defaultLow
        }
        
        self.getEmployeeListZoneWise(arrZone: [])
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
}
