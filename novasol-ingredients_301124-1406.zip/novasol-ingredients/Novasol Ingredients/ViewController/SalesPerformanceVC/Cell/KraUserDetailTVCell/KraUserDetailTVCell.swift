//
//  KraUserDetailTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 25/09/24.
//

import UIKit

class KraUserDetailTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMBorder: UIView!
    
    @IBOutlet weak var viewMCodeNTitle: UIView!
    @IBOutlet weak var viewCodeNTitle: UIView!
    @IBOutlet weak var constraintHeightViewCodeNTitle: NSLayoutConstraint!
    @IBOutlet weak var lblCode: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
    
    @IBOutlet weak var viewTitles: UIView!
    @IBOutlet weak var constraintHeightViewTitles: NSLayoutConstraint!
    
    @IBOutlet weak var viewParticularsTitle: UIView!
    @IBOutlet weak var lblParticularsTitle: UILabel!
    
    @IBOutlet weak var viewActualSalesTitle: UIView!
    @IBOutlet weak var lblActualSalesTitle: UILabel!
    
    @IBOutlet weak var viewGPSalesTitle: UIView!
    @IBOutlet weak var lblGPSalesTitle: UILabel!
    
    @IBOutlet weak var viewTotalExpTitle: UIView!
    @IBOutlet weak var lblTotalExpTitle: UILabel!
    
    @IBOutlet weak var viewProjectedSalesTitle: UIView!
    @IBOutlet weak var lblProjectedSalesTitle: UILabel!
    
    @IBOutlet weak var viewActualVsProjectedTitle: UIView!
    @IBOutlet weak var lblActualVsProjectedTitle: UILabel!
    
    
    @IBOutlet weak var viewQuarters: UIView!
    @IBOutlet weak var lblQuarter: UILabel!
    
    
    
    @IBOutlet weak var viewValues: UIView!
    
    @IBOutlet weak var viewParticulars: UIView!
    @IBOutlet weak var lblParticulars: UILabel!
    
    @IBOutlet weak var viewActualSales: UIView!
    @IBOutlet weak var lblActualSales: UILabel!
    
    @IBOutlet weak var viewGPSales: UIView!
    @IBOutlet weak var lblGPSales: UILabel!
    
    @IBOutlet weak var viewTotalExp: UIView!
    @IBOutlet weak var lblTotalExp: UILabel!
    
    @IBOutlet weak var viewProjectedSales: UIView!
    @IBOutlet weak var lblProjectedSales: UILabel!
    
    @IBOutlet weak var viewActualVsProjected: UIView!
    @IBOutlet weak var lblActualVsProjected: UILabel!
    
    
    
    
    
    
    // MARK: - Variable
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        //self.viewCodeNTitle.cornersWFullBorder([.topLeft, .topRight], radius: 10, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        
        self.lblCode.textColor = UIColor(hexString: "#4496CB", alpha: 1.0)
        self.lblName.textColor = Colors.theme.returnColor()
        
        self.lblQuarter.textColor = UIColor(hexString: "#4496CB", alpha: 1.0)
        
        self.viewParticularsTitle.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewActualSalesTitle.backgroundColor = UIColor(hexString: "#D9D9D9", alpha: 1.0)
        self.viewGPSalesTitle.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewTotalExpTitle.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewProjectedSalesTitle.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewActualVsProjectedTitle.backgroundColor = UIColor(hexString: "#C4BD97", alpha: 1.0)
        
        self.viewParticulars.backgroundColor = .white
        self.viewActualSales.backgroundColor = UIColor(hexString: "#D9D9D9", alpha: 1.0)
        self.viewGPSales.backgroundColor = .white
        self.viewTotalExp.backgroundColor = .white
        self.viewProjectedSales.backgroundColor = UIColor(hexString: "#D9D9D9", alpha: 1.0)
        self.viewActualVsProjected.backgroundColor = UIColor(hexString: "#C4BD97", alpha: 1.0)
        
        
        self.viewTitles.addBorders(edges: [.all], color: Colors.gray.returnColor())
        self.viewParticularsTitle.addBorders(edges: [.right], color: Colors.gray.returnColor())
        self.viewActualSalesTitle.addBorders(edges: [.right], color: Colors.gray.returnColor())
        self.viewGPSalesTitle.addBorders(edges: [.right], color: Colors.gray.returnColor())
        self.viewTotalExpTitle.addBorders(edges: [.right], color: Colors.gray.returnColor())
        self.viewProjectedSalesTitle.addBorders(edges: [.right], color: Colors.gray.returnColor())
        
        self.viewQuarters.addBorders(edges: [.all], color: Colors.gray.returnColor())
        
        //self.viewValues.addBorders(edges: [.all], color: Colors.gray.returnColor())
        self.viewParticulars.addBorders(edges: [.right], color: Colors.gray.returnColor())
        self.viewActualSales.addBorders(edges: [.right], color: Colors.gray.returnColor())
        self.viewGPSales.addBorders(edges: [.right], color: Colors.gray.returnColor())
        self.viewTotalExp.addBorders(edges: [.right], color: Colors.gray.returnColor())
        self.viewProjectedSales.addBorders(edges: [.right], color: Colors.gray.returnColor())
        
        //self.viewValues.cornersWFullBorder([.bottomLeft, .bottomRight], radius: 10, borderColor: Colors.gray.returnColor(), colorOpacity: 1)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
