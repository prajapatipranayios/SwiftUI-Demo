//
//  SalesPerformanceVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 25/09/24.
//

import Foundation
import UIKit


// MARK: - UITableView DataSource, Delegate

extension SalesPerformanceVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrKra?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "KraUserDetailTVCell", for: indexPath) as! KraUserDetailTVCell
        
        cell.lblCode.text = self.arrKra?[indexPath.row].employeeCode ?? ""
        cell.lblName.text = self.arrKra?[indexPath.row].fullName ?? ""
        
        cell.lblQuarter.text = self.getQuarter(quarter: self.arrKra?[indexPath.row].quarter ?? "")
        
        cell.lblParticulars.text = self.arrKra?[indexPath.row].label ?? ""
        cell.lblActualSales.text = "\(self.arrKra?[indexPath.row].actualSale ?? 0.0)".curFormatAsRegion()
        cell.lblGPSales.text = self.arrKra?[indexPath.row].gpSales ?? ""
        cell.lblTotalExp.text = "\(self.arrKra?[indexPath.row].totalExp ?? 0.0)".curFormatAsRegion()
        cell.lblProjectedSales.text = "\(self.arrKra?[indexPath.row].projectedSale ?? 0.0)".curFormatAsRegion()
        cell.lblActualVsProjected.text = self.arrKra?[indexPath.row].projectedSaleQuarter ?? ""
        
        cell.constraintHeightViewCodeNTitle.priority = .defaultLow
        cell.constraintHeightViewTitles.priority = .defaultLow
        
        cell.viewValues.addBorders(edges: [.top, .left, .right, .bottom], color: Colors.gray.returnColor(), thickness: 1.0)
        
        if indexPath.row == 0 {
            cell.viewCodeNTitle.cornersWFullBorder([.topLeft, .topRight], radius: 10, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        }
        
        if indexPath.row < ((self.arrKra?.count ?? 0) - 1) {
            if (self.arrKra?[indexPath.row].fullName ?? "") != (self.arrKra?[indexPath.row + 1].fullName ?? "") {
                cell.viewValues.cornersWFullBorder([.bottomLeft, .bottomRight], radius: 10, borderColor: Colors.gray.returnColor(), colorOpacity: 1)
            }
        }
        else if indexPath.row == ((self.arrKra?.count ?? 0) - 1) {
            cell.viewValues.cornersWFullBorder([.bottomLeft, .bottomRight], radius: 10, borderColor: Colors.gray.returnColor(), colorOpacity: 1)
        }
        
        if indexPath.row > 0 {
            if (self.arrKra?[indexPath.row].fullName ?? "") == (self.arrKra?[indexPath.row - 1].fullName ?? "") {
                cell.constraintHeightViewCodeNTitle.priority = .required
                cell.constraintHeightViewTitles.priority = .required
            }
            else {
                cell.viewCodeNTitle.cornersWFullBorder([.topLeft, .topRight], radius: 10, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func getQuarter(quarter: String) -> String {
        if quarter == "Q1" {
            return "Quarter 1"
        }
        else if quarter == "Q2" {
            return "Quarter 2"
        }
        else if quarter == "Q3" {
            return "Quarter 3"
        }
        else if quarter == "Q4" {
            return "Quarter 4"
        }
        return "Quarter"
    }
    
}



// MARK: Webservices

extension SalesPerformanceVC {
    
    func getEmployeeListZoneWise(arrZone: [String]) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployeeListZoneWise(arrZone: arrZone)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "zone": arrZone
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EMPLOYEE_LIST_ZONE_WISE, parameters: param) { (response: ApiResponseTarget?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrEmp = response?.result?.employee ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getUserKRA(employeeId: [Int], year: String, arrQuarter: [String]) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getUserKRA(employeeId: employeeId, year: year, arrQuarter: arrQuarter)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "employeeId": employeeId,
            "year": year,
            "quarter": arrQuarter,
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_USER_KRA, parameters: param) { (response: ApiResponseSalesPerformance?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrKra = response?.result?.kra ?? []
                    self.lblSalesPerformanceYear.text = self.strKraYearMsg + "\(self.lblSelectedYears.text ?? "")"
                    self.tvKra.reloadData()
                    
                    self.viewNoData.isHidden = true
                    if self.arrKra?.count ?? 0 == 0 {
                        self.lblSalesPerformanceYear.text = ""
                        self.viewNoData.isHidden = false
                        self.lblNoData.text = response?.message ?? ""
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
                self.lblSalesPerformanceYear.text = ""
                self.viewNoData.isHidden = false
                self.lblNoData.text = response?.message ?? ""
            }
        }
    }
    
}
