//
//  HomeVC.swift
//  GE Sales
//
//  Created by Auxano on 15/04/24.
//

import Foundation
import UIKit

class HomeVC: UIViewController {
    
    // MARK: - Controls
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        //self.viewTransparent.isHidden = false
        //toggleSideMenuView()
        
        revealViewController()?.revealSideMenu()
    }
    @IBOutlet weak var btnNotification: UIButton!
    @IBAction func btnNotificationTap(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "NotificationListVC") as! NotificationListVC
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    @IBOutlet weak var btnChat: UIButton!
    @IBAction func btnChatTap(_ sender: UIButton) {
        
    }
    @IBOutlet weak var colleCategory: UICollectionView!
    @IBOutlet weak var viewTransparent: UIView!
    
    // MARK: - Variables
    var colleSection: Int? = 0
    var categoryCell: [String]? = []
    var TADACell: [String]? = []
    var gedashboard: Dashboard?
    let temp = SideMenuViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.sideMenuController()?.sideMenu?.delegate = self
        self.viewTransparent.isHidden = true
        
        self.setupCollectionView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if !appDelegate.isAutoLogin {
            self.loginNav()
        }
        else {
            APIManager.sharedManager.userId = UserDefaults.standard.value(forKey: UserDefaultType.userId) as? Int ?? 0
            self.getUserProfile()
            DispatchQueue.main.async {
                self.getBranch()
            }
        }
    }
    
    private func setupCollectionView() {
        
        self.colleCategory.delegate = self
        self.colleCategory.dataSource = self
        //self.colleCategory.collectionViewLayout = createCollectionViewLayout()
        
        colleCategory.register(UINib(nibName: "CategoryCVCell", bundle: nil), forCellWithReuseIdentifier: "CategoryCVCell")
        colleCategory.register(UINib(nibName: "TADACVCell", bundle: nil), forCellWithReuseIdentifier: "TADACVCell")
    }
    
    func loginNav() {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
