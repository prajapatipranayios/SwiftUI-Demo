//
//  HeaderRV.swift
//  GE Sales
//
//  Created by Auxano on 17/04/24.
//

import UIKit

class HeaderRV: UICollectionReusableView {
        
    @IBOutlet weak var lblHeader: UILabel!
    @IBOutlet weak var constraintHeightlblHeader: NSLayoutConstraint!
    
}
