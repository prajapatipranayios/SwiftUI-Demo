//
//  HomeVC_Extension .swift
//  GE Sales
//
//  Created by Auxano on 18/04/24.
//

import Foundation
import UIKit

// MARK: UICollectionView Delegate, DataSource, FlowLayout

extension HomeVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return self.colleSection ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (section == 0) ? self.categoryCell?.count ?? 0 : self.TADACell?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCVCell", for: indexPath) as! CategoryCVCell
            
            cell.lblCategoryName.text = self.categoryCell?[indexPath.item] ?? ""
            cell.imgCategory.image = UIImage(named: "\((self.categoryCell?[indexPath.item] ?? "").replacingOccurrences(of: " ", with: "-"))")
            
            /*if (self.categoryCell?[indexPath.item] ?? "") == "Commission" {
                APIManager.sharedManager.isCommissionActive = true
            }   //  */
            
            if self.categoryCell?[indexPath.item] ?? "" == HomeCategory.products.rawValue {
                //cell.lblCount.text = "\(self.gedashboard?.products ?? 0)" != "0" ? "\(self.gedashboard?.products ?? 0)" : ""
                cell.lblCount.text = "\(self.gedashboard?.products ?? 0)"
            }
            else if self.categoryCell?[indexPath.item] ?? "" == HomeCategory.businessPartners.rawValue {
                //cell.lblCount.text = "\(self.gedashboard?.businessPartners ?? 0)" != "0" ? "\(self.gedashboard?.businessPartners ?? 0)" : ""
                cell.lblCount.text = "\(self.gedashboard?.businessPartners ?? 0)"
            }
            else if self.categoryCell?[indexPath.item] ?? "" == HomeCategory.salesOrder.rawValue {
                //cell.lblCount.text = "\(self.gedashboard?.salesOrder ?? 0)" != "0" ? "\(self.gedashboard?.salesOrder ?? 0)" : ""
                cell.lblCount.text = "\(self.gedashboard?.salesOrder ?? 0)"
            }
            else if self.categoryCell?[indexPath.item] ?? "" == HomeCategory.sampleRequest.rawValue {
                //cell.lblCount.text = "\(self.gedashboard?.sampleRequest ?? 0)" != "0" ? "\(self.gedashboard?.sampleRequest ?? 0)" : ""
                cell.lblCount.text = "\(self.gedashboard?.sampleRequest ?? 0)"
            }
            else if self.categoryCell?[indexPath.item] ?? "" == HomeCategory.quotation.rawValue {
                //cell.lblCount.text = "\(self.gedashboard?.quotation ?? 0)" != "0" ? "\(self.gedashboard?.quotation ?? 0)" : ""
                cell.lblCount.text = "\(self.gedashboard?.quotation ?? 0)"
            }
            else if self.categoryCell?[indexPath.item] ?? "" == HomeCategory.proformaInvoice.rawValue {
                //cell.lblCount.text = "\(self.gedashboard?.proformaInvoice ?? 0)" != "0" ? "\(self.gedashboard?.proformaInvoice ?? 0)" : ""
                cell.lblCount.text = "\(self.gedashboard?.proformaInvoice ?? 0)"
            }
            else if self.categoryCell?[indexPath.item] ?? "" == HomeCategory.followUp.rawValue {
                //cell.lblCount.text = "\(self.gedashboard?.followUp ?? 0)" != "0" ? "\(self.gedashboard?.followUp ?? 0)" : ""
                cell.lblCount.text = "\(self.gedashboard?.followUp ?? 0)"
            }
            else if self.categoryCell?[indexPath.item] ?? "" == HomeCategory.draftOrder.rawValue {
                //cell.lblCount.text = "\(self.gedashboard?.draftOrder ?? 0)" != "0" ? "\(self.gedashboard?.draftOrder ?? 0)" : ""
                cell.lblCount.text = "\(self.gedashboard?.draftOrder ?? 0)"
            }
            else {
                cell.lblCount.text = ""
            }
            
            return cell
        }
        else if indexPath.section == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TADACVCell", for: indexPath) as! TADACVCell
            
            cell.lblTaDaName.text = self.TADACell?[indexPath.item] ?? ""
            cell.img.image = UIImage(named: "\((self.TADACell?[indexPath.item] ?? "").replacingOccurrences(of: " ", with: "-"))")
            
            if self.TADACell?[indexPath.item] ?? "" == TaDa.MTP.rawValue {
                cell.lblTaDaFName.text = TaDa.MTP.getFName()
            }
            else if self.TADACell?[indexPath.item] ?? "" == TaDa.DVR.rawValue {
                cell.lblTaDaFName.text = TaDa.DVR.getFName()
            }
            else if self.TADACell?[indexPath.item] ?? "" == TaDa.Expense.rawValue {
                cell.lblTaDaFName.text = TaDa.Expense.getFName()
            }
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as UICollectionViewCell
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if indexPath.section == 0 {
            let width = (collectionView.frame.width - 80) / 2
            let height = 90.0
            return CGSize(width: width, height: height)
        }
        else if indexPath.section == 1 {
            let width = (collectionView.frame.width - 80) / 3
            let height = 120.0
            return CGSize(width: width, height: height)
        }
        else {
            return .zero
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        switch kind {
        case UICollectionView.elementKindSectionHeader:
            if indexPath.section == 1 {
                let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HeaderRV", for: indexPath) as! HeaderRV
                //headerView.lblHeader.text = "TA & DA"
                return headerView
            }
            else {
                assert(false, "Unexpected element kind")
            }
        default:
            assert(false, "Unexpected element kind")
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 1 {
            return CGSizeMake(collectionView.frame.size.width, 65)
        }
        else {
            return CGSizeZero
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        var vc = UIViewController()
        var isValid: Bool = false
        
        if indexPath.section == 0 {
            let title = self.categoryCell?[indexPath.item] ?? ""
            
            switch title {
            case HomeCategory.products.rawValue:
                // Product History
                vc = sb.instantiateViewController(withIdentifier: "ProductCategoryVC")
                isValid = true
            case HomeCategory.businessPartners.rawValue:
                // Business Partners
                vc = sb.instantiateViewController(withIdentifier: "BusinessPartnerVC")
                isValid = true
            case HomeCategory.salesOrder.rawValue:
                // Sales Order
                vc = sb.instantiateViewController(withIdentifier: "SalesOrderVC")
                isValid = true
            case HomeCategory.sampleRequest.rawValue:
                // Sample Request
                vc = sb.instantiateViewController(withIdentifier: "SampleRequestVC")
                isValid = true
            case HomeCategory.quotation.rawValue:
                // Quotation
                vc = sb.instantiateViewController(withIdentifier: "QIVC")
                isValid = true
            case HomeCategory.proformaInvoice.rawValue:
                // Proforma Invoice
                vc = sb.instantiateViewController(withIdentifier: "PIVC")
                isValid = true
            case HomeCategory.commission.rawValue:
                // Commission
                vc = sb.instantiateViewController(withIdentifier: "CommissionVC")
                isValid = true
            case HomeCategory.followUp.rawValue:
                // Follow Up
                vc = sb.instantiateViewController(withIdentifier: "FollowUpVC")
                isValid = true
            case HomeCategory.draftOrder.rawValue:
                // Draft Order
                vc = sb.instantiateViewController(withIdentifier: "DraftOrderVC")
                isValid = true
            case HomeCategory.dashboard.rawValue:
                // Dashboard
                vc = sb.instantiateViewController(withIdentifier: "DashboardVC")
                isValid = true
            case HomeCategory.target.rawValue:
                // Target
                vc = sb.instantiateViewController(withIdentifier: "TargetVC")
                isValid = true
            case HomeCategory.salesPerformance.rawValue:
                // Sales Performance
                vc = sb.instantiateViewController(withIdentifier: "SalesPerformanceVC")
                isValid = true
            case HomeCategory.crm.rawValue:
                // CRM
                vc = sb.instantiateViewController(withIdentifier: "CRMVC")
                isValid = true
            default:
                isValid = false
            }
            /****if isValid {
                self.navigationController?.pushViewController(vc, animated: false)
            }   //  */
        }
        else {
            let title = self.TADACell?[indexPath.item] ?? ""
            
            /****let sb = UIStoryboard(name: "Main", bundle: nil)
            var vc = UIViewController()
            var isValid: Bool = false   //  */
            
            switch title {
            case TaDa.MTP.rawValue:
                // MTP
                vc = sb.instantiateViewController(withIdentifier: "MonthlyTourPlanVC")
                isValid = true
            case TaDa.DVR.rawValue:
                // DVR
                vc = sb.instantiateViewController(withIdentifier: "DVRListVC")
                isValid = true
            case TaDa.Expense.rawValue:
                // Expense
                vc = sb.instantiateViewController(withIdentifier: "ExpensesVC")
                isValid = true
            default:
                break
            }
        }
        if isValid {
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
}

// MARK: Webservices

extension HomeVC {
    
    func getUserProfile() {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getUserProfile()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.VIEW_USER_PROFILE, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                
                APIManager.sharedManager.userDetail = response?.result?.userDetail
                APIManager.sharedManager.userId = response?.result?.userDetail?.id ?? 0
                self.gedashboard = response?.result?.geDashboard
                DispatchQueue.main.async {
                    
                    if response?.result?.userDetail?.isLogged ?? 0 == 0 {
                        
                        UserDefaults.standard.set(0, forKey: UserDefaultType.userId)
                        UserDefaults.standard.set(0, forKey: UserDefaultType.userRole)
                        self.restartApplication()
                    }
                    else {
                        UserDefaults.standard.set(APIManager.sharedManager.userId, forKey: UserDefaultType.userId)
                        UserDefaults.standard.set(response?.result?.userDetail?.roleId ?? 0, forKey: UserDefaultType.userRole)
                        
                        (self.colleSection, self.categoryCell, self.TADACell) = Role.getInfo(forRole: APIManager.sharedManager.userDetail?.roleId ?? 0)
                        
                        self.colleCategory.reloadData()
                        
                        self.getExpenseCategory()
                        //self.getTravelMode()
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getBranch() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBranch()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": 1
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_BRANCHES, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    APIManager.sharedManager.arrBranches = response?.result?.branch ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
                //self.getBranch()
            }
        }
    }
    
    func getExpenseCategory() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getExpenseCategory()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "designation": APIManager.sharedManager.userDetail?.designationId ?? 0
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EXPENSE_CATEGORY, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    
                    APIManager.sharedManager.arrExpenseCategory = response?.result?.category ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getTravelMode() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getTravelMode()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_TRAVEL_MODE, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    
                    APIManager.sharedManager.arrTravelMode = response?.result?.travelModes ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
