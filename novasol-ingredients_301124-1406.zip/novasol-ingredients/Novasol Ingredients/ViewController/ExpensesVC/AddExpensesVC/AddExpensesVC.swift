//
//  AddExpensesVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 09/09/24.
//

import UIKit
import SearchTextField
import PhotosUI

class AddExpensesVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismissMyKeyboard()
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = "Are you sure to discard Expenses?"
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            self.navigationController?.popViewController(animated: true)
        }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
        //self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var viewScrollMOut: UIView!
    @IBOutlet weak var constraintBottomViewScrollMOutSuper: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIView!
    @IBOutlet weak var viewScrollMIn: UIView!
    
    
    // View Option HQ & OS
    
    @IBOutlet weak var viewOptionHQ_OS: UIView!
    @IBOutlet weak var viewInnerOptionHQ_OS: UIView!
    
    @IBOutlet weak var btnHQ: UIButton!
    @IBAction func btnHQTap(_ sender: UIButton) {
        self.btnHQ.isSelected = true
        self.strSelectedOption = "HQ"
        self.btnOS.isSelected = false
        
        self.lblExpensesCategory.text = "Select Expense Category"
        
        self.constraintBottomViewExpensesDate.priority = .required
        self.constraintHeightViewSpentAtNCity.priority = .required
        self.constraintHeightViewTravelModeNDistance.priority = .required
        self.constraintHeightViewPaymentModeNAmont.priority = .required
        self.constraintHeightViewUploadImg.priority = .required
        self.constraintHeightViewButtons.priority = .required
        
        self.clearAllData()
    }
    
    @IBOutlet weak var btnOS: UIButton!
    @IBAction func btnOSTap(_ sender: UIButton) {
        self.btnHQ.isSelected = false
        self.strSelectedOption = "OS"
        self.btnOS.isSelected = true
        
        self.lblExpensesCategory.text = "Select Expense Category"
        
        self.constraintBottomViewExpensesDate.priority = .required
        self.constraintHeightViewSpentAtNCity.priority = .required
        self.constraintHeightViewTravelModeNDistance.priority = .required
        self.constraintHeightViewPaymentModeNAmont.priority = .required
        self.constraintHeightViewUploadImg.priority = .required
        self.constraintHeightViewButtons.priority = .required
        
        self.clearAllData()
    }
    
    
    
    // View Expenses Category N Date
    
    @IBOutlet weak var viewExpensesCategoryNDate: UIView!
    @IBOutlet weak var constraintHeightViewExpensesCategoryNDate: NSLayoutConstraint!
    
    @IBOutlet weak var viewExpensesCategory: UIView!
    @IBOutlet weak var lblExpensesCategory: UILabel!
    @IBOutlet weak var btnExpensesCategory: UIButton!
    @IBAction func btnExpensesCategoryTap(_ sender: UIButton) {
        
        self.dismissMyKeyboard()
        
        let arrExpenseCategory = APIManager.sharedManager.arrExpenseCategory
        
        var arrTempExpenseCategory: [String] = []
        if self.strSelectedOption == "HQ" {
            arrTempExpenseCategory = (arrExpenseCategory ?? []).compactMap { item -> String? in
                guard let EName = item.name,
                      let isHq = item.isHq,
                      isHq == 1 else { return nil }
                return EName
            }
        }
        else {
            arrTempExpenseCategory = (arrExpenseCategory ?? []).compactMap { item -> String? in
                guard let EName = item.name,
                      let isOS = item.isOS,
                      isOS == 1 else { return nil }
                return EName
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Expenses Category"
        popupVC.value = arrTempExpenseCategory
        popupVC.selectedValue = self.lblExpensesCategory.text ?? "Select Expense Category"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.setUpView(strValue: strValue)
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewExpensesDate: UIView!
    @IBOutlet weak var constraintBottomViewExpensesDate: NSLayoutConstraint!
    @IBOutlet weak var lblExpensesDate: UILabel!
    @IBOutlet weak var btnExpensesDate: UIButton!
    @IBAction func btnExpensesDateTap(_ sender: UIButton) {
        
        self.dismissMyKeyboard()
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.didSelectDate = { date in
            self.lblExpensesDate.text = date
            self.strExpensesDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy/MM/dd")
            
            self.lblExpensesDate.textColor = .black
            
            self.checkExpenseDate(eDate: self.strExpensesDate)
        }
        popupVC.onClose = {
            //self.lblExpensesDate.text = "Select Date"
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var lblSeparatorEDate: UILabel!
    
    @IBOutlet weak var viewToDate: UIView!
    @IBOutlet weak var lblToDate: UILabel!
    @IBOutlet weak var btnToDate: UIButton!
    @IBAction func btnToDateTap(_ sender: UIButton) {
        
        self.dismissMyKeyboard()
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.minStartDate = self.lblExpensesDate.text ?? ""
        popupVC.didSelectDate = { date in
            self.lblToDate.text = date
            self.strToDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy/MM/dd")
            
            self.lblToDate.textColor = .black
            
            self.checkExpenseDate(eDate: self.strToDate, isToDate: true)
        }
        popupVC.onClose = {
            //self.lblExpensesDate.text = "Select Date"
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var lblSeparatorToDate: UILabel!
    
    
    
    
    // View SpentAt N City Name
    @IBOutlet weak var viewSpentAtNCity: UIView!
    @IBOutlet weak var constraintHeightViewSpentAtNCity: NSLayoutConstraint!
    
    @IBOutlet weak var txtSpentAt: TLTextField!
    @IBOutlet weak var viewCityType: UIView!
    @IBOutlet weak var lblCityType: UILabel!
    @IBOutlet weak var btnCityType: UIButton!
    @IBAction func btnCityTypeTap(_ sender: UIButton) {
        
        self.dismissMyKeyboard()
        
        let arrTempCityType: [String] = self.arrStrCityType
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "City Type"
        popupVC.value = arrTempCityType
        popupVC.selectedValue = self.lblCityType.text ?? "Select City Type"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.lblCityType.text = strValue
            self.txtCityName.text = ""
            self.configureCitySearchTextField()
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var txtCityName: SearchTextField!
    
    
    
    // View Travel Mode
    
    @IBOutlet weak var viewTravelModeNDistance: UIView!
    @IBOutlet weak var constraintHeightViewTravelModeNDistance: NSLayoutConstraint!
    
    @IBOutlet weak var viewTravelMode: UIView!
    @IBOutlet weak var lblTravelMode: UILabel!
    @IBOutlet weak var btnTravelMode: UIButton!
    @IBAction func btnTravelModesTap(_ sender: UIButton) {
        
        self.dismissMyKeyboard()
        
        let arrTravelMode = APIManager.sharedManager.arrTravelMode
        
        var arrTempTravelMode: [String] = []
        
        if self.strSelectedCategory == "travel_mode_local" {
            
            arrTempTravelMode = (arrTravelMode ?? []).compactMap { item -> String? in
                guard let mode = item.travelMode,
                      let isFuel = item.isFuel,
                      isFuel == 1 else { return nil }
                return mode
            }
        }
        else {
            arrTempTravelMode = (arrTravelMode ?? []).compactMap { item -> String? in
                guard let mode = item.travelMode,
                      let isTicket = item.isTicket,
                      isTicket == 1 else { return nil }
                return mode
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Select Travel Mode"
        popupVC.value = arrTempTravelMode
        popupVC.selectedValue = self.lblTravelMode.text ?? "Select Travel Mode"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.lblTravelMode.text = strValue
            
            let tempObj = arrTravelMode?.filter { $0.travelMode ?? "" == strValue }
            self.intTravelModeId = tempObj?[0].id ?? 0
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var txtFromCityName: SearchTextField!
    @IBOutlet weak var txtToCityName: SearchTextField!
    @IBOutlet weak var txtAlsoCoveredCityName: SearchTextField!
    @IBOutlet weak var btnAddOther: UIButton!
    @IBAction func btnAddOtherTap(_ sender: UIButton) {
        if self.txtAlsoCoveredCityName.text != "" {
            self.arrViaCity?.append(self.txtAlsoCoveredCityName.text ?? "")
            self.constraintHeightTVCoveredCity.constant = CGFloat((self.arrViaCity?.count ?? 0) * 35)
            self.tvCoveredCity.reloadData()
            self.txtAlsoCoveredCityName.text = ""
        }
    }
    @IBOutlet weak var tvCoveredCity: UITableView! {
        didSet {
            self.tvCoveredCity.delegate = self
            self.tvCoveredCity.dataSource = self
            self.tvCoveredCity.register(UINib(nibName: "AddMtpCityEmpTVCell", bundle: nil), forCellReuseIdentifier: "AddMtpCityEmpTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVCoveredCity: NSLayoutConstraint!
    @IBOutlet weak var txtDistance: SearchTextField!
    
    
    // View Payment Mode
    
    @IBOutlet weak var viewPaymentModeNAmont: UIView!
    @IBOutlet weak var constraintHeightViewPaymentModeNAmont: NSLayoutConstraint!
    
    @IBOutlet weak var viewPaymentMode: UIView!
    @IBOutlet weak var lblPaymentMode: UILabel!
    @IBOutlet weak var btnPaymentMode: UIButton!
    @IBAction func btnPaymentModesTap(_ sender: UIButton) {
        
        self.dismissMyKeyboard()
        
        let arrTempPaymentMode: [String] = ["Cash", "Wallet", "Credit Card"]
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = "Select Travel Mode"
        popupVC.value = arrTempPaymentMode
        popupVC.selectedValue = self.lblPaymentMode.text ?? "Select Travel Mode"
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.didSelectItem = { strValue in
            self.lblPaymentMode.text = strValue
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var txtAmount: TLTextField!
    @IBOutlet weak var txtRemarks: TLTextField!
    
    
    // View Upload Image
    
    @IBOutlet weak var viewUploadImg: UIView!
    @IBOutlet weak var constraintHeightViewUploadImg: NSLayoutConstraint!
    
    @IBOutlet weak var lblUploadImgTitle: UILabel!
    @IBOutlet weak var btnUploadImg: UIButton!
    @IBAction func btnUploadImgTap(_ sender: UIButton) {
        
        self.selectImgFromGallery()
        
        /*let actionSheet = UIAlertController(title: "Choose an option", message: nil, preferredStyle: .actionSheet)
        
        let option1Action = UIAlertAction(title: "Camera", style: .default) { _ in
            self.captureImageFromCamera()
        }
        
        let option2Action = UIAlertAction(title: "Gallery", style: .default) { _ in
            self.selectImgFromGallery()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
        }
        
        actionSheet.addAction(option1Action)
        actionSheet.addAction(option2Action)
        actionSheet.addAction(cancelAction)
        
        present(actionSheet, animated: true, completion: nil)   ///  */
    }
    @IBOutlet weak var cvUploadImg: UICollectionView! {
        didSet {
            self.cvUploadImg.delegate = self
            self.cvUploadImg.dataSource = self
            self.cvUploadImg.register(UINib(nibName: "AddOrderUploadImgCVCell", bundle: nil), forCellWithReuseIdentifier: "AddOrderUploadImgCVCell")
        }
    }
    @IBOutlet weak var constraintHeightCVUploadImg: NSLayoutConstraint!
    
    
    // View buttons
    
    @IBOutlet weak var viewButtons: UIView!
    @IBOutlet weak var constraintHeightViewButtons: NSLayoutConstraint!
    
    @IBOutlet weak var btnSaveDraft: UIButton!
    @IBAction func btnSaveDraftTap(_ sender: UIButton) {
        self.checkValidation(isDraft: 1)
    }
    @IBOutlet weak var btnSubmit: UIButton!
    @IBAction func btnSubmitTap(_ sender: UIButton) {
        self.checkValidation(isDraft: 0)
    }
    
    
    @IBOutlet weak var ivCheckImg: UIImageView!
    
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Expenses"
    
    var strSelectedOption: String = "HQ"
    var strSelectedCategory: String = ""
    
    var isFoodExpense: Bool = false
    var isHotelExpense: Bool = false
    var isLocalConveyance: Bool = false
    var isTicketBooking: Bool = false
    var isOther: Bool = false
    
    var strExpensesDate: String = ""
    var strToDate: String = ""
    
    var arrStrCityType: [String] = []
    var arrCities: [CityInfo]? = []
    var arrCityType: [CityType]? = []
    var arrViaCity: [String]? = []
    
    var arrImg: [String] = []
    var arrUploadImg: [ImgUpload]? = []
    var isCameraClick : Bool = false
    
    var intTravelModeId: Int = 0
    
    
    // Edit Expense
    
    var isFromEdit: Bool = false
    var editExpenseObj: UserExpenseListDetails?
    var intEditExpenseId: Int = 0
    var strEditExpenseType: String? = ""
    var strEditExpenseCategory: String? = ""
    var arrDeleteImgId: [String] = []
    
    
    // Add from DVR
    var strDvrDate: String = ""
    var strDvrCity: String = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.constraintBottomViewExpensesDate.priority = .required
        self.constraintHeightViewSpentAtNCity.priority = .required
        self.constraintHeightViewTravelModeNDistance.priority = .required
        self.constraintHeightViewPaymentModeNAmont.priority = .required
        self.constraintHeightViewUploadImg.priority = .required
        self.constraintHeightViewButtons.priority = .required
        
        self.btnHQ.isSelected = true
        
        self.constraintHeightCVUploadImg.constant = 0
        self.constraintHeightTVCoveredCity.constant = 0 
        
        self.arrCities = self.loadDataFromJson(fileName: "Cities", as: [CityInfo].self)
        self.arrCityType = self.loadDataFromJson(fileName: "CityType", as: [CityType].self)
        self.arrStrCityType = Array(Set((self.arrCityType ?? []).map { $0.category! })).sorted()
        
        self.btnAddOther.cornersWFullBorder(radius: 7.0, borderColor: .black, colorOpacity: 1.0)
        
        self.configureCitySearchTextField()
        self.checkKeyboard(kView: self.viewBack)
        self.checkKeyboard(kView: self.viewOptionHQ_OS)
        self.checkKeyboard(kView: self.viewExpensesCategoryNDate)
        self.checkKeyboard(kView: self.viewSpentAtNCity)
        self.checkKeyboard(kView: self.viewTravelMode)
        self.checkKeyboard(kView: self.tvCoveredCity)
        self.checkKeyboard(kView: self.viewPaymentMode)
        self.checkKeyboard(kView: self.viewUploadImg)
        self.checkKeyboard(kView: self.viewButtons)
        
        //self.getExpenseCategory()
        //self.getTravelMode()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        if self.isFromEdit {    
            self.intEditExpenseId = self.editExpenseObj?.id ?? 0
            self.setUpView(strValue: self.editExpenseObj?.category ?? "")
            
            self.strSelectedOption = self.editExpenseObj?.expenseType ?? ""
            self.strSelectedCategory = self.editExpenseObj?.category ?? ""
            
            if self.strSelectedOption == "OS" {
                self.btnOSTap(UIButton())
            }
        }
        
        if self.strDvrDate != "" {
            self.lblExpensesDate.text = Utilities.convertStrDateToString(date: self.strDvrDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd-MMM-yyyy")
            self.strExpensesDate = Utilities.convertStrDateToString(date: self.strDvrDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "yyyy/MM/dd")
            
            self.lblExpensesDate.textColor = .black
        }
        
        if self.strDvrCity != "" {
            self.txtCityName.text = self.strDvrCity
            self.txtCityName.text = self.strDvrCity
        }
    }

    func setUpView(strValue: String) {
        
        if strValue != "" {
            self.lblExpensesCategory.text = strValue
            let tempObj = APIManager.sharedManager.arrExpenseCategory?.filter { $0.name! == strValue }
            self.strSelectedCategory = tempObj?[0].slug ?? ""
        }
        //self.lblExpensesCategory.text = "Select Expense Category"
        self.clearAllData()
        
        self.constraintBottomViewExpensesDate.priority = .required
        self.constraintHeightViewSpentAtNCity.priority = .required
        self.constraintHeightViewTravelModeNDistance.priority = .required
        self.constraintHeightViewPaymentModeNAmont.priority = .required
        self.constraintHeightViewUploadImg.priority = .required
        self.constraintHeightViewButtons.priority = .required
        
        self.isFoodExpense = false
        self.isHotelExpense = false
        self.isLocalConveyance = false
        self.isTicketBooking = false
        self.isOther = false
        
        if strValue == "Food Expense" {
            self.isFoodExpense = true
            self.constraintHeightViewSpentAtNCity.priority = .defaultLow
            self.constraintHeightViewPaymentModeNAmont.priority = .defaultLow
            self.constraintHeightViewUploadImg.priority = .defaultLow
            self.constraintHeightViewButtons.priority = .defaultLow
        }
        else if (strValue == "Local Conveyance") || (strValue == "Ticket Booking") {
            self.isLocalConveyance = true
            self.isTicketBooking = true
            
            self.constraintHeightViewTravelModeNDistance.priority = .defaultLow
            self.constraintHeightViewPaymentModeNAmont.priority = .defaultLow
            self.constraintHeightViewUploadImg.priority = .defaultLow
            self.constraintHeightViewButtons.priority = .defaultLow
        }
        else if strValue == "Other" {
            self.isOther = true
            self.constraintHeightViewSpentAtNCity.priority = .defaultLow
            self.constraintHeightViewPaymentModeNAmont.priority = .defaultLow
            self.constraintHeightViewUploadImg.priority = .defaultLow
            self.constraintHeightViewButtons.priority = .defaultLow
        }
        else if strValue == "Hotel Expense" {
            self.isFoodExpense = true
            self.isHotelExpense = true
            self.constraintBottomViewExpensesDate.priority = .defaultLow
            self.constraintHeightViewSpentAtNCity.priority = .defaultLow
            self.constraintHeightViewPaymentModeNAmont.priority = .defaultLow
            self.constraintHeightViewUploadImg.priority = .defaultLow
            self.constraintHeightViewButtons.priority = .defaultLow
        }
        
        if self.isFromEdit {
            self.setUpData()
        }
    }
    
    func setUpData() {
        self.lblExpensesDate.text = Utilities.convertStrDateToString(date: self.editExpenseObj?.expenseDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd-MMM-yyyy")
        self.strExpensesDate = Utilities.convertStrDateToString(date: self.editExpenseObj?.expenseDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "yyyy/MM/dd")
        self.lblExpensesDate.textColor = .black
        
        
        self.lblExpensesDate.textColor = .black
        
        if self.isFoodExpense || self.isOther || self.isHotelExpense {
            
            self.txtSpentAt.text = self.editExpenseObj?.spentAt ?? ""
            
            self.lblCityType.text = self.editExpenseObj?.cityCategory ?? ""
                
            self.txtCityName.text = self.editExpenseObj?.cityName ?? ""
            
            if self.isHotelExpense {
                self.lblToDate.text = Utilities.convertStrDateToString(date: self.editExpenseObj?.toDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd-MMM-yyyy")
                self.strToDate = Utilities.convertStrDateToString(date: self.editExpenseObj?.toDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "yyyy/MM/dd")
                self.lblToDate.textColor = .black
            }
        }
        
        if self.isLocalConveyance || self.isTicketBooking {
            
            let tempObj = APIManager.sharedManager.arrTravelMode?.filter { $0.id ?? 0 == self.editExpenseObj?.travelModeID ?? 0 }
            if (tempObj?.count ?? 0) > 0 {
                self.lblTravelMode.text = tempObj?[0].travelMode ?? ""
                self.intTravelModeId = tempObj?[0].id ?? 0
            }
            
            self.txtFromCityName.text = self.editExpenseObj?.travelFrom ?? ""
            self.txtToCityName.text = self.editExpenseObj?.travelTo ?? ""
            
            self.arrViaCity = (self.editExpenseObj?.travelVia ?? "").components(separatedBy: ",")
            self.constraintHeightTVCoveredCity.constant = CGFloat((self.arrViaCity?.count ?? 0) * 35)
            self.tvCoveredCity.reloadData()
            self.txtDistance.text = "\(self.editExpenseObj?.distance ?? 0.0)"
        }
        
        self.lblPaymentMode.text = self.editExpenseObj?.paymentMode ?? ""
        self.txtAmount.text = self.editExpenseObj?.amount ?? ""
        
        self.arrUploadImg = []
        for (_, value) in (self.editExpenseObj?.expenseAttachment ?? []).enumerated() {
            self.arrImg.append(value.attachment ?? "")
            let temp = ImgUpload(id: value.id ?? 0, img: value.attachment ?? "")
            self.arrUploadImg?.append(temp)
        }
        self.cvUploadImg.reloadData()
        self.constraintHeightCVUploadImg.constant = 0
        if (self.arrUploadImg?.count ?? 0) > 0 {
            self.constraintHeightCVUploadImg.constant = 170
        }
        
    }
    
    func checkValidation(isDraft: Int) {
        var isValid: Bool = true
        var msg: String = ""
        
        if self.lblExpensesCategory.text == "Select Expense Category" && isValid {
            msg = "Plese select expense category"
            isValid = false
        }
        
        
        
        if self.isFoodExpense || self.isOther || self.isHotelExpense {
            if self.lblExpensesDate.text == "Select Date" && isValid {
                msg = "Plese select expense date"
                isValid = false
            }
            
            if isHotelExpense {
                if self.lblToDate.text == "To Date" && isValid {
                    msg = "Plese select to date"
                    isValid = false
                }
            }
            
            if self.txtSpentAt.text == "" && isValid {
                msg = "Plese enter spent at"
                isValid = false
            }
            
            if self.lblCityType.text == "Select City Type" && isValid {
                msg = "Plese select city type"
                isValid = false
            }
            
            if self.txtCityName.text == "" && isValid {
                msg = "Plese enter city name"
                isValid = false
            }
        }
        
        if self.isLocalConveyance || self.isTicketBooking {
            if self.lblTravelMode.text == "Select Travel Mode" && isValid {
                msg = "Plese select travel mode"
                isValid = false
            }
            
            if self.txtFromCityName.text == "" && isValid {
                msg = "Plese enter from city name"
                isValid = false
            }
            
            if self.txtToCityName.text == "" && isValid {
                msg = "Plese enter to city name"
                isValid = false
            }
            
            if (self.txtDistance.text == "") && isValid {
                msg = "Plese enter to distance"
                isValid = false
            }
            else if (Int(self.txtDistance.text ?? "0") ?? 0 <= 0) {
                msg = "Plese enter valid distance"
                isValid = false
            }
            
        }
        
        if self.lblPaymentMode.text == "Select Payment Mode" && isValid {
            msg = "Plese select payment mode"
            isValid = false
        }
        
        if self.txtAmount.text == "" && isValid {
            msg = "Plese enter amount"
            isValid = false
        }
        
        
        if isValid {
            self.addExpense(isDraft: isDraft)
        }
        else {
            Utilities.showPopup(title: msg, type: .error)
        }
    }
}

extension AddExpensesVC {
    
    fileprivate func configureCitySearchTextField() {
        // Start visible even without user's interaction as soon as created - Default: false
        self.txtCityName.startVisibleWithoutInteraction = false
        
        self.txtFromCityName.startVisibleWithoutInteraction = false
        self.txtToCityName.startVisibleWithoutInteraction = false
        self.txtAlsoCoveredCityName.startVisibleWithoutInteraction = false
        
        self.txtCityName.theme = SearchTextFieldTheme.defaultTheme(font: Fonts.Regular.returnFont(size: 17.0))
        
        self.txtFromCityName.theme = SearchTextFieldTheme.defaultTheme(font: Fonts.Regular.returnFont(size: 17.0))
        self.txtToCityName.theme = SearchTextFieldTheme.defaultTheme(font: Fonts.Regular.returnFont(size: 17.0))
        self.txtAlsoCoveredCityName.theme = SearchTextFieldTheme.defaultTheme(font: Fonts.Regular.returnFont(size: 17.0))
        
        self.txtCityName.theme.bgColor = UIColor(hexString: "#FEFEFE", alpha: 1.0)
        
        self.txtFromCityName.theme.bgColor = UIColor(hexString: "#FEFEFE", alpha: 1.0)
        self.txtToCityName.theme.bgColor = UIColor(hexString: "#FEFEFE", alpha: 1.0)
        self.txtAlsoCoveredCityName.theme.bgColor = UIColor(hexString: "#FEFEFE", alpha: 1.0)
        
        self.txtCityName.maxResultsListHeight = 200
        
        self.txtFromCityName.maxResultsListHeight = 200
        self.txtToCityName.maxResultsListHeight = 200
        self.txtAlsoCoveredCityName.maxResultsListHeight = 200
        
        self.txtCityName.font = Fonts.Regular.returnFont(size: 17)
        
        self.txtFromCityName.font = Fonts.Regular.returnFont(size: 17)
        self.txtToCityName.font = Fonts.Regular.returnFont(size: 17)
        self.txtAlsoCoveredCityName.font = Fonts.Regular.returnFont(size: 17)
        
        
        // Set data source
        let cities = (self.arrCities ?? []).map { $0.name! }
        let typeCities = (self.arrCityType ?? []).compactMap { item -> String? in
            guard let cityName = item.cityName,
                  let category = item.category,
                  category == (self.lblCityType.text ?? "") else { return nil }
            return cityName
        }
        
        self.txtCityName.filterStrings(typeCities)
        
        self.txtFromCityName.filterStrings(cities)
        self.txtToCityName.filterStrings(cities)
        self.txtAlsoCoveredCityName.filterStrings(cities)
        
    }
    
    func captureImageFromCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            var imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            imagePicker.allowsEditing = false
            imagePicker.mediaTypes = ["public.image"]
            isCameraClick = true
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func selectImgFromGallery() {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            var imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false

            present(imagePicker, animated: true, completion: nil)
            
        }
    }
    
    func clearAllData() {
        self.lblToDate.text = "To Date"
        
        self.txtSpentAt.text = ""
        self.lblCityType.text = "Select City Type"
        self.txtCityName.text = ""
        
        self.lblTravelMode.text = "Select Travel Mode"
        
        self.lblPaymentMode.text = "Select Payment Mode"
        self.txtAmount.text = ""
        self.txtRemarks.text = ""
        
        self.txtFromCityName.text = ""
        self.txtToCityName.text = ""
        self.txtAlsoCoveredCityName.text = ""
        self.txtDistance.text = ""
        
        if self.strDvrCity != "" {
            self.txtCityName.text = self.strDvrCity
            self.txtFromCityName.text = self.strDvrCity
        }
        
        self.intTravelModeId = 0
    }
    
}

