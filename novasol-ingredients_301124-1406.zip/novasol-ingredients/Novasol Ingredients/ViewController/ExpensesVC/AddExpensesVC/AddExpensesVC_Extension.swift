//
//  AddExpensesVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 09/09/24.
//

import Foundation
import UIKit
import PhotosUI


// MARK: UITableView Delegate, DataSource

extension AddExpensesVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrViaCity?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddMtpCityEmpTVCell", for: indexPath) as! AddMtpCityEmpTVCell
        
        cell.index = indexPath.row
        cell.viewBorder.cornersWFullBorder(radius: 1, borderColor: .clear, colorOpacity: 0.0)
        cell.lblValue.text = self.arrViaCity?[indexPath.row] ?? ""
        
        cell.didSelect = { index in
            self.arrViaCity?.remove(at: index)
            self.constraintHeightTVCoveredCity.constant = CGFloat((self.arrViaCity?.count ?? 0) * 35)
            self.tvCoveredCity.reloadData()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 35   //UITableView.automaticDimension
    }
}


// MARK: UICollectionView Delegate, DataSource, FlowLayout

extension AddExpensesVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrUploadImg?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddOrderUploadImgCVCell", for: indexPath) as! AddOrderUploadImgCVCell
        
        cell.index = indexPath.item
        cell.ivUploadImg.setImage(imageUrl: self.arrUploadImg?[indexPath.item].img ?? "")
        
        cell.txtComment.isHidden = true
        
        cell.onDeleteTap = { index in
            if !(self.arrUploadImg?[index].isNew ?? false) {
                self.arrDeleteImgId.append("\(self.arrUploadImg?[index].id ?? 0)")
            }
                
            self.arrImg.remove(at: index)
            self.arrUploadImg?.remove(at: index)
            
            if (self.arrUploadImg?.count ?? 0) <= 0 {
                self.constraintHeightCVUploadImg.constant = 0
            }
            self.cvUploadImg.reloadData()
            self.btnUploadImg.isHidden = false
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = 100.0   //(collectionView.frame.width - 40) / 3
        let height = 150.0
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
}
    

// MARK: - Selet Image

extension AddExpensesVC: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if isCameraClick && (info[.originalImage] is UIImage)
        {
            picker.dismiss(animated: true) {
                guard let image = info[.originalImage] as? UIImage else {
                    print("No image found")
                    return
                }
                self.ivCheckImg.image = image
            }
            
        }
        else if info[UIImagePickerController.InfoKey.originalImage] is UIImage
        {
            picker.dismiss(animated: true) {
                //let imageUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL
                //let imageUrl = info[.imageURL] as? URL
                let checkUrl: String = String(describing: info[.referenceURL] ?? "")
                let imgUrl: String = String(describing: info[.imageURL] ?? "")
                
                if !self.arrImg.contains(checkUrl) {
                    self.arrImg.append(checkUrl)
                    let temp = ImgUpload(img: imgUrl, comment: "", isNew: true)
                    self.arrUploadImg?.append(temp)
                }
                else {
                    Utilities.showPopup(title: "Please select different image.", type: .error)
                }
                DispatchQueue.main.async {
                    if self.arrImg.count > 0 {
                        self.constraintHeightCVUploadImg.constant = 170
                    }
                    self.cvUploadImg.reloadData()
                    
                    if self.arrImg.count > 4 {
                        self.btnUploadImg.isHidden = true
                    }
                }
                
                /*guard let image = info[.originalImage] as? UIImage else {
                    print("No image found")
                    return
                }
                self.ivCheckImg.image = image   //  */
            }
        }
    }
    
    func saveImageToPhotosAlbum(_ image: UIImage, info: [UIImagePickerController.InfoKey : Any]) {
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
        
        // Get the URL of the saved image
        if let url = info[.imageURL] as? URL {
            //urlLabel.text = url.absoluteString
        } else {
            print("Error getting image URL")
        }
    }
    
    // Helper method to save image data to a temporary directory and return the file URL
    func saveImageDataToTemporaryDirectory(imageData: Data) -> URL? {
        let tempDirectory = FileManager.default.temporaryDirectory
        let fileName = UUID().uuidString + ".jpg" // Generate a unique file name
        let fileURL = tempDirectory.appendingPathComponent(fileName)
        
        do {
            try imageData.write(to: fileURL)
            return fileURL
        } catch {
            print("Error saving image to temporary directory: \(error)")
            return nil
        }
    }
    
//    if let pickedImage = info[.originalImage] as? UIImage {
//        // You now have the selected or captured image (pickedImage).
//        // You can use it as needed within your app.
//        
//        self.dismiss(animated: true) {
//            let checkUrl: String = String(describing: info[.referenceURL] ?? "")
//            let imgUrl: String = String(describing: info[.imageURL] ?? "")
//            if !self.arrImg.contains(checkUrl) {
//                self.arrImg.append(checkUrl)
//                let temp = ImgUpload(img: imgUrl, comment: "")
//                self.arrUploadImg?.append(temp)
//            }
//            else {
//                Utilities.showPopup(title: "Please select different image.", type: .error)
//            }
//            DispatchQueue.main.async {
//                if self.arrImg.count > 0 {
//                    self.constraintHeightCVUploadImg.constant = 170
//                }
//                self.cvUploadImg.reloadData()
//                
//                if self.arrImg.count > 4 {
//                    self.btnUploadImg.isHidden = true
//                }
//            }
//        }
//    }
}



// MARK: - Keyboard

extension AddExpensesVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomViewScrollOutToSuper.constant = keyboardOverlap > 0 ? (keyboardOverlap - 0) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}

    

// MARK: - Web Servicess

extension AddExpensesVC {
    
    func checkExpenseDate(eDate: String, isToDate: Bool = false) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.checkExpenseDate(eDate: eDate, isToDate: isToDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "expense_date": eDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CHECK_EXPENSES_DATE, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    if response?.result?.dateValid ?? 0 == 0 {
                        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
                        popupVC.modalPresentationStyle = .overCurrentContext
                        popupVC.modalTransitionStyle = .crossDissolve
                        popupVC.titleTxt = "Alert"
                        popupVC.strImgName = "InfoWLightRed"
                        popupVC.strMessage = response?.message ?? ""
                        popupVC.onTapOk = { str in
                            if !isToDate {
                                self.lblExpensesDate.text = "Select Date"
                                self.strExpensesDate = ""
                                self.lblExpensesDate.textColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                            }
                            else {
                                self.lblToDate.text = "To Date"
                                self.strToDate = ""
                                self.lblToDate.textColor = UIColor(hexString: "#A1A1A1", alpha: 1.0)
                            }
                        }
                        self.present(popupVC, animated: true)
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func addExpense(isDraft: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addExpense(isDraft: isDraft)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "designation": APIManager.sharedManager.userDetail?.designationId ?? 0,
            "category": self.strSelectedCategory,
            "spent_at": self.txtSpentAt.text ?? "",
            "city_name": self.txtCityName.text ?? "",
            "title": "",
            "payment_mode": self.lblPaymentMode.text ?? "",
            "expense_date": self.strExpensesDate,
            "amount": self.txtAmount.text ?? "",
            "is_draft": isDraft,
            "expense_type": self.strSelectedOption,
            "city_category": self.lblCityType.text ?? "",
            "travel_mode_id": self.intTravelModeId,
            "travel_from": self.txtFromCityName.text ?? "",
            "travel_to": self.txtToCityName.text ?? "",
            "travel_via": (self.arrViaCity ?? []).joined(separator: ","),
            "distance": self.txtDistance.text ?? "",
            "remarks": self.txtRemarks.text ?? "",
            "is_violated": 0,    //  Need to change this.
            "id": self.intEditExpenseId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_EXPENSES, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //self.popupWImg(message: response?.message ?? "")
                    if self.isFromEdit && ((self.arrDeleteImgId.count) > 0) {
                        self.remvoeExpenseAttachment()
                    }
                    
                    if (self.arrUploadImg?.count ?? 0) > 0 {
                        self.showLoadingWMsg(strMsg: "Uploading image...")
                        
                        let tempImgObj = self.arrUploadImg?.compactMap { item -> String? in
                            guard let imgUrl = item.img,
                                  let isNew = item.isNew,
                                  isNew == true else { return nil }
                            return imgUrl
                        }   //  */
                        
                        //let tempImgObj = self.arrUploadImg?.filter { $0.isNew == true }
                        
                        if (tempImgObj?.count ?? 0) > 0 {
                            self.uploadImage(id: response?.result?.expenseId ?? 0, strMessage: response?.message ?? "", arrUploadImg: tempImgObj ?? [])
                        }
                        else {
                            self.popupWImg(message: response?.message ?? "")
                        }
                    }
                    else {
                        self.popupWImg(message: response?.message ?? "")
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func uploadImage(id: Int, index: Int = 0, strMessage: String, arrUploadImg: [String]?) {
        var imgFileName: String = ""
        imgFileName = imgFileName == "" ? (URL(string: arrUploadImg?[index] ?? "")?.lastPathComponent)! : imgFileName
        imgFileName = imgFileName != "" ? imgFileName : "\(Utilities.fileName()).png"
        let ivUploadImg = UIImageView()
        ivUploadImg.setImage(imageUrl: arrUploadImg?[index] ?? "")
        
        //showLoading()
        APIManager.sharedManager.uploadImage(url: APIManager.sharedManager.UPLOAD_EXPENSE_ATTACHMENT,
                                             dictiParam: [ "user_id": APIManager.sharedManager.userId,
                                                           "expense_id": id,
                                                           "image": imgFileName
                                                         ],
                                             image: ivUploadImg.image as Any,
                                             type: "image",
                                             contentType: imgFileName.mimeType())
        { isValid, strValue in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                //self.hideLoading()
                if ((arrUploadImg?.count ?? 0) - 1) > index {
                    let i = index + 1
                    self.uploadImage(id: id, index: i, strMessage: strMessage, arrUploadImg: arrUploadImg)
                }
                else {
                    DispatchQueue.main.async {
                        self.hideLoadingWMsg()
                        self.popupWImg(message: strMessage)
                    }
                }
            }
        } errorCompletion: { isValid, strValue in
            print("Close with error")
            self.hideLoadingWMsg()
            //self.hideLoading()
        }
    }
    
    func remvoeExpenseAttachment() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.remvoeExpenseAttachment()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "deleted_ids": self.arrDeleteImgId.joined(separator: ",")
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.REMOVE_EXPENSE_ATTACHMENT, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //self.popupWImg(message: response?.message ?? "")s
                    /*if (self.arrUploadImg?.count ?? 0) > 0 {
                        self.showLoadingWMsg(strMsg: "Uploading image...")
                        
                        let tempImgObj = self.arrUploadImg?.compactMap { item -> String? in
                            guard let imgUrl = item.img,
                                  let isNew = item.isNew,
                                  isNew else { return nil }
                            return imgUrl
                        }
                        
                        let tempImgObj = self.arrUploadImg?.filter { $0.isNew == true }
                        self.uploadImage(id: response?.result?.expenseId ?? 0, strMessage: response?.message ?? "", arrUploadImg: tempImgObj ?? [])
                    }
                    else {
                        self.popupWImg(message: response?.message ?? "")
                    }   /// */
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func popupWImg(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.navigationController?.popViewController(animated: true)
        }
        self.present(popupVC, animated: true)
    }
}
