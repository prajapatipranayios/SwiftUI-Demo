//
//  ExpensesDetailsVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/09/24.
//

import UIKit

class ExpensesDetailsVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
//        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
//        popupVC.titleTxt = Title.ConfirmationPopupTitle
//        popupVC.modalPresentationStyle = .overCurrentContext
//        popupVC.modalTransitionStyle = .crossDissolve
//        popupVC.strMessage = "Are you sure to discard DVR details?"
//        popupVC.colorTitleText = .black
//        popupVC.colorBtnYesText = Colors.theme.returnColor()
//        popupVC.colorBtnNoText = Colors.theme.returnColor()
//        popupVC.onYesTap = { ans in
//            self.navigationController?.popViewController(animated: true)
//        }
//        popupVC.onNoTap = { ans in
//        }
//        self.present(popupVC, animated: true)
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var viewScrollMOut: UIView!
    @IBOutlet weak var constraintBottomViewScrollMOutSuper: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIView!
    @IBOutlet weak var viewScrollMIn: UIView!
    
    @IBOutlet weak var tvExpenseDetail: UITableView! {
        didSet {
            self.tvExpenseDetail.delegate = self
            self.tvExpenseDetail.dataSource = self
            self.tvExpenseDetail.register(UINib(nibName: "ExpensesDetailsTVCell", bundle: nil), forCellReuseIdentifier: "ExpensesDetailsTVCell")
        }
    }
    
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Expenses Details"
    
    var expenseId: Int? = 0
    var intClub: Int? = 0
    
    var arrExpensesDetails: [UserExpenseListDetails]? = []
    
    var isBtnViewHistoryTap: Bool = false
    
    
    var isFromEdit: Bool = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.getExpenseDetail(id: self.expenseId ?? 0, isClub: self.intClub ?? 0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if self.isFromEdit {
            self.navigationController?.popViewController(animated: false)
        }
    }
    
}
