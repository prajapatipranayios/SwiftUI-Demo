//
//  ExpensesDetailsVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/09/24.
//

import Foundation
import UIKit


// MARK: - UITableview Delegate, DataSources

extension ExpensesDetailsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrExpensesDetails?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExpensesDetailsTVCell", for: indexPath) as! ExpensesDetailsTVCell
        
        cell.lblCategory.text = self.arrExpensesDetails?[indexPath.row].category ?? ""
        
        var code: String = "E"
        if self.intClub == 1 {
            code = "C"
        }
        cell.lblENo.text = code + (self.arrExpensesDetails?[indexPath.row].expenseCode ?? "")
        
        var strEType = ""
        if self.arrExpensesDetails?[indexPath.row].expenseType ?? "" == "HQ" {
            strEType = "Head Quarter"
        }
        else if self.arrExpensesDetails?[indexPath.row].expenseType ?? "" == "OS" {
            strEType = "Out Station"
        }
        cell.lblEType.text = strEType
        
        cell.lblESpentAt.text = self.arrExpensesDetails?[indexPath.row].spentAt ?? ""
        cell.lblECityName.text = self.arrExpensesDetails?[indexPath.row].cityName ?? ""
        
        cell.lblETravelModeNDistance.text = "\(self.arrExpensesDetails?[indexPath.row].travelMode ?? "") \(self.arrExpensesDetails?[indexPath.row].distance ?? 0) km"
        cell.lblETravelCity.text = (self.arrExpensesDetails?[indexPath.row].travelFrom ?? "") + " To " + (self.arrExpensesDetails?[indexPath.row].travelTo ?? "")
        cell.lblETravelVia.text = self.arrExpensesDetails?[indexPath.row].travelVia ?? ""
        
        cell.constraintHeightViewESpentAt.priority = .defaultLow
        cell.constraintHeightViewECityName.priority = .defaultLow
        
        cell.constraintHeightViewETravelModeNDistance.priority = .required
        cell.constraintHeightViewETravelCity.priority = .required
        cell.constraintHeightViewETravelVia.priority = .required
        
        if self.arrExpensesDetails?[indexPath.row].isTravel ?? 0 == 1 {
            cell.constraintHeightViewESpentAt.priority = .required
            cell.constraintHeightViewECityName.priority = .required
            
            cell.constraintHeightViewETravelModeNDistance.priority = .defaultLow
            cell.constraintHeightViewETravelCity.priority = .defaultLow
            cell.constraintHeightViewETravelVia.priority = .defaultLow
        }
        
        cell.lblERemark.text = self.arrExpensesDetails?[indexPath.row].remarks ?? ""
        cell.constraintHeightViewERemark.priority = .defaultLow
        if self.arrExpensesDetails?[indexPath.row].remarks ?? "" == "" {
            cell.constraintHeightViewERemark.priority = .required
        }
        
        var isBtnInvoiceVisible: Bool = true
        if self.arrExpensesDetails?[indexPath.row].expenseAttachment?.count ?? 0 == 0 {
            //Invoices hide
            cell.btnInvoices.isHidden = true
            isBtnInvoiceVisible = false
        }
        
        cell.btnViewHistory.isHidden = false
        if self.arrExpensesDetails?[indexPath.row].statusHistory?.count ?? 0 == 0 {
            //View History hide
            cell.btnViewHistory.isHidden = true
        }
        else {
            cell.arrCVStatusHistory = self.arrExpensesDetails?[indexPath.row].statusHistory ?? []
        }
        
        cell.constraintLeadingViewHistoryToSuper.priority = .defaultLow
        if !isBtnInvoiceVisible {
            cell.constraintLeadingViewHistoryToSuper.priority = .required
        }
        
        
        cell.lblEDate.text = self.arrExpensesDetails?[indexPath.row].expenseDate ?? ""
        var strStatus: String = ""
        var statusColor: UIColor = .black
        (strStatus, statusColor) = Expenses.getStatusNameColor(status: self.arrExpensesDetails?[indexPath.row].status ?? 0)
        cell.lblEStatus.text = strStatus
        cell.lblEStatus.textColor = statusColor
        
        var designation: String = "By "
        if (self.arrExpensesDetails?[indexPath.row].statusByDesignation ?? "") == "" {
            designation = ""
        }
        cell.lblEDesignation.text = designation + (self.arrExpensesDetails?[indexPath.row].statusByDesignation ?? "")
        
        cell.lblEAmount.text = "₹"+(self.arrExpensesDetails?[indexPath.row].amount ?? "".curFormatAsRegion())
        
        var paymentMode: String = self.arrExpensesDetails?[indexPath.row].paymentMode ?? ""
        if paymentMode != "" {
            paymentMode = "(\(paymentMode))"
        }
        cell.lblECashMode.text = paymentMode
        
        cell.lblEReductionAmount.text = "₹"+(self.arrExpensesDetails?[indexPath.row].reductionAmount ?? "".curFormatAsRegion())
        cell.lblEReductionAmountHR.text = "₹"+(self.arrExpensesDetails?[indexPath.row].reductionAmountHr ?? "".curFormatAsRegion())
        
        
        if (self.arrExpensesDetails?[indexPath.row].reductionAmount ?? "" == "0.0") || (self.arrExpensesDetails?[indexPath.row].reductionAmount ?? "" == "0.00") {
            cell.constraintHeightViewReductionAmount.priority = .required
        }
        else {
            cell.lblEAmount.textColor = Colors.themeRed.returnColor()
            cell.lblEReductionAmount.textColor = Colors.themeGreen.returnColor()
            cell.constraintHeightViewReductionAmount.priority = .defaultLow
        }
        
        if (self.arrExpensesDetails?[indexPath.row].reductionAmountHr ?? "" == "0.0") || (self.arrExpensesDetails?[indexPath.row].reductionAmountHr ?? "" == "0.00") {
            cell.constraintHeightViewReductionAmountHR.priority = .required
        }
        else {
            cell.constraintHeightViewReductionAmountHR.priority = .defaultLow
            cell.lblEAmount.textColor = Colors.themeRed.returnColor()
            cell.lblEReductionAmountHR.textColor = Colors.themeGreen.returnColor()
        }
            
        if APIManager.sharedManager.userId == self.arrExpensesDetails?[indexPath.row].userID ?? 0 {
            if self.arrExpensesDetails?[indexPath.row].status ?? 0 == 1 {
                // edit btn visible
                cell.btnEdit.isHidden = false
            }
            else if self.arrExpensesDetails?[indexPath.row].status ?? 0 == 0 {
                if self.arrExpensesDetails?[indexPath.row].isDraft ?? 0 == 1 {
                    // edit visible
                    cell.btnEdit.isHidden = false
                }
                else {
                    // edit btn hide
                    cell.btnEdit.isHidden = true
                }
            }
            else {
                // edit btn hide
                cell.btnEdit.isHidden = true
            }
        }
        else {
            // edit btn hide
            cell.btnEdit.isHidden = true
        }
        
        if self.arrExpensesDetails?[indexPath.row].toDate ?? "" != "" {
            cell.lblEDate.text = (self.arrExpensesDetails?[indexPath.row].expenseDate ?? "") + " to " + (self.arrExpensesDetails?[indexPath.row].toDate ?? "")
        }
        
        cell.lblEViolated.isHidden = true
        if self.arrExpensesDetails?[indexPath.row].isViolated ?? 0 == 1 {
            cell.lblEViolated.isHidden = false
        }
        
        cell.onInvoiceTap = { index in
            self.displayInvoice(expenseObj: self.arrExpensesDetails?[index])
        }
        
        cell.onViewHistoryTap = { index in
            self.isBtnViewHistoryTap = !self.isBtnViewHistoryTap
            self.tvExpenseDetail.reloadData()
        }
        
        cell.onEditTap = { index in
            self.editExpense(expenseObj: self.arrExpensesDetails?[index])
        }
        
        if self.isBtnViewHistoryTap {
            cell.arrStatusHistory = self.arrExpensesDetails?[indexPath.row].statusHistory ?? []
        }
        else {
            cell.arrStatusHistory = []
        }
        
        return cell
    }
    
    func displayInvoice(expenseObj: UserExpenseListDetails?) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ExpenseViewInvoicesVC") as! ExpenseViewInvoicesVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.arrExpenseAttachment = expenseObj?.expenseAttachment ?? []
        self.present(popupVC, animated: true)
    }
    
    func editExpense(expenseObj: UserExpenseListDetails?) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(identifier: "AddExpensesVC") as! AddExpensesVC
        viewController.isFromEdit = true
        viewController.editExpenseObj = expenseObj
        self.isFromEdit = true
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}


// MARK: - Web Service

extension ExpensesDetailsVC {
    
    func getExpenseDetail(id: Int, isClub: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getExpenseDetail(id: id, isClub: isClub)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "id": id,
            "is_club": isClub
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EXPENSE_DETAILS, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrExpensesDetails = response?.result?.expenses ?? []
                    //self.setExpenseDetail(expenseDetail: self.arrExpensesDetails?.first)
                    self.tvExpenseDetail.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
}
