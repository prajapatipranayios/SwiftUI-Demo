//
//  ExpensesDetailsTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 06/09/24.
//

import UIKit

class ExpensesDetailsTVCell: UITableViewCell {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewEDetail: UIView!
    
    @IBOutlet weak var lblCategory: UILabel!
    
    @IBOutlet weak var viewENo: UIView!
    @IBOutlet weak var lblENoTitle: UILabel!
    @IBOutlet weak var lblENo: UILabel!
    
    @IBOutlet weak var viewEType: UIView!
    @IBOutlet weak var lblETypeTitle: UILabel!
    @IBOutlet weak var lblEType: UILabel!
    
    @IBOutlet weak var viewESpentAt: UIView!
    @IBOutlet weak var constraintHeightViewESpentAt: NSLayoutConstraint!
    @IBOutlet weak var lblESpentAtTitle: UILabel!
    @IBOutlet weak var lblESpentAt: UILabel!
    
    @IBOutlet weak var viewECityName: UIView!
    @IBOutlet weak var constraintHeightViewECityName: NSLayoutConstraint!
    @IBOutlet weak var lblECityName: UILabel!
    
    @IBOutlet weak var viewETravelModeNDistance: UIView!
    @IBOutlet weak var constraintHeightViewETravelModeNDistance: NSLayoutConstraint!
    @IBOutlet weak var lblETravelModeNDistance: UILabel!
    
    @IBOutlet weak var viewETravelCity: UIView!
    @IBOutlet weak var constraintHeightViewETravelCity: NSLayoutConstraint!
    @IBOutlet weak var lblETravelCity: UILabel!
    
    @IBOutlet weak var viewETravelVia: UIView!
    @IBOutlet weak var constraintHeightViewETravelVia: NSLayoutConstraint!
    @IBOutlet weak var lblETravelVia: UILabel!
    
    @IBOutlet weak var viewERemark: UIView!
    @IBOutlet weak var constraintHeightViewERemark: NSLayoutConstraint!
    @IBOutlet weak var lblERemarkTitle: UILabel!
    @IBOutlet weak var lblERemark: UILabel!
    
    
    
    
    @IBOutlet weak var lblEDate: UILabel!
    
    @IBOutlet weak var lblEStatus: UILabel!
    @IBOutlet weak var lblEDesignation: UILabel!
    
    @IBOutlet weak var viewEAmount: UIView!
    @IBOutlet weak var constraintHeightViewEAmount: NSLayoutConstraint!
    @IBOutlet weak var lblEAmount: UILabel!
    @IBOutlet weak var lblECashMode: UILabel!
    
    @IBOutlet weak var viewEReductionAmount: UIView!
    @IBOutlet weak var constraintHeightViewReductionAmount: NSLayoutConstraint!
    @IBOutlet weak var lblEReductionAmount: UILabel!
    
    @IBOutlet weak var viewEReductionAmountHR: UIView!
    @IBOutlet weak var constraintHeightViewReductionAmountHR: NSLayoutConstraint!
    @IBOutlet weak var lblEReductionAmountHR: UILabel!
    
    @IBOutlet weak var viewEViolated: UIView!
    @IBOutlet weak var lblEViolated: UILabel!
    
    
    @IBOutlet weak var viewStatusBar: UIView!
    @IBOutlet weak var constraintHeightViewStatusBar: NSLayoutConstraint!
    @IBOutlet weak var cvExpenseStatus: UICollectionView! {
        didSet {
            self.cvExpenseStatus.delegate = self
            self.cvExpenseStatus.dataSource = self
            self.cvExpenseStatus.register(UINib(nibName: "ExpenseStatusCVCell", bundle: nil), forCellWithReuseIdentifier: "ExpenseStatusCVCell")
        }
    }
    
    
    
    @IBOutlet weak var viewButtons: UIView!
    @IBOutlet weak var constraintHeightViewButtons: NSLayoutConstraint!
    
    @IBOutlet weak var btnInvoices: UIButton!
    @IBAction func btnInvoicesTap(_ sender: UIButton) {
        if self.onInvoiceTap != nil {
            self.onInvoiceTap!(index)
        }
    }
    
    @IBOutlet weak var btnViewHistory: UIButton!
    @IBAction func btnViewHistoryTap(_ sender: UIButton) {
        if self.onViewHistoryTap != nil {
            self.onViewHistoryTap!(index)
        }
    }
    @IBOutlet weak var constraintLeadingViewHistoryToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var btnEdit: UIButton!
    @IBAction func btnEditTap(_ sender: UIButton) {
        if self.onEditTap != nil {
            self.onEditTap!(index)
        }
    }
    
    @IBOutlet weak var viewTVStatus: UIView!
    @IBOutlet weak var tvStatus: UITableView! {
        didSet {
            self.tvStatus.delegate = self
            self.tvStatus.dataSource = self
            self.tvStatus.register(UINib(nibName: "ExpenseStatusTVCell", bundle: nil), forCellReuseIdentifier: "ExpenseStatusTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVStatus: NSLayoutConstraint!
    
    
    
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onInvoiceTap:((Int)->Void)?
    var onViewHistoryTap:((Int)->Void)?
    var onEditTap:((Int)->Void)?
    
    
    var arrCVStatusHistory: [StatusHistory]? {
        didSet {
            self.constraintHeightViewStatusBar.constant = 50
            self.cvExpenseStatus.reloadData()
        }
    }
    
    var arrStatusHistory: [StatusHistory]? {
        didSet {
            self.constraintHeightTVStatus.constant = CGFloat(70 * (self.arrStatusHistory?.count ?? 0))
            self.tvStatus.reloadData()
        }
    }
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.constraintHeightViewStatusBar.constant = 0
        self.constraintHeightTVStatus.constant = 0
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    

}


// MARK: - UITableView DataSource, Delegate

extension ExpensesDetailsTVCell: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrStatusHistory?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //DvrDetailClientProductTVCell
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExpenseStatusTVCell", for: indexPath) as! ExpenseStatusTVCell
        
        if indexPath.row == 0 {
            cell.lblDateTitle.text = "Expenses Date :"
        }
        else {
            cell.lblDateTitle.text = "Status Changed Date :"
        }
        
        cell.lblDate.text = self.arrStatusHistory?[indexPath.row].statusDate ?? ""
        
        var strStatus: String = ""
        var statusColor: UIColor = .black
        (strStatus, statusColor) = Expenses.getStatusNameColor(status: Int(self.arrStatusHistory?[indexPath.row].status ?? "") ?? 0)
        var strDesignation: String = ""
        if self.arrStatusHistory?[indexPath.row].statusByDesignation ?? "" != "" {
            strDesignation = "By \(self.arrStatusHistory?[indexPath.row].statusByDesignation ?? "")"
        }
        cell.lblStatus.attributedText = "\(strStatus) \(strDesignation)".setColorToString(strValue: [strStatus], color: [statusColor], fontSize: 17.0)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
}


extension ExpensesDetailsTVCell {
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            let changedTableView = object as? UITableView
            
            if changedTableView == self.tvStatus {
                if let newvalue = change?[.newKey] {
                    let newsize  = newvalue as! CGSize
                    self.constraintHeightTVStatus.constant = newsize.height
                }
            }
        }
    }
}


// MARK: - UICollectionView Delegate, DataSource

extension ExpensesDetailsTVCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrCVStatusHistory?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ExpenseStatusCVCell", for: indexPath) as! ExpenseStatusCVCell
        
        var strStatus: String = ""
        var statusColor: UIColor = .black
        (strStatus, statusColor) = Expenses.getStatusNameColor(status: Int(self.arrCVStatusHistory?[indexPath.item].status ?? "") ?? 0)
        
        cell.lblStatus.text = strStatus
        cell.lblLeftLine.isHidden = false
        cell.ivProgress.image = UIImage(systemName: "circle")
        
        if indexPath.item == 0 {
            cell.lblLeftLine.isHidden = true
        }
        
        if indexPath.row == (self.arrCVStatusHistory?.count ?? 0) - 1 {
            cell.lblRighttLine.isHidden = true
            cell.ivProgress.image = UIImage(systemName: "circle.inset.filled")
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = 65.0
        let height = 50.0
        return CGSize(width: width, height: height)
    }
}
