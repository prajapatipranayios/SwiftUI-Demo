//
//  ExpenseStatusCVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 06/09/24.
//

import UIKit

class ExpenseStatusCVCell: UICollectionViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var ivProgress: UIImageView!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblLeftLine: UILabel!
    @IBOutlet weak var lblRighttLine: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        //circle
        //circle.inset.filled
    }

}
