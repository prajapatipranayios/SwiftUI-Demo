//
//  ExpenseViewInvoicesVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 11/09/24.
//

import UIKit

class ExpenseViewInvoicesVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        //self.navigationController?.popViewController(animated: true)
        self.dismiss(animated: true)
    }
    
    @IBOutlet weak var viewScrollMOut: UIView!
    @IBOutlet weak var constraintBottomViewScrollMOutSuper: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIView!
    @IBOutlet weak var viewScrollMIn: UIView!
    
    @IBOutlet weak var viewTVExpenseAttachment: UIView!
    @IBOutlet weak var tvExpenseAttachment: UITableView! {
        didSet {
            self.tvExpenseAttachment.delegate = self
            self.tvExpenseAttachment.dataSource = self
            self.tvExpenseAttachment.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        }
    }
    
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "View Invoices"
    
    var arrExpenseAttachment: [ExpenseAttachment]?
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
}


// MARK: - UITableview Delegate, DataSources

extension ExpenseViewInvoicesVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrExpenseAttachment?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        // Load image and update cell directly
        let imgUrl = self.arrExpenseAttachment?[indexPath.row].attachment ?? ""
        DispatchQueue.global(qos: .background).async { [weak self] in
            DispatchQueue.main.async {
                let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: (self?.viewMain.frame.width)!, height: (self?.viewMain.frame.width)! - 10))
                imageView.contentMode = .scaleAspectFit
                imageView.setImage(imageUrl: imgUrl)
                cell.addSubview(imageView)
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.viewMain.frame.width
    }
    
}
