//
//  ExpensesDetailsTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 04/09/24.
//

import UIKit

class ExpensesListTVCell: UITableViewCell {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewExpensesDate: UIView!
    @IBOutlet weak var lblExpensesSeparator: UILabel!
    @IBOutlet weak var lblExpensesDate: UILabel!
    
    
    @IBOutlet weak var viewExpensesStatusAmount: UIView!
    @IBOutlet weak var lblSeparatorTop: UILabel!
    @IBOutlet weak var lblExpensesStatusColor: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    @IBOutlet weak var lblExpensesAmount: UILabel!
    @IBOutlet weak var lblExpensesName: UILabel!
    @IBOutlet weak var lblExpensesStatus: UILabel!
    @IBOutlet weak var lblExpensesViolated: UILabel!
    @IBOutlet weak var lblSeparatorBottom: UILabel!
    @IBOutlet weak var constraintTopViewExpensesStatusAmountsToSuper: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewOptionSelect: UIView!
    @IBOutlet weak var constraintWidthViewOptionSelect: NSLayoutConstraint!
    
    @IBOutlet weak var btnSelect: UIButton!
    @IBAction func btnSelectTap(_ sender: UIButton) {
        if self.onOptionSelectTap != nil {
            self.onOptionSelectTap!(index)
        }
    }
    
    @IBOutlet weak var btnSubmit: UIButton!
    @IBAction func btnSubmitTap(_ sender: UIButton) {
        if self.onSubmitTap != nil {
            self.onSubmitTap!(index)
        }
    }
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onOptionSelectTap:((Int)->Void)?
    var onSubmitTap:((Int)->Void)?
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.constraintTopViewExpensesStatusAmountsToSuper.priority = .required
        self.lblExpensesViolated.textColor = .red
        
        self.btnSubmit.corners(radius: self.btnSubmit.frame.height / 2)
        self.btnSubmit.setTitleColor(.white, for: .normal)
        self.btnSubmit.backgroundColor = Colors.theme.returnColor()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
