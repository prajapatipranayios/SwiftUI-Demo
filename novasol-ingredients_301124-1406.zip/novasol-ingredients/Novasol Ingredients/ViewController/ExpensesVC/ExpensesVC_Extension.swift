//
//  ExpensesVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 04/09/24.
//

import Foundation
import UIKit


// MARK: - UITableview Delegate, DataSources

extension ExpensesVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.arrExpensesUsers?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "TVDvrListHFView") as! TVDvrListHFView
        //headerView.viewMain.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
        if section == 0 {
            headerView.lblSeparatorTop.isHidden = false
            headerView.lblSeparatorBottom.isHidden = false
        }
        else {
            headerView.lblSeparatorTop.isHidden = true
            headerView.lblSeparatorBottom.isHidden = false
        }
        headerView.lblSeparatorTop.backgroundColor = UIColor(hexString: "#A1A1A1")
        headerView.lblSeparatorBottom.backgroundColor = UIColor(hexString: "#A1A1A1")
        headerView.lblName.text = "\(self.arrExpensesUsers?[section].firstname ?? "") \(self.arrExpensesUsers?[section].lastname ?? "")"
        headerView.lblDate.text = "\(self.arrExpensesUsers?[section].startDateShow ?? "") to \(self.arrExpensesUsers?[section].endDateShow ?? "")"
        
        let imgName: String = self.intSelectedSection == section ? "chevron.up" : "chevron.down"
        headerView.ivArrow.image = UIImage(systemName: imgName)
        
        headerView.btnExpand.tag = section
        headerView.btnExpand.addTarget(self, action: #selector(self.btnHeaderExpandTap), for: .touchUpInside)
        
        if (self.intSelectedSection == section) && self.isApproveDeleteApiCall {
            let btnClick = UIButton()
            btnClick.tag = self.intSelectedSection
            self.btnHeaderExpandTap(btnClick)
        }
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 42
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.intSelectedSection == section {
            return self.arrExpensesUsersDetails?.count ?? 0
        }
        else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExpensesListTVCell", for: indexPath) as! ExpensesListTVCell
        
        cell.index = indexPath.row
        cell.lblExpensesDate.text = self.arrExpensesUsersDetails?[indexPath.row].requestDate ?? ""
        cell.lblCode.textColor = Colors.gray.returnColor()
        
        var status: String = ""
        var statusColor: UIColor = .clear
        (status, statusColor) = Expenses.getStatusNameColor(status: self.arrExpensesUsersDetails?[indexPath.row].status ?? 0)
        cell.lblExpensesStatusColor.backgroundColor = statusColor
        cell.lblCode.text = self.arrExpensesUsersDetails?[indexPath.row].code ?? ""
        cell.lblExpensesAmount.text = "₹" + (self.arrExpensesUsersDetails?[indexPath.row].amount ?? "").curFormatAsRegion()
        cell.lblExpensesAmount.textColor = Colors.theme.returnColor()
        
        cell.lblExpensesName.text = (self.arrExpensesUsersDetails?[indexPath.row].title ?? "").capitalized
        cell.lblExpensesName.textColor = Colors.theme.returnColor()
        cell.lblExpensesStatus.text = status
        cell.lblExpensesStatus.textColor = statusColor
        
        cell.lblExpensesStatusColor.text = "E"
        if self.arrExpensesUsersDetails?[indexPath.row].isClub ?? 0 == 1 {
            cell.lblExpensesStatusColor.text = "C"
        }
        
        cell.lblExpensesViolated.isHidden = true
        if self.arrExpensesUsersDetails?[indexPath.row].isViolated ?? 0 == 1 {
            cell.lblExpensesViolated.isHidden = false
        }
        
        cell.constraintTopViewExpensesStatusAmountsToSuper.priority = .defaultLow
        if indexPath.row > 0 {
            if (self.arrExpensesUsersDetails?[indexPath.row].requestDate ?? "") == (self.arrExpensesUsersDetails?[indexPath.row - 1].requestDate ?? "") {
                cell.constraintTopViewExpensesStatusAmountsToSuper.priority = .required
            }
        }
        
        cell.btnSubmit.isHidden = true
        cell.constraintWidthViewOptionSelect.constant = 0
        if self.arrExpensesUsersDetails?[indexPath.row].isDraft ?? 0 == 1 {
            cell.btnSubmit.isHidden = false
            cell.constraintWidthViewOptionSelect.constant = 33
        }
        
        cell.btnSelect.isSelected = false
        if self.arrIntSelectIdForClub.contains(self.arrExpensesUsersDetails?[indexPath.row].id ?? 0) {
            cell.btnSelect.isSelected = true
        }
        
        cell.onOptionSelectTap = { index in
            if self.arrIntSelectIdForClub.contains(self.arrExpensesUsersDetails?[indexPath.row].id ?? 0) {
                for i in 0..<self.arrIntSelectIdForClub.count {
                    if (self.arrExpensesUsersDetails?[indexPath.row].id ?? 0) == self.arrIntSelectIdForClub[i] {
                        self.arrIntSelectIdForClub.remove(at: i)
                        break
                    }
                }
            }
            else {
                self.arrIntSelectIdForClub.append(self.arrExpensesUsersDetails?[indexPath.row].id ?? 0)
            }
            
            self.constraintBottomViewTVExpensesList.priority = .required
            if self.arrIntSelectIdForClub.count > 1 {
                self.constraintBottomViewTVExpensesList.priority = .defaultLow
            }
            self.tvExpensesList.reloadData()
        }
        
        cell.onSubmitTap = { index in
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        var viewController = storyBoard.instantiateViewController(withIdentifier: "ExpensesDetailsVC") as! ExpensesDetailsVC
        viewController.expenseId = self.arrExpensesUsersDetails?[indexPath.row].id ?? 0
        viewController.intClub = self.arrExpensesUsersDetails?[indexPath.row].isClub ?? 0
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    @objc func btnHeaderExpandTap(_ sendar: UIButton) {
        if !self.isApproveDeleteApiCall {
            self.intSelectedSection = (self.intSelectedSection == sendar.tag) ? -1 : sendar.tag
        }
        self.isApproveDeleteApiCall = false
        
        if self.intSelectedSection > -1 {
            self.getExpenses(
                employeeId: self.arrExpensesUsers?[self.intSelectedSection].userID ?? 0,
                startDate: self.arrExpensesUsers?[self.intSelectedSection].startDate ?? "",
                endDate: self.arrExpensesUsers?[self.intSelectedSection].endDate ?? "",
                draft: ((self.arrExpensesUsers?[self.intSelectedSection].userID ?? 0) == APIManager.sharedManager.userId ? 0 : 1)
            )
        }
        else {
            self.arrExpensesUsersDetails?.removeAll()
            self.tvExpensesList.reloadData()
        }
    }
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let approve = UIContextualAction(style: .normal, title: "") { action, view, complete in
            self.isApproveDeleteApiCall = true
            //self.tvExpensesList.reloadData()
            self.updateExpenseStatus(
                statusByDesignation: APIManager.sharedManager.userDetail?.userDesignation ?? "",
                expenseId: self.arrExpensesUsersDetails?[indexPath.row].id ?? 0,
                status: 3,
                comment: "",
                isClub: self.arrExpensesUsersDetails?[indexPath.row].isClub ?? 0
            )
            complete(true)
        }
        let lblApprove = UILabel()
        lblApprove.text = "Approve"
        lblApprove.font = Fonts.Regular.returnFont(size: 20.0)
        lblApprove.sizeToFit()
        lblApprove.textColor = .white
        approve.image = Utilities.addLabelToImage(image: UIImage(named: "ApproveCircleW")!, label: lblApprove)
        approve.image?.withTintColor(.white)
        approve.backgroundColor = UIColor(hexString: "#5FA02E", alpha: 1.0)
        
        let delete = UIContextualAction(style: .normal, title: "") { action, view, complete in
            
            // Open popup for reason.
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupEnterReasonVC") as! PopupEnterReasonVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.strPopupTitle = "Reject Reason"
            popupVC.strBtnOkTitle = "DONE"
            popupVC.onTapOk = { strValue in
                self.isApproveDeleteApiCall = true
                //self.tvExpensesList.reloadData()
                self.updateExpenseStatus(
                    statusByDesignation: APIManager.sharedManager.userDetail?.userDesignation ?? "",
                    expenseId: self.arrExpensesUsersDetails?[indexPath.row].id ?? 0,
                    status: 1,
                    comment: strValue,
                    isClub: self.arrExpensesUsersDetails?[indexPath.row].isClub ?? 0
                )
            }
            popupVC.onTapClose = { strValue in
            }
            self.present(popupVC, animated: true, completion: nil)
            
            complete(true)
        }
        let lblDelete = UILabel()
        lblDelete.text = "Reject"
        lblDelete.font = Fonts.Regular.returnFont(size: 20.0)
        lblDelete.sizeToFit()
        lblDelete.textColor = .white
        
        delete.image = Utilities.addLabelToImage(image: UIImage(named: "DeleteCircleW")!, label: lblDelete)
        delete.backgroundColor = .red
        
        var isSwipe: Bool = false
        if APIManager.sharedManager.userId != self.arrExpensesUsersDetails?[indexPath.row].userID ?? 0 {
            if self.arrExpensesUsersDetails?[indexPath.row].status ?? 0 == 0 {
                if [3, 4, 11].contains(APIManager.sharedManager.userDetail?.roleId ?? 0) {
                    isSwipe = true
                }
            }
        }
        
        return isSwipe ? UISwipeActionsConfiguration(actions: [delete,approve]) : nil
    }
    
}


// MARK: - Web Service

extension ExpensesVC {
    
    func getExpensesUsers(startDate: String, endDate: String) {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getExpensesUsers(startDate: startDate, endDate: endDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "role_id": APIManager.sharedManager.userDetail?.roleId ?? 0,
            "start_date": startDate,
            "end_date": endDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EXPENSE_USERS, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrExpensesUsers = response?.result?.expense ?? []
                    self.tvExpensesList.reloadData()
                    
                    self.viewNoData.isHidden = true
                    if !(self.arrExpensesUsers?.count ?? 0 > 0) {
                        self.viewNoData.isHidden = false
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
                DispatchQueue.main.async {
                    self.arrExpensesUsersDetails?.removeAll()
                    self.intSelectedSection = -1
                    self.tvExpensesList.reloadData()
                }
            }
        }
    }
    
    func getExpenses(employeeId: Int, startDate: String, endDate: String, draft: Int) {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getExpenses(employeeId: employeeId, startDate: startDate, endDate: endDate, draft: draft)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "employee_id": employeeId,
            "start_date": startDate,
            "end_date": endDate,
            "isDraft": draft
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EXPENSES, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            self.arrExpensesUsersDetails?.removeAll()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrExpensesUsersDetails = response?.result?.expenses ?? []
                    self.tvExpensesList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func updateExpenseStatus(statusByDesignation: String, expenseId: Int, status: Int, comment: String, isClub: Int) {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.updateExpenseStatus(statusByDesignation: statusByDesignation, expenseId: expenseId, status: status, comment: comment, isClub: isClub)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "status_by_designation": statusByDesignation,
            "expense_id": expenseId,
            "status": status,
            "comment": comment,
            "is_club": isClub
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.UPDATE_EXPENSE_STATUS, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.tvExpensesList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func clubExpense(clubTitle: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.clubExpense(clubTitle: clubTitle)
                }
            }
            return
        }
        //{"user_id":85,"club_title":"Test Club","expenses":[{"id":2344},{"id":2345}]}
        
        var arrExpense: [[String: Any]] = []
        for value in self.arrIntSelectIdForClub.enumerated() {
            let tempObj = [
                "id": value.element
            ]
            arrExpense.append(tempObj)
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "club_title": clubTitle,
            "expenses": arrExpense
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CLUB_EXPENSE, parameters: param) { (response: ApiResponseExpenses?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.constraintBottomViewTVExpensesList.priority = .required
                    self.tvExpensesList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
}
