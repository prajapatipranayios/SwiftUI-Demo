//
//  ExpensesVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 04/09/24.
//

import UIKit

class ExpensesVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    
    
    @IBOutlet weak var btnAddExpenses: UIButton!
    @IBAction func btnAddExpensesTap(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "AddExpensesVC") as! AddExpensesVC
        self.navigationController?.pushViewController(viewController, animated: true)
        
        //self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var viewBody: UIView!
    @IBOutlet weak var viewMStartEndDate: UIView!
    @IBOutlet weak var viewSEDate: UIView!
    
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var btnStartDate: UIButton!
    @IBAction func btnStartDateTap(_ sender: UIButton) {
        self.lblStartDate.text = "Start Date"
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "yyyy-MM-dd"
        popupVC.isMaxDateLimit = false
        popupVC.didSelectDate = { date in
            self.lblStartDate.text = date
            self.strStartDate = date
        }
        popupVC.onClose = {
            self.lblStartDate.text = "Start Date"
            self.lblEndDate.text = "End Date"
            
            self.strStartDate = ""
            self.strEndDate = ""
            self.arrExpensesUsers?.removeAll()
            self.arrExpensesUsersDetails?.removeAll()
            self.intSelectedSection = -1
            
            self.getExpensesUsers(startDate: self.strStartDate, endDate: self.strEndDate)
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var btnEndDate: UIButton!
    @IBAction func btnEndDateTap(_ sender: UIButton) {
        if self.strStartDate != "" {
            self.lblEndDate.text = "End Date"
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.dateFormat = "yyyy-MM-dd"
            popupVC.minStartDate = lblStartDate.text!
            popupVC.isMaxDateLimit = false
            popupVC.didSelectDate = { date in
                self.lblEndDate.text = date
                self.strEndDate = date
                self.arrExpensesUsers?.removeAll()
                self.arrExpensesUsersDetails?.removeAll()
                self.intSelectedSection = -1
                
                self.getExpensesUsers(startDate: self.strStartDate, endDate: self.strEndDate)
            }
            popupVC.onClose = {
            }
            self.present(popupVC, animated: true, completion: nil)
        }
        else {
            Utilities.showPopup(title: "Please select start date.", type: .error)
        }
    }
    
    @IBOutlet weak var viewTVExpensesList: UIView!
    @IBOutlet weak var tvExpensesList: UITableView! {
        didSet {
            self.tvExpensesList.delegate = self
            self.tvExpensesList.dataSource = self
            self.tvExpensesList.register(UINib(nibName: "TVDvrListHFView", bundle: nil), forHeaderFooterViewReuseIdentifier: "TVDvrListHFView")
            self.tvExpensesList.register(UINib(nibName: "ExpensesListTVCell", bundle: nil), forCellReuseIdentifier: "ExpensesListTVCell")
            if #available(iOS 15.0, *) {
                self.tvExpensesList.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
    // View No Data
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblSeparator: UILabel!
    @IBOutlet weak var lblNoData: UILabel!
    
    @IBOutlet weak var btnClubAll: UIButton!
    @IBAction func btnClubAllTap(_ sender: UIButton) {
        // Open popup for reason.
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupEnterReasonVC") as! PopupEnterReasonVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strPopupTitle = "Club Title"
        popupVC.strBtnOkTitle = "DONE"
        popupVC.strTxtPlaceholder = "enter club title"
        popupVC.onTapOk = { strValue in
            self.isApproveDeleteApiCall = true
            self.clubExpense(clubTitle: strValue)
        }
        popupVC.onTapClose = { strValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var constraintBottomViewTVExpensesList: NSLayoutConstraint!
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Expenses"
    
    
    // Var
    
    var strStartDate: String = ""
    var strEndDate: String = ""
    
    var arrExpensesUsers: [UserExpenseListDetails]? = []
    var arrExpensesUsersDetails: [UserExpenseListDetails]? = []
    var intSelectedSection: Int = -1
    var isApproveDeleteApiCall: Bool = false
    
    var arrIntSelectIdForClub: [Int] = []
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.constraintBottomViewTVExpensesList.priority = .required
        
        self.btnClubAll.corners(radius: self.btnClubAll.frame.height / 2)
        
        self.getExpensesUsers(startDate: self.strStartDate, endDate: self.strEndDate)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
}
