//
//  TargetVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 18/09/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, DataSource

extension TargetVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView == self.tvEmpGrpTarget {
            if self.isEmpGrpTarget {
                return self.arrObjTVData?.count ?? 0
            }
            else if self.isEmpTarget {
                return self.arrZoneKeys.count
            }
            return 1
        }
        else if tableView == self.tvEmployeeTargetDetails {
            return self.arrEmpTargetDetails?.count ?? 0
        }
        return 0
    }
    
    // Customize the section header view
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if self.isEmpTarget || self.isEmpTargetDetails {
            
            if tableView == self.tvEmpGrpTarget {
                
                let headerView = UIView()
                headerView.backgroundColor = .systemBackground
                
                let label = UILabel()
                label.text = self.arrZoneKeys[section]
                label.textColor = Colors.theme.returnColor()
                label.textAlignment = .center
                label.font = Fonts.Bold.returnFont(size: 19) //UIFont.boldSystemFont(ofSize: 19)
                label.translatesAutoresizingMaskIntoConstraints = false
                
                headerView.addSubview(label)
                
                // Set constraints to center the label in the header
                NSLayoutConstraint.activate([
                    label.centerXAnchor.constraint(equalTo: headerView.centerXAnchor),
                    label.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
                    label.widthAnchor.constraint(equalTo: headerView.widthAnchor),
                    label.heightAnchor.constraint(equalToConstant: 30) // Adjust height as needed
                ])
                return headerView
            }
            else if tableView == self.tvEmployeeTargetDetails {
                
                let headerView = UIView()
                headerView.backgroundColor = .systemBackground
                
                let label = UILabel()
                label.text = self.arrEmpTargetDetails?[section].employeeData?.fullName ?? ""
                label.textColor = Colors.theme.returnColor()
                label.textAlignment = .center
                label.font = Fonts.Bold.returnFont(size: 25) //UIFont.boldSystemFont(ofSize: 19)
                label.translatesAutoresizingMaskIntoConstraints = false
                
                headerView.addSubview(label)
                
                // Set constraints to center the label in the header
                /*NSLayoutConstraint.activate([
                    // Set the leading constraint
                    label.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 32),
                    // Set the trailing constraint
                    label.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: 20),
                    // Set the top constraint
                    label.topAnchor.constraint(equalTo: headerView.topAnchor, constant: 20),
                    // Set the bottom constraint
                    label.bottomAnchor.constraint(equalTo: headerView.bottomAnchor, constant: 20)
                ])  ///  */
                
                /*NSLayoutConstraint.activate([
                    label.centerXAnchor.constraint(equalTo: headerView.centerXAnchor),
                    label.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
                    label.widthAnchor.constraint(equalTo: headerView.widthAnchor),
                    label.heightAnchor.constraint(equalToConstant: 30) // Adjust height as needed
                ])  //  */
                
                if (section > 0) && (self.arrEmpTargetDetails?[section].employeeData?.fullName ?? "") == (self.arrEmpTargetDetails?[section - 1].employeeData?.fullName ?? "") {
                    return nil
                }
                return headerView
            }
        }
        return nil
    }
    
    // Set the height for the section header
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == self.tvEmpGrpTarget {
            if self.isEmpTarget {
                return 45.0 // Adjust height as needed
            }
        }
        else if tableView == self.tvEmployeeTargetDetails {
            if self.isEmpTargetDetails {
                if section == 0 {
                    return 45.0 // Adjust height as needed
                }
            }
        }
        return 0
    }
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        if self.isEmpTarget {
//            return "Zone"
//        }
//        return ""
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.isEmpGrpTarget {
            return self.arrObjTVData?[section].data?.count ?? 0
        }
        else if self.isEmpTarget {
            return self.arrZoneEmpTarget?[self.arrZoneKeys[section]]?.count ?? 0
        }
        else if self.isEmpTargetDetails {
            return self.arrEmpTargetDetails?[section].data?.count ?? 0
        }
        return self.arrObjTVData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmpGrpTargetTVCell", for: indexPath) as! EmpGrpTargetTVCell
        
        cell.section = indexPath.section
        cell.index = indexPath.row
        
        var tempObjTarget: Target?
        
        cell.constraintHeightViewNameCategory.constant = 40
        cell.constraintHeightViewTitles.constant = 43
        cell.constraintBottomViewValuesToSuper.constant = 16
        
        if self.isEmpGrpTarget {
            
            cell.constraintLeadingViewTitlesToSuper.priority = .required
            
            tempObjTarget = Target.init(from: (self.arrObjTVData?[indexPath.section].data ?? [])[indexPath.row])
            
            cell.lblName.text = self.arrObjTVData?[indexPath.section].data?[indexPath.row].name ?? ""
            cell.lblCategory.text = self.arrObjTVData?[indexPath.section].data?[indexPath.row].categoryGroup ?? ""
            
            cell.viewNameCategory.backgroundColor = Colors.gray.returnColor()
            cell.ivArrowStatus.isHidden = true
        }
        else if self.isEmpTarget {
            
            cell.constraintLeadingViewTitlesToSuper.priority = .defaultLow
            
            tempObjTarget = self.arrZoneEmpTarget?[self.arrZoneKeys[indexPath.section]]?[indexPath.row]
            
            cell.lblName.text = tempObjTarget?.fullName ?? ""
            cell.lblCategory.text = ""
            
            cell.viewNameCategory.backgroundColor = .systemBackground
            
            cell.ivArrowStatus.isHidden = false
            //cell.ivArrowStatus.image = UIImage(systemName: "arrow.down")
            //cell.ivArrowStatus.tintColor = Colors.themeRed.returnColor()
            cell.ivArrowStatus.image = UIImage(systemName: "arrow.up")
            cell.ivArrowStatus.tintColor = Colors.themeGreen.returnColor()
            
            if tempObjTarget?.targetStatus ?? 0 == 0 {
                cell.ivArrowStatus.image = UIImage(systemName: "arrow.down")
                cell.ivArrowStatus.tintColor = Colors.themeRed.returnColor()
            }
        }
        else if self.isEmpTargetDetails {
            cell.constraintLeadingViewTitlesToSuper.priority = .defaultLow
            
            tempObjTarget = Target.init(from: (self.arrEmpTargetDetails?[indexPath.section].data ?? [])[indexPath.row])
            
            cell.lblName.text = self.arrEmpTargetDetails?[indexPath.section].employeeData?.monthYear ?? ""
            cell.lblCategory.text = ""
            
            cell.viewNameCategory.backgroundColor = .systemBackground
            
            cell.ivArrowStatus.isHidden = true
            
            if indexPath.row != 0 {
                cell.constraintHeightViewNameCategory.constant = 0
                cell.constraintHeightViewTitles.constant = 0
            }
            cell.constraintBottomViewValuesToSuper.constant = 0
            
        }
        
        cell.lblItemGrp.text = tempObjTarget?.name ?? ""
        
        cell.lblActualQty.text = "\(tempObjTarget?.unitTarget ?? 0.0)".curFormatAsRegion()
        cell.lblActualRupee.text = "\(tempObjTarget?.actualTarget ?? 0.0)".curFormatAsRegion()
        
        cell.lblAchievedQty.text = "\(tempObjTarget?.unitTargetAchieved ?? 0)".curFormatAsRegion()
        cell.lblAchievedRupee.text = "\(tempObjTarget?.achievedTarget ?? 0)".curFormatAsRegion()
        
        
        var achievedQtyPer = String("\(tempObjTarget?.unitPer ?? "")".dropLast())
        /*if achievedQtyPer.hasPrefix("+") {
         achievedQtyPer.removeFirst()
         }   //  */
        cell.lblAchievedQtyPer.text = achievedQtyPer
        
        var achievedRupeePer = String("\(tempObjTarget?.targetPer ?? "")".dropLast())
        /*if achievedRupeePer.hasPrefix("+") {
         achievedRupeePer.removeFirst()
         }   //  */
        cell.lblAchievedRupeePer.text = achievedRupeePer
        
        
        var remainingQty = 0
        
        if (tempObjTarget?.unitTarget ?? 0) <= (tempObjTarget?.unitTargetAchieved ?? 0) {
            remainingQty = Int((tempObjTarget?.unitTarget ?? 0.0) - (tempObjTarget?.unitTargetAchieved ?? 0.0))
        }
        else {
            remainingQty = Int((tempObjTarget?.unitTargetAchieved ?? 0.0) - (tempObjTarget?.unitTarget ?? 0.0))
        }
        
        cell.lblRemainingQty.text = "\(abs(remainingQty))".curFormatAsRegion()
        
        var remainingRupee = 0
        
        if (tempObjTarget?.actualTarget ?? 0.0) <= (tempObjTarget?.achievedTarget ?? 0.0) {
            remainingRupee = Int((tempObjTarget?.actualTarget ?? 0.0) - (tempObjTarget?.achievedTarget ?? 0.0))
        }
        else {
            remainingRupee = Int((tempObjTarget?.achievedTarget ?? 0.0) - (tempObjTarget?.actualTarget ?? 0.0))
        }
        
        cell.lblRemainingRupee.text = "\(abs(remainingRupee))".curFormatAsRegion()
        
        
        /*var remainingQtyPer = String("\(tempObjTarget?.unitRemaining ?? "")".dropLast())
         if remainingQtyPer.hasPrefix("+") {
         remainingQtyPer.removeFirst()
         }   //  */
        cell.lblRemainingQtyPer.text = String("\(tempObjTarget?.unitRemaining ?? "")".dropLast())
        
        /*var remainingRupeePer = String("\(tempObjTarget?.targetRemaining ?? "")".dropLast())
         if remainingRupeePer.hasPrefix("+") {
         remainingRupeePer.removeFirst()
         }   //  */
        cell.lblRemainingRupeePer.text = String("\(tempObjTarget?.targetRemaining ?? "")".dropLast())
        
        
        if (tempObjTarget?.unitTarget ?? 0) > (tempObjTarget?.unitTargetAchieved ?? 0) {
            
            cell.lblAchievedQty.textColor = Colors.themeRed.returnColor()
            cell.lblAchievedQtyPer.textColor = Colors.themeRed.returnColor()
            
            cell.lblRemainingQty.textColor = Colors.themeRed.returnColor()
            cell.lblRemainingQtyPer.textColor = Colors.themeRed.returnColor()
        }
        else {
            cell.lblAchievedQty.textColor = Colors.themeGreen.returnColor()
            cell.lblAchievedQtyPer.textColor = Colors.themeGreen.returnColor()
            
            cell.lblRemainingQty.textColor = Colors.themeGreen.returnColor()
            cell.lblRemainingQtyPer.textColor = Colors.themeGreen.returnColor()
        }
        
        
        if (tempObjTarget?.actualTarget ?? 0) > (tempObjTarget?.achievedTarget ?? 0) {
            
            cell.lblAchievedRupee.textColor = Colors.themeRed.returnColor()
            cell.lblAchievedRupeePer.textColor = Colors.themeRed.returnColor()
            
            cell.lblRemainingRupee.textColor = Colors.themeRed.returnColor()
            cell.lblRemainingRupeePer.textColor = Colors.themeRed.returnColor()
        }
        else {
            cell.lblAchievedRupee.textColor = Colors.themeGreen.returnColor()
            cell.lblAchievedRupeePer.textColor = Colors.themeGreen.returnColor()
            
            cell.lblRemainingRupee.textColor = Colors.themeGreen.returnColor()
            cell.lblRemainingRupeePer.textColor = Colors.themeGreen.returnColor()
        }
        
        cell.onNameTap = { section, index in
            //self.loadDataBasedOnSelection(section, index)
            var tempTarget: Target?
            if self.isEmpGrpTarget {
                tempTarget = Target.init(from: (self.arrObjTVData?[section].data ?? [])[index])
            }
            else if self.isEmpTarget {
                tempTarget = self.arrZoneEmpTarget?[self.arrZoneKeys[section]]?[index]
            }
            else if self.isEmpTargetDetails {
                
            }
            self.loadDataBasedOnSelection(objTarget: tempTarget)
        }
        
        return cell
        
        //return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func loadDataBasedOnSelection(objTarget: Target?) {
        if self.isEmpGrpTarget {
            
            self.intSelectedCategory = (objTarget?.categoryID ?? 0)
            
            self.getEmployeeTarget(userIds: self.arrSelectedEmployee, year: self.strSelectedYear, targetType: self.strTargetType, zone: self.arrIntSelectedZone, category: self.intSelectedCategory)
        }
        else if self.isEmpTarget {
            
            self.intSelectedEmpId = (objTarget?.userID ?? 0)
            
            if APIManager.sharedManager.userDetail?.roleId ?? 0 == 2 {
                self.getEmployeeTargetDetails(employeeId: [self.intSelectedEmpId], year: self.strSelectedYear, targetType: self.strTargetType, categoryGrp: self.strSelectedCategory, category: [])
            }
            else {
                self.getEmployeeTargetDetails(employeeId: [self.intSelectedEmpId], year: self.strSelectedYear, targetType: self.strTargetType, categoryGrp: self.strSelectedCategory, category: [self.intSelectedCategory])
            }
            
        }
    }
    
}



// MARK: Webservices

extension TargetVC {
    
    func categoryGroupList(categoryGroup: String = "0") {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.categoryGroupList(categoryGroup: categoryGroup)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "category_group": categoryGroup
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CATEGORY_GROUP_LIST, parameters: param) { (response: ApiResponseTarget?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrTempCategoryItemGrp = response?.result?.categories ?? []
                    if categoryGroup == "0" {
                        self.arrCategoryItemGrp = self.arrTempCategoryItemGrp
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getEmployeeList(arrZone: [String]) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployeeList(arrZone: arrZone)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "zone": arrZone
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.EMPLOYEE_LIST_ZONE_WISE, parameters: param) { (response: ApiResponseTarget?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrTempEmployee = response?.result?.employee ?? []
                    if arrZone.isEmpty {
                        self.arrEmployee = self.arrTempEmployee
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getEmployeeGroupTarget(targetType: String, year: String, categoryGrp: String, category: [String]) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployeeGroupTarget(targetType: targetType, year: year, categoryGrp: categoryGrp, category: category)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "year": year,
            "target_type": targetType,
            "category_group": categoryGrp,
            "category": category
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EMPLOYEE_GROUP_TARGET, parameters: param) { (response: ApiResponseTarget?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrEmpGrpTarget = response?.result?.target ?? []
                    self.arrObjTVData = self.arrEmpGrpTarget
                    self.tvEmpGrpTarget.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getEmployeeTarget(userIds: [Int], year: String, targetType: String, zone: [Int], category: Int) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployeeTarget(userIds: userIds, year: year, targetType: targetType, zone: zone, category: category)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "user_ids": userIds,
            "year": year,
            "target_type": targetType,
            "zone": zone,
            "category": category
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EMPLOYEE_TARGET, parameters: param) { (response: ApiResponseTarget?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrEmpTarget = response?.result?.target ?? []
                    
                    self.setUpEmpTargetData(objTarget: self.arrEmpTarget)
                    
                    //self.arrObjTVData = self.arrEmpTarget
                    //self.tvEmpGrpTarget.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getEmployeeTargetDetails(employeeId: [Int], year: String, targetType: String, categoryGrp: String, category: [Int]) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployeeTargetDetails(employeeId: employeeId, year: year, targetType: targetType, categoryGrp: categoryGrp, category: category)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "employeeId": employeeId,
            "year": year,
            "target_type": targetType,
            "category_group": categoryGrp,
            "category": category
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EMPLOYEE_TARGET_DETAILS, parameters: param) { (response: ApiResponseTarget?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrEmpTargetDetails = response?.result?.target ?? []
                    
                    self.setUpEmpTargeDetailstData(objTarget: self.arrEmpTargetDetails)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
}
