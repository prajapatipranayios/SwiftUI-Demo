//
//  TargetVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 18/09/24.
//

import UIKit

class TargetVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        
        revealViewController()?.revealSideMenu()
    }
    
    @IBOutlet weak var btnCloseEmpTargetDetails: UIButton!
    @IBAction func btnCloseEmpTargetDetailsTap(_ sender: UIButton) {
        self.viewEmployeeTargetDetails.isHidden = true
        
        //self.btnSideMenu.setImage(UIImage(named: "Sidemenu"), for: .normal)    //Sidemenu/Close
        self.btnCloseEmpTargetDetails.isHidden = true
        
        self.isEmpGrpTarget = false
        self.isEmpTarget = true
        self.isEmpTargetDetails = false
        
        self.btnSelectDuration.isEnabled = true
        self.btnSelectYear.isEnabled = true
        self.btnSelectCategory.isEnabled = true
        self.btnSelectItemGrp.isEnabled = true
        self.btnSelectZone.isEnabled = true
        self.btnSelectEmployee.isEnabled = true
        
        self.btnBackEmpTarget.isHidden = false
        
        self.constraintHeightViewFilters2.priority = .required
        self.constraintHeightViewFilters3.priority = .defaultLow
        
        if APIManager.sharedManager.userDetail?.roleId ?? 0 == 2 {
            self.constraintHeightViewFilters2.priority = .required
            self.constraintHeightViewFilters3.priority = .required
            
            self.btnBackEmpTarget.isHidden = true
        }
        
        self.arrIntSelectedZone.removeAll()
        self.arrSelectedEmployee.removeAll()
        self.lblSelectedZone.text = "Zone"
        self.lblSelectedEmployee.text = "Employee"
    }
    
    
    @IBOutlet weak var viewFilters: UIView!
    
    @IBOutlet weak var viewFilters1: UIView!
    
    @IBOutlet weak var viewDuration: UIView!
    @IBOutlet weak var lblSelectedDuration: UILabel!
    @IBOutlet weak var btnSelectDuration: UIButton!
    @IBAction func btnSelectDurationTap(_ sender: UIButton) {
        
        let tempDuration: [String] = ["Monthly", "Quarterly", "Yearly"]
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = ""
        popupVC.value = tempDuration
        popupVC.selectedValue = self.lblSelectedDuration.text ?? "Monthly"
        popupVC.didSelectItem = { strValue in
            self.lblSelectedDuration.text = strValue
            self.strTargetType = strValue
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewYear: UIView!
    @IBOutlet weak var lblSelectedYear: UILabel!
    @IBOutlet weak var btnSelectYear: UIButton!
    @IBAction func btnSelectYearTap(_ sender: UIButton) {
        
        let currYear = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).year ?? 0
        
        let tempYear: [String] = ["\(currYear - 1)", "\(currYear)", "\(currYear + 1)"]
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = ""
        popupVC.value = tempYear
        popupVC.selectedValue = self.lblSelectedYear.text ?? "\(currYear)"
        popupVC.didSelectItem = { strValue in
            self.lblSelectedYear.text = strValue
            self.strSelectedYear = strValue
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewFilters2: UIView!
    @IBOutlet weak var constraintHeightViewFilters2: NSLayoutConstraint!
    
    @IBOutlet weak var viewCategory: UIView!
    @IBOutlet weak var lblSelectedCategory: UILabel!
    @IBOutlet weak var btnSelectCategory: UIButton!
    @IBAction func btnSelectCategoryTap(_ sender: UIButton) {
        
        let tempCategory: [String] = ["Category All", "Category 1", "Category 2", "Category 3"]
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.titleTxt = ""
        popupVC.value = tempCategory
        popupVC.selectedValue = self.lblSelectedCategory.text ?? "Category All"
        popupVC.didSelectItem = { strValue in
            
            if (self.lblSelectedCategory.text ?? "") != strValue {
                
                self.lblSelectedCategory.text = strValue
                self.arrSelectedItemGrp.removeAll()
                self.lblSelectedItemGrp.text = "Item Group"
                
                var isCallAPI: Bool = false
                switch strValue {
                case "Category 1":
                    self.strSelectedCategory = "1"
                    isCallAPI = true
                case "Category 2":
                    self.strSelectedCategory = "2"
                    isCallAPI = true
                case "Category 3":
                    self.strSelectedCategory = "3"
                    isCallAPI = true
                default:
                    self.strSelectedCategory = "0"
                    self.arrTempCategoryItemGrp = self.arrCategoryItemGrp
                }
                
                if isCallAPI {
                    self.categoryGroupList(categoryGroup: self.strSelectedCategory)
                }
            }
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewItemGrp: UIView!
    @IBOutlet weak var lblSelectedItemGrp: UILabel!
    @IBOutlet weak var btnSelectItemGrp: UIButton!
    @IBAction func btnSelectItemGrpTap(_ sender: UIButton) {
        
        let arrTempItemGrp: [String] = self.arrTempCategoryItemGrp?.map { $0.name ?? "" } ?? []
        
        var arrTempSelectedValue: [String] = []
        for (_, value) in self.arrSelectedItemGrp.enumerated() {
            let tempObj = self.arrTempCategoryItemGrp?.filter { "\($0.id ?? 0)" == value }
            if tempObj?.count ?? 0 > 0 {
                arrTempSelectedValue.append(tempObj?[0].name ?? "")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Item Group"
        popupVC.value = arrTempItemGrp
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.didSelectItem = { arrValue in
            
            var  strText: String = ""
            self.arrSelectedItemGrp.removeAll()
            for (_, value) in arrValue.enumerated() {
                let tempObj = self.arrTempCategoryItemGrp?.filter { $0.name == value }
                
                if tempObj?.count ?? 0 > 0 {
                    self.arrSelectedItemGrp.append("\(tempObj?[0].id ?? 0)")
                    
                    if strText == "" {
                        strText = value
                    }
                    else {
                        strText = strText + ", " + value
                    }
                }
            }
            
            self.lblSelectedItemGrp.text = strText
            if strText == "" {
                self.lblSelectedItemGrp.text = "Item Group"
            }
            
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewFilters3: UIView!
    @IBOutlet weak var constraintHeightViewFilters3: NSLayoutConstraint!
    
    @IBOutlet weak var viewZone: UIView!
    @IBOutlet weak var lblSelectedZone: UILabel!
    @IBOutlet weak var btnSelectZone: UIButton!
    @IBAction func btnSelectZoneTap(_ sender: UIButton) {
        
        struct Zone: Codable {
            var id: Int?
            var name: String?
        }
        
        var arrZone: [Zone] = []
        arrZone.append(Zone(id: 1, name: "North"))
        arrZone.append(Zone(id: 2, name: "East"))
        arrZone.append(Zone(id: 3, name: "South"))
        arrZone.append(Zone(id: 4, name: "West"))
        
        //let arrBranch: [String] = (APIManager.sharedManager.arrBranches ?? []).map { $0.branchName! }
        let arrTempZone: [String] = arrZone.map { $0.name! }
        
        var arrTempSelectedValue: [String] = []
        for strValue in self.arrIntSelectedZone.enumerated() {
            let tempValue = arrZone.filter { $0.id! == strValue.element }
            if tempValue.count > 0 {
                arrTempSelectedValue.append("\(tempValue[0].name!)")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Zone"
        popupVC.value = arrTempZone
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.didSelectItem = { arrValue in
            
            self.arrIntSelectedZone.removeAll()
            self.arrStrSelectedZone = arrValue
            
            var  strZone: String = ""
            for strValue in arrValue.enumerated() {
                let tempValue = arrZone.filter { $0.name! == strValue.element }
                if tempValue.count > 0 {
                    self.arrIntSelectedZone.append(tempValue[0].id ?? 0)
                    if strZone != "" {
                        strZone = strZone + ", " + strValue.element
                    }
                    else {
                        strZone = strValue.element
                    }
                }
            }
            
            self.lblSelectedZone.text = "Zone"
            if strZone != "" {
                self.lblSelectedZone.text = strZone
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewEmployee: UIView!
    @IBOutlet weak var lblSelectedEmployee: UILabel!
    @IBOutlet weak var btnSelectEmployee: UIButton!
    @IBAction func btnSelectEmployeeTap(_ sender: UIButton) {
        
        let arrTempEmp: [String] = self.arrTempEmployee?.map { "\($0.firstname ?? "") \($0.lastname ?? "")" } ?? []
        
        var arrTempSelectedValue: [String] = []
        for (_, value) in self.arrSelectedEmployee.enumerated() {
            let tempObj = self.arrTempEmployee?.filter { ($0.id ?? 0) == value }
            if tempObj?.count ?? 0 > 0 {
                arrTempSelectedValue.append("\(tempObj?[0].firstname ?? "") \(tempObj?[0].lastname ?? "")")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Employee"
        popupVC.value = arrTempEmp
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.didSelectItem = { arrValue in
            
            var  strText: String = ""
            self.arrSelectedItemGrp.removeAll()
            for (_, value) in arrValue.enumerated() {
                let tempObj = self.arrTempEmployee?.filter { "\($0.firstname ?? "") \($0.lastname ?? "")" == value }
                
                if tempObj?.count ?? 0 > 0 {
                    self.arrSelectedEmployee.append(tempObj?[0].id ?? 0)
                    
                    if strText == "" {
                        strText = value
                    }
                    else {
                        strText = strText + ", " + value
                    }
                }
            }
            
            self.lblSelectedEmployee.text = strText
            if strText == "" {
                self.lblSelectedEmployee.text = "Employee"
            }
            
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    
    @IBOutlet weak var btnSearch: UIButton!
    @IBAction func btnSearchTap(_ sender: UIButton) {
        if self.isEmpGrpTarget {
            self.getEmployeeGroupTarget(targetType: self.strTargetType, year: self.strSelectedYear, categoryGrp: self.strSelectedCategory, category: self.arrSelectedItemGrp)
        }
        else if self.isEmpTarget {
            self.getEmployeeTarget(userIds: self.arrSelectedEmployee, year: self.strSelectedYear, targetType: self.strTargetType, zone: self.arrIntSelectedZone, category: self.intSelectedCategory)
        }
        else if self.isEmpTargetDetails {
            //self.getEmployeeTargetDetails(employeeId: [self.intSelectedEmpId], year: self.strSelectedYear, targetType: self.strTargetType, categoryGrp: self.strSelectedCategory, category: [self.intSelectedCategory])
            self.getEmployeeTargetDetails(employeeId: [self.intSelectedEmpId], year: self.strSelectedYear, targetType: self.strTargetType, categoryGrp: self.strSelectedCategory, category: [])
        }
    }
    
    
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var viewEmpGrpTarget: UIView!
    @IBOutlet weak var tvEmpGrpTarget: UITableView! {
        didSet {
            self.tvEmpGrpTarget.delegate = self
            self.tvEmpGrpTarget.dataSource = self
            self.tvEmpGrpTarget.register(UINib(nibName: "EmpGrpTargetTVCell", bundle: nil), forCellReuseIdentifier: "EmpGrpTargetTVCell")
            if #available(iOS 15.0, *) {
                self.tvEmpGrpTarget.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
    @IBOutlet weak var btnBackEmpTarget: UIButton!
    @IBAction func btnBackEmpTargetTap(_ sender: UIButton) {
        self.isEmpGrpTarget = true
        self.isEmpTarget = false
        self.isEmpTargetDetails = false
        
        self.tvEmpGrpTarget.reloadData()
        
        self.constraintHeightViewFilters2.priority = .defaultLow
        self.constraintHeightViewFilters3.priority = .required
        
        self.btnBackEmpTarget.isHidden = true
        
        self.arrIntSelectedZone.removeAll()
        self.arrSelectedEmployee.removeAll()
        self.lblSelectedZone.text = "Zone"
        self.lblSelectedEmployee.text = "Employee"
        
        
        if APIManager.sharedManager.userDetail?.roleId ?? 0 == 2 {
            self.constraintHeightViewFilters2.priority = .required
            self.constraintHeightViewFilters3.priority = .required
        }
        
    }
    
    
    
    /// View Employee Target Details
    
    @IBOutlet weak var viewEmployeeTargetDetails: UIView!
    @IBOutlet weak var tvEmployeeTargetDetails: UITableView! {
        didSet {
            self.tvEmployeeTargetDetails.delegate = self
            self.tvEmployeeTargetDetails.dataSource = self
            self.tvEmployeeTargetDetails.register(UINib(nibName: "EmpGrpTargetTVCell", bundle: nil), forCellReuseIdentifier: "EmpGrpTargetTVCell")
            if #available(iOS 15.0, *) {
                self.tvEmployeeTargetDetails.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
    
    
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    
    
    
    
    
    
    
    // MARK: - Variable
    
    var strScreenTitle = "Target"
    
    var strTargetType: String = "Monthly"
    var strSelectedYear: String = "2024"
    var strSelectedCategory: String = "0"
    
    var arrCategoryItemGrp: [Category]? = []
    var arrTempCategoryItemGrp: [Category]? = []
    var arrSelectedItemGrp: [String] = []
    
    var arrIntSelectedZone: [Int] = []
    var arrStrSelectedZone: [String] = []
    
    var arrEmployee: [Employee]? = []
    var arrTempEmployee: [Employee]? = []
    var arrSelectedEmployee: [Int] = []
    
    
    var arrObjTVData: [Target]? = []
    
    var arrEmpGrpTarget: [Target]?
    var isEmpGrpTarget: Bool = false
    
    var arrEmpTarget: [Target]?
    var isEmpTarget: Bool = false
    var intSelectedCategory: Int = 0
    var arrZoneEmpTarget: [String: [Target]]? = [:]
    var arrZoneKeys: [String] = []
    
    var arrEmpTargetDetails: [Target]?
    var isEmpTargetDetails: Bool = false
    
    var intSelectedEmpId: Int = 0
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.constraintHeightViewFilters2.priority = .defaultLow
        self.constraintHeightViewFilters3.priority = .required
        
        self.btnCloseEmpTargetDetails.isHidden = true
        
        self.btnBackEmpTarget.corners(radius: self.btnBackEmpTarget.frame.height / 2)
        self.btnBackEmpTarget.isHidden = true
        
        let currYear = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).year ?? 0
        self.strSelectedYear = "\(currYear)"
        
        self.lblSelectedDuration.text = self.strTargetType
        self.lblSelectedYear.text = self.strSelectedYear
        self.lblSelectedCategory.text = "Category All"
        
        self.isEmpGrpTarget = true
        self.categoryGroupList()
        self.getEmployeeList(arrZone: self.arrStrSelectedZone)
        
        //self.getEmployeeGroupTarget(targetType: self.strTargetType, year: self.strSelectedYear, categoryGrp: self.strSelectedCategory, category: self.arrSelectedItemGrp)
        
        if APIManager.sharedManager.userDetail?.roleId ?? 0 == 2 {
            self.constraintHeightViewFilters2.priority = .required
            self.constraintHeightViewFilters3.priority = .required
            
            self.isEmpGrpTarget = false
            self.isEmpTarget = true
            self.isEmpTargetDetails = false
            
            self.getEmployeeTarget(userIds: self.arrSelectedEmployee, year: self.strSelectedYear, targetType: self.strTargetType, zone: self.arrIntSelectedZone, category: self.intSelectedCategory)
        }
        else {
            self.getEmployeeGroupTarget(targetType: self.strTargetType, year: self.strSelectedYear, categoryGrp: self.strSelectedCategory, category: self.arrSelectedItemGrp)
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
    }
    
}


extension TargetVC {
    
    func setUpEmpTargetData(objTarget: [Target]?) {
        
        //let tempZone: [String] = ["North", "East", "South", "West"]
        let tempZone: [String] = ["West", "South", "North", "East"]
        
        self.arrZoneEmpTarget?.removeAll()
        self.arrZoneKeys.removeAll()
        
        for (_, value1) in tempZone.enumerated() {
            
            var tempObjTarget: [Target]? = []
            
            for (_, value2) in (objTarget ?? []).enumerated() {
                if (value2.zone ?? "").contains(value1) {
                    tempObjTarget?.append(value2)
                }
            }
            
            if (tempObjTarget?.count ?? 0) > 0 {
                self.arrZoneKeys.append(value1)
                self.arrZoneEmpTarget?[value1] = tempObjTarget
            }
            
        }   //  */
        
        self.isEmpGrpTarget = false
        self.isEmpTarget = true
        self.isEmpTargetDetails = false
        
        self.btnBackEmpTarget.isHidden = false
        
        self.constraintHeightViewFilters2.priority = .required
        self.constraintHeightViewFilters3.priority = .defaultLow
        
        if APIManager.sharedManager.userDetail?.roleId ?? 0 == 2 {
            self.constraintHeightViewFilters2.priority = .required
            self.constraintHeightViewFilters3.priority = .required
            
            self.btnBackEmpTarget.isHidden = true
        }
        
        self.tvEmpGrpTarget.reloadData()
        if self.arrZoneKeys.count > 0 {
            self.tvEmpGrpTarget.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: false)
        }
    }
    
    func setUpEmpTargeDetailstData(objTarget: [Target]?) {
        
        /*//let tempZone: [String] = ["North", "East", "South", "West"]
        let tempZone: [String] = ["West", "South", "North", "East"]
         
        self.arrZoneEmpTarget?.removeAll()
        self.arrZoneKeys.removeAll()
        
        for (_, value1) in tempZone.enumerated() {
            
            var tempObjTarget: [Target]? = []
            
            for (_, value2) in (objTarget ?? []).enumerated() {
                if (value2.zone ?? "").contains(value1) {
                    tempObjTarget?.append(value2)
                }
            }
            
            if (tempObjTarget?.count ?? 0) > 0 {
                self.arrZoneKeys.append(value1)
                self.arrZoneEmpTarget?[value1] = tempObjTarget
            }
            
        }   ///  */
        
        self.viewEmployeeTargetDetails.isHidden = false
        
        //self.btnSideMenu.setImage(UIImage(named: "Close"), for: .normal)    //Sidemenu/Close
        self.btnCloseEmpTargetDetails.isHidden = false
        
        self.viewEmployeeTargetDetails.isHidden = false
        
        self.isEmpGrpTarget = false
        self.isEmpTarget = false
        self.isEmpTargetDetails = true
        
        self.btnSelectDuration.isEnabled = false
        self.btnSelectYear.isEnabled = false
        self.btnSelectCategory.isEnabled = false
        self.btnSelectItemGrp.isEnabled = false
        self.btnSelectZone.isEnabled = false
        self.btnSelectEmployee.isEnabled = false
        
        self.btnBackEmpTarget.isHidden = true
        
        self.constraintHeightViewFilters2.priority = .defaultLow
        self.constraintHeightViewFilters3.priority = .required
        
        if APIManager.sharedManager.userDetail?.roleId ?? 0 == 2 {
            self.constraintHeightViewFilters2.priority = .required
            self.constraintHeightViewFilters3.priority = .required
        }
        
        self.tvEmployeeTargetDetails.reloadData()
    }
    
}
