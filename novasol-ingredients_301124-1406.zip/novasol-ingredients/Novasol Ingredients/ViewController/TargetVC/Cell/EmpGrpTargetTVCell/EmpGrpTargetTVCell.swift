//
//  EmpGrpTargetTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 18/09/24.
//

import UIKit

class EmpGrpTargetTVCell: UITableViewCell {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewNameCategory: UIView!
    @IBOutlet weak var constraintHeightViewNameCategory: NSLayoutConstraint!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var btnNameClick: UIButton!
    @IBAction func btnNameClickTap(_ sender: UIButton) {
        if self.onNameTap != nil {
            self.onNameTap!(section, index)
        }
    }
    @IBOutlet weak var ivArrowStatus: UIImageView!
    
    
    
    @IBOutlet weak var viewItemGrp: UIView!
    @IBOutlet weak var constraintWidthViewItemGrp: NSLayoutConstraint!
    @IBOutlet weak var constraintTrailViewItemGrpToPrefix: NSLayoutConstraint!
    
    @IBOutlet weak var lblItemGrpTitle: UILabel!
    @IBOutlet weak var lblItemGrp: UILabel!
    
    
    @IBOutlet weak var viewTitles: UIView!
    @IBOutlet weak var constraintLeadingViewTitlesToSuper: NSLayoutConstraint!
    @IBOutlet weak var constraintHeightViewTitles: NSLayoutConstraint!
    
    @IBOutlet weak var viewPrefix: UIView!
    @IBOutlet weak var lblPrefixTitle: UILabel!
    
    @IBOutlet weak var viewActual: UIView!
    @IBOutlet weak var lblActualTitle: UILabel!
    
    @IBOutlet weak var viewMAchieved: UIView!
    @IBOutlet weak var viewAchieved1: UIView!
    @IBOutlet weak var viewAchieved2: UIView!
    @IBOutlet weak var lblAchievedTitle: UILabel!
    @IBOutlet weak var lblAchievedPercentageTitle: UILabel!
    
    @IBOutlet weak var viewMRemaining: UIView!
    @IBOutlet weak var viewRemaining1: UIView!
    @IBOutlet weak var viewRemaining2: UIView!
    @IBOutlet weak var lblRemainingTitle: UILabel!
    @IBOutlet weak var lblRemainingPercentageTitle: UILabel!
    
    
    
    @IBOutlet weak var viewValues: UIView!
    @IBOutlet weak var constraintBottomViewValuesToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var viewQty: UIView!
    @IBOutlet weak var lblQtyTitle: UILabel!
    @IBOutlet weak var lblRupeeTitle: UILabel!
    
    @IBOutlet weak var viewActualAmount: UIView!
    @IBOutlet weak var lblActualQty: UILabel!
    @IBOutlet weak var lblActualRupee: UILabel!
    
    @IBOutlet weak var viewAchievedAmount: UIView!
    @IBOutlet weak var lblAchievedQty: UILabel!
    @IBOutlet weak var lblAchievedRupee: UILabel!
    
    @IBOutlet weak var viewAchievedPercentage: UIView!
    @IBOutlet weak var lblAchievedQtyPer: UILabel!
    @IBOutlet weak var lblAchievedRupeePer: UILabel!
    
    @IBOutlet weak var viewRemainingAmount: UIView!
    @IBOutlet weak var lblRemainingQty: UILabel!
    @IBOutlet weak var lblRemainingRupee: UILabel!
    
    @IBOutlet weak var viewRemainingPercentage: UIView!
    @IBOutlet weak var lblRemainingQtyPer: UILabel!
    @IBOutlet weak var lblRemainingRupeePer: UILabel!
    
    
    
    
    // MARK: - Variable
    
    var section: Int = 0
    var index: Int = 0
    var onNameTap:((Int, Int)->Void)?
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewNameCategory.backgroundColor = Colors.gray.returnColor()
        self.lblName.textColor = Colors.theme.returnColor()
        self.lblCategory.textColor = .white
        
        self.ivArrowStatus.isHidden = true
        self.ivArrowStatus.image = UIImage(systemName: "arrow.down")
        self.ivArrowStatus.tintColor = Colors.themeRed.returnColor()
        //self.ivArrowStatus.image = UIImage(systemName: "arrow.up")
        //self.ivArrowStatus.tintColor = Colors.themeGreen.returnColor()
        
        self.lblItemGrpTitle.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.lblItemGrpTitle.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        self.viewPrefix.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewPrefix.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        self.viewActual.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewActual.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        self.viewMAchieved.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewMAchieved.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.lblAchievedTitle.addBorders(edges: [.bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.viewAchieved1.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewAchieved1.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.viewAchieved2.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewAchieved2.addBorders(edges: [.bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        self.viewMRemaining.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewMRemaining.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.lblRemainingTitle.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.viewRemaining1.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewRemaining1.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.viewRemaining2.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        self.viewRemaining2.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        
        self.lblItemGrp.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        self.lblQtyTitle.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        self.lblQtyTitle.textColor = Colors.theme.returnColor()
        
        self.lblRupeeTitle.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        self.lblRupeeTitle.textColor = Colors.theme.returnColor()
        
        
        self.lblActualQty.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        self.lblActualQty.textColor = Colors.theme.returnColor()
        
        self.lblActualRupee.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        self.lblActualRupee.textColor = Colors.theme.returnColor()
        
        
        self.lblAchievedQty.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.lblAchievedRupee.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        self.lblAchievedQtyPer.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.lblAchievedRupeePer.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        self.lblRemainingQty.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.lblRemainingRupee.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        self.lblRemainingQtyPer.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        self.lblRemainingRupeePer.addBorders(edges: [.right, .bottom], color: Colors.gray.returnColor(), thickness: 1.5)
        
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
