//
//  QiPiDetailsVC.swift
//  GE Sales
//
//  Created by Auxano on 08/05/24.
//

import UIKit

class QiPiDetailsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var btnEdit: UIButton!
    @IBAction func btnEditTap(_ sender: UIButton) {
        self.editOrderDetails()
    }
    
    @IBOutlet weak var viewMainScroll1: UIView!
    @IBOutlet weak var constraintHeightViewSV1: NSLayoutConstraint!
    
    @IBOutlet weak var viewBasicDetails: UIView!
    
    @IBOutlet weak var viewCompanyName: UIView!
    @IBOutlet weak var ivCompanyName: UIImageView!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    
    @IBOutlet weak var viewBasic: UIView!
    @IBOutlet weak var lblBasicTitle: UILabel!
    @IBOutlet weak var lblBasic: UILabel!
    
    @IBOutlet weak var viewGST: UIView!
    @IBOutlet weak var lblGSTTitle: UILabel!
    @IBOutlet weak var lblGST: UILabel!
    
    @IBOutlet weak var viewNetAmount: UIView!
    @IBOutlet weak var lblNetAmountTitle: UILabel!
    @IBOutlet weak var lblNetAmount: UILabel!
    
    @IBOutlet weak var viewButtonsM: UIView!
    @IBOutlet weak var viewButtons: UIView!
    @IBOutlet weak var btnProducts: UIButton!
    @IBAction func btnProductsTap(_ sender: UIButton) {
        
        self.btnQiDetails.layer.shadowOpacity = 0
        self.btnQiDetails.backgroundColor = .clear
        self.btnQiDetails.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnQiDetails.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.btnProducts.backgroundColor = .white
        self.btnProducts.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnProducts.titleLabel?.font = UIFont(name: "Roboto-Bold", size: 16.0)
        self.btnProducts.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.viewQiDetails.isHidden = true
        self.constraintHeightTVProduct.priority = .required
        self.constraintBottomQiDetail.priority = .defaultLow
        
    }
    @IBOutlet weak var btnQiDetails: UIButton!
    @IBAction func btnQiDetailsTap(_ sender: UIButton) {
        
        self.btnProducts.layer.shadowOpacity = 0
        self.btnProducts.backgroundColor = .clear
        self.btnProducts.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnProducts.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.btnQiDetails.backgroundColor = .white
        self.btnQiDetails.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnQiDetails.titleLabel?.font = UIFont(name: "Roboto-Bold", size: 16.0)
        self.btnQiDetails.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.viewQiDetails.isHidden = false
        self.constraintHeightTVProduct.priority = .defaultLow
        self.constraintBottomQiDetail.priority = .required
    }
    
    @IBOutlet weak var viewMainScroll2: UIView!
    
    @IBOutlet weak var viewProductDetails: UIView!
    @IBOutlet weak var tvProductDetail: UITableView! {
        didSet {
            self.tvProductDetail.delegate = self
            self.tvProductDetail.dataSource = self
            self.tvProductDetail.register(UINib(nibName: "OrderDetailsTVCell", bundle: nil), forCellReuseIdentifier: "OrderDetailsTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVProduct: NSLayoutConstraint!
    
    @IBOutlet weak var viewQiDetails: UIView!
    @IBOutlet weak var ViewOrder: UIView!
    @IBOutlet weak var viewBilling: UIView!
    @IBOutlet weak var lblQiNo: UILabel!
    @IBOutlet weak var lblClientCode: UILabel!
    @IBOutlet weak var lblReqDate: UILabel!
    @IBOutlet weak var lblQuotationValidity: UILabel!
    @IBOutlet weak var lblDeliveryTo: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var lblBillingLocation: UILabel!
    @IBOutlet weak var lblDeliveryOption: UILabel!
    @IBOutlet weak var lblDeliveryLocation: UILabel!
    @IBOutlet weak var lblDeliveryType: UILabel!
    @IBOutlet weak var lblFreightTerms: UILabel!
    @IBOutlet weak var lblComments: UILabel!
    
    
    @IBOutlet weak var lblTransportName: UILabel!
    @IBOutlet weak var lblTransportGSTNo: UILabel!
    @IBOutlet weak var lblBookingPoint: UILabel!
    @IBOutlet weak var lblReferenceName: UILabel!
    @IBOutlet weak var lblPaymentType: UILabel!
    @IBOutlet weak var btnPurchasedOrder: UIButton!
    @IBAction func btnPurchasedOrderTap(_ sender: UIButton) {
    }
    @IBOutlet weak var btnTReceiptTap: UIButton!
    @IBAction func btnTReceiptTap(_ sender: UIButton) {
    }
    @IBOutlet weak var constraintBottomQiDetail: NSLayoutConstraint!
    
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "QI DETAILS"
    var isQiDetail: Bool = false
    var isPiDetail: Bool = false
    var bpOrderDetail: BPOrderDetail?
    var intOrderId: Int = 0
    
    var isAddOtherProduct: Bool = false
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.btnEdit.tintColor = .black
        self.btnEdit.isHidden = true
        
        self.lblNetAmount.textColor = Colors.theme  .returnColor()
        
        self.btnProducts.setTitleColor(Colors.theme.returnColor(), for: .normal)
        
        self.viewButtons.layer.cornerRadius = self.viewButtons.frame.height / 2
        self.btnProducts.layer.cornerRadius = self.btnProducts.frame.height / 2
        self.btnQiDetails.layer.cornerRadius = self.btnQiDetails.frame.height / 2
        
        DispatchQueue.main.async {
            self.constraintHeightViewSV1.constant = self.viewMainScroll1.frame.height + self.viewButtonsM.frame.origin.y - 10
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.tvProductDetail.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        self.btnProducts.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.btnQiDetails.backgroundColor = .clear
        self.btnQiDetails.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnQiDetails.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.ViewOrder.cornersWFullBorder(radius: 25, borderColor: UIColor(hexString: "#CFCFCF"), colorOpacity: 0.4)
        
        self.viewQiDetails.isHidden = true
        self.constraintHeightTVProduct.priority = .required
        
        self.getQiPiDetail(orderId: self.intOrderId)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.tvProductDetail.removeObserver(self, forKeyPath: "contentSize")
    }
    
//    override func viewDidDisappear(_ animated: Bool) {
//        self.tvProductDetail.removeObserver(self, forKeyPath: "contentSize")
//    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                //self.constraintHeightTVProduct.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                self.constraintHeightTVProduct.constant = newsize.height
                self.updateViewConstraints()
            }
        }
    }
    
    func setDetail(bpOrderDetail: BPOrderDetail) {
        
        self.lblCompanyName.text = bpOrderDetail.businessPartnerName ?? ""
        self.lblCode.text = bpOrderDetail.codeID ?? ""
        
        self.lblBasic.text = "₹ " + "\(bpOrderDetail.basicTotal ?? 0)".curFormatAsRegion()
        self.lblGST.text = "₹ " + "\(bpOrderDetail.gstTotal ?? 0)".curFormatAsRegion()
        self.lblNetAmount.text = "₹ " + "\(Double(bpOrderDetail.grandTotalAmount ?? 0.0))".curFormatAsRegion()
        
        self.lblQiNo.text = bpOrderDetail.orderCode ?? ""
        self.lblCode.text = bpOrderDetail.codeID ?? ""
        self.lblReqDate.text = Utilities.convertStrDateToString(date: bpOrderDetail.orderDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy hh:mm a", NewDateFormate: "MMM dd, yyyy")
        self.lblQuotationValidity.text = Utilities.convertStrDateToString(date: bpOrderDetail.requiredDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "MMM dd, yyyy")
        
        self.lblDeliveryTo.text = bpOrderDetail.deliveryTo ?? ""
        self.lblStatus.text = OrderStatus.getStatusTitle(status: bpOrderDetail.orderStatus ?? 0)
        self.lblStatus.textColor = OrderStatus.getStatusColor(status: bpOrderDetail.orderStatus ?? 0)
        
        self.lblEmpName.text = "\((bpOrderDetail.userName ?? "") == "" ? "-" : bpOrderDetail.userName ?? "")"
        self.lblBillingLocation.text = "\((bpOrderDetail.billingLocation ?? "") == "" ? "-" : bpOrderDetail.billingLocation ?? "")"
        self.lblDeliveryOption.text = "\((bpOrderDetail.deliveryOption ?? "") == "" ? "-" : bpOrderDetail.deliveryOption ?? "")"
        self.lblDeliveryLocation.text = "\((bpOrderDetail.deliveryLocation ?? "") == "" ? "-" : bpOrderDetail.deliveryLocation ?? "")"
        self.lblDeliveryType.text = "\((bpOrderDetail.orderDeliveryType ?? "") == "" ? "-" : bpOrderDetail.orderDeliveryType ?? "")"
        
        self.lblFreightTerms.text = "\((bpOrderDetail.freightCharges ?? "") == "" ? "-" : bpOrderDetail.freightCharges ?? "")"
        
        self.lblComments.text = "\((bpOrderDetail.comment ?? "") == "" ? "-" : bpOrderDetail.comment ?? "")"
        
        self.constraintHeightTVProduct.constant = CGFloat((bpOrderDetail.products?.count ?? 0) * 541)
        self.constraintHeightTVProduct.priority = .defaultHigh
        self.constraintBottomQiDetail.priority = .defaultLow
        
        self.tvProductDetail.reloadData()
        
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            self.btnEdit.isHidden = !self.editBtnVisible()
        }
    }
}
