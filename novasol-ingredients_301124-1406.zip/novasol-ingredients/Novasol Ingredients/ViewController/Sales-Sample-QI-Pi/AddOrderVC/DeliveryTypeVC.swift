//
//  DeliveryTypeVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 12/06/24.
//

import UIKit

class DeliveryTypeVC: UIViewController {

    // MARK: - Outlet
    @IBOutlet weak var viewMain : UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
        }
    }
    @IBOutlet weak var btnAdd: UIButton!
    @IBAction func btnAddTap(_ sender: UIButton) {
        //self.dismissMyKeyboard()
    }
    
    
    @IBOutlet weak var viewScrollViewOut: UIView!
    @IBOutlet weak var constraintBottomViewScrollViewOut: NSLayoutConstraint!
    @IBOutlet weak var viewScrollViewIn: UIView!
    
    
    @IBOutlet weak var viewSelfPickup: UIView!
    @IBOutlet weak var btnSelfPickUp: UIButton!
    @IBAction func btnSelfPickUpTap(_ sender: UIButton) {
        self.btnSelfPickUp.tintColor = Colors.themeGreen.returnColor()
        self.btnSelfPickUp.isSelected = true
        self.isSelfPickUp = true
        self.strSelectedValue = "Self Pickup"
        self.saveToDraftOrder.orderDeliveryType = self.strSelectedValue
        self.saveToDraftOrder.orderDeliveryType = "Self"
        
        self.btnDeliveryBy.tintColor = Colors.gray.returnColor()
        self.btnDeliveryBy.isSelected = false
        self.isDeliveryBy = false
        self.constraintBottomBtnDeliveryBy.priority = .required
        
        self.btnDeliveryBySalesEmp.tintColor = Colors.gray.returnColor()
        self.btnDeliveryBySalesEmp.isSelected = false
        self.isDeliveryBySalesEmp = false
        self.constraintBottomBtnDeliveryBySalesEmp.priority = .required
    }
    
    
    @IBOutlet weak var viewDeliveryBy: UIView!
    
    @IBOutlet weak var btnDeliveryBy: UIButton!
    @IBAction func btnDeliveryByTap(_ sender: UIButton) {
        self.btnDeliveryBy.tintColor = Colors.themeGreen.returnColor()
        self.btnDeliveryBy.isSelected = true
        self.isDeliveryBy = true
        self.constraintBottomBtnDeliveryBy.priority = .defaultLow
        self.strSelectedValue = "Delivery By"
        self.saveToDraftOrder.orderDeliveryType = self.strSelectedValue
        self.saveToDraftOrder.orderDeliveryType = "Customer"
        
        self.lblDeliveryLocation.text = self.saveToDraftOrder.deliveryAddressName ?? ""
        self.lblTransportName.text = self.saveToDraftOrder.transporterTitle ?? ""
        self.lblTransportGSTNo.text = (self.saveToDraftOrder.transporterGSTNo ?? "") == "" ? "-" : (self.saveToDraftOrder.transporterGSTNo ?? "")
        
        if self.isFromSalesOrder {
            self.viewCourier.isHidden = true
            self.viewTransport.isHidden = false
            self.constraintBottomViewTransportToBookingPoint.priority = .required
            self.constraintBottomTransportGSTNoToViewTransport.priority = .defaultLow
        }
        else if self.isFromSampleRequest {
            self.constraintBottomDeliveryLocation.priority = .defaultLow
            
            if self.isCourier {
                self.btnCourier.isSelected = true
                self.isCourier = true
                self.viewCourier.isHidden = false
                self.constraintBottomViewCourierToBookingPoint.priority = .required
                
                self.btnTransporter.isSelected = false
                self.isTransporter = false
                self.viewTransport.isHidden = true
                self.constraintBottomViewTransportToBookingPoint.priority = .defaultLow
            }
            else {
                self.btnTransporter.isSelected = true
                self.isTransporter = true
                self.viewTransport.isHidden = false
                self.constraintBottomViewTransportToBookingPoint.priority = .required
                
                self.btnCourier.isSelected = false
                self.isCourier = false
                self.viewCourier.isHidden = true
                self.constraintBottomViewCourierToBookingPoint.priority = .defaultLow
            }
        }
        else if self.isFromQI || self.isFromPI {
            self.viewCourier.isHidden = true
            self.viewTransport.isHidden = false
            self.constraintBottomViewTransportToBookingPoint.priority = .required
            self.constraintBottomTransportGSTNoToViewTransport.priority = .defaultLow
            self.constraintHeightBookingPoint.priority = .required
        }
        
        self.btnDeliveryBySalesEmp.tintColor = Colors.gray.returnColor()
        self.btnDeliveryBySalesEmp.isSelected = false
        self.isDeliveryBySalesEmp = false
        self.constraintBottomBtnDeliveryBySalesEmp.priority = .required
        
        self.btnSelfPickUp.tintColor = Colors.gray.returnColor()
        self.btnSelfPickUp.isSelected = false
        self.isSelfPickUp = false
    }
    
    @IBOutlet weak var viewDeliveryLocation: UIView!
    @IBOutlet weak var constraintBottomDeliveryLocation: NSLayoutConstraint!
    @IBOutlet weak var lblDeliveryLocation: UILabel!
    @IBOutlet weak var lblSeparatorDeliveryLocation: UILabel!
    @IBOutlet weak var btnDeliveryLocation: UIButton!
    @IBAction func btnDeliveryLocationTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "BillingLocationListVC") as! BillingLocationListVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.intBusinessPartnerId = self.saveToDraftOrder.businessPartnersID ?? 0
        popupVC.addressType = 2 //  2 - Delivary Type
        popupVC.onCellTap = { isSelect, businessPDAddress in
            if isSelect {
                self.businessPartnerDAddress = businessPDAddress
                self.lblDeliveryLocation.text = self.businessPartnerDAddress?.addressTitle ?? ""
                
                self.saveToDraftOrder.deliveryAddressID = "\(self.businessPartnerDAddress?.id ?? 0)"
                self.saveToDraftOrder.deliveryAddressName = self.businessPartnerDAddress?.addressTitle ?? ""
            }
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewCourierTransporter: UIView!
    @IBOutlet weak var btnCourier: UIButton!
    @IBAction func btnCourierTap(_ sender: UIButton) {
        self.btnCourier.isSelected = true
        self.isCourier = true
        self.viewCourier.isHidden = false
        self.constraintBottomViewCourierToBookingPoint.priority = .required
        
        self.saveToDraftOrder.transporterTitle = self.lblCourier.text ?? ""
        
        self.btnTransporter.isSelected = false
        self.isTransporter = false
        self.viewTransport.isHidden = true
        self.constraintBottomViewTransportToBookingPoint.priority = .defaultLow
    }
    
    @IBOutlet weak var viewCourier: UIView!
    @IBOutlet weak var constraintBottomViewCourierToBookingPoint: NSLayoutConstraint!
    @IBOutlet weak var lblCourier: UILabel!
    @IBOutlet weak var lblSeparatorCourier: UILabel!
    @IBOutlet weak var btnSelectCourier: UIButton!
    @IBAction func btnSelectCourierTap(_ sender: UIButton) {
    }
    
    
    @IBOutlet weak var btnTransporter: UIButton!
    @IBAction func btnTransporterTap(_ sender: UIButton) {
        self.btnTransporter.isSelected = true
        self.isTransporter = true
        self.viewTransport.isHidden = false
        self.constraintBottomViewTransportToBookingPoint.priority = .required
        
        self.lblTransportName.text = ""
        self.lblTransportGSTNo.text = "-"
        self.saveToDraftOrder.transporterTitle = self.lblTransportName.text ?? ""
        
        self.btnCourier.isSelected = false
        self.isCourier = false
        self.viewCourier.isHidden = true
        self.constraintBottomViewCourierToBookingPoint.priority = .defaultLow
    }
    
    @IBOutlet weak var viewTransport: UIView!
    @IBOutlet weak var constraintBottomViewTransportToBookingPoint: NSLayoutConstraint!
    @IBOutlet weak var ViewTransportName: UIView!
    @IBOutlet weak var lblTransportName: UILabel!
    @IBOutlet weak var lblSeparatorTransportName: UILabel!
    @IBOutlet weak var btnTransportName: UIButton!
    @IBAction func btnTransportNameTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "TransportNamesVC") as! TransportNamesVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.arrBPTransporters = self.arrBPTransporters
        popupVC.intBusinessPId = self.saveToDraftOrder.businessPartnersID ?? 0
        popupVC.didSelect = { isSelect, selectedIndex, arrTransport, strValue in
            if isSelect {
                self.lblTransportName.text = arrTransport[selectedIndex].transporterTitle ?? ""
                self.lblTransportGSTNo.text = (arrTransport[selectedIndex].transporterGSTNo ?? "") == "" ? "-" : (arrTransport[selectedIndex].transporterGSTNo ?? "")
                
                self.saveToDraftOrder.transportNamelist = arrTransport
                self.saveToDraftOrder.transporterID = "\(arrTransport[selectedIndex].transporterId ?? 0)"
                self.saveToDraftOrder.transporterTitle = arrTransport[selectedIndex].transporterTitle ?? ""
                self.saveToDraftOrder.transporterGSTNo = arrTransport[selectedIndex].transporterGSTNo ?? ""
            }
            else {
                self.lblTransportName.text = strValue
                self.lblTransportGSTNo.text = "-"
                
                self.saveToDraftOrder.transporterID = "\(arrTransport[selectedIndex].transporterId ?? 0)"
                self.saveToDraftOrder.transporterTitle = strValue
                self.saveToDraftOrder.transporterGSTNo = ""
            }
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var constraintHeightViewTransportName: NSLayoutConstraint!
    
    @IBOutlet weak var viewTransportGST: UIView!
    @IBOutlet weak var lblTransportGSTNoTitle: UILabel!
    @IBOutlet weak var lblTransportGSTNo: UILabel!
    @IBOutlet weak var lblSeparatorTransportGSTNo: UILabel!
    @IBOutlet weak var constraintHeightViewTransportGST: NSLayoutConstraint!
    
    @IBOutlet weak var viewFreightCharges: UIView!
    @IBOutlet weak var lblFreightChargesTitle: UILabel!
    @IBOutlet weak var btnToPayByCustomer: UIButton!
    @IBAction func btnToPayByCustomerTap(_ sender: UIButton) {
        self.btnToPayByCustomer.isSelected = true
        self.isToPayByCustomer = true
        self.btnToPayByCustomer.tintColor = Colors.themeGreen.returnColor()
        self.saveToDraftOrder.freightCharges = "To Pay"
        
        self.btnPaidByCompany.isSelected = false
        self.isPaidByCompany = false
        self.btnPaidByCompany.tintColor = Colors.gray.returnColor()
        
        self.btnPaidInInvoice.isSelected = false
        self.isPaidInInvoice = false
        self.btnPaidInInvoice.tintColor = Colors.gray.returnColor()
    }
    @IBOutlet weak var btnPaidByCompany: UIButton!
    @IBAction func btnPaidByCompanyTap(_ sender: UIButton) {
        self.btnToPayByCustomer.isSelected = false
        self.isToPayByCustomer = false
        self.btnToPayByCustomer.tintColor = Colors.gray.returnColor()
        
        self.btnPaidByCompany.isSelected = true
        self.isPaidByCompany = true
        self.btnPaidByCompany.tintColor = Colors.themeGreen.returnColor()
        self.saveToDraftOrder.freightCharges = "To Paid"
        
        self.btnPaidInInvoice.isSelected = false
        self.isPaidInInvoice = false
        self.btnPaidInInvoice.tintColor = Colors.gray.returnColor()
    }
    @IBOutlet weak var btnPaidInInvoice: UIButton!
    @IBAction func btnPaidInInvoiceTap(_ sender: UIButton) {
        self.btnToPayByCustomer.isSelected = false
        self.isToPayByCustomer = false
        self.btnToPayByCustomer.tintColor = Colors.gray.returnColor()
        
        self.btnPaidByCompany.isSelected = false
        self.isPaidByCompany = false
        self.btnPaidByCompany.tintColor = Colors.gray.returnColor()
        
        self.btnPaidInInvoice.isSelected = true
        self.isPaidInInvoice = true
        self.btnPaidInInvoice.tintColor = Colors.themeGreen.returnColor()
        self.saveToDraftOrder.freightCharges = "Paid Added In Invoice"
    }
    @IBOutlet weak var lblSeparatorFreightCharges: UILabel!
    @IBOutlet weak var constraintBottomTransportGSTNoToViewTransport: NSLayoutConstraint!
    
    @IBOutlet weak var viewBookingPoint: UIView!
    @IBOutlet weak var lblBookingPointTitle: UILabel!
    @IBOutlet weak var lblBookingPoint: UILabel!
    @IBOutlet weak var lblSeparatorBookingPoint: UILabel!
    @IBOutlet weak var btnBookingPoint: UIButton!
    @IBAction func btnBookingPointTap(_ sender: UIButton) {
        let arrBookingPoint: [String] = (self.arrBookingPoint ?? []).map { $0.bookingPoint! }
        if arrBookingPoint.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.BookingPoint
            popupVC.value = arrBookingPoint
            popupVC.selectedValue = self.lblBookingPoint.text ?? "Select Booking Point"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                if strValue == "Other" {
                    self.viewAddOtherBookingPoint.isHidden = false
                }
                else {
                    self.lblBookingPoint.text = strValue
                    self.saveToDraftOrder.bookingPoint = strValue
                }
            }
            popupVC.onClose = { strValue in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    
    @IBOutlet weak var viewAddOtherBookingPoint: UIView!
    //@IBOutlet weak var txtBookingPoint: TLTextField!
    @IBOutlet weak var txtBookingPoint: TLTextField!
    @IBOutlet weak var btnCloseAddBookingPoint: UIButton!
    @IBAction func btnCloseAddBookingPointTap(_ sender: UIButton) {
        self.viewAddOtherBookingPoint.isHidden = true
    }
    @IBOutlet weak var btnAddBookingPoint: UIButton!
    @IBAction func btnAddBookingPointTap(_ sender: UIButton) {
        if (self.txtBookingPoint.text ?? "") != "" {
            let temp = BookingPoint(id: "0", bookingPoint: self.txtBookingPoint.text ?? "")
            self.arrBookingPoint?.append(temp)
            self.lblBookingPoint.text = self.txtBookingPoint.text ?? ""
            self.txtBookingPoint.text = ""
            self.viewAddOtherBookingPoint.isHidden = true
            
            self.saveToDraftOrder.bookingPoint = self.lblBookingPoint.text ?? ""
        }
    }
    @IBOutlet weak var constraintHeightBookingPoint: NSLayoutConstraint!
    
    
    @IBOutlet weak var constraintBottomBtnDeliveryBy: NSLayoutConstraint!
    
    
    
    @IBOutlet weak var viewDeliveryBySalesEmp: UIView!
    @IBOutlet weak var btnDeliveryBySalesEmp: UIButton!
    @IBAction func btnDeliveryBySalesEmpTap(_ sender: UIButton) {
        self.btnDeliveryBySalesEmp.tintColor = Colors.themeGreen.returnColor()
        self.btnDeliveryBySalesEmp.isSelected = true
        self.isDeliveryBySalesEmp = true
        self.constraintBottomBtnDeliveryBySalesEmp.priority = .defaultLow
        self.strSelectedValue = "Hand Delivered"
        self.saveToDraftOrder.orderDeliveryType = self.strSelectedValue
        self.saveToDraftOrder.orderDeliveryType = "Hand Delivered"
        
        self.btnSelfPickUp.tintColor = Colors.gray.returnColor()
        self.btnSelfPickUp.isSelected = false
        self.isSelfPickUp = false
        
        self.btnDeliveryBy.tintColor = Colors.gray.returnColor()
        self.btnDeliveryBy.isSelected = false
        self.isDeliveryBy = false
        self.constraintBottomBtnDeliveryBy.priority = .required
    }
    @IBOutlet weak var txtDeliveryBySalesEmp: TLTextField!
    @IBOutlet weak var lblErrorDeliveryBySalesEmp: UILabel!
    @IBOutlet weak var constraintBottomBtnDeliveryBySalesEmp: NSLayoutConstraint!
    
    @IBOutlet weak var btnSubmit: UIButton!
    @IBAction func btnSubmitTap(_ sender: UIButton) {
        var isValid: Bool = true
        
        if self.strSelectedValue == "Delivery By" {
//            if self.isFromSalesOrder || self.isFromSampleRequest {
//                if self.lblBookingPoint.text == "Select Booking Point" {
//                    Utilities.showPopup(title: "Select booking point.", type: .error)
//                    isValid = false
//                }
//            }
            
            if self.isFromSalesOrder || self.isFromQI || self.isFromPI {
                if self.isToPayByCustomer || self.isPaidByCompany || self.isPaidInInvoice {
                }
                else {
                    Utilities.showPopup(title: "Select freight charges.", type: .error)
                    isValid = false
                }
            }
            
            if self.lblTransportName.text == "" {
                if self.isFromSalesOrder || (self.isFromSampleRequest && self.isTransporter) {
                    Utilities.showPopup(title: "Select transport name.", type: .error)
                    isValid = false
                }
            }
            
            if self.lblDeliveryLocation.text == "" {
                self.lblDeliveryLocation.text = "Select delivery location"
                isValid = false
            }
        }
        else if self.strSelectedValue == "Hand Delivered" {
            
            self.txtDeliveryBySalesEmp.text = self.txtDeliveryBySalesEmp.text?.trimmingCharacters(in: .whitespaces)
            if self.txtDeliveryBySalesEmp.text == "" {
                self.lblErrorDeliveryBySalesEmp.getEmptyValidationString("Enter employee name.".lowercased())
                isValid = false
            }
            else {
                self.saveToDraftOrder.handDeliveryText = self.txtDeliveryBySalesEmp.text ?? ""
            }
        }
        
        if isValid {
            self.dismiss(animated: true) {
                if self.didSelect != nil {
                    self.didSelect!(self.strSelectedValue, self.saveToDraftOrder)
                }
            }
        }
    }
    
    
    
    // MARK: - Variable
    
    var strScreenTitle = "SELECT DELIVERY OPTION"
    var isFromSalesOrder: Bool = false
    var isFromSampleRequest: Bool = false
    var isFromQI: Bool = false
    var isFromPI: Bool = false
    var didSelect: ((String, SaveToDraftOrder)->Void)?
    var onClose: (()->Void)?
    
    var saveToDraftOrder = SaveToDraftOrder()
    var strSelectedValue: String = ""
    var isSelfPickUp: Bool = false
    var isDeliveryBy: Bool = false
    var isDeliveryBySalesEmp: Bool = false
    var isDeliveryLocationSelected: Bool = false
    var isToPayByCustomer: Bool = false
    var isPaidByCompany: Bool = false
    var isPaidInInvoice: Bool = false
    var businessPartnerDAddress: BusinessPartnerAddress?
    var arrBPTransporters: [Transporter]? = []
    var arrBookingPoint: [BookingPoint]? = []
    
    // Sample
    var isCourier: Bool = false
    var isTransporter: Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.viewSelfPickup.cornersWFullBorder(radius: 12.0, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.viewDeliveryBy.cornersWFullBorder(radius: 12.0, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.viewDeliveryBySalesEmp.cornersWFullBorder(radius: 12.0, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        
        self.viewAddOtherBookingPoint.isHidden = true
        self.btnAddBookingPoint.corners(radius: 12.0)
        
        self.lblSeparatorDeliveryLocation.backgroundColor = Colors.separator.returnColor()
        self.lblSeparatorTransportName.backgroundColor = Colors.separator.returnColor()
        self.lblSeparatorTransportGSTNo.backgroundColor = Colors.separator.returnColor()
        self.lblSeparatorFreightCharges.backgroundColor = Colors.separator.returnColor()
        self.lblSeparatorBookingPoint.backgroundColor = Colors.separator.returnColor()
        
        self.btnSelfPickUp.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnDeliveryBy.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnDeliveryBySalesEmp.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.lblFreightChargesTitle.textColor = Colors.theme.returnColor()
        self.lblBookingPointTitle.textColor = Colors.theme.returnColor()
        
        self.btnSelfPickUp.tintColor = Colors.gray.returnColor()
        self.btnDeliveryBy.tintColor = Colors.gray.returnColor()
        self.btnDeliveryBySalesEmp.tintColor = Colors.gray.returnColor()
        
        self.btnToPayByCustomer.tintColor = Colors.gray.returnColor()
        self.btnPaidByCompany.tintColor = Colors.gray.returnColor()
        self.btnPaidInInvoice.tintColor = Colors.gray.returnColor()
        
        self.constraintBottomBtnDeliveryBySalesEmp.priority = .required
        self.constraintBottomBtnDeliveryBy.priority = .required
        self.constraintBottomDeliveryLocation.priority = .required
        self.constraintBottomTransportGSTNoToViewTransport.priority = .required
        
        self.btnSubmit.corners(radius: 15.0)
        
        self.viewDeliveryBySalesEmp.isHidden = true
        if self.isFromSampleRequest {
            self.viewDeliveryBySalesEmp.isHidden = false
        }
        else if self.isFromQI || self.isFromPI {
            self.constraintHeightViewTransportName.priority = .required
            self.constraintHeightViewTransportGST.priority = .required
            //self.constraintBottomViewTransportToBookingPoint.priority = .defaultLow
            //self.constraintBottomTransportGSTNoToViewTransport.priority = .defaultLow
            //self.constraintHeightBookingPoint.priority = .required
        }
        
        if self.strSelectedValue == "Self Pickup" {
            self.btnSelfPickUp.tintColor = Colors.themeGreen.returnColor()
            self.btnSelfPickUp.isSelected = true
            self.isSelfPickUp = true
            self.strSelectedValue = "Self Pickup"
            self.saveToDraftOrder.orderDeliveryType = self.strSelectedValue
            self.saveToDraftOrder.orderDeliveryType = "Self"
        }
        else if self.strSelectedValue == "Delivery By" {
            self.btnDeliveryBy.tintColor = Colors.themeGreen.returnColor()
            self.btnDeliveryBy.isSelected = true
            self.isDeliveryBy = true
            self.constraintBottomBtnDeliveryBy.priority = .defaultLow
            self.strSelectedValue = "Delivery By"
            self.saveToDraftOrder.orderDeliveryType = self.strSelectedValue
            self.saveToDraftOrder.orderDeliveryType = "Customer"
            
            self.lblDeliveryLocation.text = self.saveToDraftOrder.deliveryAddressName ?? ""
            
            self.lblBookingPoint.text = self.saveToDraftOrder.bookingPoint ?? ""
            
            if self.isFromSalesOrder {
                self.lblTransportName.text = self.saveToDraftOrder.transporterTitle ?? ""
                self.lblTransportGSTNo.text = (self.saveToDraftOrder.transporterGSTNo ?? "") == "" ? "-" : (self.saveToDraftOrder.transporterGSTNo ?? "")
                
                self.constraintBottomViewTransportToBookingPoint.priority = .required
                self.viewCourier.isHidden = true
                self.viewTransport.isHidden = false
                self.constraintBottomTransportGSTNoToViewTransport.priority = .defaultLow
                
                self.saveToDraftOrder.freight = 1
                
                if self.saveToDraftOrder.freightCharges == "To Pay" {
                    self.btnToPayByCustomer.isSelected = true
                    self.isToPayByCustomer = true
                    self.btnToPayByCustomer.tintColor = Colors.themeGreen.returnColor()
                    self.saveToDraftOrder.freightCharges = "To Pay"
                }
                else if self.saveToDraftOrder.freightCharges == "To Paid" {
                    self.btnPaidByCompany.isSelected = true
                    self.isPaidByCompany = true
                    self.btnPaidByCompany.tintColor = Colors.themeGreen.returnColor()
                    self.saveToDraftOrder.freightCharges = "To Paid"
                }
                else if self.saveToDraftOrder.freightCharges == "Paid Added In Invoice" {
                    self.btnPaidInInvoice.isSelected = true
                    self.isPaidInInvoice = true
                    self.btnPaidInInvoice.tintColor = Colors.themeGreen.returnColor()
                    self.saveToDraftOrder.freightCharges = "Paid Added In Invoice"
                }
            }
            else if self.isFromSampleRequest {
                self.btnCourier.isSelected = true
                self.isCourier = true
                self.viewCourier.isHidden = false
                self.constraintBottomViewCourierToBookingPoint.priority = .required
                
                self.saveToDraftOrder.transporterTitle = self.lblCourier.text ?? ""
                
                self.btnTransporter.isSelected = false
                self.isTransporter = false
                self.viewTransport.isHidden = true
                self.constraintBottomViewTransportToBookingPoint.priority = .defaultLow
                
                self.constraintBottomDeliveryLocation.priority = .defaultLow
                self.saveToDraftOrder.freight = 0
            }
            else if self.isFromQI || self.isFromPI {
                self.viewCourier.isHidden = true
                self.viewTransport.isHidden = false
                self.constraintBottomBtnDeliveryBy.priority = .defaultLow
                self.constraintBottomViewTransportToBookingPoint.priority = .required
                self.constraintBottomTransportGSTNoToViewTransport.priority = .defaultLow
                self.constraintHeightBookingPoint.priority = .required
                
                self.saveToDraftOrder.freight = 1
                
                if self.saveToDraftOrder.freightCharges == "To Pay" {
                    self.btnToPayByCustomer.isSelected = true
                    self.isToPayByCustomer = true
                    self.btnToPayByCustomer.tintColor = Colors.themeGreen.returnColor()
                    self.saveToDraftOrder.freightCharges = "To Pay"
                }
                else if self.saveToDraftOrder.freightCharges == "To Paid" {
                    self.btnPaidByCompany.isSelected = true
                    self.isPaidByCompany = true
                    self.btnPaidByCompany.tintColor = Colors.themeGreen.returnColor()
                    self.saveToDraftOrder.freightCharges = "To Paid"
                }
                else if self.saveToDraftOrder.freightCharges == "Paid Added In Invoice" {
                    self.btnPaidInInvoice.isSelected = true
                    self.isPaidInInvoice = true
                    self.btnPaidInInvoice.tintColor = Colors.themeGreen.returnColor()
                    self.saveToDraftOrder.freightCharges = "Paid Added In Invoice"
                }
            }
        }
        else if self.strSelectedValue == "Hand Delivered" {
            self.btnDeliveryBySalesEmp.tintColor = Colors.themeGreen.returnColor()
            self.btnDeliveryBySalesEmp.isSelected = true
            self.isDeliveryBySalesEmp = true
            self.constraintBottomBtnDeliveryBySalesEmp.priority = .defaultLow
            self.strSelectedValue = "Hand Delivered"
            self.saveToDraftOrder.orderDeliveryType = self.strSelectedValue
            self.saveToDraftOrder.orderDeliveryType = "Hand Delivered"
            
            self.txtDeliveryBySalesEmp.text = self.saveToDraftOrder.handDeliveryText
        }
        
        self.checkKeyboard(kView: viewMain)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if self.isFromSalesOrder {
            self.getBookingPoint(intBusinessPartnersId: self.saveToDraftOrder.businessPartnersID ?? 0)
        }
        else if self.isFromSampleRequest {
            let temp = BookingPoint(id: "-1", bookingPoint: "Door Delivery")
            self.arrBookingPoint?.append(temp)
            let temp2 = BookingPoint(id: "-2", bookingPoint: "Office Pickup")
            self.arrBookingPoint?.append(temp2)
            self.lblBookingPoint.text = "Door Delivery"
        }
    }
}

// MARK: - Web Services

extension DeliveryTypeVC {
    func getBookingPoint(intBusinessPartnersId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBookingPoint(intBusinessPartnersId: intBusinessPartnersId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partners_id": intBusinessPartnersId
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_BOOKING_POINT, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrBookingPoint = response?.result?.bookingPoints ?? []
                    let temp = BookingPoint(id: "0", bookingPoint: "Other")
                    self.arrBookingPoint?.append(temp)
                }
            }
            else {
                //Utilities.showPopup(title: response?.message ?? "", type: .error)
                let temp = BookingPoint(id: "0", bookingPoint: "Other")
                self.arrBookingPoint?.append(temp)
            }
        }
    }
}

// MARK: - Keyboard

extension DeliveryTypeVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomBSheet.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            
            self.constraintBottomViewScrollViewOut.constant = keyboardOverlap > 0 ? (keyboardOverlap - 78) : 12
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}
