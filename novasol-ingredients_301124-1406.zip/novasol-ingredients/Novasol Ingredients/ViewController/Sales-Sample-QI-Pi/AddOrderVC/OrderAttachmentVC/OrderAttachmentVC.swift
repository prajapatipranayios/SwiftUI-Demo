//
//  OrderAttachmentVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 20/06/24.
//

import UIKit

class OrderAttachmentVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onTap != nil {
                self.onTap!(false, "")
            }
        }
    }
    
    @IBOutlet weak var viewScrollViewOut: UIView!
    @IBOutlet weak var viewScrollViewIn: UIView!
    
    @IBOutlet weak var viewMSelectFollowUpDays: UIView!
    @IBOutlet weak var lblSelectFollowUpDaysTitle: UILabel!
    @IBOutlet weak var viewSelectFollowUpDays: UIView! {
        didSet {
            self.viewSelectFollowUpDays.corners(radius: 15.0)
        }
    }
    @IBOutlet weak var lblFollowUpDays: UILabel!
    @IBOutlet weak var btnSelectFollowUpDays: UIButton!
    @IBAction func btnSelectFollowUpDaysTap(_ sender: UIButton) {
        if self.isKeyboardActive {
            self.dismissMyKeyboard()
        }
        if self.arrFollowUpDays?.count ?? 0 > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.SelectFollowUpDays
            popupVC.value = self.arrFollowUpDays ?? []
            popupVC.selectedValue = self.lblFollowUpDays.text ?? "Select FollowUp Days"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.lblFollowUpDays.text = strValue
                if strValue == "Custom Days" {
                    self.constraintHeightTXTCustomFollowUpDays.constant = 35
                    self.txtCustomFollowUpDays.text = ""
                    self.lblFollowUpDate.text = ""
                }
                else {
                    self.constraintHeightTXTCustomFollowUpDays.constant = 0
                    self.txtCustomFollowUpDays.text = ""
                    let arr = strValue.components(separatedBy: " ")
                    self.lblFollowUpDate.text = "Next Follow Up Date: \(Utilities.getStrDateAdding(days: Int(arr[0]) ?? 0, dateFormate: "dd/MM/yyyy"))"
                    self.saveToDraftOrder.followUpDays = Int(arr[0]) ?? 0
                }
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    @IBOutlet weak var txtCustomFollowUpDays: TLTextField!
    @IBOutlet weak var constraintHeightTXTCustomFollowUpDays: NSLayoutConstraint!
    @IBOutlet weak var lblFollowUpDate: UILabel!
    
    
    @IBOutlet weak var viewMSelectAttachment: UIView!
    @IBOutlet weak var lblSelectAttachmentTtitle: UILabel!
    @IBOutlet weak var viewSelectAttachment: UIView!
    @IBOutlet weak var lblSelectAttachment: UILabel!
    @IBOutlet weak var btnSelectAttachment: UIButton!
    @IBAction func btnSelectAttachmentTap(_ sender: UIButton) {
        if self.isKeyboardActive {
            self.dismissMyKeyboard()
        }
        if self.arrSelectAttachment?.count ?? 0 > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.SelectOrderAttachment
            popupVC.value = self.arrSelectAttachment ?? []
            popupVC.selectedValue = self.lblSelectAttachment.text ?? "Select Attachment"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.setAttachmentDetails(strValue: strValue)
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    
    func setAttachmentDetails(strValue: String) {
        
        self.lblSelectAttachment.text = strValue
        if strValue == "NA" {
            self.constraintHeightTXTSelectAttachment.constant = 35
            self.viewUpload.isHidden = true
        }
        else {
            self.txtSelectAttachmentReason.text = ""
            self.constraintHeightTXTSelectAttachment.constant = 0
            self.viewUpload.isHidden = false
            //let arr = strValue.components(separatedBy: " ")
            //self.lblSelectAttachment.text = "Next Follow Up Date: \(Utilities.getStrDateAdding(days: Int(arr[0]) ?? 0, dateFormate: "dd/MM/yyyy"))"
        }
    }
    
    @IBOutlet weak var txtSelectAttachmentReason: UITextField!
    @IBOutlet weak var constraintHeightTXTSelectAttachment: NSLayoutConstraint!
    
    @IBOutlet weak var cvUploadImg: UICollectionView! {
        didSet {
            self.cvUploadImg.delegate = self
            self.cvUploadImg.dataSource = self
            self.cvUploadImg.register(UINib(nibName: "AddOrderUploadImgCVCell", bundle: nil), forCellWithReuseIdentifier: "AddOrderUploadImgCVCell")
        }
    }
    @IBOutlet weak var constraintHeightCVUploadImg: NSLayoutConstraint!
    @IBOutlet weak var viewUpload: UIView!
    @IBOutlet weak var lblUploadPurchaseOrderTittle: UILabel!
    @IBOutlet weak var btnUpload: UIButton!
    @IBAction func btnUploadTap(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    
    @IBOutlet weak var btnSubmitSalesOrder: UIButton!
    @IBAction func btnSubmitSalesOrderTap(_ sender: UIButton) {
        
        self.dismissMyKeyboard()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            var isValid: Bool = true
            
            if self.lblSelectAttachment.text! == "Select Attachment" {
                isValid = false
                Utilities.showPopup(title: "Select attachment.", type: .error)
            }
            else if self.lblSelectAttachment.text == "NA" {
                if self.txtSelectAttachmentReason.text! == "" {
                    isValid = false
                    Utilities.showPopup(title: "Enter reason.", type: .error)
                }
            }
            else {
                if (self.arrUploadImg?.count ?? 0) > 0 {
//                    for i in 0..<(self.arrUploadImg?.count ?? 0) {
//                        if self.arrUploadImg?[i].comment == "" {
//                            isValid = false
//                            Utilities.showPopup(title: "Enter comment.", type: .error)
//                            break
//                        }
//                    }
                }
                else {
                    isValid = false
                    Utilities.showPopup(title: "Upload image.", type: .error)
                }
            }
            
            
            if self.lblFollowUpDays.text! == "Select Follow Up Days" {
                isValid = false
                Utilities.showPopup(title: "Select followup days.", type: .error)
            }
            else if self.lblFollowUpDays.text == "Custom Days" {
                if self.txtCustomFollowUpDays.text! == "" {
                    Utilities.showPopup(title: "Enter custom day(s).", type: .error)
                    isValid = false
                }
            }
            
            
            if isValid {
                print("Valid --> \(isValid)")
                
                //self.uploadImage()
                self.addNewOrder()
            }
            else {
                print("Valid --> \(isValid)")
            }
        }
    }
    
    // MARK: - Variable
    
    var strScreenTitle = "Attachment"
    var onTap: ((Bool, String)->Void)?
    
    var saveToDraftOrder = SaveToDraftOrder()
    var isFromSales: Bool = false
    var isFromSample: Bool = false
    var isFromQI: Bool = false
    var isFromPI: Bool = false
    
    var arrFollowUpDays: [String]? = []
    var intCustomFollowUpMaxDays: Int = 0
    var arrSelectAttachment: [String]? = ["Purchase Order", "Proforma Invoice", "Quotation", "NA"]
    var imagePicker = UIImagePickerController()
    var arrImg: [String] = []
    var arrUploadImg: [ImgUpload]? = []
    var arrTempUploadImg: [ImgUpload]? = []
    
    var isKeyboardActive: Bool = false
    var isFromEditRejectedOrder: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.constraintHeightTXTCustomFollowUpDays.constant = 0
        self.constraintHeightTXTSelectAttachment.constant = 0
        self.constraintHeightCVUploadImg.constant = 0
        
        self.viewUpload.isHidden = true
        
        self.btnSubmitSalesOrder.backgroundColor = Colors.theme.returnColor()
        self.btnSubmitSalesOrder.corners(radius: 15.0)
        self.btnUpload.corners(radius: 10.0)
        
        self.checkKeyboard(kView: viewMain)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if isFromEditRejectedOrder {
            self.fillOrderData()
        }
    }
    
    func fillOrderData() {
        self.lblFollowUpDays.text = "\(self.saveToDraftOrder.followUpDays ?? 0)"
        self.lblFollowUpDate.text = "Next Follow Up Date: \(Utilities.getStrDateAdding(days: self.saveToDraftOrder.followUpDays ?? 0, dateFormate: "dd/MM/yyyy"))"
        
        if (self.saveToDraftOrder.poAttachment?.count ?? 0) != 0 {
            setAttachmentDetails(strValue: self.saveToDraftOrder.poAttachment?[0].poType ?? "")
            
            for i in 0..<(self.saveToDraftOrder.poAttachment?.count ?? 0) {
                self.arrImg.append(self.saveToDraftOrder.poAttachment?[i].attachment ?? "")
                let temp = ImgUpload(img: self.saveToDraftOrder.poAttachment?[i].attachment ?? "", comment: self.saveToDraftOrder.poAttachment?[i].caption ?? "", isNew: false)
                self.arrUploadImg?.append(temp)
            }
            
            self.cvUploadImg.reloadData()
            
            DispatchQueue.main.async {
                if self.arrImg.count > 0 {
                    self.constraintHeightCVUploadImg.constant = 170
                }
                self.cvUploadImg.reloadData()
                
                if self.arrImg.count > 2 {
                    self.btnUpload.isHidden = true
                }
            }
        }
        else {
            setAttachmentDetails(strValue: "NA")
        }
    }
    
}
