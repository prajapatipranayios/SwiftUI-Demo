//
//  OrderAttachmentVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 20/06/24.
//

import Foundation
import UIKit
import MBProgressHUD

// MARK: UICollectionView Delegate, DataSource, FlowLayout

extension OrderAttachmentVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrUploadImg?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddOrderUploadImgCVCell", for: indexPath) as! AddOrderUploadImgCVCell
        
        cell.index = indexPath.item
        //cell.ivUploadImg.image = self.arrImg[indexPath.row]
        //cell.ivUploadImg.image = UIImage(named: self.arrUploadImg?[indexPath.item].img ?? "")
        cell.ivUploadImg.setImage(imageUrl: self.arrUploadImg?[indexPath.item].img ?? "")
        
        cell.txtComment.text = self.arrUploadImg?[indexPath.item].comment ?? ""
        
        cell.txtComment.tag = indexPath.item
        cell.txtComment.delegate = self
        
        cell.btnDelete.isHidden = false
        if !(self.arrUploadImg?[indexPath.row].isNew ?? false) {
            cell.btnDelete.isHidden = true
        }
        
        cell.onDeleteTap = { index in
            self.arrImg.remove(at: index)
            self.arrUploadImg?.remove(at: index)
            
            if (self.arrUploadImg?.count ?? 0) <= 0 {
                self.constraintHeightCVUploadImg.constant = 0
            }
            self.cvUploadImg.reloadData()
            self.btnUpload.isHidden = false
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        //let width = (collectionView.frame.width - 40) / 3
        let height = 170.0
        return CGSize(width: 100.0, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
}


// MARK: - Selet Image

extension OrderAttachmentVC: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
//    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!){
//        self.dismiss(animated: true, completion: { () -> Void in
//            
//        })
//        self.arrImg.append(image)
//        DispatchQueue.main.async {
//            self.cvUploadImg.reloadData()
//        }
//    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            // You now have the selected or captured image (pickedImage).
            // You can use it as needed within your app.
            
            self.imagePicker.dismiss(animated: true) {
                let checkUrl: String = String(describing: info[.referenceURL] ?? "")
                let imgUrl: String = String(describing: info[.imageURL] ?? "")
                if !self.arrImg.contains(checkUrl) {
                    self.arrImg.append(checkUrl)
                    let temp = ImgUpload(img: imgUrl, comment: "", isNew: true)
                    self.arrUploadImg?.append(temp)
                }
                else {
                    Utilities.showPopup(title: "Please select different image.", type: .error)
                }
                DispatchQueue.main.async {
                    if self.arrImg.count > 0 {
                        self.constraintHeightCVUploadImg.constant = 170
                    }
                    self.cvUploadImg.reloadData()
                    
                    if self.arrImg.count > 2 {
                        self.btnUpload.isHidden = true
                    }
                }
            }
        }
    }
}


// MARK: - TextField Delegate

extension OrderAttachmentVC: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
//        if textField.tag == 1 {
//            self.txtSelectAttachment.placeholder = ""
//        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        if textField == self.txtCustomFollowUpDays {
            if Int(self.txtCustomFollowUpDays.text ?? "0") ?? 0 > self.intCustomFollowUpMaxDays {
                self.txtCustomFollowUpDays.text = ""
            }
            switch string {
            case "0","1","2","3","4","5","6","7","8","9":
                return true
            case ".":
                return false
                
                /*let array = (textField.text)!.map { String($0) }
                 var decimalCount = 0
                 for character in array {
                 if character == "." {
                 decimalCount += 1
                 }
                 }
                 
                 if decimalCount == 1 {
                 return false
                 } else {
                 return true
                 }   //  */
            default:
                let array = Array(string)
                if array.count == 0 {
                    return true
                }
                return false
            }
        }
        else {
            return true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        
        if textField == self.txtCustomFollowUpDays {
            self.lblFollowUpDate.text = "Next Follow Up Date: \(Utilities.getStrDateAdding(days: Int(textField.text!) ?? 0, dateFormate: "dd/MM/yyyy"))"
            self.saveToDraftOrder.followUpDays = Int(self.txtCustomFollowUpDays.text ?? "") ?? 0
        }
        else if textField == self.txtSelectAttachmentReason {
            
        }
        else {
            let index = IndexPath(row: textField.tag, section: 0)
            //let cell = self.cvUploadImg.cellForRow(at: index) as! AddOrderUploadImgCVCell
            let cell = self.cvUploadImg.cellForItem(at: index) as! AddOrderUploadImgCVCell
            self.arrUploadImg?[textField.tag].comment = cell.txtComment.text ?? ""
        }
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
        }
        return value
    }
}

// MARK: - Keyboard

extension OrderAttachmentVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            self.isKeyboardActive = keyboardOverlap > 0 ? true : false
            print("Keyboard -----> \(keyboardOverlap)")
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomBSheet.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            
            //self.constraintBottomTVProductList.constant = keyboardOverlap > 0 ? (keyboardOverlap - 85) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}


// MARK: - WebServices

extension OrderAttachmentVC {
    
    func addNewOrder() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addNewOrder()
                }
            }
            return
        }
        
        let tempDictQue: [String: String] = [:]
        
        var products: [Any] = []
        for i in 0..<(self.saveToDraftOrder.products?.count ?? 0) {
            
            var productWarehouse: [Any] = []
            for j in 0..<(self.saveToDraftOrder.products?[i].productWarehouse?.count ?? 0) {
                let tempProductWarehouse = [
                    "available": self.saveToDraftOrder.products?[i].productWarehouse?[j].available ?? 0,
                    "branchId": self.saveToDraftOrder.products?[i].productWarehouse?[j].branchId ?? 0,
                    "city": self.saveToDraftOrder.products?[i].productWarehouse?[j].city ?? "",
                    "inCommited": self.saveToDraftOrder.products?[i].productWarehouse?[j].inCommited ?? 0,
                    "inStock": self.saveToDraftOrder.products?[i].productWarehouse?[j].inStock ?? "",
                    "productId": self.saveToDraftOrder.products?[i].productWarehouse?[j].productId ?? 0
                  ] as [String : Any]
                productWarehouse.append(tempProductWarehouse)
            }
            
            let tempProduct = [
                "categoryId": self.saveToDraftOrder.products?[i].categoryId ?? 0,
                "categoryName": self.saveToDraftOrder.products?[i].categoryName ?? "",
                "commission": self.saveToDraftOrder.products?[i].commission ?? 0,
                "description": self.saveToDraftOrder.products?[i].description ?? "",
                "discount_amount": self.saveToDraftOrder.products?[i].discountAmount ?? 0,
                "discount_price": self.saveToDraftOrder.products?[i].discountPrice ?? 0,
                "hsnNumber": self.saveToDraftOrder.products?[i].hsnNumber ?? "",
                "lastPrice": self.saveToDraftOrder.products?[i].lastPrice ?? 0,
                "maxDiscount": self.saveToDraftOrder.products?[i].maxDiscount ?? 0,
                "pack_size": self.saveToDraftOrder.products?[i].packSize ?? 0,
                "productUnitMesurement": self.saveToDraftOrder.products?[i].productUnitMesurement ?? "",
                "productWarehouse": productWarehouse,
                "product_basic_price": self.saveToDraftOrder.products?[i].productBasicPrice ?? "",
                "product_code": self.saveToDraftOrder.products?[i].productCode ?? "",
                "product_id": self.saveToDraftOrder.products?[i].id ?? "",
                "moq": self.saveToDraftOrder.products?[i].moq ?? 0,
                "product_name": self.saveToDraftOrder.products?[i].productName ?? "",
                "product_old_price": self.saveToDraftOrder.products?[i].productOldPrice ?? 0,
                "product_price": self.saveToDraftOrder.products?[i].productPrice ?? 0,
                "quantity": self.saveToDraftOrder.products?[i].quantity ?? 0,
                "product_total": self.saveToDraftOrder.products?[i].productTotal ?? 0,
                "product_unit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "productUnit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "moq_unit": self.saveToDraftOrder.products?[i].moqUnit ?? "",
                //"questions": self.saveToDraftOrder.products?[i].questions ?? "",
                "questions": tempDictQue,
                "remark": self.saveToDraftOrder.products?[i].remark ?? "",
                "showWarehouse": self.saveToDraftOrder.products?[i].showWarehouse ?? "",
                "status": self.saveToDraftOrder.products?[i].status ?? 0,
                "storeQty": self.saveToDraftOrder.products?[i].storeQty ?? 0,
                "tax": self.saveToDraftOrder.products?[i].tax ?? 0,
                "userCommission": self.saveToDraftOrder.products?[i].userCommission ?? 0,
                "userCommissionByCategory": [
                ],
                "warehouseQty": self.saveToDraftOrder.products?[i].warehouseQty ?? ""
              ] as [String : Any]
            products.append(tempProduct)
        }
        
        var transportNamelist: [Any] = []
        for i in 0..<(self.saveToDraftOrder.transportNamelist?.count ?? 0) {
            let tempTransportNamelist = [
                "position": self.saveToDraftOrder.transportNamelist?[i].position ?? false,
                "transporterCode": self.saveToDraftOrder.transportNamelist?[i].transporterCode ?? "",
                "transporterGSTNo": self.saveToDraftOrder.transportNamelist?[i].transporterGSTNo ?? "",
                "transporterId": self.saveToDraftOrder.transportNamelist?[i].transporterId ?? 0,
                "transporterTitle": self.saveToDraftOrder.transportNamelist?[i].transporterTitle ?? ""
            ] as [String : Any]
            transportNamelist.append(tempTransportNamelist)
        }
        
        var businessPTransportNamelist: [Any] = []
        for i in 0..<(self.saveToDraftOrder.businessPartnerTransporter?.count ?? 0) {
            
            let tempTransport = [
                "transporterID": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterID ?? 0,
                "transporterCode": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterCode ?? "",
                "transporterTitle": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterTitle ?? "",
                "transporterGSTNo": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterGSTNo ?? 0,
                "businessPartnersID": self.saveToDraftOrder.businessPartnerTransporter?[i].businessPartnersID ?? 0
            ] as [String : Any]
            businessPTransportNamelist.append(tempTransport)
        }
        
        let tempPaymentDetail = [
            "id": self.saveToDraftOrder.paymentsDetail?.id ?? 0,
            "paymentType": self.saveToDraftOrder.paymentsDetail?.paymentType ?? 0,
            "ordersId": self.saveToDraftOrder.paymentsDetail?.ordersId ?? 0,
            "paymentMode": self.saveToDraftOrder.paymentsDetail?.paymentMode ?? 0,
            "creditDay": self.saveToDraftOrder.paymentsDetail?.creditDay ?? 0,
            "paymentAmount": self.saveToDraftOrder.paymentsDetail?.paymentAmount ?? 0.0,
            "paymentDate": self.saveToDraftOrder.paymentsDetail?.paymentDate ?? "",
            "paymentTransactionId": self.saveToDraftOrder.paymentsDetail?.paymentTransactionId ?? "",
            "paymentChequeNo": self.saveToDraftOrder.paymentsDetail?.paymentChequeNo ?? "",
            "hasApproval": self.saveToDraftOrder.paymentsDetail?.hasApproval ?? 0,
            "paymentStatus": self.saveToDraftOrder.paymentsDetail?.paymentStatus ?? 0,
            "createdAt": self.saveToDraftOrder.paymentsDetail?.createdAt ?? "",
            "updatedAt": self.saveToDraftOrder.paymentsDetail?.updatedAt ?? ""
        ] as [String : Any]
        
        let param = [ "user_id": APIManager.sharedManager.userId,
                      "billing_address_id": self.saveToDraftOrder.billingAddressID ?? 0,
                      "billing_address_name": self.saveToDraftOrder.billingAddressName ?? "",
                      "booking_point": self.saveToDraftOrder.bookingPoint ?? "",
                      "branch_id": self.saveToDraftOrder.branchID ?? 0,
                      "branchName": self.saveToDraftOrder.branchName ?? "",
                      "businessPartnerTransporter": businessPTransportNamelist,
                      "business_partners_id": self.saveToDraftOrder.businessPartnersID ?? 0,
                      "business_partner_name": self.saveToDraftOrder.businessPartnerName ?? "",
                      "businesscode": self.saveToDraftOrder.businesscode ?? "",
                      "cgstAmount": self.saveToDraftOrder.cgstAmount ?? 0,
                      "comment": self.saveToDraftOrder.comment ?? "",
                      "company_type": 1,
                      "credit_day": self.saveToDraftOrder.creditDay ?? "",
                      "deliveryTo": self.saveToDraftOrder.deliveryTo ?? "",
                      "delivery_address_id": self.saveToDraftOrder.deliveryAddressID ?? "",
                      "delivery_address_name": self.saveToDraftOrder.deliveryAddressName ?? "",
                      "draft_id": self.saveToDraftOrder.draftID ?? 0,
                      "follow_up_days": self.saveToDraftOrder.followUpDays ?? 0,
                      "freight": self.saveToDraftOrder.freight ?? 0,
                      "freight_charges": self.saveToDraftOrder.freightCharges ?? "",
                      "freight_gst": self.saveToDraftOrder.freightGst ?? 0,
                      "grand_total_amount": self.saveToDraftOrder.grandTotalAmount ?? "",
                      "gstTotal": self.saveToDraftOrder.gstTotal ?? 0,
                      "hand_delivery_text": self.saveToDraftOrder.handDeliveryText ?? "",
                      "igstAmount": self.saveToDraftOrder.igstAmount ?? 0,
                      "isEditableOrder": self.saveToDraftOrder.isEditableOrder ?? false,
                      "lastTransporterId": self.saveToDraftOrder.lastTransporterID ?? 0,
                      "order_delivery_type": self.saveToDraftOrder.orderDeliveryType ?? "",
                      "order_id": ((self.saveToDraftOrder.orderID ?? 0) == 0 ? "" : (self.saveToDraftOrder.orderID ?? 0)),
                      "order_type": self.saveToDraftOrder.orderType ?? 0,
                      "otherTransporter": self.saveToDraftOrder.otherTransporter ?? "",
                      "payment_amount": self.saveToDraftOrder.paymentAmount ?? "",
                      "payment_cheque_no": self.saveToDraftOrder.paymentChequeNo ?? "",
                      "payment_date": self.saveToDraftOrder.paymentDate ?? "",
                      "payment_mode": self.saveToDraftOrder.paymentMode ?? "",
                      "payment_transaction_id": self.saveToDraftOrder.paymentTransactionID ?? "",
                      "payment_type": self.saveToDraftOrder.paymentType ?? "",
                      "paymentsDetail": tempPaymentDetail,   //self.saveToDraftOrder.paymentsDetail ?? "",
                      "poAttachment": [],
                      "preferredBranchId": self.saveToDraftOrder.preferredBranchID ?? 0,
                      "products": products,
                      "qiValidity": self.saveToDraftOrder.qiValidity ?? "",
                      "qi_pi_id": self.saveToDraftOrder.qiPiID ?? 0,
                      "referenceEmployeeName": self.saveToDraftOrder.referenceEmployeeName ?? "",
                      "remainder_id": self.saveToDraftOrder.remainderID ?? 0,
                      "required_date": self.saveToDraftOrder.requiredDate ?? "",
                      "sAPId": self.saveToDraftOrder.sAPID ?? "",
                      "sample__request_id": self.saveToDraftOrder.sampleRequestID ?? "",
                      "sgstAmount": self.saveToDraftOrder.sgstAmount ?? 0,
                      "transportNamelist": transportNamelist,
                      "transporterGSTNo": self.saveToDraftOrder.transporterGSTNo ?? "",
                      "transporter_id": self.saveToDraftOrder.transporterID ?? "",
                      "transporter_title": self.saveToDraftOrder.transporterTitle ?? ""
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_NEW_ORDER, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    if (self.lblSelectAttachment.text ?? "") == "NA" {
                        self.savePOAattachment(orderId: response?.result?.orderId ?? 0)
                    }
                    else {
                        //self.showLoadingWMsg(strMsg: "Uploading image...")
                        //self.arrTempUploadImg = self.arrUploadImg
                        for (_, value) in (self.arrUploadImg ?? []).enumerated() {
                            if value.isNew ?? false {
                                self.arrTempUploadImg?.append(value)
                            }
                        }
                        
                        if (self.arrTempUploadImg?.count ?? 0) != 0 {
                            self.showLoadingWMsg(strMsg: "Uploading image...")
                            self.uploadImage(orderId: response?.result?.orderId ?? 0)
                        }
                        else {
                            DispatchQueue.main.async {
                                self.dismiss(animated: true) {
                                    if self.onTap != nil {
                                        self.onTap!(true, response?.message ?? "")
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func savePOAattachment(orderId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.savePOAattachment(orderId: orderId)
                }
            }
            return
        }
        
        let param = [ "user_id": APIManager.sharedManager.userId,
                      "order_id": orderId,
                      "po_type": self.lblSelectAttachment.text ?? "",
                      "reason": self.txtSelectAttachmentReason.text ?? "",
                      "caption": "",
                      "attachment": ""
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.SAVE_ORDER_POATTACHMENT, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //Utilities.showPopup(title: response?.message ?? "", type: .success)
                    DispatchQueue.main.async {
                        self.dismiss(animated: true) {
                            if self.onTap != nil {
                                self.onTap!(true, response?.message ?? "")
                            }
                        }
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func uploadImage(orderId: Int, index: Int = 0) {
        var imgFileName: String = ""
        imgFileName = imgFileName == "" ? (URL(string: (self.arrTempUploadImg?[index].img ?? ""))?.lastPathComponent)! : imgFileName
        imgFileName = imgFileName != "" ? imgFileName : "\(Utilities.fileName()).png"
        var ivUploadImg = UIImageView()
        ivUploadImg.setImage(imageUrl: self.arrTempUploadImg?[index].img ?? "")
        
        //showLoading()
        APIManager.sharedManager.uploadImage(url: APIManager.sharedManager.SAVE_ORDER_POATTACHMENT,
                                             dictiParam: [ "user_id": APIManager.sharedManager.userId,
                                                           "order_id": orderId,
                                                           "po_type": self.lblSelectAttachment.text ?? "",
                                                           "reason": self.txtSelectAttachmentReason.text ?? "",
                                                           "caption": self.arrTempUploadImg?[index].comment ?? "",
                                                           "image": imgFileName],
                                             image: ivUploadImg.image as Any,
                                             type: "image",
                                             contentType: imgFileName.mimeType())
        { isValid, strValue in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                //self.hideLoading()
                if ((self.arrTempUploadImg?.count ?? 0) - 1) > index {
                    let i = index + 1
                    self.uploadImage(orderId: orderId, index: i)
                }
                else {
                    //Utilities.showPopup(title: strValue, type: .success)
                    self.hideLoadingWMsg()
                    DispatchQueue.main.async {
                        self.dismiss(animated: true) {
                            if self.onTap != nil {
                                self.onTap!(true, strValue)
                            }
                        }
                    }
                }
            }
        } errorCompletion: { isValid, strValue in
            self.hideLoadingWMsg()
        }
    }
}
