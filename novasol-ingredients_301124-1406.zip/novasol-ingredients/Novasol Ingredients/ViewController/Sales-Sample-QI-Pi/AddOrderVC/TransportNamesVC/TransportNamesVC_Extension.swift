//
//  TransportNamesVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 14/06/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, DataSource

extension TransportNamesVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.isAddMoreTransporter {
            return self.arrTransporters?.count ?? 0
        }
        else {
            return self.arrBPTransporters?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if self.isAddMoreTransporter {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TransportNamesTVCell", for: indexPath) as! TransportNamesTVCell
            cell.index = indexPath.row
            cell.lblName.text = self.arrTransporters?[indexPath.row].transporterTitle ?? ""
            cell.lblName.textColor = Colors.theme.returnColor()
            cell.constraiantBottomLblNameToSuperView.priority = .required
            
            if self.arrSelectedTransporter.contains("\(self.arrTransporters?[indexPath.row].transporterId ?? 0)") {
                cell.btnSelect.isSelected = true
                cell.btnSelect.tintColor = Colors.themeGreen.returnColor()
            }
            else {
                cell.btnSelect.isSelected = false
                cell.btnSelect.tintColor = Colors.gray.returnColor()
            }
            
            cell.didSelect = { index in
                if self.arrSelectedTransporter.contains("\(self.arrTransporters?[index].transporterId ?? 0)") {
                    for z in 0 ..< self.arrSelectedTransporter.count {
                        if self.arrSelectedTransporter[z] == "\(self.arrTransporters?[index].transporterId ?? 0)" {
                            self.arrSelectedTransporter.remove(at: z)
                            self.arrSTransporter.remove(at: z)
                            print("ASDFG --> \((self.arrTransporters ?? [])[index])")
                            break
                        }
                    }
                }
                else {
                    if self.arrSelectedTransporter.count < self.intAddOtherTransporterLimit {
                        self.arrSelectedTransporter.append("\(self.arrTransporters?[index].transporterId ?? 0)")
                        self.arrSTransporter.append((self.arrTransporters ?? [])[index])
                    }
                }
                self.tvList.reloadData()
            }
            
            if self.hasMore {
                if indexPath.row >= ((self.arrBPTransporters?.count ?? 0) - 5) {
                    self.page += 1
                    self.getTransporter(intCourier: 0, searchText: self.searchText, page: self.page, companyType: self.companyType)
                }
            }
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TransportNamesTVCell", for: indexPath) as! TransportNamesTVCell
            cell.index = indexPath.row
            cell.lblName.text = self.arrBPTransporters?[indexPath.row].transporterTitle ?? ""
            cell.lblName.textColor = Colors.theme.returnColor()
            
            if (self.arrSelectedTransporter ?? []).contains("\(self.arrBPTransporters?[indexPath.row].transporterId ?? 0)") {
                cell.btnSelect.isSelected = true
                cell.btnSelect.tintColor = Colors.themeGreen.returnColor()
            }
            else {
                cell.btnSelect.isSelected = false
                cell.btnSelect.tintColor = Colors.gray.returnColor()
            }
            
            cell.btnSelect.isSelected = false
            cell.btnSelect.tintColor = Colors.gray.returnColor()
            cell.constraiantBottomLblNameToSuperView.priority = .required
            if self.isOtherTap {
                if (self.arrBPTransporters?[indexPath.row].transporterTitle ?? "") == "Other" {
                    cell.constraiantBottomLblNameToSuperView.priority = .defaultLow
                    cell.btnSelect.isSelected = true
                    cell.btnSelect.tintColor = Colors.themeGreen.returnColor()
                }
                
                cell.onAddTap = { strValue in
                    self.dismiss(animated: true) {
                        if self.didSelect != nil {
                            self.didSelect!(false, 0, self.arrBPTransporters ?? [], strValue)
                        }
                    }
                }
            }
            
            cell.didSelect = { index in
                if (self.arrBPTransporters?[index].transporterTitle ?? "") == "Other" {
                    self.isOtherTap = true
                    self.tvList.reloadData()
                }
                else {
                    self.dismiss(animated: true) {
                        if self.didSelect != nil {
                            self.didSelect!(true, index, self.arrBPTransporters ?? [], "")
                        }
                    }
                }
            }
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

// MARK: - SearchBar Delegate

extension TransportNamesVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        if searchText != "" {
            self.page = 1
            self.searchText = searchText
            self.getTransporter(intCourier: 0, searchText: self.searchText, page: self.page, companyType: self.companyType)
        }
        else {
            self.page = 1
            self.searchText = searchText
            self.getTransporter(intCourier: 0, searchText: self.searchText, page: self.page, companyType: self.companyType)
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
        self.searchBar.text = ""
        self.page = 1
        self.searchText = ""
        self.getTransporter(intCourier: 0, searchText: self.searchText, page: self.page, companyType: self.companyType)
    }
}

// MARK: - UITextFieldDelegate

extension TransportNamesVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
//        if textField == self.txtCompanyName {
//            self.page = 1
//            self.strSearchText = newString as String
//            self.getExistBusinessPaartner(searchText: self.strSearchText ?? "", page: self.page)
//            return true
//        }
//        else if (textField == self.txtTeleNo) || (textField == self.txtSContactNo) {
//            if (self.txtTeleNo.text?.isNumber)! || (self.txtSContactNo.text?.isNumber)! {
//                return newString.length <= MAX_TELE_LENGTH
//            }
//            else {
//                return true
//            }
//        }
//        else if (textField == self.txtMobileNo) || (textField == self.txtPContactNo) {
//            if (self.txtMobileNo.text?.isNumber)! || (self.txtPContactNo.text?.isNumber)! {
//                return newString.length <= MAX_MOBILE_LENGTH
//            }
//            else {
//                return true
//            }
//        }
//        else if (textField == self.txtZipCode) || (textField == self.txtDZipCode) {
//            if (self.txtZipCode.text?.isNumber)! || (self.txtDZipCode.text?.isNumber)! {
//                return newString.length <= MAX_ZIP_LENGTH
//            }
//            else {
//                return true
//            }
//        }
//        else if textField == self.txtAnnualTurnover {
//            switch string {
//            case "0","1","2","3","4","5","6","7","8","9":
//                return true
//            case ".":
//                let array = (textField.text)!.map { String($0) }
//                var decimalCount = 0
//                for character in array {
//                    if character == "." {
//                        decimalCount += 1
//                    }
//                }
//                
//                if decimalCount == 1 {
//                    return false
//                } else {
//                    return true
//                }
//            default:
//                let array = Array(string)
//                if array.count == 0 {
//                    return true
//                }
//                return false
//            }
//        }
//        else if textField == self.txtPAN {
//            return newString.length <= MAX_MOBILE_LENGTH
//        }
//        else {
            return true
//        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //self.txtCompanyName.resignFirstResponder()
        textField.resignFirstResponder()
           
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        if self.checkValidation(to: textField.tag, from: textField.tag + 1) {
        }
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            
            // Add Transport
            if i == 0 {
                self.txtTransportTitle.text = self.txtTransportTitle.text?.trimmingCharacters(in: .whitespaces)
                if self.txtTransportTitle.text == "" {
                    self.lblErrorTransportTitle.text = "Please \((self.txtTransportTitle.placeholder ?? "").lowercased())"
                    value = false
                }
                else {
                    self.lblErrorTransportTitle.text = ""
                }
            }
        }
        return value
    }
}


// MARK: - Webservices

extension TransportNamesVC {
    func getTransporter(intCourier: Int = 0, searchText: String, page: Int, companyType: Int = 1) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getTransporter(intCourier: intCourier, searchText: searchText, page: page, companyType: companyType)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "is_courier": intCourier,
            "search_value": searchText,
            "page": page,
            "company_type": APIManager.sharedManager.companyType ?? 1
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_TRANSPORTERS, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    let arrTempTransporters = response?.result?.transporters ?? []
                    if page == 1 {
                        self.arrTransporters = arrTempTransporters
                    }
                    else if page > 1 {
                        self.arrTransporters?.append(contentsOf: arrTempTransporters)
                    }
                    self.tvList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func addTransporter() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addTransporter()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": APIManager.sharedManager.companyType ?? 1,
            "transporter_title": self.txtTransportTitle.text!,
            "transporter_email_id": self.txtTransportEmail.text!,
            "transporter_tel_no": self.txtTransportTelNo.text!,
            "transporter_mobile_no": self.txtTransportMobile.text!,
            "transporter_address": self.txtTransportAddress.text!,
            "transporter_desc": self.txtTransportDesc.text!,
            "transporter_GSTNo": self.txtTransportGSTNo.text!
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_TRANSPORTER, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.viewMain.isHidden = false
                    self.viewTransport.isHidden = true
                    
                    self.txtTransportTitle.text = ""
                    self.txtTransportEmail.text = ""
                    self.txtTransportTelNo.text = ""
                    self.txtTransportMobile.text = ""
                    self.txtTransportGSTNo.text = ""
                    self.txtTransportAddress.text = ""
                    self.txtTransportDesc.text = ""
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func saveTransporter() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.saveTransporter()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partners_id": self.intBusinessPId,
            "transporter": self.arrSelectedTransporter ?? []
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.SAVE_TRANSPORTER, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.displayMessage(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func displayMessage(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.updateNewTransporter()
        }
        self.present(popupVC, animated: true)
    }
}
