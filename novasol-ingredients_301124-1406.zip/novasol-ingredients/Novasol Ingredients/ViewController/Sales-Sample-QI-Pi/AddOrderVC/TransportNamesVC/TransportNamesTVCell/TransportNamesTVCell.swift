//
//  TransportNamesTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 17/06/24.
//

import UIKit

class TransportNamesTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnSelect: UIButton!
    @IBAction func btnSelectTap(_ sender: UIButton) {
        if self.didSelect != nil {
            self.didSelect!(self.index)
        }
    }
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var constraiantBottomLblNameToSuperView: NSLayoutConstraint!
    //@IBOutlet weak var txtTransportName: TLTextField!
    @IBOutlet weak var txtTransportName: UITextField!
    @IBOutlet weak var btnAdd: UIButton!
    @IBAction func btnAddTap(_ sender: UIButton) {
        if self.onAddTap != nil {
            self.onAddTap!(self.txtTransportName.text ?? "")
        }
    }
    
    // MARK: - Variable
    
    var didSelect: ((Int)->Void)?
    var index: Int = 0
    var onAddTap: ((String)->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.btnAdd.corners(radius: 8.0)
        self.btnAdd.backgroundColor = Colors.theme.returnColor()
        self.btnAdd.setTitleColor(.white, for: .normal)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
