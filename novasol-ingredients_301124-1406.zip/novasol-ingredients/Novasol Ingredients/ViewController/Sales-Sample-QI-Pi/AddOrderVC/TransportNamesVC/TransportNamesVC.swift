//
//  TransportNamesVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 14/06/24.
//

import UIKit

class TransportNamesVC: UIViewController {
    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain : UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        if self.isAddMoreTransporter {
            self.constraintBottomTVListToSuperView.priority = .defaultLow
            self.isAddMoreTransporter = false
            
            self.costraintHeightSearchBar.constant = 0
            
            self.btnAdd.setImage(UIImage(systemName: "plus.circle"), for: .normal)
            self.btnAdd.imageView?.contentMode = .scaleAspectFit
            self.tvList.reloadData()
        }
        else {
            self.dismiss(animated: true) {
            }
        }
    }
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var costraintHeightSearchBar: NSLayoutConstraint!
    
    @IBOutlet weak var tvList: UITableView! {
        didSet {
            self.tvList.delegate = self
            self.tvList.dataSource = self
            self.tvList.register(UINib(nibName: "TransportNamesTVCell", bundle: nil), forCellReuseIdentifier: "TransportNamesTVCell")
        }
    }
    @IBOutlet weak var constraintBottomTVListToSuperView: NSLayoutConstraint!
    
    @IBOutlet weak var btnSelectMoreTransporter: UIButton!
    @IBAction func btnSelectMoreTransporterTap(_ sender: UIButton) {
        self.isAddMoreTransporter = true
        self.constraintBottomTVListToSuperView.priority = .required
        
        self.searchBar.text = ""
        self.searchText = ""
        
        self.costraintHeightSearchBar.constant = 45
        
        self.btnAdd.setImage(UIImage(systemName: "checkmark"), for: .normal)
        self.btnAdd.imageView?.contentMode = .scaleAspectFit
        //call api
        self.getTransporter(intCourier: 0, searchText: self.searchText, page: self.page, companyType: self.companyType)
    }
    
    // Add Transporter
    
    @IBOutlet weak var btnAdd: UIButton!
    @IBAction func btnAddTap(_ sender: UIButton) {
        if self.isAddMoreTransporter {
            self.saveTransporter()
        }
        else {
            self.viewMain.isHidden = true
            self.viewTransport.isHidden = false
        }
    }
    
    @IBOutlet weak var viewTransport: UIView!
    @IBOutlet weak var viewTransportBack: UIView!
    @IBOutlet weak var lblTransportScreenTitle: UILabel!
    @IBOutlet weak var btnTransportBack: UIButton!
    @IBAction func btnTransportBackTap(_ sender: UIButton) {
        self.viewMain.isHidden = false
        self.viewTransport.isHidden = true
        view.endEditing(true)
    }
    
    @IBOutlet weak var viewScrollViewOut: UIView!
    @IBOutlet weak var constraintBottomViewScrollViewOut: NSLayoutConstraint!
    @IBOutlet weak var viewScrollViewIn: UIView!
    
    @IBOutlet weak var txtTransportTitle: TLTextField!
    @IBOutlet weak var lblErrorTransportTitle: UILabel!
    
    @IBOutlet weak var txtTransportEmail: TLTextField!
    @IBOutlet weak var lblErrorTransportEmail: UILabel!
    
    @IBOutlet weak var txtTransportTelNo: TLTextField!
    @IBOutlet weak var lblErrorTransportTelNo: UILabel!
    
    @IBOutlet weak var txtTransportMobile: TLTextField!
    @IBOutlet weak var lblErrorTransportMobile: UILabel!
    
    @IBOutlet weak var txtTransportGSTNo: TLTextField!
    @IBOutlet weak var lblErrorTransportGSTNo: UILabel!
    
    @IBOutlet weak var txtTransportAddress: TLTextField!
    @IBOutlet weak var lblErrorTransportAddress: UILabel!
    
    @IBOutlet weak var txtTransportDesc: TLTextField!
    @IBOutlet weak var lblErrorTransportDesc: UILabel!
    
    @IBOutlet weak var btnTransportSubmit: UIButton!
    @IBAction func btnTransportSubmitTap(_ sender: UIButton) {
        var isAddTransportValid: Bool = true
        isAddTransportValid = self.checkValidation(to: 0, from: 1)
        if isAddTransportValid {
            self.addTransporter()
        }
    }
    
    // MARK: - Variable
    
    var didSelect: ((Bool, Int, [Transporter], String)->Void)?
    var arrBPTransporters: [Transporter]? = []
    var arrTransporters: [Transporter]? = []
    var arrSelectedTransporter: [String] = []
    var arrSTransporter: [Transporter] = []
    var searchText: String = ""
    var isAddMoreTransporter: Bool = false
    var hasMore: Bool = false
    var page: Int = 1
    var companyType: Int = 1
    var isOtherTap: Bool = false
    var intAddOtherTransporterLimit: Int = 3
    var intBusinessPId: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.btnSelectMoreTransporter.corners(radius: self.btnSelectMoreTransporter.frame.height / 2)
        
        self.arrSTransporter = self.arrBPTransporters ?? []
        self.arrSTransporter.removeAll(where: { $0.transporterId == 0 })
        
        self.arrSelectedTransporter = self.arrSTransporter.map { "\($0.transporterId ?? 0)" }
        
        if (self.arrBPTransporters?.count ?? 0) > 3 {
            self.constraintBottomTVListToSuperView.priority = .required
        }
        else {
            self.constraintBottomTVListToSuperView.priority = .defaultLow
            
            self.intAddOtherTransporterLimit = 3
        }
        self.costraintHeightSearchBar.constant = 0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
}

extension TransportNamesVC {
    func updateNewTransporter() {
        self.arrBPTransporters?.removeAll()
//        for i in 0 ..< (self.arrSelectedTransporter.count) {
//            let tempTransporter = self.arrTransporters?.filter { "\($0.transporterId!)" == (self.arrSelectedTransporter[i]) }
//            self.arrBPTransporters?.append(contentsOf: tempTransporter ?? [])
//        }
        self.arrBPTransporters = self.arrSTransporter
        
        let tempTransporter = Transporter(transporterId: 0, transporterTitle: "Other")
        self.arrBPTransporters?.append(tempTransporter)
        
        self.isAddMoreTransporter = false
        
        self.searchBar.text = ""
        self.searchText = ""
        
        self.costraintHeightSearchBar.constant = 0
        
        self.btnAdd.setImage(UIImage(systemName: "plus.circle"), for: .normal)
        self.btnAdd.imageView?.contentMode = .scaleAspectFit
        
        if (self.arrBPTransporters?.count ?? 0) > 3 {
            self.constraintBottomTVListToSuperView.priority = .required
        }
        else {
            self.constraintBottomTVListToSuperView.priority = .defaultLow
            self.intAddOtherTransporterLimit = 3
        }
        self.tvList.reloadData()
    }
}
