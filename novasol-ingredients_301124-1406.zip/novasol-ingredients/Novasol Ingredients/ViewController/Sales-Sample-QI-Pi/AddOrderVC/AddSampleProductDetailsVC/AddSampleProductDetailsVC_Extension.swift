//
//  AddSampleProductDetailsVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 28/06/24.
//

import Foundation
import UIKit


// MARK: - 

extension AddSampleProductDetailsVC {
}


// MARK: UICollectionView Delegate, DataSource, FlowLayout

extension AddSampleProductDetailsVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return (self.arrWarehouse?.count ?? 0) + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return rowHeaders.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WarehouseCVCell", for: indexPath) as! WarehouseCVCell
        cell.lblValue.backgroundColor = .clear
        if indexPath.section == 0 {
            cell.lblValue.text = rowHeaders[indexPath.item]
            cell.lblValue.textAlignment = .left
            cell.viewMain.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        }
        else {
            cell.viewMain.backgroundColor = .white
            if indexPath.item == 0 {
                //let warehouse = APIManager.sharedManager.userDetail?.warehouse?.filter { $0.id == self.productDetails?.productWarehouse?[indexPath.section - 1].branchId ?? 0 }
                let warehouse = APIManager.sharedManager.userDetail?.warehouse?.filter { $0.id == self.arrWarehouse?[indexPath.section - 1].branchId ?? 0 }
                cell.lblValue.text = "\(warehouse?[0].branchName ?? "")"
                cell.lblValue.textAlignment = .left
            }
            else if indexPath.item == 1 {
                //cell.lblValue.text = "\(self.productDetails?.productWarehouse?[indexPath.section - 1].inStock ?? "")"
                cell.lblValue.text = "\(self.arrWarehouse?[indexPath.section - 1].inStock ?? "")"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 2 {
                //cell.lblValue.text = "\(self.productDetails?.productWarehouse?[indexPath.section - 1].inCommited ?? 0)"
                cell.lblValue.text = "\(self.arrWarehouse?[indexPath.section - 1].inCommited ?? 0)"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 3 {
                //cell.lblValue.text = "\(self.productDetails?.productWarehouse?[indexPath.section - 1].available ?? 0)"
                cell.lblValue.text = "\(self.arrWarehouse?[indexPath.section - 1].available ?? 0)"
                cell.lblValue.textAlignment = .center
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 0) / 4
        let height = 40.0
        return CGSize(width: width, height: height)
    }
}


// MARK: - Keyboard

extension AddSampleProductDetailsVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomBSheet.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            
            self.constraintBottomScrollViewToSuperView.constant = keyboardOverlap > 0 ? keyboardOverlap : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}
