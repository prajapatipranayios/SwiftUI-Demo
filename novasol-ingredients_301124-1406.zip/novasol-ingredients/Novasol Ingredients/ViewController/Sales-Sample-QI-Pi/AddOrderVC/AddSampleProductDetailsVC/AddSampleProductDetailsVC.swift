//
//  AddSampleProductDetailsVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/06/24.
//

import UIKit

class AddSampleProductDetailsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onSaveTap != nil {
                if !self.isFromEditProduct {
                    self.arrSelectedProductList?.removeLast()
                }
                self.onSaveTap!(false, true, self.arrSelectedProductList, self.arrDictQueAns)
            }
        }
    }
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnAdd: UIButton!
    @IBAction func btnAddTap(_ sender: UIButton) {
        var isValid: Bool = true
         
        if self.txtQuantity.text == "" {
            isValid = false
            Utilities.showPopup(title: "Please add at least one quantity", type: .error)
        }
        else if self.txtAns1.text == "" {
            isValid = false
            Utilities.showPopup(title: "Please enter sample for which applications!!", type: .error)
        }
        else if self.txtAns2.text == "" {
            isValid = false
            Utilities.showPopup(title: "Please enter trial batch size!!", type: .error)
        }
        else if self.txtAns3.text == "" {
            isValid = false
            Utilities.showPopup(title: "Please enter which brand client is currently using!!", type: .error)
        }
        else if self.txtAns4.text == "" {
            isValid = false
            Utilities.showPopup(title: "Please enter potential monthly quentity!!", type: .error)
        }
        
        if isValid {
            self.arrSelectedProductList?[self.intProductIndex].quantity = Double(self.txtQuantity.text ?? "0")
            self.arrSelectedProductList?[self.intProductIndex].productUnit = self.lblQtyUnit.text ?? ""
            self.arrSelectedProductList?[self.intProductIndex].moq = Double(self.txtMOQ.text ?? "0")
            self.arrSelectedProductList?[self.intProductIndex].moqUnit = self.lblMOQUnit.text ?? ""
            
            self.arrDictQueAns[self.intProductIndex][self.strQue1] = self.txtAns1.text ?? ""
            self.arrDictQueAns[self.intProductIndex][self.strQue2] = self.txtAns2.text ?? ""
            self.arrDictQueAns[self.intProductIndex][self.strQue3] = self.txtAns3.text ?? ""
            self.arrDictQueAns[self.intProductIndex][self.strQue4_1] = self.txtAns4.text ?? ""
            self.arrDictQueAns[self.intProductIndex][self.strQue4_2] = self.lblPotentialUnit.text ?? ""
            self.arrDictQueAns[self.intProductIndex][self.strQue4_3] = self.lblPotentialTimeUnit.text ?? ""
            
            if self.isFromEditProduct {
                self.dismiss(animated: true) {
                    if self.onSaveTap != nil {
                        self.onSaveTap!(false, false, self.arrSelectedProductList, self.arrDictQueAns)
                    }
                }
            }
            else {
                let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
                popupVC.titleTxt = Title.ConfirmationPopupTitle
                popupVC.modalPresentationStyle = .overCurrentContext
                popupVC.modalTransitionStyle = .crossDissolve
                popupVC.strMessage = "Do you want to add more products ?"
                popupVC.colorTitleText = .black
                popupVC.colorBtnYesText = Colors.theme.returnColor()
                popupVC.colorBtnNoText = Colors.theme.returnColor()
                popupVC.onYesTap = { ans in
                    self.dismiss(animated: true) {
                        if self.onSaveTap != nil {
                            self.onSaveTap!(true, false, self.arrSelectedProductList, self.arrDictQueAns)
                        }
                    }
                }
                popupVC.onNoTap = { ans in
                    self.dismiss(animated: true) {
                        if self.onSaveTap != nil {
                            self.onSaveTap!(false, false, self.arrSelectedProductList, self.arrDictQueAns)
                        }
                    }
                }
                self.present(popupVC, animated: true)
            }
        }
    }
    
    @IBOutlet weak var viewProductDetails: UIView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    
    @IBOutlet weak var lblBasePrice: UILabel!
    
    @IBOutlet weak var viewTabButtonsM: UIView!
    @IBOutlet weak var viewTabButtons: UIView!
    @IBOutlet weak var btnSampleRequest: UIButton!
    @IBAction func btnSampleRequestTap(_ sender: UIButton) {
        
        self.btnDetails.layer.shadowOpacity = 0
        self.btnDetails.backgroundColor = .clear
        self.btnDetails.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnDetails.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.btnSampleRequest.backgroundColor = .white
        self.btnSampleRequest.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnSampleRequest.titleLabel?.font = UIFont(name: "Roboto-Bold", size: 16.0)
        self.btnSampleRequest.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.viewSampleRequest.isHidden = false
        self.constraintBottomViewSampleReqToSuperView.priority = .required
        self.viewDetails.isHidden = true
        self.constraintBottomViewDetailsToSuperView.priority = .defaultLow
    }
    @IBOutlet weak var btnDetails: UIButton!
    @IBAction func btnDetailsTap(_ sender: UIButton) {
        
        self.btnSampleRequest.layer.shadowOpacity = 0
        self.btnSampleRequest.backgroundColor = .clear
        self.btnSampleRequest.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnSampleRequest.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.btnDetails.backgroundColor = .white
        self.btnDetails.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnDetails.titleLabel?.font = UIFont(name: "Roboto-Bold", size: 16.0)
        self.btnDetails.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.viewSampleRequest.isHidden = true
        self.constraintBottomViewSampleReqToSuperView.priority = .defaultLow
        self.viewDetails.isHidden = false
        self.constraintBottomViewDetailsToSuperView.priority = .required
    }
    
    @IBOutlet weak var viewScrollMainOut: UIView!
    @IBOutlet weak var viewScrollMainIn: UIView!
    @IBOutlet weak var constraintBottomScrollViewToSuperView: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewSampleRequest: UIView!
    @IBOutlet weak var constraintBottomViewSampleReqToSuperView: NSLayoutConstraint!
    
    @IBOutlet weak var viewPrice: UIView!
    @IBOutlet weak var constraintHeightPrice: NSLayoutConstraint!
    @IBOutlet weak var lblPriceTitle: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblSeparatorPrice: UILabel!
    
    @IBOutlet weak var viewMOQ: UIView!
    @IBOutlet weak var constraintHeightMOQ: NSLayoutConstraint!
    @IBOutlet weak var lblMOQTitle: UILabel!
    @IBOutlet weak var txtMOQ: UITextField!
    @IBOutlet weak var viewMOQUnit: UIView!
    @IBOutlet weak var lblMOQUnit: UILabel!
    @IBOutlet weak var btnMOQUnit: UIButton!
    @IBAction func btnMOQUnitTap(_ sender: UIButton) {
        self.selectUnit(unit: self.lblMOQUnit.text ?? "") { isValid, strValue in
            self.lblMOQUnit.text = strValue
        }
    }
    @IBOutlet weak var lblSeparatorMOQ: UILabel!
    
    @IBOutlet weak var viewQuantity: UIView!
    @IBOutlet weak var lblQuantityTitle: UILabel!
    @IBOutlet weak var txtQuantity: UITextField!
    @IBOutlet weak var viewQtyUnit: UIView!
    @IBOutlet weak var lblQtyUnit: UILabel!
    @IBOutlet weak var btnQtyUnit: UIButton!
    @IBAction func btnQtyUnitTap(_ sender: UIButton) {
        self.selectUnit(unit: self.lblQtyUnit.text ?? "") { isValid, strValue in
            self.lblQtyUnit.text = strValue
        }
    }
    @IBOutlet weak var lblSeparatorQuantity: UILabel!
    
    @IBOutlet weak var view1N25KG: UIView!
    @IBOutlet weak var btn1KG: UIButton!
    @IBAction func btn1KGTap(_ sender: UIButton) {
        
        self.btn1KG.isSelected = true
        self.btn1KG.tintColor = Colors.themeGreen.returnColor()
        self.is1KG = true
        self.btn25KG.isSelected = false
        self.btn25KG.tintColor = Colors.gray.returnColor()
        self.is25KG = true
    }
    @IBOutlet weak var btn25KG: UIButton!
    @IBAction func btn25KGTap(_ sender: UIButton) {
        
        self.btn1KG.isSelected = false
        self.btn1KG.tintColor = Colors.gray.returnColor()
        self.is1KG = false
        self.btn25KG.isSelected = true
        self.btn25KG.tintColor = Colors.themeGreen.returnColor()
        self.is25KG = true
    }
    
    
    @IBOutlet weak var viewQueAns: UIView!
    @IBOutlet weak var constraintTopViewQueAnsToQty: NSLayoutConstraint!
    
    @IBOutlet weak var viewQueAns1: UIView!
    @IBOutlet weak var lblQue1: UILabel!
    @IBOutlet weak var txtAns1: UITextField!
    @IBOutlet weak var lblSeparatorQue1: UILabel!
    
    @IBOutlet weak var viewQueAns2: UIView!
    @IBOutlet weak var lblQue2: UILabel!
    @IBOutlet weak var txtAns2: UITextField!
    @IBOutlet weak var lblSeparatorQue2: UILabel!
    
    @IBOutlet weak var viewQueAns3: UIView!
    @IBOutlet weak var lblQue3: UILabel!
    @IBOutlet weak var txtAns3: UITextField!
    @IBOutlet weak var lblSeparatorQue3: UILabel!
    
    @IBOutlet weak var viewQueAns4: UIView!
    @IBOutlet weak var lblQue4: UILabel!
    @IBOutlet weak var txtAns4: UITextField!
    
    @IBOutlet weak var viewPotentialUnit: UIView!
    @IBOutlet weak var lblPotentialUnit: UILabel!
    @IBOutlet weak var btnPotentialUnit: UIButton!
    @IBAction func btnPotentialUnitTap(_ sender: UIButton) {
        self.selectUnit(unit: self.lblPotentialUnit.text ?? "") { isValid, strValue in
            self.lblPotentialUnit.text = strValue
        }
    }
    @IBOutlet weak var viewPotentialTimeUnit: UIView!
    @IBOutlet weak var lblPotentialTimeUnit: UILabel!
    @IBOutlet weak var btnPotentialTimeUnit: UIButton!
    @IBAction func btnPotentialTimeUnitTap(_ sender: UIButton) {
        self.selectUnit(unit: self.lblPotentialTimeUnit.text ?? "", arrUnits: ["DAILY", "MONTHLY", "QUARTERLY", "YEARLY"]) { isValid, strValue in
            self.lblPotentialTimeUnit.text = strValue
        }
    }
    @IBOutlet weak var lblSeparatorQue4: UILabel!
    
    
    @IBOutlet weak var viewDetails: UIView!
    @IBOutlet weak var constraintBottomViewDetailsToSuperView: NSLayoutConstraint!
    
    @IBOutlet weak var viewItemCode: UIView!
    @IBOutlet weak var lblItemCodeTitle: UILabel!
    @IBOutlet weak var lblItemCode: UILabel!
    @IBOutlet weak var lblSeparatorItemCode: UILabel!
    
    @IBOutlet weak var viewHSNCode: UIView!
    @IBOutlet weak var lblHSNCodeTitle: UILabel!
    @IBOutlet weak var lblHSNCode: UILabel!
    @IBOutlet weak var lblSeparatorHSNCode: UILabel!
    
    @IBOutlet weak var viewDescription: UIView!
    @IBOutlet weak var lblDescriptionTitle: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblSeparatorDescription: UILabel!
    
    @IBOutlet weak var viewGST: UIView!
    @IBOutlet weak var lblGSTTitle: UILabel!
    @IBOutlet weak var lblGST: UILabel!
    @IBOutlet weak var lblSeparatorGST: UILabel!
    
    @IBOutlet weak var viewItemGrp: UIView!
    @IBOutlet weak var lblItemGrpTitle: UILabel!
    @IBOutlet weak var lblItemGrp: UILabel!
    @IBOutlet weak var lblSeparatorItemGrp: UILabel!
    
    @IBOutlet weak var lblAllInKG: UILabel!
    @IBOutlet weak var viewWarehouse: UIView!
    @IBOutlet weak var cvWarehouse: UICollectionView! {
        didSet {
            self.cvWarehouse.delegate = self
            self.cvWarehouse.dataSource = self
            self.cvWarehouse.register(UINib(nibName: "WarehouseCVCell", bundle: nil), forCellWithReuseIdentifier: "WarehouseCVCell")
        }
    }
    @IBOutlet weak var constraintHeightCVWarehouse: NSLayoutConstraint!
    
    @IBOutlet weak var btnViewOrders: UIButton!
    @IBAction func btnViewOrdersTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductOrderVC") as! ProductOrderVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.productId = self.arrSelectedProductList?[(self.arrSelectedProductList?.count ?? 0) - 1].id ?? 0
        popupVC.isFromAddOrder = true
        popupVC.onCloseTap = { isValid in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    
    // MARK: - Variables
    
    // "Save or not", "isBack", product list, dictionary
    var onSaveTap:((Bool, Bool, [ProductList]?, [[String: Any]])->Void)?
    var arrSelectedProductList: [ProductList]? = []
    var strScreenTitle: String = "PRODUCT DETAILS"
    var rowHeaders: [String] = ["Warehouse", "Phy. Stock", "SO Commited", "Available"]
    var arrWarehouse: [ProductWarehouse]?
    var intProductIndex: Int = 0
    
    var isFromSalesOrder: Bool = false
    var isFromSampleRequest: Bool = false
    var isFromQI: Bool = false
    var isFromPI: Bool = false
    var isFromEditProduct: Bool = false
    var intEditProductIndex: Int = 0
    
    var is1KG: Bool = false
    var is25KG: Bool = false
    
    // Sample Que ans
    var arrDictQueAns: [[String: Any]] = []
    var strQue1: String = "q_application"
    var strQue2: String = "q_trail_bach_size"
    var strQue3: String = "q_brand"
    var strQue4_1: String = "q_potential_qty"
    var strQue4_2: String = "q_potential_measurement"
    var strQue4_3: String = "q_potential_type"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.btnSampleRequest.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.lblBasePrice.textColor = Colors.theme.returnColor()
        
        self.viewTabButtons.layer.cornerRadius = self.viewTabButtons.frame.height / 2
        self.btnSampleRequest.layer.cornerRadius = self.btnSampleRequest.frame.height / 2
        self.btnDetails.layer.cornerRadius = self.btnDetails.frame.height / 2
        
        self.lblPriceTitle.textColor = Colors.theme.returnColor()
        self.lblMOQTitle.textColor = Colors.theme.returnColor()
        self.lblQuantityTitle.textColor = Colors.theme.returnColor()
        self.lblQue1.textColor = Colors.theme.returnColor()
        self.lblQue2.textColor = Colors.theme.returnColor()
        self.lblQue3.textColor = Colors.theme.returnColor()
        self.lblQue4.textColor = Colors.theme.returnColor()
        
        self.lblItemCodeTitle.textColor = Colors.theme.returnColor()
        self.lblHSNCodeTitle.textColor = Colors.theme.returnColor()
        self.lblDescriptionTitle.textColor = Colors.theme.returnColor()
        self.lblGSTTitle.textColor = Colors.theme.returnColor()
        self.lblItemGrpTitle.textColor = Colors.theme.returnColor()
        self.lblAllInKG.textColor = Colors.theme.returnColor()
        
        
        if self.isFromSampleRequest {
            constraintHeightPrice.priority = .required
            constraintHeightMOQ.priority = .required
        }
        else {
            if self.isFromQI || self.isFromPI {
                constraintHeightPrice.priority = .required
                constraintHeightMOQ.priority = .defaultLow
            }
            else {
                constraintHeightPrice.priority = .defaultLow
                constraintHeightMOQ.priority = .required
            }
        }
        
        if APIManager.sharedManager.companyType == 2 {
            if self.isFromSampleRequest {
                self.constraintTopViewQueAnsToQty.priority = .required
            }
            else {
                self.constraintTopViewQueAnsToQty.priority = .defaultLow
            }
        }
        else {
            self.constraintTopViewQueAnsToQty.priority = .required
        }
        
        if self.isFromEditProduct {
            self.intProductIndex = self.intEditProductIndex
        }
        else {
            self.intProductIndex = (self.arrSelectedProductList?.count ?? 0) - 1
        }
        
        self.lblProductName.text = self.arrSelectedProductList?[self.intProductIndex].name ?? ""
        let remark: String = (self.arrSelectedProductList?[self.intProductIndex].remark ?? "") == "" ? "" : "(\(self.arrSelectedProductList?[self.intProductIndex].remark ?? ""))"
        self.lblCategory.text = remark
        
        var unit: String = (self.arrSelectedProductList?[self.intProductIndex].productUnit ?? "")
        self.lblQtyUnit.text = (unit == "" ? "KG" : unit)
        self.lblPotentialUnit.text = (unit == "" ? "KG" : unit)
        
        unit = unit == "" ? "" : " / \(unit)"
        self.lblBasePrice.text = "₹ \(self.arrSelectedProductList?[self.intProductIndex].unitPrice ?? 0.0)\(unit)"
        
        self.lblItemCode.text = self.arrSelectedProductList?[self.intProductIndex].productCode ?? ""
        self.lblHSNCode.text = (self.arrSelectedProductList?[self.intProductIndex].hsnNumber ?? "") == "" ? "-" : (self.arrSelectedProductList?[self.intProductIndex].hsnNumber ?? "")
        self.lblDescription.text = (self.arrSelectedProductList?[self.intProductIndex].description ?? "") == "" ? "-" : (self.arrSelectedProductList?[self.intProductIndex].description ?? "")
        let gst = "\(self.arrSelectedProductList?[self.intProductIndex].tax ?? 0)"
        self.lblGST.text = gst == "" ? "-" : gst
        self.lblItemGrp.text = (self.arrSelectedProductList?[self.intProductIndex].categoryName ?? "") == "" ? "-" : (self.arrSelectedProductList?[self.intProductIndex].categoryName ?? "")
        
        self.arrWarehouse = self.arrSelectedProductList?[self.intProductIndex].productWarehouse ?? []
        self.constraintHeightCVWarehouse.constant = CGFloat(self.intProductIndex * 40)
        
        if self.isFromEditProduct {
            self.txtMOQ.text = "\(self.arrSelectedProductList?[self.intProductIndex].moq ?? 0.0)"
            self.lblMOQUnit.text = self.arrSelectedProductList?[self.intProductIndex].moqUnit ?? ""
            self.txtQuantity.text = "\(self.arrSelectedProductList?[self.intProductIndex].quantity ?? 0.0)"
            self.lblQtyUnit.text = self.arrSelectedProductList?[self.intProductIndex].productUnit ?? ""
            self.txtAns1.text = self.arrDictQueAns[self.intProductIndex][self.strQue1] as? String
            self.txtAns2.text = self.arrDictQueAns[self.intProductIndex][self.strQue2] as? String
            self.txtAns3.text = self.arrDictQueAns[self.intProductIndex][self.strQue3] as? String
            self.txtAns4.text = self.arrDictQueAns[self.intProductIndex][self.strQue4_1] as? String
            self.lblPotentialUnit.text = self.arrDictQueAns[self.intProductIndex][self.strQue4_2] as? String
            self.lblPotentialTimeUnit.text = self.arrDictQueAns[self.intProductIndex][self.strQue4_3] as? String
        }
        
        self.checkKeyboard(kView: self.viewScrollMainIn)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.btnSampleRequest.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.btnDetails.backgroundColor = .clear
        self.btnDetails.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnDetails.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.viewSampleRequest.isHidden = false
        self.constraintBottomViewSampleReqToSuperView.priority = .required
        self.viewDetails.isHidden = true
        self.constraintBottomViewDetailsToSuperView.priority = .defaultLow
    }
}

extension AddSampleProductDetailsVC {
    func selectUnit(unit: String, arrUnits: [String] = ["KG", "LTR", "CASES", "BOX", "NOS", "DRUM", "ML", "GRAM"], COMPLETION completion: @escaping ((Bool, String) -> Void)) {
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.BPCreditDaysTitle
        popupVC.value = arrUnits
        popupVC.selectedValue = unit
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { value in
            completion(true, value)
        }
        popupVC.onClose = { value in
            completion(false, value)
        }
        self.present(popupVC, animated: true)
    }
}
