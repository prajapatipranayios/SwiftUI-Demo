//
//  OrderCofirmationVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 19/06/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, DataSource

extension OrderConfirmationVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.saveToDraftOrder.products?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderConfirmationProductTVCell", for: indexPath) as! OrderConfirmationProductTVCell
        
        cell.lblProductName.text = self.saveToDraftOrder.products?[indexPath.row].name ?? ""
        
        var category: String = self.saveToDraftOrder.products?[indexPath.row].categoryName ?? ""
        
        if category != "" {
            category = "(\(category))"
        }
        
        if (self.saveToDraftOrder.products?[indexPath.row].remark ?? "") != "" {
            category = category + " (\(self.saveToDraftOrder.products?[indexPath.row].remark ?? ""))"
        }
        
        cell.lblCategory.text = category
        
        if self.isFromSalesOrder || self.isFromQI || self.isFromPI {
            let qty = "\(self.saveToDraftOrder.products?[indexPath.row].quantity ?? 0) \(self.saveToDraftOrder.products?[indexPath.row].productUnit ?? "")@\(self.saveToDraftOrder.products?[indexPath.row].productPrice ?? 0) | \(self.saveToDraftOrder.products?[indexPath.row].tax ?? 0)% GST | \(self.saveToDraftOrder.products?[indexPath.row].discountPrice ?? 0)% Discount"
            
            cell.lblQtyPriceGSTDisc.text = qty
            
            let totalWODisc = Double(self.saveToDraftOrder.products?[indexPath.row].productPrice ?? 0) * Double(self.saveToDraftOrder.products?[indexPath.row].quantity ?? 0)
            let disc = (totalWODisc * Double(self.saveToDraftOrder.products?[indexPath.row].discountPrice ?? 0))/100
            
            let totalWDisc = totalWODisc - disc
            
            let gst = (totalWDisc * Double(self.saveToDraftOrder.products?[indexPath.row].tax ?? 0))/100
            
            cell.lblBasic.text = "₹ " + "\(totalWODisc)".curFormatAsRegion()
            cell.lblDiscount.text = "₹ " + "\(disc)".curFormatAsRegion()
            cell.lblGST.text = "₹ " + "\(gst)".curFormatAsRegion()
            cell.lblNet.text = "₹ " + "\(totalWDisc + gst)".curFormatAsRegion()
            
            cell.lblNet.textColor = Colors.theme.returnColor()
        }
        else if self.isFromSampleRequest {
            cell.lblQtyPriceGSTDisc.text = ""
            
            cell.constraintWidthViewBasicGSTNet.priority = .required
            cell.constraintHeightViewBasicGSTNet.priority = .required
        }
        else if self.isFromPI {
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}


// MARK: -

extension OrderConfirmationVC {
    func setData() {
        self.hideAllView()
        
        self.constraintHeightBusinessPartner.priority = .defaultLow
        self.lblBusinessPartner.text = self.saveToDraftOrder.businessPartnerName ?? ""
        
        self.constraintHeightBusinessPartnerCode.priority = .defaultLow
        self.lblBusinessPartnerCode.text = self.saveToDraftOrder.businesscode ?? ""
        
        self.constraintHeightBillingLocation.priority = .defaultLow
        self.lblBillingLocation.text = self.saveToDraftOrder.billingAddressName ?? ""
        
        self.constraintHeightDeliveryDate.priority = .defaultLow
        self.lblDeliveryDate.text = Utilities.convertStrDateToString(date: self.saveToDraftOrder.requiredDate ?? "", CurrentDateFormate: "yyyy/MM/dd", NewDateFormate: "dd-MMM-yyyy")
        
        self.constraintHeightBranch.priority = .defaultLow
        self.lblBranch.text = self.saveToDraftOrder.branchName ?? ""
        
        
        self.constraintHeightDeliveryType.priority = .defaultLow
        self.lblDeliveryType.text = (self.saveToDraftOrder.orderDeliveryType ?? "") == "Customer" ? "Delivery By" : (self.saveToDraftOrder.orderDeliveryType ?? "")
        
        self.constraintHeightDeliveryTo.priority = .defaultLow
        self.lblDeliveryTo.text = self.saveToDraftOrder.deliveryTo ?? ""
        
        if (self.saveToDraftOrder.orderDeliveryType ?? "") == "Customer" {
            if self.saveToDraftOrder.transporterTitle ?? "" != "" {
                self.constraintHeightTransporterName.priority = .defaultLow
                self.lblTransporterName.text = self.saveToDraftOrder.transporterTitle ?? ""
            }
            
            if self.saveToDraftOrder.transporterGSTNo ?? "" != "" {
                self.constraintHeightTransporterGSTNo.priority = .defaultLow
                self.lblTransporterGSTNo.text = self.saveToDraftOrder.transporterGSTNo ?? ""
            }
            
            if self.saveToDraftOrder.freightCharges ?? "" != "" {
                self.constraintHeightFreightChargrs.priority = .defaultLow
                self.lblFreightChargrs.text = self.saveToDraftOrder.freightCharges ?? ""
            }
            
            if self.saveToDraftOrder.bookingPoint ?? "" != "" {
                self.constraintHeightBookingPoint.priority = .defaultLow
                self.lblBookingPoint.text = self.saveToDraftOrder.bookingPoint ?? ""
            }
        }
        
        if self.saveToDraftOrder.comment ?? "" != "" {
            self.constraintHeightComments.priority = .defaultLow
            self.lblComments.text = self.saveToDraftOrder.comment ?? ""
        }
        
        if self.isFromSalesOrder || self.isFromQI || self.isFromPI {
            self.constraintHeightBasicAmount.priority = .defaultLow
            self.lblBasicAmount.text = "Need to Calculate basic amount"
            
            self.constraintHeightDiscount.priority = .defaultLow
            self.lblDiscount.text = "Need to Calculate Discout"
            
            self.constraintHeightBasicAmtAfterDisc.priority = .defaultLow
            self.lblBasicAmtAfterDisc.text = "Need to Calculate Discout"
            
            self.constraintHeightGST.priority = .defaultLow
            //self.lblGST.text = "Need to Calculate Discout"
            
            self.constraintHeightNetAmount.priority = .defaultLow
            self.lblNetAmount.text = "Need to Calculate Discout"
            
            if self.isFromQI || self.isFromPI {
                self.constraintHeightFreight.priority = .defaultLow
                self.lblFreight.text = "₹ \(self.saveToDraftOrder.freight ?? 0)"
                
                self.constraintHeightFreightGST.priority = .defaultLow
            }
        }
        else if self.isFromSampleRequest {
            self.constraintHeightBasicAmount.priority = .required
            self.constraintHeightDiscount.priority = .required
            self.constraintHeightBasicAmtAfterDisc.priority = .required
            self.constraintHeightGST.priority = .required
            self.constraintHeightNetAmount.priority = .required
            self.constraintHeightViewNetTotal.priority = .required
        }
        
        
        self.lblProductCount.text = "Product (\(self.saveToDraftOrder.products?.count ?? 0))"
        
        var totalWODisc: Double = 0.0
        var totalDiscount: Double = 0.0
        //var totalBasicAmount: Double = 0.0
        var totalAmtAfterDisc: Double = 0.0
        var totalNetAmount: Double = 0.0
        
        var freightGSTPercentage : Double = 0.0
        
        for i in 0..<(self.saveToDraftOrder.products?.count ?? 0) {
            if freightGSTPercentage < Double(self.saveToDraftOrder.products?[i].tax ?? 0) {
                freightGSTPercentage = Double(self.saveToDraftOrder.products?[i].tax ?? 0)
            }
            
            let tempTotal: Double = Double(self.saveToDraftOrder.products?[i].productPrice ?? 0) * Double(self.saveToDraftOrder.products?[i].quantity ?? 0)
            
            totalWODisc += tempTotal
            totalDiscount += (tempTotal * Double(self.saveToDraftOrder.products?[i].discountPrice ?? 0))/100
        }
        
        let freightGST = (Double(self.saveToDraftOrder.freight ?? 0) * freightGSTPercentage) / 100
        self.lblFreightGST.text = "₹ \(freightGST)"
        self.saveToDraftOrder.freightGst = freightGST
        
        //Basaic Amount
        self.lblBasicAmount.text = "₹ " + "\(totalWODisc)".curFormatAsRegion()
        
        //Discount
        self.lblDiscount.text = "₹ " + "\(totalDiscount)".curFormatAsRegion()
        self.lblTDiscount.text = "₹ " + "\(totalDiscount)".curFormatAsRegion()
        
        
        //Basaic Amt after Disc
        totalAmtAfterDisc = totalWODisc - totalDiscount
        self.lblBasicAmtAfterDisc.text = "₹ " + "\(totalAmtAfterDisc)".curFormatAsRegion()
        
        //Net Amount
        totalNetAmount = totalAmtAfterDisc + (self.gstResult?.gstTotal ?? 0) + Double(self.saveToDraftOrder.freight ?? 0) + freightGST
        self.lblNetAmount.text = "₹ " + "\(totalNetAmount)".curFormatAsRegion()
        
        self.lblBasic.text = "₹ " + "\(totalWODisc)".curFormatAsRegion()
        self.lblNet.text = "₹ " + "\(totalNetAmount)".curFormatAsRegion()
        self.amountToPay = totalNetAmount
        self.lblNet.textColor = Colors.theme.returnColor()
        
        //self.saveToDraftOrder.grandTotalAmount = totalNetAmount
        self.saveToDraftOrder.grandTotalAmount = "\(totalNetAmount)"
    }
    
    func hideAllView() {
        self.constraintHeightCompanyType.priority = .required
        self.constraintHeightBusinessPartner.priority = .required
        self.constraintHeightBusinessPartnerCode.priority = .required
        self.constraintHeightBillingLocation.priority = .required
        self.constraintHeightDeliveryDate.priority = .required
        self.constraintHeightBranch.priority = .required
        self.constraintHeightDeliveryType.priority = .required
        self.constraintHeightDeliveryLocation.priority = .required
        self.constraintHeightDeliveryTo.priority = .required
        self.constraintHeightCourier.priority = .required
        self.constraintHeightCourierGSTNo.priority = .required
        self.constraintHeightTransporterName.priority = .required
        self.constraintHeightTransporterGSTNo.priority = .required
        self.constraintHeightFreightChargrs.priority = .required
        self.constraintHeightBookingPoint.priority = .required
        self.constraintHeightComments.priority = .required
        self.constraintHeightiGSTAmount.priority = .required
        self.constraintHeightGSTPercentage.priority = .required
        self.constraintHeightBasicAmount.priority = .required
        self.constraintHeightDiscount.priority = .required
        self.constraintHeightBasicAmtAfterDisc.priority = .required
        self.constraintHeightGST.priority = .required
        self.constraintHeightCGSTPercentage.priority = .required
        self.constraintHeightCGSTAmount.priority = .required
        self.constraintHeightSGSTPercentage.priority = .required
        self.constraintHeightFreight.priority = .required
        self.constraintHeightFreightGST.priority = .required
        self.constraintHeightNetAmount.priority = .required
    }
}

// MARK: - Webservices

extension OrderConfirmationVC {
    func getGSTCalculation(addressStateId: Int, branchStateId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getGSTCalculation(addressStateId: addressStateId, branchStateId: branchStateId)
                }
            }
            return
        }
        
        var products: [Any] = []
        for i in 0..<(self.saveToDraftOrder.products?.count ?? 0) {
            let tempProduct : [String: Any] = [
                "product_id": self.saveToDraftOrder.products?[i].id ?? "",
                "quantity": self.saveToDraftOrder.products?[i].quantity ?? "",
                "product_price": self.saveToDraftOrder.products?[i].productPrice ?? "",
                "discount_price": self.saveToDraftOrder.products?[i].discountPrice ?? ""]
            products.append(tempProduct)
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "address_state_id": addressStateId,
            "branch_state_id": branchStateId,
            "products": products
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_GST_CALCULATION, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.gstResult = response?.result?.gstResult
                    self.arrFollowUpDays = response?.result?.followUpDays
                    self.intCustomFollowUpMaxDays = response?.result?.customMaxDays ?? 0
                    
                    self.lblGST.text = "₹ " + "\(self.gstResult?.gstTotal ?? 0)".curFormatAsRegion()
                    self.lblTGST.text = "₹ " + "\(self.gstResult?.gstTotal ?? 0)".curFormatAsRegion()
                    
                    self.saveToDraftOrder.gstTotal = self.gstResult?.gstTotal ?? 0
                    self.saveToDraftOrder.igstAmount = self.gstResult?.igstAmount ?? 0
                    self.saveToDraftOrder.cgstAmount = self.gstResult?.cgstAmount ?? 0
                    self.saveToDraftOrder.sgstAmount = self.gstResult?.sgstAmount ?? 0
                    
                    self.setData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
