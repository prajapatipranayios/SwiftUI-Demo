//
//  OrderCofirmationVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 18/06/24.
//

import UIKit

class OrderConfirmationVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onTap != nil {
                self.onTap!(false, "", [], 0, self.saveToDraftOrder)
            }
        }
    }
    
    @IBOutlet weak var viewScrollViewOut: UIView!
    @IBOutlet weak var viewScrollViewIn: UIView!
    
    @IBOutlet weak var viewCompanyType: UIView!
    @IBOutlet weak var constraintHeightCompanyType: NSLayoutConstraint!
    @IBOutlet weak var lblCompanyTypeTitle: UILabel!
    @IBOutlet weak var lblCompanyType: UILabel!
    
    @IBOutlet weak var viewBusinessPartner: UIView!
    @IBOutlet weak var constraintHeightBusinessPartner: NSLayoutConstraint!
    @IBOutlet weak var lblBusinessPartnerTitle: UILabel!
    @IBOutlet weak var lblBusinessPartner: UILabel!
    
    @IBOutlet weak var viewBusinessPartnerCode: UIView!
    @IBOutlet weak var constraintHeightBusinessPartnerCode: NSLayoutConstraint!
    @IBOutlet weak var lblBusinessPartnerCodeTitle: UILabel!
    @IBOutlet weak var lblBusinessPartnerCode: UILabel!
    
    @IBOutlet weak var viewBillingLocation: UIView!
    @IBOutlet weak var constraintHeightBillingLocation: NSLayoutConstraint!
    @IBOutlet weak var lblBillingLocationTitle: UILabel!
    @IBOutlet weak var lblBillingLocation: UILabel!
    
    @IBOutlet weak var viewDeliveryDate: UIView!
    @IBOutlet weak var constraintHeightDeliveryDate: NSLayoutConstraint!
    @IBOutlet weak var lblDeliveryDateTitle: UILabel!
    @IBOutlet weak var lblDeliveryDate: UILabel!
    
    @IBOutlet weak var viewBranch: UIView!
    @IBOutlet weak var constraintHeightBranch: NSLayoutConstraint!
    @IBOutlet weak var lblBranchTitle: UILabel!
    @IBOutlet weak var lblBranch: UILabel!
    
    @IBOutlet weak var viewDeliveryType: UIView!
    @IBOutlet weak var constraintHeightDeliveryType: NSLayoutConstraint!
    @IBOutlet weak var lblDeliveryTypeTitle: UILabel!
    @IBOutlet weak var lblDeliveryType: UILabel!
    
    @IBOutlet weak var viewDeliveryLocation: UIView!
    @IBOutlet weak var constraintHeightDeliveryLocation: NSLayoutConstraint!
    @IBOutlet weak var lblDeliveryLocationTitle: UILabel!
    @IBOutlet weak var lblDeliveryLocation: UILabel!
    
    @IBOutlet weak var viewDeliveryTo: UIView!
    @IBOutlet weak var constraintHeightDeliveryTo: NSLayoutConstraint!
    @IBOutlet weak var lblDeliveryToTitle: UILabel!
    @IBOutlet weak var lblDeliveryTo: UILabel!
    
    @IBOutlet weak var viewCourier: UIView!
    @IBOutlet weak var constraintHeightCourier: NSLayoutConstraint!
    @IBOutlet weak var lblCourierTitle: UILabel!
    @IBOutlet weak var lblCourier: UILabel!
    
    @IBOutlet weak var viewCourierGSTNo: UIView!
    @IBOutlet weak var constraintHeightCourierGSTNo: NSLayoutConstraint!
    @IBOutlet weak var lblCourierGSTNoTitle: UILabel!
    @IBOutlet weak var lblCourierGSTNo: UILabel!
    
    @IBOutlet weak var viewTransporterName: UIView!
    @IBOutlet weak var constraintHeightTransporterName: NSLayoutConstraint!
    @IBOutlet weak var lblTransporterNameTitle: UILabel!
    @IBOutlet weak var lblTransporterName: UILabel!
    
    @IBOutlet weak var viewTransporterGSTNo: UIView!
    @IBOutlet weak var constraintHeightTransporterGSTNo: NSLayoutConstraint!
    @IBOutlet weak var lblTransporterGSTNoTitle: UILabel!
    @IBOutlet weak var lblTransporterGSTNo: UILabel!
    
    @IBOutlet weak var viewFreightChargrs: UIView!
    @IBOutlet weak var constraintHeightFreightChargrs: NSLayoutConstraint!
    @IBOutlet weak var lblFreightChargrsTitle: UILabel!
    @IBOutlet weak var lblFreightChargrs: UILabel!
    
    @IBOutlet weak var viewBookingPoint: UIView!
    @IBOutlet weak var constraintHeightBookingPoint: NSLayoutConstraint!
    @IBOutlet weak var lblBookingPointTitle: UILabel!
    @IBOutlet weak var lblBookingPoint: UILabel!
    
    @IBOutlet weak var viewComments: UIView!
    @IBOutlet weak var constraintHeightComments: NSLayoutConstraint!
    @IBOutlet weak var lblCommentsTitle: UILabel!
    @IBOutlet weak var lblComments: UILabel!
    
    @IBOutlet weak var viewiGSTAmount: UIView!
    @IBOutlet weak var constraintHeightiGSTAmount: NSLayoutConstraint!
    @IBOutlet weak var lbliGSTAmountTitle: UILabel!
    @IBOutlet weak var lbliGSTAmount: UILabel!
    
    @IBOutlet weak var viewGSTPercentage: UIView!
    @IBOutlet weak var constraintHeightGSTPercentage: NSLayoutConstraint!
    @IBOutlet weak var lblGSTPercentageTitle: UILabel!
    @IBOutlet weak var lblGSTPercentage: UILabel!
    
    @IBOutlet weak var viewBasicAmount: UIView!
    @IBOutlet weak var constraintHeightBasicAmount: NSLayoutConstraint!
    @IBOutlet weak var lblBasicAmountTitle: UILabel!
    @IBOutlet weak var lblBasicAmount: UILabel!
    
    @IBOutlet weak var viewDiscount: UIView!
    @IBOutlet weak var constraintHeightDiscount: NSLayoutConstraint!
    @IBOutlet weak var lblDiscountTitle: UILabel!
    @IBOutlet weak var lblDiscount: UILabel!
    
    @IBOutlet weak var viewBasicAmtAfterDisc: UIView!
    @IBOutlet weak var constraintHeightBasicAmtAfterDisc: NSLayoutConstraint!
    @IBOutlet weak var lblBasicAmtAfterDiscTitle: UILabel!
    @IBOutlet weak var lblBasicAmtAfterDisc: UILabel!
    
    @IBOutlet weak var viewGST: UIView!
    @IBOutlet weak var constraintHeightGST: NSLayoutConstraint!
    @IBOutlet weak var lblGSTTitle: UILabel!
    @IBOutlet weak var lblGST: UILabel!
    
    @IBOutlet weak var viewCGSTPercentage: UIView!
    @IBOutlet weak var constraintHeightCGSTPercentage: NSLayoutConstraint!
    @IBOutlet weak var lblCGSTPercentageTitle: UILabel!
    @IBOutlet weak var lblCGSTPercentage: UILabel!
    
    @IBOutlet weak var viewCGSTAmount: UIView!
    @IBOutlet weak var constraintHeightCGSTAmount: NSLayoutConstraint!
    @IBOutlet weak var lblCGSTAmountTitle: UILabel!
    @IBOutlet weak var lblCGSTAmount: UILabel!
    
    @IBOutlet weak var viewSGSTPercentage: UIView!
    @IBOutlet weak var constraintHeightSGSTPercentage: NSLayoutConstraint!
    @IBOutlet weak var lblSGSTPercentageTitle: UILabel!
    @IBOutlet weak var lblSGSTPercentage: UILabel!
    
    @IBOutlet weak var viewFreight: UIView!
    @IBOutlet weak var constraintHeightFreight: NSLayoutConstraint!
    @IBOutlet weak var lblFreightTitle: UILabel!
    @IBOutlet weak var lblFreight: UILabel!
    
    @IBOutlet weak var viewFreightGST: UIView!
    @IBOutlet weak var constraintHeightFreightGST: NSLayoutConstraint!
    @IBOutlet weak var lblFreightGSTTitle: UILabel!
    @IBOutlet weak var lblFreightGST: UILabel!
    
    @IBOutlet weak var viewNetAmount: UIView!
    @IBOutlet weak var constraintHeightNetAmount: NSLayoutConstraint!
    @IBOutlet weak var lblNetAmountTitle: UILabel!
    @IBOutlet weak var lblNetAmount: UILabel!
    
    @IBOutlet weak var lblProductCount: UILabel!
    
    @IBOutlet weak var viewProductList: UIView!
    @IBOutlet weak var tvProductList: UITableView! {
        didSet {
            self.tvProductList.delegate = self
            self.tvProductList.dataSource = self
            self.tvProductList.register(UINib(nibName: "OrderConfirmationProductTVCell", bundle: nil), forCellReuseIdentifier: "OrderConfirmationProductTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVProductList: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewNetTotal: UIView!
    @IBOutlet weak var lblBasicTitle: UILabel!
    @IBOutlet weak var lblBasic: UILabel!
    @IBOutlet weak var lblTDiscountTitle: UILabel!
    @IBOutlet weak var lblTDiscount: UILabel!
    @IBOutlet weak var lblTGSTTitle: UILabel!
    @IBOutlet weak var lblTGST: UILabel!
    @IBOutlet weak var lblNetTitle: UILabel!
    @IBOutlet weak var lblNet: UILabel!
    
    @IBOutlet weak var viewBtnConfirm: UIView!
    @IBOutlet weak var btnConfirm: UIButton!
    @IBAction func btnConfirmTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onTap != nil {
                self.onTap!(true, "\(self.amountToPay)", self.arrFollowUpDays ?? [], self.intCustomFollowUpMaxDays, self.saveToDraftOrder)
            }
        }
    }
    @IBOutlet weak var constraintHeightViewNetTotal: NSLayoutConstraint!
    
    
    // MARK: - Variable
    
    var strScreenTitle = "Sales Order Confirmation"
    var onTap: ((Bool, String, [String], Int, SaveToDraftOrder)->Void)?
    
    var saveToDraftOrder = SaveToDraftOrder()
    var isFromSalesOrder: Bool = false
    var isFromSampleRequest: Bool = false
    var isFromQI: Bool = false
    var isFromPI: Bool = false
    
    var gstResult: GstResult?
    var arrFollowUpDays: [String]? = []
    var intCustomFollowUpMaxDays: Int = 0
    var amountToPay: Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.btnConfirm.corners(radius: 15.0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tvProductList.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        //self.setData()
        self.getGSTCalculation(addressStateId: self.saveToDraftOrder.businessPartnersID ?? 0, branchStateId: self.saveToDraftOrder.branchID ?? 0)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tvProductList.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                self.constraintHeightTVProductList.constant = newsize.height
                self.updateViewConstraints()
            }
        }
    }
}
