//
//  AddOrderVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 03/06/24.
//

import UIKit

class AddOrderVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        if self.isAddProductView {
            self.isAddProductView = false
            self.viewProductList.isHidden = true
            
            if self.isFromSalesOrder {
                self.btnSave.isHidden = false
            }
            else {
                self.btnSave.isHidden = true
            }
            //self.arrSelectedProductList?.removeAll()
        }
        else if self.isViewStepDeliveryType {
            self.isAddProductView = false
            self.viewProductList.isHidden = true
            
            if self.isFromSalesOrder {
                self.btnSave.isHidden = false
            }
            else {
                self.btnSave.isHidden = true
            }
            
            self.lblStepCount.text = "1 of \(self.intTotalStep)"
            self.intCurrentStep = 1
            self.viewStepCount.progress = (1 / CGFloat(self.intTotalStep)) * CGFloat(self.intCurrentStep)
            
            self.isViewStepDeliveryType = false
            self.viewStepDeliveryType.isHidden = true
            self.viewStepSelectBP.isHidden = false
            
            self.constraintBottomViewDeliveryType.priority = .defaultLow
            
            self.lblStepTitle.text = "Select Business Partner"
            self.lblNextStep.text = "Next: Delivery Type"
        }
        else if self.isViewPayment {
            self.viewStepSelectBP.isHidden = true
            self.viewStepDeliveryType.isHidden = false
            self.viewStepPaymentNReview.isHidden = true
            
            self.intCurrentStep = 2
            self.isViewStepDeliveryType = true
            self.isViewPayment = false
            self.constraintBottomViewDeliveryType.priority = .required
            
            if self.isFromSalesOrder {
                self.btnSave.isHidden = false
            }
            else {
                self.btnSave.isHidden = true
            }
            
            self.lblStepCount.text = "\(self.intCurrentStep) of \(self.intTotalStep)"
            self.viewStepCount.progress = (1 / CGFloat(self.intTotalStep)) * CGFloat(self.intCurrentStep)
            
            self.lblStepTitle.text = "Delivery Type"
            self.lblNextStep.text = "Next: Payment & Review"
            
            self.isViewStepDeliveryType = true
            
            self.saveToDraftOrder.products = self.arrSelectedProductList
        }
        else {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
            popupVC.titleTxt = Title.ConfirmationPopupTitle
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.strMessage = "Are you sure you want to discard \(self.strScreenTitle) ?"
            popupVC.colorTitleText = .black
            popupVC.colorBtnYesText = Colors.theme.returnColor()
            popupVC.colorBtnNoText = Colors.theme.returnColor()
            popupVC.onYesTap = { ans in
                self.navigationController?.popViewController(animated: true)
            }
            popupVC.onNoTap = { ans in
            }
            self.present(popupVC, animated: true)
        }
        self.dismissMyKeyboard()
    }
    @IBOutlet weak var btnAdd: UIButton!
    @IBAction func btnAddTap(_ sender: UIButton) {
        //self.dismissMyKeyboard()
        self.selectProducts()
    }
    @IBOutlet weak var btnAddOtherProduct: UIButton!
    @IBAction func btnAddOtherProductTap(_ sender: UIButton) {
        //self.dismissMyKeyboard()
        //selectProducts()
    }
    
    @IBOutlet weak var btnSave: UIButton!
    @IBAction func btnSaveTap(_ sender: UIButton) {
        DispatchQueue.main.async {
            if self.intCurrentStep == 1 {
                if self.isAddProductView {
                    self.saveToDraftOrder.products = self.arrSelectedProductList
                    self.viewConfirmedToSaveDraft.isHidden = false
                }
                else {
                    if self.isBPSelected && self.isDeliveryDateSelected && self.isBranchSelected {
                        self.viewConfirmedToSaveDraft.isHidden = false
                    }
                    else {
                        if !self.isBPSelected {
                            self.lblErrorSelectBP.text = "Please \(self.lblBusinessP.text!.lowercased())"
                            self.lblErrorBillingLocation.text = "Please \(self.lblBillingLocation.text!.lowercased())"
                        }
                        
                        if !self.isDeliveryDateSelected {
                            self.lblErrorDeliveryDate.text = "Please select \(self.lblDeliveryDate.text!.lowercased())"
                        }
                        
                        if !self.isBranchSelected {
                            self.lblErrorBranch.text = "Please select \(self.lblBranch.text!.lowercased())"
                        }
                    }
                }
            }
            else if self.intCurrentStep == 2 {
                self.dismissMyKeyboard()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    if self.checkValidation(to: 0, from: 5) {
                        self.viewConfirmedToSaveDraft.isHidden = false
                    }
                }
            }
        }
    }
    
    
    @IBOutlet weak var viewScrollViewOut: UIView!
    @IBOutlet weak var viewScrollViewIn: UIView!
    
    // View Step - 1
    @IBOutlet weak var viewStepSelectBP: UIView!
    @IBOutlet weak var constraintHeightViewStepSelectBP: NSLayoutConstraint!
    
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var viewStepCount: PlainCircularProgressBar!
    @IBOutlet weak var lblStepCount: UILabel!
    @IBOutlet weak var lblStepTitle: UILabel!
    @IBOutlet weak var lblNextStep: UILabel!
    
    @IBOutlet weak var viewBusinessP: UIView!
    @IBOutlet weak var lblBPTitle: UILabel!
    @IBOutlet weak var lblBusinessP: UILabel!
    @IBOutlet weak var btnSelectBP: UIButton!
    @IBAction func btnSelectBPTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "BusinessPartnerVC") as! BusinessPartnerVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.isFromAddOrder = true
        popupVC.onCellTap = { isSelect, businessP in
            if isSelect {
                self.businessPartner = businessP
                self.lblBusinessP.text = self.businessPartner?.name ?? ""
                self.lblBillingLocation.text = self.businessPartner?.billingLocation ?? ""
                
                self.lblBusinessP.textColor = .black
                self.lblBillingLocation.textColor = .black
                self.lblBusinessP.font = Fonts.Medium.returnFont(size: 21.0)
                self.lblBillingLocation.font = Fonts.Medium.returnFont(size: 21.0)
                
                self.saveToDraftOrder.businessPartnersID = self.businessPartner?.id ?? 0
                self.saveToDraftOrder.businessPartnerName = self.businessPartner?.name ?? ""
                self.saveToDraftOrder.businesscode = self.businessPartner?.code ?? ""
                self.saveToDraftOrder.paymentType = "\(businessP?.paymentType ?? 0)"
                
                self.constraintHeightCreditLimit.priority = .required
                if businessP?.paymentType ?? 0 == 3 {
                    self.saveToDraftOrder.creditDay = businessP?.creditDayLimit ?? ""
                    if self.isFromQI || self.isFromPI {
                        self.constraintHeightCreditLimit.priority = .defaultLow
                    }
                }
                
                self.saveToDraftOrder.billingAddressID = self.businessPartner?.billingId ?? 0
                self.saveToDraftOrder.billingAddressName = self.businessPartner?.billingLocation ?? ""
                
                self.saveToDraftOrder.deliveryAddressID = "\(self.businessPartner?.deliveryId ?? 0)"
                self.saveToDraftOrder.deliveryAddressName = self.businessPartner?.deliveryLocation ?? ""
                self.saveToDraftOrder.deliveryTo = self.businessPartner?.deliveryTo ?? ""
                
                self.saveToDraftOrder.transportNamelist = self.businessPartner?.transporters ?? []
                self.arrBPTransporters = self.businessPartner?.transporters ?? []
                
                self.saveToDraftOrder.paymentType = "\(businessP?.paymentType ?? 0)"
                
                self.txtClientCode.text = self.businessPartner?.code ?? ""
                self.txtClientCode.isEnabled = false
                
                let paymentType = Int(self.saveToDraftOrder.paymentType!) ?? 0
                self.lblPaymentTerms.text = PaymentTypes.getPaymentType(type: paymentType)
                self.lblCreditLimit.text = self.saveToDraftOrder.creditDay ?? ""
                
                self.isBPSelected = true
                
                self.lblErrorSelectBP.text = ""
                self.lblErrorBillingLocation.text = ""
                
                if self.isFromSampleRequest {
                    self.checkBusinessPartnerOrderExist(businessPartnerId: self.businessPartner?.id ?? 0)
                }
            }
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var lblSelectBPSeparator: UILabel!
    @IBOutlet weak var lblErrorSelectBP: UILabel!
    
    @IBOutlet weak var viewBillingLocation: UIView!
    @IBOutlet weak var lblBillingLocationTitle: UILabel!
    @IBOutlet weak var lblBillingLocation: UILabel!
    @IBOutlet weak var btnSelectBillingLocation: UIButton!
    @IBAction func btnSelectBillingLocationTap(_ sender: UIButton) {
        if self.isBPSelected {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "BillingLocationListVC") as! BillingLocationListVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            //popupVC.businessPartner = self.businessPartner
            popupVC.intBusinessPartnerId = self.businessPartner?.id ?? 0
            popupVC.addressType = 1     //  1 - Billing,    2 - Delivery
            popupVC.onCellTap = { isSelect, businessPAddress in
                if isSelect {
                    self.businessPartnerAddress = businessPAddress
                    self.lblBillingLocation.text = self.businessPartnerAddress?.addressTitle ?? ""
                    
                    self.saveToDraftOrder.billingAddressID = self.businessPartnerAddress?.id ?? 0
                    self.saveToDraftOrder.billingAddressName = self.businessPartnerAddress?.addressTitle ?? ""
                }
            }
            self.present(popupVC, animated: true, completion: nil)
        }
        else {
            Utilities.showPopup(title: Messages.SelectBP, type: .error)
        }
    }
    @IBOutlet weak var lblSelectBillingLocationSeparator: UILabel!
    @IBOutlet weak var lblErrorBillingLocation: UILabel!
    
    @IBOutlet weak var viewDeliveryDate: UIView!
    @IBOutlet weak var lblDeliveryDate: UILabel!
    @IBOutlet weak var btnSelectDeliveryDate: UIButton!
    @IBAction func btnSelectDeliveryDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.isMaxDateLimit = false
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.minStartDate = Utilities.convertDateToString(date: Date(), NewDateFormate: "dd-MMM-yyyy")
        popupVC.didSelectDate = { date in
            self.lblDeliveryDate.textColor = .black
            self.lblDeliveryDate.text = date
            self.lblDeliveryDate.font = Fonts.Medium.returnFont(size: 21.0)
            self.isDeliveryDateSelected = true
            
            self.lblErrorDeliveryDate.text = ""
            self.saveToDraftOrder.requiredDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy/MM/dd")
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    @IBOutlet weak var lblDeliveryDateSeparator: UILabel!
    @IBOutlet weak var lblErrorDeliveryDate: UILabel!
    
    @IBOutlet weak var viewBranch: UIView!
    @IBOutlet weak var lblBranch: UILabel!
    @IBOutlet weak var btnSelectBranch: UIButton!
    @IBAction func btnSelectBranchTap(_ sender: UIButton) {
        let arrBranch: [String] = (APIManager.sharedManager.arrBranches ?? []).map { $0.branchName! }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.BPBrachTitle
        popupVC.value = arrBranch
        popupVC.selectedValue = self.lblBranch.text ?? "Select Branch"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { strValue in
            self.lblBranch.textColor = .black
            self.lblBranch.text = strValue
            self.lblBranch.font = Fonts.Medium.returnFont(size: 21.0)
            self.isBranchSelected = true
            
            self.lblErrorBranch.text = ""
            
            let tempBranch = APIManager.sharedManager.arrBranches?.filter{ ($0.branchName! == self.lblBranch.text!) }
            let tempBranchId = tempBranch?[0].id ?? 0
            self.saveToDraftOrder.branchID = tempBranchId
            self.saveToDraftOrder.branchName = strValue
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblBranchSeparator: UILabel!
    @IBOutlet weak var lblErrorBranch: UILabel!
    
    @IBOutlet weak var btnAddProduct: UIButton!
    @IBAction func btnAddProductTap(_ sender: UIButton) {
        
        if self.isBPSelected && self.isDeliveryDateSelected && self.isBranchSelected {
            if (self.arrSelectedProductList?.count ?? 0) > 0 {
                self.isAddProductView = true
                self.viewProductList.isHidden = false
                self.btnAdd.isHidden = false
                
                if self.isFromSalesOrder {
                    self.btnSave.isHidden = false
                }
                else {
                    self.btnSave.isHidden = true
                }
                
                self.lblTotalProduct.text = "\(self.arrSelectedProductList?.count ?? 0) Product(s)"
                self.lblTotalProduct2.text = "\(self.arrSelectedProductList?.count ?? 0) Product(s)"
                self.tvProductList.reloadData()
                self.getBasicOfAllProduct()
            }
            else {
                self.selectProducts()
            }
        }
        else {
            if !self.isBPSelected {
                self.lblErrorSelectBP.text = "Please \(self.lblBusinessP.text!.lowercased())"
                self.lblErrorBillingLocation.text = "Please \(self.lblBillingLocation.text!.lowercased())"
            }
            
            if !self.isDeliveryDateSelected {
                self.lblErrorDeliveryDate.text = "Please select \(self.lblDeliveryDate.text!.lowercased())"
            }
            
            if !self.isBranchSelected {
                self.lblErrorBranch.text = "Please select \(self.lblBranch.text!.lowercased())"
            }
        }
    }
    
    // View Product List
    
    @IBOutlet weak var viewProductList: UIView!
    
    @IBOutlet weak var tvProductList: UITableView! {
        didSet {
            self.tvProductList.delegate = self
            self.tvProductList.dataSource = self
            self.tvProductList.register(UINib(nibName: "AddOrderSelectedProductTVCell", bundle: nil), forCellReuseIdentifier: "AddOrderSelectedProductTVCell")
            self.tvProductList.register(UINib(nibName: "AddSampleOrderSelectedProductTVCell", bundle: nil), forCellReuseIdentifier: "AddSampleOrderSelectedProductTVCell")
        }
    }
    @IBOutlet weak var constraintBottomViewFreight: NSLayoutConstraint!
    
    @IBOutlet weak var viewBasicTotal: UIView!
    @IBOutlet weak var lblBasicTotal: UILabel!
    @IBOutlet weak var lblTotalProduct: UILabel!
    @IBOutlet weak var btnNextProduct: UIButton!
    @IBAction func btnNextProductTap(_ sender: UIButton) {
        // On tap validate and navigate to next step 2
        
        self.dismissMyKeyboard()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            var errorMsg: String = ""
            
            if !self.isFromSampleRequest {
                if self.isFromQI || self.isFromPI {
                    if self.txtFreight.text == "" {
                        errorMsg = "Enter freight charges."
                    }
                }
                
                if (self.arrSelectedProductList?.count ?? 0) <= 0 {
                    errorMsg = "Add product(s)."
                }
                
                for i in 0 ..< (self.arrSelectedProductList?.count ?? 0) {
                    
                    let index = IndexPath(row: i, section: 0)
                    let cell = self.tvProductList.cellForRow(at: index) as! AddOrderSelectedProductTVCell
                    if (cell.txtPrice.text! == "") || (cell.txtPrice.text! == "0") || (cell.txtPrice.text! == "0.0") {
                        errorMsg = "Please enter price."
                        break
                    }
                    else if (cell.txtQty.text! == "") || (cell.txtQty.text! == "0") || (cell.txtQty.text! == "0.0") {
                        errorMsg = "Please enter quantity."
                        break
                    }
                    
                    if self.isFromQI || self.isFromPI {
                        if (cell.txtMOQ.text! == "") || (cell.txtMOQ.text! == "0") || (cell.txtMOQ.text! == "0.0") {
                            errorMsg = "Please enter minimum quantity."
                            break
                        }
                    }
                    print("Price", cell.txtPrice.text!)
                    print("Discount", cell.txtDiscount.text!)
                    print("Qty", cell.txtQty.text!)
                    print("MOQ", cell.txtMOQ.text!)
                    print("Package Size", cell.txtPackageSize.text!)
                    
                    if errorMsg != "" {
                        break
                    }
                }
            }
            else {
                if (self.arrSelectedProductList?.count ?? 0) <= 0 {
                    errorMsg = "Add product(s)."
                }
            }
            
            if errorMsg == "" {
                self.viewProductList.isHidden = true
                self.viewStepSelectBP.isHidden = true
                self.viewStepDeliveryType.isHidden = false
                
                //self.btnAdd.isHidden = true
                
                self.intCurrentStep = 2
                self.isAddProductView = false
                self.isViewStepDeliveryType = true
                
                self.constraintBottomViewDeliveryType.priority = .required
                
                for (i, value) in (self.arrSelectedProductList ?? []).enumerated() {
                    self.arrSelectedProductList?[i].productName = value.name ?? ""
                }
                
                self.saveToDraftOrder.products = self.arrSelectedProductList
                
                self.lblStepCount.text = "2 of \(self.intTotalStep)"
                self.intCurrentStep = 2
                self.viewStepCount.progress = (1 / CGFloat(self.intTotalStep)) * CGFloat(self.intCurrentStep)
                
                if self.isFromSalesOrder {
                    self.btnSave.isHidden = false
                }
                else {
                    self.btnSave.isHidden = true
                }
                
                // Need to manage sample order from here.
                
                self.lblStepTitle.text = "Delivery Type"
                self.lblNextStep.text = "Next: Payment & Review"
            }
            else {
                Utilities.showPopup(title: errorMsg, type: .error)
            }
        }
    }
    @IBOutlet weak var constraintBottomViewSelectBP: NSLayoutConstraint!
    
    // View Step - 2
    
    @IBOutlet weak var viewStepDeliveryType: UIView!
    
    @IBOutlet weak var viewClientCode: UIView!
    @IBOutlet weak var txtClientCode: TLTextField!
    @IBOutlet weak var lblErrorClientCode: UILabel!
    
    @IBOutlet weak var viewDeliveryType: UIView!
    @IBOutlet weak var lblDeliveryTypeTitle: UILabel!
    @IBOutlet weak var lblDeliveryType: UILabel!
    @IBOutlet weak var btnDeliveryType: UIButton!
    @IBAction func btnDeliveryTypeTap(_ sender: UIButton) {
        let arrDeliveryType: [String] = ["Self Pickup", "Delivery By", "Hand Delivered"]
        
        var selectedValue = self.lblDeliveryType.text ?? "Delivery Type"
        if arrDeliveryType.contains(selectedValue) { }
        else {
            selectedValue = "Self Pickup"
        }
        
        let tempTransporter = Transporter(transporterId: 0, transporterTitle: "Other")
        self.arrBPTransporters?.append(tempTransporter)
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DeliveryTypeVC") as! DeliveryTypeVC
        popupVC.strScreenTitle = "SELECT DELIVERY OPTION"
        popupVC.strSelectedValue = selectedValue
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        if self.isFromSalesOrder {
            popupVC.isFromSalesOrder = true
        }
        else if self.isFromSampleRequest {
            popupVC.isFromSampleRequest = true
        }
        else if self.isFromQI {
            popupVC.isFromQI = true
        }
        else if self.isFromPI {
            popupVC.isFromPI = true
        }
        popupVC.saveToDraftOrder = self.saveToDraftOrder
        popupVC.arrBPTransporters = self.arrBPTransporters
        popupVC.didSelect = { strValue , saveDraft in
            self.lblDeliveryType.textColor = .black
            self.lblDeliveryType.text = strValue
            self.lblDeliveryType.font = Fonts.Medium.returnFont(size: 21.0)
            
            self.saveToDraftOrder = saveDraft
            self.arrBPTransporters = saveDraft.transportNamelist
            
            if strValue == "Self Pickup" {
                self.saveToDraftOrder.orderDeliveryType = "Self"
            }
            else if strValue == "Delivery By" {
                if self.isFromSalesOrder {
                    self.saveToDraftOrder.orderDeliveryType = "Customer"
                }
                else if self.isFromSampleRequest {
                    self.saveToDraftOrder.orderDeliveryType = strValue
                }
            }
            else if strValue == "Hand Delivered" {
                self.saveToDraftOrder.orderDeliveryType = "Hand Delivered"
            }
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblDeliveryTypeSeparator: UILabel!
    @IBOutlet weak var lblErrorDeliveryType: UILabel!
    
    @IBOutlet weak var viewReferenceName: UIView!
    @IBOutlet weak var txtReferenceName: TLTextField!   //  tag - 998
    @IBOutlet weak var lblErrorReferenceName: UILabel!
    
    @IBOutlet weak var viewPaymentTerms: UIView!
    @IBOutlet weak var lblPaymentTermsTitle: UILabel!
    @IBOutlet weak var lblPaymentTerms: UILabel!
    @IBOutlet weak var lblSeparatorPaymentTerms: UILabel!
    @IBOutlet weak var lblErrorPaymentTerms: UILabel!
    @IBOutlet weak var btnPaymentTerms: UIButton!
    @IBAction func btnPaymentTermsTap(_ sender: UIButton) {
    }
    @IBOutlet weak var constraintHeightPaymentTerms: NSLayoutConstraint!
    
    @IBOutlet weak var viewCreditLimit: UIView!
    @IBOutlet weak var lblCreditLimitTitle: UILabel!
    @IBOutlet weak var lblCreditLimit: UILabel!
    @IBOutlet weak var lblSeparatorCreditLimit: UILabel!
    @IBOutlet weak var lblErrorCreditLimit: UILabel!
    @IBOutlet weak var btnCreditLimit: UIButton!
    @IBAction func btnCreditLimitTap(_ sender: UIButton) {
    }
    @IBOutlet weak var constraintHeightCreditLimit: NSLayoutConstraint!
    
    @IBOutlet weak var viewQuotationValidity: UIView!
    @IBOutlet weak var lblQuotationValidityTitle: UILabel!
    @IBOutlet weak var lblQuotationValidity: UILabel!
    @IBOutlet weak var btnQuotationValidity: UIButton!
    @IBAction func btnQuotationValidityTap(_ sender: UIButton) {
        let arrQuotation: [String] = ["3 days", "7 days", "15 days"]
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.QuotationValidity
        popupVC.value = arrQuotation
        popupVC.selectedValue = self.lblQuotationValidity.text ?? "Quotation Validity"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { strValue in
            self.lblQuotationValidity.textColor = .black
            self.lblQuotationValidity.text = strValue
            self.lblQuotationValidity.font = Fonts.Medium.returnFont(size: 21.0)
            
            self.lblErrorQuotationValidity.text = ""
            self.saveToDraftOrder.qiValidity = strValue
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblQuotationValiditySeparator: UILabel!
    @IBOutlet weak var lblErrorQuotationValidity: UILabel!
    @IBOutlet weak var constraintHeightQuotationValidity: NSLayoutConstraint!
    //@IBOutlet weak var constraintTopCommentsToRName: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewComments: UIView!
    @IBOutlet weak var txtComments: TLTextField!    //  tag - 999
    @IBOutlet weak var lblErrorComments: UILabel!
    
    @IBOutlet weak var viewBasicTotal2: UIView!
    @IBOutlet weak var lblBasicTotal2: UILabel!
    @IBOutlet weak var lblTotalProduct2: UILabel!
    @IBOutlet weak var btnNextProduct2: UIButton!
    @IBAction func btnNextProduct2Tap(_ sender: UIButton) {
        self.dismissMyKeyboard()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            if self.checkValidation(to: 0, from: 5) {
                let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "OrderConfirmationVC") as! OrderConfirmationVC
                popupVC.modalPresentationStyle = .overCurrentContext
                popupVC.modalTransitionStyle = .crossDissolve
                popupVC.saveToDraftOrder = self.saveToDraftOrder
                
                if self.isFromSalesOrder {
                    popupVC.isFromSalesOrder = true
                    popupVC.strScreenTitle = "Sales Order Confirmation"
                }
                else if self.isFromSampleRequest {
                    popupVC.isFromSampleRequest = true
                    popupVC.strScreenTitle = "Sample Request Confirmation"
                }
                else if self.isFromQI {
                    popupVC.isFromQI = true
                    popupVC.strScreenTitle = "QI Order Confirmation"
                }
                else if self.isFromPI {
                    popupVC.isFromPI = true
                    popupVC.strScreenTitle = "PI Order Confirmation"
                }
                
                popupVC.onTap = { isValid, strValue, arrFollowUpDays, intCustomFollowUpMaxDays, tempSaveToDraftOrder in
                    self.saveToDraftOrder = tempSaveToDraftOrder
                    if isValid {
                        if self.isFromSalesOrder {
                            self.viewStepSelectBP.isHidden = true
                            self.viewStepDeliveryType.isHidden = true
                            self.viewStepPaymentNReview.isHidden = false
                            
                            self.intCurrentStep = 3
                            self.isAddProductView = false
                            self.isViewStepDeliveryType = false
                            self.isViewPayment = true
                            self.btnSave.isHidden = true
                            
                            self.constraintBottomViewDeliveryType.priority = .defaultLow
                            
                            self.setPaymentMethod()
                            
                            
                            self.lblStepCount.text = "\(self.intCurrentStep) of \(self.intTotalStep)"
                            self.viewStepCount.progress = (1 / CGFloat(self.intTotalStep)) * CGFloat(self.intCurrentStep)
                            
                            self.arrFollowUpDays = arrFollowUpDays
                            self.intCustomFollowUpMaxDays = intCustomFollowUpMaxDays
                            
                            self.lblStepTitle.text = "Payment & Review"
                            self.lblNextStep.text = ""
                        }
                        else if self.isFromSampleRequest {
                            self.placeSampleOrder()
                        }
                        else if self.isFromQI || self.isFromPI {
                            self.addNewOrder()
                        }
                    }
                }
                self.present(popupVC, animated: true)
            }
        }
    }
    @IBOutlet weak var constraintBottomViewDeliveryType: NSLayoutConstraint!
    
    
    // View Step - 3
    
    @IBOutlet weak var viewStepPaymentNReview: UIView!
    @IBOutlet weak var constraintBottomViewPaymentToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var viewAdvancePayment: UIView!
    @IBOutlet weak var lblPaymentLabel: UILabel!
    @IBOutlet weak var btnAdvancePayment: UIButton!
    @IBAction func btnAdvancePaymentTap(_ sender: UIButton) {
    }
    @IBOutlet weak var constraintBottomAdvancePaymentToSuperView: NSLayoutConstraint!
    @IBOutlet weak var btnPayByCash: UIButton!
    @IBAction func btnPayByCashTap(_ sender: UIButton) {
    }
    @IBOutlet weak var btnPayByCheque: UIButton!
    @IBAction func btnPayByChequeTap(_ sender: UIButton) {
    }
    @IBOutlet weak var btnPayByBankTransfer: UIButton!
    @IBAction func btnPayByBankTransferTap(_ sender: UIButton) {
    }
    
    @IBOutlet weak var viewAgainstDelivery: UIView!
    @IBOutlet weak var btnAgainstDelivery: UIButton!
    @IBAction func btnAgainstDeliveryTap(_ sender: UIButton) {
    }
    
    @IBOutlet weak var viewCreditDays: UIView!
    @IBOutlet weak var btnCreditDays: UIButton!
    @IBAction func btnCreditDaysTap(_ sender: UIButton) {
    }
    @IBOutlet weak var lblCreditDays: UILabel!
    @IBOutlet weak var btnSelectCreditDays: UIButton!
    @IBAction func btnSelectCreditDaysTap(_ sender: UIButton) {
        let arrCreditDays: [String] = ["5", "7", "10", "15", "21", "30", "45", "60", "90"]
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.BPCreditDaysTitle
        popupVC.value = arrCreditDays
        popupVC.selectedValue = self.lblCreditDays.text ?? "5"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { days in
            self.lblCreditDays.text = days
        }
        popupVC.onClose = { days in
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewAgainstPDC: UIView!
    @IBOutlet weak var btnAgainstPDC: UIButton!
    @IBAction func btnAgainstPDCTap(_ sender: UIButton) {
    }
    
    @IBOutlet weak var btnSubmitSalesOrder: UIButton!
    @IBAction func btnSubmitSalesOrderTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "OrderAttachmentVC") as! OrderAttachmentVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.arrFollowUpDays = self.arrFollowUpDays
        popupVC.intCustomFollowUpMaxDays = self.intCustomFollowUpMaxDays
        popupVC.isFromEditRejectedOrder = self.isFromEditRejectedOrder
        popupVC.saveToDraftOrder = self.saveToDraftOrder
        popupVC.onTap = { isValid, strValue in
            if isValid {
                print("isValid --> \(isValid)")
                self.viewOrderConfirmed.isHidden = false
                self.lblMsg.text = strValue
            }
            else {
                print("isValid --> \(isValid)")
            }
        }
        self.present(popupVC, animated: true)
    }
    
    
    // View Step - Order Confirmation
    
    @IBOutlet weak var viewOrderConfirmed: UIView!
    @IBOutlet weak var viewBottomSheet: UIView!
    @IBOutlet weak var lblMsg: UILabel!
    @IBOutlet weak var btnOK: UIButton!
    @IBAction func btnOKTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
        APIManager.sharedManager.isRefreshData = true
    }
    
    
    // View Step - Save Draft
    
    @IBOutlet weak var viewConfirmedToSaveDraft: UIView!
    @IBOutlet weak var viewSaveDraft: UIView!
    @IBOutlet weak var btnSaveToDraft: UIButton!
    @IBAction func btnSaveToDraftTap(_ sender: UIButton) {
        self.placeDraftOrder()
    }
    @IBOutlet weak var btnCancelDraft: UIButton!
    @IBAction func btnCancelDraftTap(_ sender: UIButton) {
        self.viewConfirmedToSaveDraft.isHidden = true
    }
    
    @IBOutlet weak var viewFreight: UIView!
    @IBOutlet weak var lblFreightTitle: UILabel!
    @IBOutlet weak var txtFreight: UITextField!     //  tag - 997
    @IBOutlet weak var constraintHeightViewFreight: NSLayoutConstraint!
    
    
    
    // MARK: - Variable
    
    var strScreenTitle = "Sales Order"
    var isFromSalesOrder: Bool = false
    var isFromSampleRequest: Bool = false
    var isFromQI: Bool = false
    var isFromPI: Bool = false
    var ringWidth: CGFloat = 0.0
    var intCurrentStep: Int = 1
    var intTotalStep: Int = 2
    
    var businessPartner: BusinessPartner?
    var isBPSelected: Bool = false
    var isDeliveryDateSelected: Bool = false
    var isBranchSelected: Bool = false
    var businessPartnerAddress: BusinessPartnerAddress?
    
    var isAddProductView: Bool = false
    var arrSelectedProductList: [ProductList]? = []
    var saveToDraftOrder = SaveToDraftOrder()
    var arrUnit: [String]? = []
    var arrMoqUnit: [String]? = []
    
    var isViewStepDeliveryType: Bool = false
    var arrBPTransporters: [Transporter]? = []
    
    var isViewPayment: Bool = false
    var arrFollowUpDays: [String]? = []
    var intCustomFollowUpMaxDays: Int = 0
    
    var isEditableOrder: Bool = false
    var isAddOtherProduct: Bool = false
    
    // Sample Que ans
    var arrDictQueAns: [[String: Any]] = []
    var strQue1: String = "q_application"
    var strQue2: String = "q_trail_bach_size"
    var strQue3: String = "q_brand"
    var strQue4_1: String = "q_potential_qty"
    var strQue4_2: String = "q_potential_measurement"
    var strQue4_3: String = "q_potential_type"
    
    
    // Draft Order
    var isFromEditRejectedOrder: Bool = false
    var editOrderDetail: BPOrderDetail?
    var isFromDraftOrder: Bool = false
    var strJsonData: String = ""
    var intDraftId: Int? = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.isFromSalesOrder {
            self.intTotalStep = 3
        }
        
        self.viewProductList.isHidden = true
        
        self.lblScreenTitle.text = self.strScreenTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        self.ringWidth = self.viewStepCount.frame.width
        
        if (self.saveToDraftOrder.draftID ?? 0) != 0 {
            self.isEditableOrder = true
        }
        self.saveToDraftOrder.isEditableOrder = self.isEditableOrder
        
        
        self.viewStepSelectBP.bounds = self.viewMain.bounds
        
        //self.constraintTopCommentsToRName.priority = .required
        self.constraintHeightPaymentTerms.priority = .required
        self.constraintHeightPaymentTerms.constant = 0
        
        self.constraintHeightCreditLimit.priority = .required
        self.constraintHeightCreditLimit.constant = 0
        
        self.constraintHeightQuotationValidity.priority = .required
        self.constraintHeightQuotationValidity.constant = 0
        
        self.btnSave.isHidden = true
        
        self.constraintHeightViewFreight.priority = .required
        self.constraintBottomViewDeliveryType.priority = .required
        
        /**** 0 -> Sales,     1 -> QI,    2 -> PI */
        if self.isFromSalesOrder {
            self.saveToDraftOrder.orderType = 0
            self.btnSave.isHidden = false
        }
        else if self.isFromQI || self.isFromPI {
            self.saveToDraftOrder.orderType = self.isFromQI ? 1 : 2
            self.constraintHeightViewFreight.priority = .defaultLow
            
            self.constraintHeightPaymentTerms.priority = .defaultLow
            if self.isFromQI {
                self.constraintHeightQuotationValidity.priority = .defaultLow
            }
        }
        /*else if self.isFromPI {
            self.saveToDraftOrder.orderType = 2
            self.constraintHeightViewFreight.priority = .defaultLow
            
            self.constraintHeightPaymentTerms.priority = .defaultLow
            self.constraintHeightQuotationValidity.priority = .defaultLow
        }   //  */
        else if self.isFromSampleRequest {
            //self.saveToDraftOrder.orderType = 2
            
            self.lblBasicTotal.isHidden = true
            self.lblTotalProduct.isHidden = true
            
            self.lblBasicTotal2.isHidden = true
            self.lblTotalProduct2.isHidden = true
        }
        
        self.lblSelectBPSeparator.backgroundColor = Colors.separator.returnColor()
        self.lblSelectBillingLocationSeparator.backgroundColor = Colors.separator.returnColor()
        self.lblDeliveryDateSeparator.backgroundColor = Colors.separator.returnColor()
        self.lblBranchSeparator.backgroundColor = Colors.separator.returnColor()
        
        self.viewAdvancePayment.cornersWFullBorder(radius: 15.0, borderColor: Colors.gray.returnColor(), colorOpacity: 0.5)
        self.viewAgainstDelivery.cornersWFullBorder(radius: 15.0, borderColor: Colors.gray.returnColor(), colorOpacity: 0.5)
        self.viewCreditDays.cornersWFullBorder(radius: 15.0, borderColor: Colors.gray.returnColor(), colorOpacity: 0.5)
        self.viewAgainstPDC.cornersWFullBorder(radius: 15.0, borderColor: Colors.gray.returnColor(), colorOpacity: 0.5)
        
        self.viewOrderConfirmed.isHidden = true
        self.viewBottomSheet.corners([.topLeft, .topRight], radius: 25.0)
        self.btnOK.corners(radius: 10.0)
        
        self.viewConfirmedToSaveDraft.isHidden = true
        
        self.btnSaveToDraft.corners(radius: 10.0)
        self.btnSaveToDraft.tintColor = .white
        self.btnSaveToDraft.backgroundColor = Colors.theme.returnColor()
        
        self.viewSaveDraft.corners([.topLeft, .topRight], radius: 25.0)
        self.btnCancelDraft.cornersWFullBorder(radius: 11.0, borderColor: .black, colorOpacity: 0.5)
        self.btnCancelDraft.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnCancelDraft.backgroundColor = .white
        
        self.lblPaymentTermsTitle.textColor = Colors.gray.returnColor()
        self.lblCreditLimitTitle.textColor = Colors.gray.returnColor()
        
        self.viewAdvancePayment.backgroundColor = .white
        self.viewAgainstDelivery.backgroundColor = .white
        self.viewCreditDays.backgroundColor = .white
        self.viewAgainstPDC.backgroundColor = .white
        
        self.btnSubmitSalesOrder.corners(radius: 14.0)
        self.btnSelectCreditDays.isEnabled = false
        
        self.btnAdvancePayment.tintColor = Colors.gray.returnColor()
        self.btnPayByCash.tintColor = Colors.gray.returnColor()
        self.btnPayByCheque.tintColor = Colors.gray.returnColor()
        self.btnPayByBankTransfer.tintColor = Colors.gray.returnColor()
        self.btnAgainstDelivery.tintColor = Colors.gray.returnColor()
        self.btnCreditDays.tintColor = Colors.gray.returnColor()
        self.btnAgainstPDC.tintColor = Colors.gray.returnColor()
        
        self.btnAdvancePayment.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnPayByCash.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnPayByCheque.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnPayByBankTransfer.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnAgainstDelivery.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnCreditDays.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnAgainstPDC.setTitleColor(Colors.gray.returnColor(), for: .normal)
        
        self.viewStepCount.backgroundColor = UIColor(hexString: "#E9E9FF", alpha: 1.0)
        self.viewStepCount.color = Colors.theme.returnColor()
        self.lblStepCount.text = "1 of \(self.intTotalStep)"
        self.intCurrentStep = 1
        self.viewStepCount.progress = (1 / CGFloat(self.intTotalStep)) * CGFloat(self.intCurrentStep)
        
        self.btnAddProduct.backgroundColor = Colors.theme.returnColor()
        self.btnAddProduct.setTitleColor(.white, for: .normal)
        self.btnAddProduct.corners(radius: 15)
        
        self.lblBasicTotal.textColor = Colors.theme.returnColor()
        self.btnNextProduct.corners(radius: 15)
        self.btnNextProduct.backgroundColor = Colors.theme.returnColor()
        
        self.lblBasicTotal2.textColor = Colors.theme.returnColor()
        self.btnNextProduct2.corners(radius: 15)
        self.btnNextProduct2.backgroundColor = Colors.theme.returnColor()
        
        if !self.isFromSampleRequest {
            self.checkKeyboard(kView: self.viewProductList)
        }
        self.checkKeyboard(kView: self.viewStepDeliveryType)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.btnAdd.tintColor = Colors.theme.returnColor()
        self.btnAdd.backgroundColor = UIColor(hexString: "#007AFF", alpha: 0.05)
        self.btnAdd.corners(radius: 14.0)
        
        self.btnAddOtherProduct.tintColor = Colors.theme.returnColor()
        self.btnAddOtherProduct.backgroundColor = UIColor(hexString: "#007AFF", alpha: 0.05)
        self.btnAddOtherProduct.corners(radius: 14.0)
        
        self.btnAddOtherProduct.isHidden = true
        if self.isFromSampleRequest && self.isAddOtherProduct {
            self.btnAddOtherProduct.isHidden = false
        }
        
        self.btnSave.tintColor = Colors.theme.returnColor()
        
        self.saveToDraftOrder.companyType = APIManager.sharedManager.companyType ?? 1
        
        if (self.saveToDraftOrder.requiredDate ?? "") == "" {
            self.lblDeliveryDate.text = Utilities.convertDateToString(date: Date(), NewDateFormate: "dd-MMM-yyyy")
            self.lblDeliveryDate.textColor = .black
            self.lblDeliveryDate.font = Fonts.Medium.returnFont(size: 21.0)
            self.isDeliveryDateSelected = true
            self.saveToDraftOrder.requiredDate = Utilities.convertDateToString(date: Date(), NewDateFormate: "yyyy/MM/dd")
        }
        else {
            self.lblDeliveryDate.text = self.saveToDraftOrder.requiredDate ?? ""
            self.lblDeliveryDate.textColor = .black
            self.lblDeliveryDate.font = Fonts.Medium.returnFont(size: 21.0)
            self.isDeliveryDateSelected = true
        }
        
        // Set Details.
        self.lblBusinessP.text = self.saveToDraftOrder.businessPartnerName ?? "Select Business Partner"
        self.lblBillingLocation.text = self.saveToDraftOrder.billingAddressName ?? "Select Billing Location"
        self.lblBranch.text = self.saveToDraftOrder.branchName ?? "Select Branch"
        
        if self.isFromDraftOrder {
            
            guard let responseData = self.strJsonData.data(using: .utf8) else { return }
            
            do {
                let tempSaveToDraftOrder = try JSONDecoder().decode(SaveToDraftOrder.self, from: responseData)
                
                self.saveToDraftOrder = tempSaveToDraftOrder
                self.saveToDraftOrder.draftID = intDraftId
                self.setDetailsFromDraft(self.saveToDraftOrder)
                
            } catch DecodingError.typeMismatch(let key, let expectedType) {
                print("Type mismatch for key: \(key), expected \(expectedType)")
            } catch let err {
                print(err)
            }
        }
        
        if self.isFromEditRejectedOrder {
            self.saveToDraftOrder = SaveToDraftOrder(from: editOrderDetail!)
            self.setDetailsFromDraft(self.saveToDraftOrder)
        }
        
        DispatchQueue.main.async {
            self.constraintHeightViewStepSelectBP.constant = self.viewScrollViewOut.frame.height
            self.constraintHeightViewStepSelectBP.priority = .required
        }
    }
    
    func selectProducts() {
        self.showLoading()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.hideLoading()
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductCategoryVC") as! ProductCategoryVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.isFromAddOrder = true
            popupVC.strScreenTitle = "Select Product(s)"
            popupVC.arrSelectedProductList = self.arrSelectedProductList
            if self.isFromSalesOrder || self.isFromQI || self.isFromPI {
                popupVC.isFromSalesOrder = true
            }
            else if self.isFromSampleRequest {
                popupVC.isFromSampleOrder = true
            }
            popupVC.onCellTap = { isSelect, arrProductList in
                if isSelect {
                    self.arrSelectedProductList = arrProductList
                    
                    if self.isFromSalesOrder || self.isFromQI || self.isFromPI {
                        self.isAddProductView = true
                        self.viewProductList.isHidden = false
                        
                        if self.isFromSalesOrder {
                            self.btnSave.isHidden = false
                        }
                        else {
                            self.btnSave.isHidden = true
                        }
                        
                        self.lblTotalProduct.text = "\(self.arrSelectedProductList?.count ?? 0) Products"
                        self.lblTotalProduct2.text = "\(self.arrSelectedProductList?.count ?? 0) Products"
                        self.tvProductList.reloadData()
                        self.getBasicOfAllProduct()
                        
                        self.lblBasicTotal.isHidden = false
                        self.lblTotalProduct.isHidden = false
                        self.btnNextProduct.isHidden = false
                        self.viewFreight.isHidden = false
                    }
                    else if self.isFromSampleRequest {
                        self.btnSave.isHidden = true
                        
                        let tempQueAns: [String: String] = [ 
                            self.strQue1: "",
                            self.strQue2: "",
                            self.strQue3: "",
                            self.strQue4_1: "",
                            self.strQue4_2: "",
                            self.strQue4_3: ""
                        ]
                        
                        self.arrDictQueAns.append(tempQueAns)
                        
                        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "AddSampleProductDetailsVC") as! AddSampleProductDetailsVC
                        popupVC.modalPresentationStyle = .overCurrentContext
                        popupVC.modalTransitionStyle = .crossDissolve
                        //popupVC.isFromAddOrder = true
                        //popupVC.strScreenTitle = "Select Product(s)"
                        popupVC.arrSelectedProductList = self.arrSelectedProductList
                        popupVC.arrDictQueAns = self.arrDictQueAns
                        if self.isFromSampleRequest {
                            popupVC.isFromSampleRequest = true
                        }
                        popupVC.onSaveTap = { isAddNewProduct, isBack, arrProductList, arrDictQueAns in
                            self.arrSelectedProductList = arrProductList
                            self.arrDictQueAns = arrDictQueAns
                            
                            if isAddNewProduct {
                                self.selectProducts()
                            }
                            else {
                                if !isBack {
                                    self.isAddProductView = true
                                    self.viewProductList.isHidden = false
                                    self.btnNextProduct.isHidden = false
                                    self.tvProductList.reloadData()
                                }
                            }
                        }
                        self.present(popupVC, animated: true, completion: nil)
                    }
                }
                else {
                }
            }
            self.present(popupVC, animated: true, completion: nil)
        }
    }
    
    func setPaymentMethod() {
        if (self.saveToDraftOrder.paymentType ?? "") == "1" {
            self.btnAdvancePayment.isSelected = true
            self.btnAdvancePayment.tintColor = Colors.themeGreen.returnColor()
            self.btnAdvancePayment.setTitleColor(Colors.theme.returnColor(), for: .normal)
        }
        else if (self.saveToDraftOrder.paymentType ?? "") == "2" {
            self.btnAgainstDelivery.isSelected = true
            self.btnAgainstDelivery.tintColor = Colors.themeGreen.returnColor()
            self.btnAgainstDelivery.setTitleColor(Colors.theme.returnColor(), for: .normal)
        }
        else if (self.saveToDraftOrder.paymentType ?? "") == "3" {
            self.btnCreditDays.isSelected = true
            self.btnCreditDays.tintColor = Colors.themeGreen.returnColor()
            self.btnCreditDays.setTitleColor(Colors.theme.returnColor(), for: .normal)
            
            self.lblCreditDays.text = self.saveToDraftOrder.creditDay ?? ""
        }
        else if (self.saveToDraftOrder.paymentType ?? "") == "4" {
            self.btnAgainstPDC.isSelected = true
            self.btnAgainstPDC.tintColor = Colors.themeGreen.returnColor()
            self.btnAgainstPDC.setTitleColor(Colors.theme.returnColor(), for: .normal)
        }
    }
    
    func setDetailsFromDraft(_ draftData: SaveToDraftOrder) {
        
        self.lblBusinessP.text = self.saveToDraftOrder.businessPartnerName ?? "Select Business Partner"
        self.lblBusinessP.textColor = .black
        self.lblBusinessP.font = Fonts.Medium.returnFont(size: 21.0)
        self.isBPSelected = true
        
        self.txtClientCode.text = self.saveToDraftOrder.businesscode ?? ""
        self.txtClientCode.isEnabled = false
        
        self.lblBillingLocation.text = self.saveToDraftOrder.billingAddressName ?? "Select Billing Location"
        self.lblBillingLocation.textColor = .black
        self.lblBillingLocation.font = Fonts.Medium.returnFont(size: 21.0)
        
        if isFromEditRejectedOrder {
            let dateFormate = "dd-MMMM-yyyy"
            self.saveToDraftOrder.requiredDate = Utilities.convertStrDateToString(date: self.saveToDraftOrder.requiredDate ?? "", CurrentDateFormate: dateFormate, NewDateFormate: "yyyy/MM/dd")
        }
        self.lblDeliveryDate.text = Utilities.convertStrDateToString(date: self.saveToDraftOrder.requiredDate ?? "", CurrentDateFormate: "yyyy/MM/dd", NewDateFormate: "dd-MMM-yyyy")
        self.lblDeliveryDate.textColor = .black
        self.lblDeliveryDate.font = Fonts.Medium.returnFont(size: 21.0)
        self.isDeliveryDateSelected = true
        
        self.lblBranch.text = self.saveToDraftOrder.branchName ?? "Select Branch"
        self.lblBranch.textColor = .black
        self.lblBranch.font = Fonts.Medium.returnFont(size: 21.0)
        self.isBranchSelected = true
        
        self.arrSelectedProductList = self.saveToDraftOrder.products
        
        if self.isFromSampleRequest {
            let tempQueAns: [String: Any] = [
                self.strQue1: "",
                self.strQue2: "",
                self.strQue3: "",
                self.strQue4_1: "",
                self.strQue4_2: "",
                self.strQue4_3: ""
            ]
            for _ in 0 ..< (self.arrSelectedProductList?.count ?? 0) {
                self.arrDictQueAns.append(tempQueAns)
            }
        }
        
        for i in 0 ..< (self.arrSelectedProductList?.count ?? 0) {
            
            let temp = self.arrSelectedProductList?[i]
            
            if self.isFromDraftOrder {
                
                self.arrSelectedProductList?[i].id = temp?.productId ?? 0
                self.arrSelectedProductList?[i].name = temp?.productName ?? ""
                //self.arrSelectedProductList?[i].unitPrice = temp?.productOldPrice ?? 0.0
            }
            
            if self.isFromEditRejectedOrder && (self.isFromSalesOrder || self.isFromSampleRequest || self.isFromQI || self.isFromPI) {
                
                self.arrSelectedProductList?[i].id = temp?.productId ?? 0
                
                self.arrSelectedProductList?[i].name = temp?.productName ?? ""
                self.arrSelectedProductList?[i].unitPrice = temp?.originalPrice ?? 0.0
                
                self.arrSelectedProductList?[i].discountPrice = temp?.productDiscount ?? 0.0
                self.arrSelectedProductList?[i].quantity = temp?.productQty ?? 0.0
                self.arrSelectedProductList?[i].discountPrice = temp?.productDiscount ?? 0.0
                self.arrSelectedProductList?[i].tax = temp?.productTax ?? 0.0
                
                if self.isFromSampleRequest {
                    let tempQue = temp?.questions
                    self.arrDictQueAns[i][self.strQue1]   = temp?.questions?.qApplication ?? ""
                    self.arrDictQueAns[i][self.strQue2]   = temp?.questions?.qTrailBachSize ?? ""
                    self.arrDictQueAns[i][self.strQue3]   = temp?.questions?.qBrand ?? ""
                    self.arrDictQueAns[i][self.strQue4_1] = temp?.questions?.qPotentialQty ?? ""
                    self.arrDictQueAns[i][self.strQue4_2] = temp?.questions?.qPotentialMeasurement ?? ""
                    self.arrDictQueAns[i][self.strQue4_3] = temp?.questions?.qPotentialType ?? ""
                }
                
            }
            
        }
        
        self.txtReferenceName.text = self.saveToDraftOrder.referenceEmployeeName ?? ""
        self.txtComments.text = self.saveToDraftOrder.comment ?? ""
        
        self.txtFreight.text = "\(self.saveToDraftOrder.freight ?? 0.0)"
        self.lblQuotationValidity.text = self.saveToDraftOrder.qiValidity ?? ""
        
        let paymentType = Int(self.saveToDraftOrder.paymentType ?? "0") ?? 0
        self.lblPaymentTerms.text = PaymentTypes.getPaymentType(type: paymentType)
        self.lblCreditLimit.text = self.saveToDraftOrder.creditDay ?? ""
        
        var strValue: String = "Delivery Type"
        if self.saveToDraftOrder.orderDeliveryType == "Self" {
            strValue = "Self Pickup"
        }
        else if self.saveToDraftOrder.orderDeliveryType == "Customer" {
            strValue = "Delivery By"
        }
        else if self.saveToDraftOrder.orderDeliveryType == "Delivery By" {
            strValue = "Delivery By"
        }
        else if self.saveToDraftOrder.orderDeliveryType == "Hand Delivered" {
            strValue = "Hand Delivered"
        }
        
        if strValue != "Delivery Type" {
            self.lblDeliveryType.textColor = .black
            self.lblDeliveryType.text = strValue
            self.lblDeliveryType.font = Fonts.Medium.returnFont(size: 21.0)
        }
        
        self.arrBPTransporters = self.saveToDraftOrder.transportNamelist
        
    }
}
