//
//  AddOrderSelectedProductTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 06/06/24.
//

import UIKit

class AddOrderSelectedProductTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBorder: UIView!
    
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var btnDelete: UIButton!
    @IBAction func btnDeleteTap(_ sender: UIButton) {
        if self.onDeleteTap != nil {
            self.onDeleteTap!(index)
        }
    }
    
    @IBOutlet weak var lblBasePrice: UILabel!
    @IBOutlet weak var lblGST: UILabel!
    
    @IBOutlet weak var btnViewStocks: UIButton!
    @IBAction func btnViewStocksTap(_ sender: UIButton) {
        if self.onViewStockTap != nil {
            self.onViewStockTap!(index)
        }
    }
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var viewPriceDiscount: UIView!
    @IBOutlet weak var viewPrice: UIView!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var txtPrice: UITextField!
    
    @IBOutlet weak var viewDiscount: UIView!
    @IBOutlet weak var lblDiscount: UILabel!
    @IBOutlet weak var txtDiscount: UITextField!
    
    
    @IBOutlet weak var viewQtyUnit: UIView!
    
    @IBOutlet weak var viewQty: UIView!
    @IBOutlet weak var lblQty: UILabel!
    @IBOutlet weak var txtQty: UITextField!
    
    @IBOutlet weak var viewUnit: UIView!
    @IBOutlet weak var lblUnitTitle: UILabel!
    @IBOutlet weak var lblUnit: UILabel!
    @IBOutlet weak var btnUnit: UIButton!
    @IBAction func btnUnitTap(_ sender: UIButton) {
        if self.onUnitTap != nil {
            self.onUnitTap!(index)
        }
    }
    
    
    @IBOutlet weak var viewMTotal: UIView!
    
    @IBOutlet weak var viewTotal: UIView!
    @IBOutlet weak var lblTotalTitle: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    
    
    @IBOutlet weak var viewMoqNUnit: UIView!
    
    @IBOutlet weak var viewMOQ: UIView!
    @IBOutlet weak var lblMOQ: UILabel!
    @IBOutlet weak var txtMOQ: UITextField!
    
    @IBOutlet weak var viewMoqUnit: UIView!
    @IBOutlet weak var lblMoqUnit: UILabel!
    @IBOutlet weak var btnMoqUnit: UIButton!
    @IBAction func btnMoqUnitTap(_ sender: UIButton) {
        if self.onMoqUnitTap != nil {
            self.onMoqUnitTap!(index)
        }
    }
    
    
    @IBOutlet weak var viewPackageSizeViewOrders: UIView!
    
    @IBOutlet weak var viewPackageSize: UIView!
    @IBOutlet weak var lblPackageSize: UILabel!
    @IBOutlet weak var txtPackageSize: UITextField!
    
    @IBOutlet weak var viewViewOrders: UIView!
    @IBOutlet weak var btnViewOrders: UIButton!
    @IBAction func btnViewOrdersTap(_ sender: UIButton) {
        if self.onViewOrdersTap != nil {
            self.onViewOrdersTap!(index)
        }
    }
    @IBOutlet weak var constraintTopViewOrdersToViewMoqTotal: NSLayoutConstraint!
    
    // MARK: - Variable
    
    var index: Int = 0
    var onDeleteTap: ((Int)->Void)?
    var onViewStockTap: ((Int)->Void)?
    var onUnitTap: ((Int)->Void)?
    var onMoqUnitTap: ((Int)->Void)?
    var onViewOrdersTap: ((Int)->Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.viewBorder.cornersWFullBorder(radius: 15.0, borderColor: .black, colorOpacity: 0.5)
        self.lblTotal.corners(radius: 5)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
