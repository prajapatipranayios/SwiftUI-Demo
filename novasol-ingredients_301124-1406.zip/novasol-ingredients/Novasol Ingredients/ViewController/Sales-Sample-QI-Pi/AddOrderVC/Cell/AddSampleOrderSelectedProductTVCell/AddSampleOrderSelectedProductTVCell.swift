//
//  AddSampleOrderSelectedProductTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 01/07/24.
//

import UIKit

class AddSampleOrderSelectedProductTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewProductCategoryName: UIView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblCategoryName: UILabel!
    @IBOutlet weak var lblQty: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onSelect:((Int)->Int)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
