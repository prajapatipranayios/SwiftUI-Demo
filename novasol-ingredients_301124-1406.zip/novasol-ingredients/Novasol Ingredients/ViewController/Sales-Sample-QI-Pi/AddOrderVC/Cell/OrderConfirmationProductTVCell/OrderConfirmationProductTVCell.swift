//
//  OrderConfirmationProductTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 19/06/24.
//

import UIKit

class OrderConfirmationProductTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBorder: UIView!
    
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblQtyPriceGSTDisc: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    
    @IBOutlet weak var viewBasicGSTNet: UIView!
    @IBOutlet weak var lblBasic: UILabel!
    @IBOutlet weak var lblDiscount: UILabel!
    @IBOutlet weak var lblGST: UILabel!
    @IBOutlet weak var lblNet: UILabel!
    @IBOutlet weak var constraintHeightViewBasicGSTNet: NSLayoutConstraint!
    @IBOutlet weak var constraintWidthViewBasicGSTNet: NSLayoutConstraint!
    
    
    // MARK: - Variable
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.viewBorder.cornersWFullBorder(radius: 15.0, borderColor: .black, colorOpacity: 0.5)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
