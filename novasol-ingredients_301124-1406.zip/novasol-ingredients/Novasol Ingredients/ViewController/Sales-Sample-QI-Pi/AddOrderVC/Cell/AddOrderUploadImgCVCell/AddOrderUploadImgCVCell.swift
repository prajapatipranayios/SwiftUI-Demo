//
//  AddOrderUploadImgCVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 21/06/24.
//

import UIKit

class AddOrderUploadImgCVCell: UICollectionViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var ivUploadImg: UIImageView!
    @IBOutlet weak var txtComment: UITextField!
    @IBOutlet weak var btnDelete: UIButton!
    @IBAction func btnDeleteTap(_ sender: UIButton) {
        if self.onDeleteTap != nil {
            self.onDeleteTap!(index)
        }
    }
    
    
    // MARK: - Variable
    var index: Int = 0
    var onDeleteTap: ((Int)->Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
