//
//  AddOrderVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 03/06/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, DataSource

extension AddOrderVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrSelectedProductList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if self.isFromSalesOrder || self.isFromQI || self.isFromPI {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddOrderSelectedProductTVCell", for: indexPath) as! AddOrderSelectedProductTVCell
            
            if self.isFromSalesOrder {
                cell.constraintTopViewOrdersToViewMoqTotal.priority = .required
                cell.viewPackageSize.isHidden = true
                cell.viewMoqNUnit.isHidden = true
            }
            else if self.isFromQI || self.isFromPI {
                cell.constraintTopViewOrdersToViewMoqTotal.priority = .defaultLow
                cell.viewPackageSize.isHidden = false
                cell.viewMoqNUnit.isHidden = false
            }
            
            cell.index = indexPath.row
            
            cell.txtPrice.delegate = self
            cell.txtDiscount.delegate = self
            cell.txtQty.delegate = self
            cell.txtMOQ.delegate = self
            cell.txtPackageSize.delegate = self
            
            cell.txtPrice.tag = indexPath.row
            cell.txtDiscount.tag = indexPath.row
            cell.txtQty.tag = indexPath.row
            cell.txtMOQ.tag = indexPath.row
            cell.txtPackageSize.tag = indexPath.row
            
            let unit = self.arrSelectedProductList?[indexPath.row].productUnit ?? ""
            var basePrice = "₹ \(self.arrSelectedProductList?[indexPath.row].unitPrice ?? 0)"
            if unit != "" {
                basePrice = basePrice + "/ \(unit)"
            }
            
            let temp: String = self.arrSelectedProductList?[indexPath.row].name ?? ""
            cell.lblProductName.text = self.arrSelectedProductList?[indexPath.row].name ?? ""
            self.arrSelectedProductList?[indexPath.row].name = temp
            
            cell.lblCategory.text = "(\(self.arrSelectedProductList?[indexPath.row].categoryName ?? ""))"
            cell.lblBasePrice.text = basePrice
            cell.lblGST.text = "\(self.arrSelectedProductList?[indexPath.row].tax ?? 0)% GST"
            cell.lblUnit.text = self.arrSelectedProductList?[indexPath.row].productUnit ?? ""
            
            cell.txtPrice.text = ""
            cell.txtQty.text = ""
            cell.txtDiscount.text = ""
            cell.txtMOQ.text = ""
            cell.txtPackageSize.text = ""
            
            if (self.arrSelectedProductList?[indexPath.row].productPrice ?? 0.0) != 0.0 {
                cell.txtPrice.text = "\(self.arrSelectedProductList?[indexPath.row].productPrice ?? 0.0)"
            }
            
            if (self.arrSelectedProductList?[indexPath.row].quantity ?? 0.0) != 0.0 {
                cell.txtQty.text = "\(self.arrSelectedProductList?[indexPath.row].quantity ?? 0.0)"
            }
            
            if (self.arrSelectedProductList?[indexPath.row].discountPrice ?? 0.0) != 0.0 {
                cell.txtDiscount.text = "\(self.arrSelectedProductList?[indexPath.row].discountPrice ?? 0.0)"
            }
            
            if (self.arrSelectedProductList?[indexPath.row].moq ?? 0.0) != 0.0 {
                cell.txtMOQ.text = "\(self.arrSelectedProductList?[indexPath.row].moq ?? 0.0)"
            }
            
            if (self.arrSelectedProductList?[indexPath.row].moqUnit ?? "") != "" {
                cell.lblMoqUnit.text = self.arrSelectedProductList?[indexPath.row].moqUnit ?? ""
            }
            
            if ((self.arrSelectedProductList?[indexPath.row].packSize ?? "0.0") != "0.0") || ((self.arrSelectedProductList?[indexPath.row].packSize ?? "") != "") {
                cell.txtPackageSize.text = self.arrSelectedProductList?[indexPath.row].packSize ?? "0.0"
            }
            
            // Total Calculation
            let productPrice = Double(cell.txtPrice.text ?? "0") ?? 0.0
            let discount = Double(cell.txtDiscount.text ?? "0") ?? 0.0
            let qty = Double(cell.txtQty.text ?? "0") ?? 0.0
            let productUnit = cell.lblUnit.text ?? ""
            let moq = Double(cell.txtMOQ.text ?? "0") ?? 0.0
            let moqUnit = cell.lblMoqUnit.text ?? ""
            let packageSize = Double(cell.txtPackageSize.text ?? "0") ?? 0.0
            
            var total: Double = Double(productPrice) * Double(qty)
            total = total - ((total * discount)/100)
            
            let price: String = "\(total)".curFormatAsRegion()
            cell.lblTotal.text = "₹ \(price)"
            
            
            // Condition
            if (APIManager.sharedManager.userDetail?.roleId ?? 0 == 12) && !self.isFromQI {
                // Fill from uUser commission array
                // same in moq
            }
            else {
                // Fill array with product_unit
                
                if !(self.arrUnit ?? []).contains(self.arrSelectedProductList?[indexPath.row].productUnit ?? "") {
                    self.arrUnit?.append(self.arrSelectedProductList?[indexPath.row].productUnit ?? "")
                }
                
                if !(self.arrMoqUnit ?? []).contains(self.arrSelectedProductList?[indexPath.row].productUnit ?? "") {
                    self.arrMoqUnit?.append(self.arrSelectedProductList?[indexPath.row].productUnit ?? "")
                }
            }
            
            
            if (self.arrSelectedProductList?[indexPath.row].productUnit ?? "") != "" {
                cell.lblUnit.text = ((self.arrUnit ?? []).contains(self.arrSelectedProductList?[indexPath.row].productUnit ?? "")) ? (self.arrSelectedProductList?[indexPath.row].productUnit ?? "") : ""
                cell.btnUnit.isEnabled = false
            }
            else {
                if self.arrUnit?.count ?? 0 > 0 {
                    cell.lblUnit.text = self.arrUnit?[0] ?? ""
                }
            }
            
            if (self.arrSelectedProductList?[indexPath.row].moqUnit ?? "") != "" {
                cell.lblMoqUnit.text = ((self.arrMoqUnit ?? []).contains(self.arrSelectedProductList?[indexPath.row].moqUnit ?? "")) ? (self.arrSelectedProductList?[indexPath.row].moqUnit ?? "") : ""
            }
            else {
                if self.arrMoqUnit?.count ?? 0 > 0 {
                    cell.lblMoqUnit.text = self.arrMoqUnit?[0] ?? ""
                }
            }
            
            // On button tap.
            cell.onDeleteTap = { index in
                self.deleteProductPoppup(index: index)
            }
            
            cell.onViewStockTap = { index in
                self.seeProductStocks(arrProductWarehouse: self.arrSelectedProductList?[indexPath.row].productWarehouse ?? [])
            }
            
            cell.onUnitTap = { index in
                let path = IndexPath(row: index, section: 0)
                let cell = self.tvProductList.cellForRow(at: path) as! AddOrderSelectedProductTVCell
                self.selectProductUnit(index: index, isUnit: true, unit: cell.lblUnit.text!, arrUnits: self.arrUnit ?? [])
            }
            
            cell.onMoqUnitTap = { index in
                let path = IndexPath(row: index, section: 0)
                let cell = self.tvProductList.cellForRow(at: path) as! AddOrderSelectedProductTVCell
                self.selectProductUnit(index: index, isUnit: false, unit: cell.lblUnit.text!, arrUnits: self.arrMoqUnit ?? [])
            }
            
            cell.onViewOrdersTap = { index in
                self.seeProductOrders(productId: self.arrSelectedProductList?[indexPath.row].id ?? 0)
            }
            
            return cell
        }
        else if self.isFromSampleRequest {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddSampleOrderSelectedProductTVCell", for: indexPath) as! AddSampleOrderSelectedProductTVCell
            
            cell.lblProductName.textColor = Colors.theme.returnColor()
            cell.lblCategoryName.textColor = Colors.theme.returnColor()
            
            cell.lblProductName.text = self.arrSelectedProductList?[indexPath.row].name ?? ""
            
            var category: String = self.arrSelectedProductList?[indexPath.row].categoryName ?? ""
            if category != "" {
                category = "(\(category))"
            }
            if (self.arrSelectedProductList?[indexPath.row].remark ?? "") != "" {
                category = category + " (\(self.arrSelectedProductList?[indexPath.row].remark ?? ""))"
            }
            cell.lblCategoryName.text = category
            
            let qty: Double = self.arrSelectedProductList?[indexPath.row].quantity ?? 0.0
            cell.lblQty.text = "\(qty) \(self.arrSelectedProductList?[indexPath.row].productUnit ?? "")"
            
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.isFromSampleRequest {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "AddSampleProductDetailsVC") as! AddSampleProductDetailsVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.arrSelectedProductList = self.arrSelectedProductList
            popupVC.arrDictQueAns = self.arrDictQueAns
            popupVC.isFromEditProduct = true
            popupVC.intEditProductIndex = indexPath.row
            popupVC.isFromSampleRequest = true
            popupVC.onSaveTap = { isAddNewProduct, isBack, arrProductList, arrDictQueAns in
                if !isAddNewProduct && !isBack {
                    self.arrSelectedProductList = arrProductList
                    self.arrDictQueAns = arrDictQueAns
                    
                    self.isAddProductView = true
                    self.viewProductList.isHidden = false
                    self.tvProductList.reloadData()
                }
            }
            self.present(popupVC, animated: true, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if self.isFromSampleRequest {
            return true
        }
        else {
            return false
        }
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let delete = UIContextualAction(style: .normal, title: "Delete") { action, view, complete in
            
            // Open popup for reason.
            //self.arrSelectedProductList?.remove(at: indexPath.row)
            //self.arrDictQueAns.remove(at: indexPath.row)
            //self.tvProductList.reloadData()
            self.deleteProductPoppup(index: indexPath.row, isFromSample: true)
            
            complete(true)
        }
        let lblDelete = UILabel()
        lblDelete.text = "Delete"
        lblDelete.font = Fonts.Regular.returnFont(size: 20.0)
        lblDelete.sizeToFit()
        lblDelete.textColor = .white
        //delete.image = UIImage(systemName: "xmark.circle")     //UIImage(named: "Delete")
        
        delete.image = Utilities.addLabelToImage(image: UIImage(named: "DeleteCircleW")!, label: lblDelete)
        delete.backgroundColor = .red
        
        return UISwipeActionsConfiguration(actions: [delete])
    }
    
    func seeProductStocks(arrProductWarehouse: [ProductWarehouse]?) {
        if (arrProductWarehouse?.count ?? 0) > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewStocksVC") as! ViewStocksVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.titleTxt = "Stocks"
            popupVC.arrProductWarehouse = arrProductWarehouse
            popupVC.onClose = {  }
            self.present(popupVC, animated: true)
        }
        else {
            Utilities.showPopup(title: "No stock data.", type: .error)
        }
    }
    
    func seeProductOrders(productId: Int) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductOrderVC") as! ProductOrderVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.productId = productId
        popupVC.isFromAddOrder = true
        popupVC.onCloseTap = { isClose in
        }
        self.present(popupVC, animated: true)
    }
    
    func selectProductUnit(index: Int, isUnit: Bool, unit: String, arrUnits: [String] = ["KG", "NOS", "Ltr", "CTN"]) {
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = "Unit"
        popupVC.value = arrUnits
        popupVC.selectedValue = unit
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { value in
            let path = IndexPath(row: index, section: 0)
            let cell = self.tvProductList.cellForRow(at: path) as! AddOrderSelectedProductTVCell
            
            if isUnit {
                cell.lblUnit.text = value
                self.arrSelectedProductList?[index].productUnitMesurement = value
                self.arrSelectedProductList?[index].productUnit = value
            }
            else {
                cell.lblMoqUnit.text = value
                self.arrSelectedProductList?[index].moqUnit = value
            }
        }
        popupVC.onClose = { value in
        }
        self.present(popupVC, animated: true)
    }
    
    func deleteProductPoppup(index: Int, isFromSample: Bool = false) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = "Are you want to remove this product ?"
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            if !isFromSample {
                self.arrSelectedProductList?.remove(at: index)
                self.getBasicOfAllProduct()
                
                self.lblTotalProduct.text = "\(self.arrSelectedProductList?.count ?? 0) Products"
                self.lblTotalProduct2.text = "\(self.arrSelectedProductList?.count ?? 0) Products"
                
                if (self.arrSelectedProductList?.count ?? 0) == 0 {
                    self.lblBasicTotal.isHidden = true
                    self.lblTotalProduct.isHidden = true
                    self.btnNextProduct.isHidden = true
                    self.viewFreight.isHidden = true
                    self.txtFreight.text = ""
                }
            }
            else {
                self.arrSelectedProductList?.remove(at: index)
                self.arrDictQueAns.remove(at: index)
                
                if (self.arrSelectedProductList?.count ?? 0) == 0 {
                    self.btnNextProduct.isHidden = true
                }
            }
            self.tvProductList.reloadData()
         }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
    }
    
    func getBasicOfAllProduct() {
        var basicTotal: Double = 0.0
        for i in 0 ..< (self.arrSelectedProductList?.count ?? 0) {
            
            var totalPrice: Double = Double(self.arrSelectedProductList?[i].productPrice ?? 0.0) * Double(self.arrSelectedProductList?[i].quantity ?? 0.0)
            totalPrice = totalPrice - ((totalPrice * (self.arrSelectedProductList?[i].discountPrice ?? 0.0))/100)
            basicTotal += totalPrice
        }
        
        self.lblBasicTotal.text = "Basic Total: ₹ " + "\(basicTotal)".curFormatAsRegion()
        self.lblBasicTotal2.text = "Basic Total: ₹ " + "\(basicTotal)".curFormatAsRegion()
        self.lblPaymentLabel.text = "₹ " + "\(basicTotal)".curFormatAsRegion()
    }
}

// MARK: - TextField Delegate

extension AddOrderVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        if self.isAddProductView {
            if textField == self.txtFreight {
            } else {
                let index = IndexPath(row: textField.tag, section: 0)
                let cell = self.tvProductList.cellForRow(at: index) as! AddOrderSelectedProductTVCell
                if cell.txtDiscount == textField {
                    if Double(newString as Substring) ?? 0.0 > 100 {
                        cell.txtDiscount.text = ""
                    }
                }
            }
            switch string {
            case "0","1","2","3","4","5","6","7","8","9":
                return true
            case ".":
                let array = (textField.text)!.map { String($0) }
                var decimalCount = 0
                for character in array {
                    if character == "." {
                        decimalCount += 1
                    }
                }
                
                if decimalCount == 1 {
                    return false
                } else {
                    return true
                }
            default:
                let array = Array(string)
                if array.count == 0 {
                    return true
                }
                return false
            }
        }
        else {
            return true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        
        if self.isAddProductView {
            if textField == self.txtFreight {
                self.saveToDraftOrder.freight = Double(self.txtFreight.text ?? "0")
            }
            else {
                if !self.isFromSampleRequest {
                    let index = IndexPath(row: textField.tag, section: 0)
                    let cell = self.tvProductList.cellForRow(at: index) as! AddOrderSelectedProductTVCell
                    
                    let productPrice = Double(cell.txtPrice.text ?? "0") ?? 0.0
                    let discount = Double(cell.txtDiscount.text ?? "0") ?? 0.0
                    let qty = Double(cell.txtQty.text ?? "0") ?? 0.0
                    let productUnit = cell.lblUnit.text ?? ""
                    let moq = Double(cell.txtMOQ.text ?? "0") ?? 0.0
                    let moqUnit = cell.lblMoqUnit.text ?? ""
                    let packageSize = Double(cell.txtPackageSize.text ?? "0") ?? 0.0
                    
                    var total: Double = Double(productPrice) * Double(qty)
                    total = total - ((total * discount)/100)
                    
                    let price = "\(total)".curFormatAsRegion()
                    cell.lblTotal.text = "₹ \(price)"
                    
                    self.arrSelectedProductList?[textField.tag].productPrice = productPrice
                    self.arrSelectedProductList?[textField.tag].discountPrice = discount        //discount in %
                    self.arrSelectedProductList?[textField.tag].quantity = qty
                    self.arrSelectedProductList?[textField.tag].productUnit = productUnit
                    self.arrSelectedProductList?[textField.tag].moq = moq
                    self.arrSelectedProductList?[textField.tag].moqUnit = moqUnit
                    self.arrSelectedProductList?[textField.tag].productUnitMesurement = productUnit
                    self.arrSelectedProductList?[textField.tag].packSize = "\(packageSize)"
                    
                    self.getBasicOfAllProduct()
                }
            }
        }
        else {
            if textField.tag == 998 {
                self.saveToDraftOrder.referenceEmployeeName = self.txtReferenceName.text ?? ""
            }
            else if textField.tag == 999 {
                self.saveToDraftOrder.comment = self.txtComments.text ?? ""
            }
        }
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            if i == 0 {
                self.txtClientCode.text = self.txtClientCode.text?.trimmingCharacters(in: .whitespaces)
                if self.txtClientCode.text == "" {
                    self.lblErrorClientCode.getEmptyValidationString((self.txtClientCode.placeholder ?? "").lowercased())
                    //value = false
                }
                else {
                    self.lblErrorClientCode.text = ""
                }
            }
            else if i == 1 {
                self.txtReferenceName.text = self.txtReferenceName.text?.trimmingCharacters(in: .whitespaces)
                if self.txtReferenceName.text == "" {
                    self.lblErrorReferenceName.getEmptyValidationString((self.txtReferenceName.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorReferenceName.text = ""
                }
            }
            else if i == 2 {
                self.txtComments.text = self.txtComments.text?.trimmingCharacters(in: .whitespaces)
                /*if self.txtComments.text == "" {
                 self.lblErrorComments.getEmptyValidationString((self.txtComments.placeholder ?? "").lowercased())
                 value = false
                 }
                 else {
                 self.lblErrorComments.text = ""
                 }   //  */
            }
            else if i == 3 {
                self.lblDeliveryType.text = self.lblDeliveryType.text?.trimmingCharacters(in: .whitespaces)
                if (self.lblDeliveryType.text == "") || (self.lblDeliveryType.text == "Delivery Type") {
                    self.lblErrorDeliveryType.getEmptyValidationString((self.lblDeliveryType.text ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorDeliveryType.text = ""
                }
            }
            else if i == 4 {
                if self.isFromQI {
                    self.lblQuotationValidity.text = self.lblQuotationValidity.text?.trimmingCharacters(in: .whitespaces)
                    if (self.lblQuotationValidity.text == "") || (self.lblQuotationValidity.text == "Quotation Validity") {
                        self.lblErrorQuotationValidity.getEmptyValidationString((self.lblQuotationValidity.text ?? "").lowercased())
                        value = false
                    }
                    else {
                        self.lblErrorQuotationValidity.text = ""
                    }
                }
            }
        }
        return value
    }
}


// MARK: - Keyboard

extension AddOrderVC {
    
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            if self.isAddProductView {
                self.constraintBottomViewFreight.constant = keyboardOverlap > 0 ? (keyboardOverlap - 85) : 0
            }
            else if self.isViewStepDeliveryType {
                self.constraintBottomViewDeliveryType.constant = keyboardOverlap > 0 ? (keyboardOverlap - 85) : 0
            }
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}


// MARK: - Webservices

extension AddOrderVC {
    /*func getBusinessPNEmployeeList(companyType: Int, orderStatus: Int, type: Int, orderType: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBusinessPNEmployeeList(companyType: companyType, orderStatus: orderStatus, type: type, orderType: orderType)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": companyType,
            "order_status": orderStatus,
            "type": type,
            "order_type": orderType
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ORDERED_BUSINESS_PARTNERS, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }// */
    
    /*func changeOrderStatus(orderId: Int, orderStatus: Int, reason: String, preferredWarehouse: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.changeOrderStatus(orderId: orderId, orderStatus: orderStatus, reason: reason, preferredWarehouse: preferredWarehouse)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "order_id": orderId,
            "status": orderStatus,
            "reason": reason,
            "preferredWarehouse": preferredWarehouse
        ] as? [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CHANGE_ORDER_STATUS, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    
                }
            }
            else {
                DispatchQueue.main.async {
                    Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }// */
    
    func placeDraftOrder() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.placeDraftOrder()
                }
            }
            return
        }
        
        let tempDictQue: [String: String] = [:]
        
        var products: [Any] = []
        for i in 0..<(self.saveToDraftOrder.products?.count ?? 0) {
            
            var productWarehouse: [Any] = []
            for j in 0..<(self.saveToDraftOrder.products?[i].productWarehouse?.count ?? 0) {
                let tempProductWarehouse = [
                    "available": self.saveToDraftOrder.products?[i].productWarehouse?[j].available ?? 0,
                    "branchId": self.saveToDraftOrder.products?[i].productWarehouse?[j].branchId ?? 0,
                    "city": self.saveToDraftOrder.products?[i].productWarehouse?[j].city ?? "",
                    "inCommited": self.saveToDraftOrder.products?[i].productWarehouse?[j].inCommited ?? 0,
                    "inStock": self.saveToDraftOrder.products?[i].productWarehouse?[j].inStock ?? "",
                    "productId": self.saveToDraftOrder.products?[i].productWarehouse?[j].productId ?? 0
                ] as [String : Any]
                productWarehouse.append(tempProductWarehouse)
            }
            
            let tempProduct = [
                "categoryId": self.saveToDraftOrder.products?[i].categoryId ?? 0,
                "categoryName": self.saveToDraftOrder.products?[i].categoryName ?? "",
                "commission": self.saveToDraftOrder.products?[i].commission ?? 0,
                "description": self.saveToDraftOrder.products?[i].description ?? "",
                "discount_amount": self.saveToDraftOrder.products?[i].discountAmount ?? 0,
                "discount_price": self.saveToDraftOrder.products?[i].discountPrice ?? 0,
                "hsnNumber": self.saveToDraftOrder.products?[i].hsnNumber ?? "",
                "lastPrice": self.saveToDraftOrder.products?[i].lastPrice ?? 0,
                "maxDiscount": self.saveToDraftOrder.products?[i].maxDiscount ?? 0,
                "pack_size": self.saveToDraftOrder.products?[i].packSize ?? 0,
                "productUnitMesurement": self.saveToDraftOrder.products?[i].productUnitMesurement ?? "",
                "productWarehouse": productWarehouse,
                "product_basic_price": self.saveToDraftOrder.products?[i].productBasicPrice ?? "",
                "product_code": self.saveToDraftOrder.products?[i].productCode ?? "",
                //"id": self.saveToDraftOrder.products?[i].id ?? "",
                "product_id": "\(self.saveToDraftOrder.products?[i].id ?? 0)",
                "moq": self.saveToDraftOrder.products?[i].moq ?? 0,
                "product_name": self.saveToDraftOrder.products?[i].name ?? "",
                "name": self.saveToDraftOrder.products?[i].name ?? "",
                "product_old_price": self.saveToDraftOrder.products?[i].productOldPrice ?? 0,
                "product_price": self.saveToDraftOrder.products?[i].productPrice ?? 0,
                "quantity": self.saveToDraftOrder.products?[i].quantity ?? 0,
                "product_total": self.saveToDraftOrder.products?[i].productTotal ?? 0,
                "product_unit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "productUnit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "moq_unit": self.saveToDraftOrder.products?[i].moqUnit ?? "",
                //"questions": self.saveToDraftOrder.products?[i].questions ?? "",
                "questions": tempDictQue,
                "remark": self.saveToDraftOrder.products?[i].remark ?? "",
                "showWarehouse": self.saveToDraftOrder.products?[i].showWarehouse ?? "",
                "status": self.saveToDraftOrder.products?[i].status ?? 0,
                "storeQty": self.saveToDraftOrder.products?[i].storeQty ?? 0,
                "tax": self.saveToDraftOrder.products?[i].tax ?? 0,
                "userCommission": self.saveToDraftOrder.products?[i].userCommission ?? 0,
                "userCommissionByCategory": [],
                "warehouseQty": self.saveToDraftOrder.products?[i].warehouseQty ?? "",
                
                "unitPrice": self.saveToDraftOrder.products?[i].unitPrice ?? 0.0
            ] as [String : Any]
            products.append(tempProduct)
        }
        
        var transportNamelist: [Any] = []
        for i in 0..<(self.saveToDraftOrder.transportNamelist?.count ?? 0) {
            let tempTransportNamelist = [
                "position": self.saveToDraftOrder.transportNamelist?[i].position ?? false,
                "transporterCode": self.saveToDraftOrder.transportNamelist?[i].transporterCode ?? "",
                "transporterGSTNo": self.saveToDraftOrder.transportNamelist?[i].transporterGSTNo ?? "",
                "transporterId": self.saveToDraftOrder.transportNamelist?[i].transporterId ?? 0,
                "transporterTitle": self.saveToDraftOrder.transportNamelist?[i].transporterTitle ?? ""
            ] as [String : Any]
            transportNamelist.append(tempTransportNamelist)
        }
        
        let jsonData = [ "user_id": APIManager.sharedManager.userId,
                         "billing_address_id": self.saveToDraftOrder.billingAddressID ?? 0,
                         "billing_address_name": self.saveToDraftOrder.billingAddressName ?? "",
                         "booking_point": self.saveToDraftOrder.bookingPoint ?? "",
                         "branch_id": self.saveToDraftOrder.branchID ?? 0,
                         "branchName": self.saveToDraftOrder.branchName ?? "",
                         "businessPartnerTransporter": self.saveToDraftOrder.businessPartnerTransporter ?? [],
                         "business_partners_id": self.saveToDraftOrder.businessPartnersID ?? 0,
                         "business_partner_name": self.saveToDraftOrder.businessPartnerName ?? "",
                         "businesscode": self.saveToDraftOrder.businesscode ?? "",
                         "cgstAmount": self.saveToDraftOrder.cgstAmount ?? 0.0,
                         "comment": self.saveToDraftOrder.comment ?? "",
                         "company_type": 1,
                         "credit_day": self.saveToDraftOrder.creditDay ?? "",
                         "deliveryTo": self.saveToDraftOrder.deliveryTo ?? "",
                         "delivery_address_id": self.saveToDraftOrder.deliveryAddressID ?? "",
                         "delivery_address_name": self.saveToDraftOrder.deliveryAddressName ?? "",
                         "draft_id": self.saveToDraftOrder.draftID ?? 0,
                         "follow_up_days": self.saveToDraftOrder.followUpDays ?? 0,
                         "freight": self.saveToDraftOrder.freight ?? 0.0,
                         "freight_charges": self.saveToDraftOrder.freightCharges ?? "",
                         "freight_gst": self.saveToDraftOrder.freightGst ?? 0,
                         "grand_total_amount": self.saveToDraftOrder.grandTotalAmount ?? "",
                         "gstTotal": self.saveToDraftOrder.gstTotal ?? 0.0,
                         "hand_delivery_text": self.saveToDraftOrder.handDeliveryText ?? "",
                         "igstAmount": self.saveToDraftOrder.igstAmount ?? 0.0,
                         "isEditableOrder": self.saveToDraftOrder.isEditableOrder ?? false,
                         "lastTransporterId": self.saveToDraftOrder.lastTransporterID ?? 0,
                         "order_delivery_type": self.saveToDraftOrder.orderDeliveryType ?? "",
                         "order_id": self.saveToDraftOrder.orderID ?? 0,
                         "order_type": self.saveToDraftOrder.orderType ?? 0,
                         "otherTransporter": self.saveToDraftOrder.otherTransporter ?? "",
                         "payment_amount": self.saveToDraftOrder.paymentAmount ?? "",
                         "payment_cheque_no": self.saveToDraftOrder.paymentChequeNo ?? "",
                         "payment_date": self.saveToDraftOrder.paymentDate ?? "",
                         "payment_mode": self.saveToDraftOrder.paymentMode ?? "",
                         "payment_transaction_id": self.saveToDraftOrder.paymentTransactionID ?? "",
                         "payment_type": self.saveToDraftOrder.paymentType ?? "",
                         //"paymentsDetail": self.saveToDraftOrder.paymentsDetail ?? "",
                         "paymentsDetail": [:],
                         "poAttachment": [],
                         "preferredBranchId": self.saveToDraftOrder.preferredBranchID ?? 0,
                         "products": products,
                         "qiValidity": self.saveToDraftOrder.qiValidity ?? "",
                         "qi_pi_id": self.saveToDraftOrder.qiPiID ?? 0,
                         "referenceEmployeeName": self.saveToDraftOrder.referenceEmployeeName ?? "",
                         "remainder_id": self.saveToDraftOrder.remainderID ?? 0,
                         "required_date": self.saveToDraftOrder.requiredDate ?? "",
                         "sAPId": self.saveToDraftOrder.sAPID ?? "",
                         "sample__request_id": self.saveToDraftOrder.sampleRequestID ?? 0,
                         "sgstAmount": self.saveToDraftOrder.sgstAmount ?? 0.0,
                         "transportNamelist": transportNamelist,
                         "transporterGSTNo": self.saveToDraftOrder.transporterGSTNo ?? "",
                         "transporter_id": self.saveToDraftOrder.transporterID ?? "",
                         "transporter_title": self.saveToDraftOrder.transporterTitle ?? ""
        ] as [String : Any]
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "order_type": 1,
            "draft_id": self.saveToDraftOrder.draftID ?? 0,
            "business_partners_id": self.saveToDraftOrder.businessPartnersID ?? 0,
            "business_partners_name": self.saveToDraftOrder.businessPartnerName ?? "",
            "json_data": Utilities.convertJsonToString(json: jsonData)   //jsonData
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.PLACE_DRAFT_ORDER, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.viewConfirmedToSaveDraft.isHidden = true
                    self.draftSavedPopup(message: response?.message ?? "")
                }
            }
            else {
                DispatchQueue.main.async {
                    Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }
    
    func checkBusinessPartnerOrderExist(businessPartnerId: Int) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.checkBusinessPartnerOrderExist(businessPartnerId: businessPartnerId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partner_id": businessPartnerId
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CHECK_BUSINESS_PARTNER_ORDER_EXIST, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
                    popupVC.modalPresentationStyle = .overCurrentContext
                    popupVC.modalTransitionStyle = .crossDissolve
                    popupVC.titleTxt = "Alert"
                    popupVC.strImgName = "InfoWLightRed"
                    popupVC.strMessage = response?.message ?? ""
                    popupVC.onTapOk = { str in
                    }
                    self.present(popupVC, animated: true)
                }
            }
            else {
                DispatchQueue.main.async {
                    //Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }
    
    func placeSampleOrder() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.placeSampleOrder()
                }
            }
            return
        }
        
        var products: [Any] = []
        for i in 0..<(self.saveToDraftOrder.products?.count ?? 0) {
            
            let tempProduct = [
                "pack_size": self.saveToDraftOrder.products?[i].packSize ?? 0,
                "product_id": "\(self.saveToDraftOrder.products?[i].id ?? 0)",
                "quantity": self.saveToDraftOrder.products?[i].quantity ?? 0,
                "product_unit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "questions": [
                    self.strQue1 : self.arrDictQueAns[i][self.strQue1],
                    self.strQue2 : self.arrDictQueAns[i][self.strQue2],
                    self.strQue3 : self.arrDictQueAns[i][self.strQue3],
                    self.strQue4_1 : self.arrDictQueAns[i][self.strQue4_1],
                    self.strQue4_2 : self.arrDictQueAns[i][self.strQue4_2],
                    self.strQue4_3 : self.arrDictQueAns[i][self.strQue4_3],
                ]
            ] as [String : Any]
            products.append(tempProduct)
        }
        
        var transportNamelist: [Any] = []
        for i in 0..<(self.saveToDraftOrder.transportNamelist?.count ?? 0) {
            let tempTransportNamelist = [
                "position": self.saveToDraftOrder.transportNamelist?[i].position ?? false,
                "transporterCode": self.saveToDraftOrder.transportNamelist?[i].transporterCode ?? "",
                "transporterGSTNo": self.saveToDraftOrder.transportNamelist?[i].transporterGSTNo ?? "",
                "transporterId": self.saveToDraftOrder.transportNamelist?[i].transporterId ?? 0,
                "transporterTitle": self.saveToDraftOrder.transportNamelist?[i].transporterTitle ?? ""
            ] as [String : Any]
            transportNamelist.append(tempTransportNamelist)
        }
         
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "billing_address_id": self.saveToDraftOrder.billingAddressID ?? 0,
            "booking_point": self.saveToDraftOrder.bookingPoint ?? "",
            "branch_id": self.saveToDraftOrder.branchID ?? "",
            "business_partners_id": self.saveToDraftOrder.businessPartnersID ?? 0,
            "businesscode": self.saveToDraftOrder.businesscode ?? "",
            "comment": self.saveToDraftOrder.comment ?? "",
            "company_type": APIManager.sharedManager.companyType ?? 1,
            "deliveryTo": self.saveToDraftOrder.deliveryTo ?? "",
            "delivery_address_id": self.saveToDraftOrder.deliveryAddressID ?? "",
            "hand_delivery_text": self.saveToDraftOrder.handDeliveryText ?? "",
            "lastTransporterId": self.saveToDraftOrder.lastTransporterID ?? 0,
            "order_delivery_type": self.saveToDraftOrder.orderDeliveryType ?? "",
            "order_id": self.saveToDraftOrder.orderID ?? "",
            "otherTransporter": self.saveToDraftOrder.otherTransporter ?? "",
            "products": products,
            "required_date": self.saveToDraftOrder.requiredDate ?? "",
            "transportNamelist": transportNamelist,
            "transporterGSTNo": self.saveToDraftOrder.transporterGSTNo ?? "",
            "transporter_id": self.saveToDraftOrder.transporterID ?? "",
            "transporter_title": self.saveToDraftOrder.transporterTitle ?? ""
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.PLACE_SAMPLE_ORDER, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.draftSavedPopup(message: response?.message ?? "")
                }
            }
            else {
                DispatchQueue.main.async {
                    Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }
    
    /*func addNewOrder() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addNewOrder()
                }
            }
            return
        }
        
        let tempDictQue: [String: String] = [:]
        
        var products: [Any] = []
        for i in 0..<(self.saveToDraftOrder.products?.count ?? 0) {
            
            var productWarehouse: [Any] = []
            for j in 0..<(self.saveToDraftOrder.products?[i].productWarehouse?.count ?? 0) {
                let tempProductWarehouse = [
                    "available": self.saveToDraftOrder.products?[i].productWarehouse?[j].available ?? 0,
                    "branchId": self.saveToDraftOrder.products?[i].productWarehouse?[j].branchId ?? 0,
                    "city": self.saveToDraftOrder.products?[i].productWarehouse?[j].city ?? "",
                    "inCommited": self.saveToDraftOrder.products?[i].productWarehouse?[j].inCommited ?? 0,
                    "inStock": self.saveToDraftOrder.products?[i].productWarehouse?[j].inStock ?? "",
                    "productId": self.saveToDraftOrder.products?[i].productWarehouse?[j].productId ?? 0
                  ] as [String : Any]
                productWarehouse.append(tempProductWarehouse)
            }
            
            let tempProduct = [
                "categoryId": self.saveToDraftOrder.products?[i].categoryId ?? 0,
                "categoryName": self.saveToDraftOrder.products?[i].categoryName ?? "",
                "commission": self.saveToDraftOrder.products?[i].commission ?? 0,
                "description": self.saveToDraftOrder.products?[i].description ?? "",
                "discount_amount": self.saveToDraftOrder.products?[i].discountAmount ?? 0,
                "discount_price": self.saveToDraftOrder.products?[i].discountPrice ?? 0,
                "hsnNumber": self.saveToDraftOrder.products?[i].hsnNumber ?? "",
                "lastPrice": self.saveToDraftOrder.products?[i].lastPrice ?? 0,
                "maxDiscount": self.saveToDraftOrder.products?[i].maxDiscount ?? 0,
                "pack_size": self.saveToDraftOrder.products?[i].packSize ?? 0,
                "productUnitMesurement": self.saveToDraftOrder.products?[i].productUnitMesurement ?? "",
                "productWarehouse": productWarehouse,
                "product_basic_price": self.saveToDraftOrder.products?[i].productBasicPrice ?? "",
                "product_code": self.saveToDraftOrder.products?[i].productCode ?? "",
                "product_id": self.saveToDraftOrder.products?[i].id ?? "",
                "moq": self.saveToDraftOrder.products?[i].moq ?? 0,
                "product_name": self.saveToDraftOrder.products?[i].productName ?? "",
                "product_old_price": self.saveToDraftOrder.products?[i].productOldPrice ?? 0,
                "product_price": self.saveToDraftOrder.products?[i].productPrice ?? 0,
                "quantity": self.saveToDraftOrder.products?[i].quantity ?? 0,
                "product_total": self.saveToDraftOrder.products?[i].productTotal ?? 0,
                "product_unit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "productUnit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "moq_unit": self.saveToDraftOrder.products?[i].moqUnit ?? "",
                //"questions": self.saveToDraftOrder.products?[i].questions ?? "",
                "questions": tempDictQue,
                "remark": self.saveToDraftOrder.products?[i].remark ?? "",
                "showWarehouse": self.saveToDraftOrder.products?[i].showWarehouse ?? "",
                "status": self.saveToDraftOrder.products?[i].status ?? 0,
                "storeQty": self.saveToDraftOrder.products?[i].storeQty ?? 0,
                "tax": self.saveToDraftOrder.products?[i].tax ?? 0,
                "userCommission": self.saveToDraftOrder.products?[i].userCommission ?? 0,
                "userCommissionByCategory": [
                ],
                "warehouseQty": self.saveToDraftOrder.products?[i].warehouseQty ?? ""
              ] as [String : Any]
            products.append(tempProduct)
        }
        
        var transportNamelist: [Any] = []
        for i in 0..<(self.saveToDraftOrder.transportNamelist?.count ?? 0) {
            let tempTransportNamelist = [
                "position": self.saveToDraftOrder.transportNamelist?[i].position ?? false,
                "transporterCode": self.saveToDraftOrder.transportNamelist?[i].transporterCode ?? "",
                "transporterGSTNo": self.saveToDraftOrder.transportNamelist?[i].transporterGSTNo ?? "",
                "transporterId": self.saveToDraftOrder.transportNamelist?[i].transporterId ?? 0,
                "transporterTitle": self.saveToDraftOrder.transportNamelist?[i].transporterTitle ?? ""
            ] as [String : Any]
            transportNamelist.append(tempTransportNamelist)
        }
        
        var businessPTransportNamelist: [Any] = []
        for i in 0..<(self.saveToDraftOrder.businessPartnerTransporter?.count ?? 0) {
            
            let tempTransport = [
                "transporterID": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterID ?? 0,
                "transporterCode": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterCode ?? "",
                "transporterTitle": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterTitle ?? "",
                "transporterGSTNo": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterGSTNo ?? 0,
                "businessPartnersID": self.saveToDraftOrder.businessPartnerTransporter?[i].businessPartnersID ?? 0
            ] as [String : Any]
            businessPTransportNamelist.append(tempTransport)
        }
        
        let tempPaymentDetail = [
            "id": self.saveToDraftOrder.paymentsDetail?.id ?? 0,
            "paymentType": self.saveToDraftOrder.paymentsDetail?.paymentType ?? 0,
            "ordersId": self.saveToDraftOrder.paymentsDetail?.ordersId ?? 0,
            "paymentMode": self.saveToDraftOrder.paymentsDetail?.paymentMode ?? 0,
            "creditDay": self.saveToDraftOrder.paymentsDetail?.creditDay ?? 0,
            "paymentAmount": "\(self.saveToDraftOrder.paymentsDetail?.paymentAmount ?? "")",
            "paymentDate": self.saveToDraftOrder.paymentsDetail?.paymentDate ?? "",
            "paymentTransactionId": self.saveToDraftOrder.paymentsDetail?.paymentTransactionId ?? "",
            "paymentChequeNo": self.saveToDraftOrder.paymentsDetail?.paymentChequeNo ?? "",
            "hasApproval": self.saveToDraftOrder.paymentsDetail?.hasApproval ?? 0,
            "paymentStatus": self.saveToDraftOrder.paymentsDetail?.paymentStatus ?? 0,
            "createdAt": self.saveToDraftOrder.paymentsDetail?.createdAt ?? "",
            "updatedAt": self.saveToDraftOrder.paymentsDetail?.updatedAt ?? ""
        ] as [String : Any]
        
        let param = [ "user_id": APIManager.sharedManager.userId,
                      "billing_address_id": self.saveToDraftOrder.billingAddressID ?? 0,
                      "billing_address_name": self.saveToDraftOrder.billingAddressName ?? "",
                      "booking_point": self.saveToDraftOrder.bookingPoint ?? "",
                      "branch_id": self.saveToDraftOrder.branchID ?? 0,
                      "branchName": self.saveToDraftOrder.branchName ?? "",
                      "businessPartnerTransporter": businessPTransportNamelist,
                      "business_partners_id": self.saveToDraftOrder.businessPartnersID ?? 0,
                      "business_partner_name": self.saveToDraftOrder.businessPartnerName ?? "",
                      "businesscode": self.saveToDraftOrder.businesscode ?? "",
                      "cgstAmount": self.saveToDraftOrder.cgstAmount ?? 0,
                      "comment": self.saveToDraftOrder.comment ?? "",
                      "company_type": 1,
                      "credit_day": self.saveToDraftOrder.creditDay ?? "",
                      "deliveryTo": self.saveToDraftOrder.deliveryTo ?? "",
                      "delivery_address_id": self.saveToDraftOrder.deliveryAddressID ?? "",
                      "delivery_address_name": self.saveToDraftOrder.deliveryAddressName ?? "",
                      "draft_id": self.saveToDraftOrder.draftID ?? 0,
                      "follow_up_days": self.saveToDraftOrder.followUpDays ?? 0,
                      "freight": self.saveToDraftOrder.freight ?? 0,
                      "freight_charges": self.saveToDraftOrder.freightCharges ?? "",
                      "freight_gst": self.saveToDraftOrder.freightGst ?? 0,
                      "grand_total_amount": self.saveToDraftOrder.grandTotalAmount ?? "",
                      "gstTotal": self.saveToDraftOrder.gstTotal ?? 0,
                      "hand_delivery_text": self.saveToDraftOrder.handDeliveryText ?? "",
                      "igstAmount": self.saveToDraftOrder.igstAmount ?? 0,
                      "isEditableOrder": self.saveToDraftOrder.isEditableOrder ?? false,
                      "lastTransporterId": self.saveToDraftOrder.lastTransporterID ?? 0,
                      "order_delivery_type": self.saveToDraftOrder.orderDeliveryType ?? "",
                      "order_id": self.saveToDraftOrder.orderID ?? "",
                      "order_type": self.saveToDraftOrder.orderType ?? 0,
                      "otherTransporter": self.saveToDraftOrder.otherTransporter ?? "",
                      "payment_amount": self.saveToDraftOrder.paymentAmount ?? "",
                      "payment_cheque_no": self.saveToDraftOrder.paymentChequeNo ?? "",
                      "payment_date": self.saveToDraftOrder.paymentDate ?? "",
                      "payment_mode": self.saveToDraftOrder.paymentMode ?? "",
                      "payment_transaction_id": self.saveToDraftOrder.paymentTransactionID ?? "",
                      "payment_type": self.saveToDraftOrder.paymentType ?? "",
                      "paymentsDetail": tempPaymentDetail,   //self.saveToDraftOrder.paymentsDetail ?? "",
                      "poAttachment": [],
                      "preferredBranchId": self.saveToDraftOrder.preferredBranchID ?? 0,
                      "products": products,
                      "qiValidity": self.saveToDraftOrder.qiValidity ?? "",
                      "qi_pi_id": self.saveToDraftOrder.qiPiID ?? 0,
                      "referenceEmployeeName": self.saveToDraftOrder.referenceEmployeeName ?? "",
                      "remainder_id": self.saveToDraftOrder.remainderID ?? 0,
                      "required_date": self.saveToDraftOrder.requiredDate ?? "",
                      "sAPId": self.saveToDraftOrder.sAPID ?? "",
                      "sample__request_id": self.saveToDraftOrder.sampleRequestID ?? "",
                      "sgstAmount": self.saveToDraftOrder.sgstAmount ?? 0,
                      "transportNamelist": transportNamelist,
                      "transporterGSTNo": self.saveToDraftOrder.transporterGSTNo ?? "",
                      "transporter_id": self.saveToDraftOrder.transporterID ?? "",
                      "transporter_title": self.saveToDraftOrder.transporterTitle ?? ""
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_NEW_ORDER, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.draftSavedPopup(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    /// */
    
    func addNewOrder() {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addNewOrder()
                }
            }
            return
        }
        
        let tempDictQue: [String: String] = [:]
        
        var products: [Any] = []
        for i in 0..<(self.saveToDraftOrder.products?.count ?? 0) {
            
            var productWarehouse: [Any] = []
            for j in 0..<(self.saveToDraftOrder.products?[i].productWarehouse?.count ?? 0) {
                let tempProductWarehouse = [
                    "available": self.saveToDraftOrder.products?[i].productWarehouse?[j].available ?? 0,
                    "branchId": self.saveToDraftOrder.products?[i].productWarehouse?[j].branchId ?? 0,
                    "city": self.saveToDraftOrder.products?[i].productWarehouse?[j].city ?? "",
                    "inCommited": self.saveToDraftOrder.products?[i].productWarehouse?[j].inCommited ?? 0,
                    "inStock": self.saveToDraftOrder.products?[i].productWarehouse?[j].inStock ?? "",
                    "productId": self.saveToDraftOrder.products?[i].productWarehouse?[j].productId ?? 0
                  ] as [String : Any]
                productWarehouse.append(tempProductWarehouse)
            }
            
            let tempProduct = [
                "categoryId": self.saveToDraftOrder.products?[i].categoryId ?? 0,
                "categoryName": self.saveToDraftOrder.products?[i].categoryName ?? "",
                "commission": self.saveToDraftOrder.products?[i].commission ?? 0,
                "description": self.saveToDraftOrder.products?[i].description ?? "",
                "discount_amount": self.saveToDraftOrder.products?[i].discountAmount ?? 0,
                "discount_price": self.saveToDraftOrder.products?[i].discountPrice ?? 0,
                "hsnNumber": self.saveToDraftOrder.products?[i].hsnNumber ?? "",
                "lastPrice": self.saveToDraftOrder.products?[i].lastPrice ?? 0,
                "maxDiscount": self.saveToDraftOrder.products?[i].maxDiscount ?? 0,
                "pack_size": self.saveToDraftOrder.products?[i].packSize ?? 0,
                "productUnitMesurement": self.saveToDraftOrder.products?[i].productUnitMesurement ?? "",
                "productWarehouse": productWarehouse,
                "product_basic_price": self.saveToDraftOrder.products?[i].productBasicPrice ?? "",
                "product_code": self.saveToDraftOrder.products?[i].productCode ?? "",
                //"product_id": "\(self.saveToDraftOrder.products?[i].id ?? 0)",
                "product_id": self.saveToDraftOrder.products?[i].id ?? 0,
                "moq": self.saveToDraftOrder.products?[i].moq ?? 0,
                "product_name": self.saveToDraftOrder.products?[i].productName ?? "",
                "product_old_price": self.saveToDraftOrder.products?[i].productOldPrice ?? 0,
                "product_price": self.saveToDraftOrder.products?[i].productPrice ?? 0,
                "quantity": self.saveToDraftOrder.products?[i].quantity ?? 0,
                "product_total": self.saveToDraftOrder.products?[i].productTotal ?? 0,
                "product_unit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "productUnit": self.saveToDraftOrder.products?[i].productUnit ?? "",
                "moq_unit": self.saveToDraftOrder.products?[i].moqUnit ?? "",
                //"questions": self.saveToDraftOrder.products?[i].questions ?? "",
                "questions": tempDictQue,
                "remark": self.saveToDraftOrder.products?[i].remark ?? "",
                "showWarehouse": self.saveToDraftOrder.products?[i].showWarehouse ?? "",
                "status": self.saveToDraftOrder.products?[i].status ?? 0,
                "storeQty": self.saveToDraftOrder.products?[i].storeQty ?? 0,
                "tax": self.saveToDraftOrder.products?[i].tax ?? 0,
                "userCommission": self.saveToDraftOrder.products?[i].userCommission ?? 0,
                "userCommissionByCategory": [],
                "warehouseQty": self.saveToDraftOrder.products?[i].warehouseQty ?? ""
              ] as [String : Any]
            products.append(tempProduct)
        }
        
        var transportNamelist: [Any] = []
        for i in 0..<(self.saveToDraftOrder.transportNamelist?.count ?? 0) {
            let tempTransportNamelist = [
                "position": self.saveToDraftOrder.transportNamelist?[i].position ?? false,
                "transporterCode": self.saveToDraftOrder.transportNamelist?[i].transporterCode ?? "",
                "transporterGSTNo": self.saveToDraftOrder.transportNamelist?[i].transporterGSTNo ?? "",
                "transporterId": self.saveToDraftOrder.transportNamelist?[i].transporterId ?? 0,
                "transporterTitle": self.saveToDraftOrder.transportNamelist?[i].transporterTitle ?? ""
            ] as [String : Any]
            transportNamelist.append(tempTransportNamelist)
        }
        
        var businessPTransportNamelist: [Any] = []
        for i in 0..<(self.saveToDraftOrder.businessPartnerTransporter?.count ?? 0) {
            let tempTransport = [
                "transporterID": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterID ?? 0,
                "transporterCode": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterCode ?? "",
                "transporterTitle": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterTitle ?? "",
                "transporterGSTNo": self.saveToDraftOrder.businessPartnerTransporter?[i].transporterGSTNo ?? 0,
                "businessPartnersID": self.saveToDraftOrder.businessPartnerTransporter?[i].businessPartnersID ?? 0
            ] as [String : Any]
            businessPTransportNamelist.append(tempTransport)
        }
        
        let tempPaymentDetail = [
            "id": self.saveToDraftOrder.paymentsDetail?.id ?? 0,
            "paymentType": self.saveToDraftOrder.paymentsDetail?.paymentType ?? 0,
            "ordersId": self.saveToDraftOrder.paymentsDetail?.ordersId ?? 0,
            "paymentMode": self.saveToDraftOrder.paymentsDetail?.paymentMode ?? 0,
            "creditDay": self.saveToDraftOrder.paymentsDetail?.creditDay ?? 0,
            "paymentAmount": "\(self.saveToDraftOrder.paymentsDetail?.paymentAmount ?? 0)",
            "paymentDate": self.saveToDraftOrder.paymentsDetail?.paymentDate ?? "",
            "paymentTransactionId": self.saveToDraftOrder.paymentsDetail?.paymentTransactionId ?? "",
            "paymentChequeNo": self.saveToDraftOrder.paymentsDetail?.paymentChequeNo ?? "",
            "hasApproval": self.saveToDraftOrder.paymentsDetail?.hasApproval ?? 0,
            "paymentStatus": self.saveToDraftOrder.paymentsDetail?.paymentStatus ?? 0,
            "createdAt": self.saveToDraftOrder.paymentsDetail?.createdAt ?? "",
            "updatedAt": self.saveToDraftOrder.paymentsDetail?.updatedAt ?? ""
        ] as [String : Any]
        
        let param = [ "user_id": APIManager.sharedManager.userId,
                      "billing_address_id": self.saveToDraftOrder.billingAddressID ?? 0,
                      "billing_address_name": self.saveToDraftOrder.billingAddressName ?? "",
                      "booking_point": self.saveToDraftOrder.bookingPoint ?? "",
                      "branch_id": self.saveToDraftOrder.branchID ?? 0,
                      "branchName": self.saveToDraftOrder.branchName ?? "",
                      "businessPartnerTransporter": businessPTransportNamelist,
                      "business_partners_id": self.saveToDraftOrder.businessPartnersID ?? 0,
                      "business_partner_name": self.saveToDraftOrder.businessPartnerName ?? "",
                      "businesscode": self.saveToDraftOrder.businesscode ?? "",
                      "cgstAmount": self.saveToDraftOrder.cgstAmount ?? 0,
                      "comment": self.saveToDraftOrder.comment ?? "",
                      "company_type": 1,
                      "credit_day": self.saveToDraftOrder.creditDay ?? "",
                      "deliveryTo": self.saveToDraftOrder.deliveryTo ?? "",
                      "delivery_address_id": self.saveToDraftOrder.deliveryAddressID ?? "",
                      "delivery_address_name": self.saveToDraftOrder.deliveryAddressName ?? "",
                      "draft_id": self.saveToDraftOrder.draftID ?? 0,
                      "follow_up_days": self.saveToDraftOrder.followUpDays ?? 0,
                      "freight": self.saveToDraftOrder.freight ?? 0,
                      "freight_charges": self.saveToDraftOrder.freightCharges ?? "",
                      "freight_gst": self.saveToDraftOrder.freightGst ?? 0,
                      "grand_total_amount": self.saveToDraftOrder.grandTotalAmount ?? "",
                      "gstTotal": self.saveToDraftOrder.gstTotal ?? 0,
                      "hand_delivery_text": self.saveToDraftOrder.handDeliveryText ?? "",
                      "igstAmount": self.saveToDraftOrder.igstAmount ?? 0,
                      "isEditableOrder": self.saveToDraftOrder.isEditableOrder ?? false,
                      "lastTransporterId": self.saveToDraftOrder.lastTransporterID ?? 0,
                      "order_delivery_type": self.saveToDraftOrder.orderDeliveryType ?? "",
                      "order_id": self.saveToDraftOrder.orderID ?? "",
                      "order_type": self.saveToDraftOrder.orderType ?? 0,
                      "otherTransporter": self.saveToDraftOrder.otherTransporter ?? "",
                      "payment_amount": self.saveToDraftOrder.paymentAmount ?? "",
                      "payment_cheque_no": self.saveToDraftOrder.paymentChequeNo ?? "",
                      "payment_date": self.saveToDraftOrder.paymentDate ?? "",
                      "payment_mode": self.saveToDraftOrder.paymentMode ?? "",
                      "payment_transaction_id": self.saveToDraftOrder.paymentTransactionID ?? "",
                      "payment_type": self.saveToDraftOrder.paymentType ?? "",
                      "paymentsDetail": tempPaymentDetail,
                      "poAttachment": [],
                      "preferredBranchId": self.saveToDraftOrder.preferredBranchID ?? 0,
                      "products": products,
                      "qiValidity": self.saveToDraftOrder.qiValidity ?? "",
                      "qi_pi_id": self.saveToDraftOrder.qiPiID ?? 0,
                      "referenceEmployeeName": self.saveToDraftOrder.referenceEmployeeName ?? "",
                      "remainder_id": self.saveToDraftOrder.remainderID ?? 0,
                      "required_date": self.saveToDraftOrder.requiredDate ?? "",
                      "sAPId": self.saveToDraftOrder.sAPID ?? "",
                      "sample__request_id": self.saveToDraftOrder.sampleRequestID ?? "",
                      "sgstAmount": self.saveToDraftOrder.sgstAmount ?? 0,
                      "transportNamelist": transportNamelist,
                      "transporterGSTNo": self.saveToDraftOrder.transporterGSTNo ?? "",
                      "transporter_id": self.saveToDraftOrder.transporterID ?? "",
                      "transporter_title": self.saveToDraftOrder.transporterTitle ?? ""
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_NEW_ORDER, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.draftSavedPopup(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    /// */
    
    func draftSavedPopup(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.navigationController?.popViewController(animated: true)
            APIManager.sharedManager.isRefreshData = true
        }
        self.present(popupVC, animated: true)
    }
}
