//
//  AddBillingLocationVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/06/24.
//

import UIKit

class AddBillingLocationVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onAddTap != nil {
                self.onAddTap!(false)
            }
        }
    }
    
    
    @IBOutlet weak var viewScrollOutMain: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var viewScrollInMain: UIView!
    
    @IBOutlet weak var constraintBottomViewInMain: NSLayoutConstraint!
    
    @IBOutlet weak var viewBillingAddressType: UIView!
    @IBOutlet weak var btnWarehouse: UIButton!
    @IBAction func btnWarehouseTap(_ sender: UIButton) {
        self.btnWarehouse.isSelected = true
        self.btnWarehouse.tintColor = Colors.themeGreen.returnColor()
        self.isWareHouse = true
        self.isOffice = false
        self.btnOffice.isSelected = false
        self.btnOffice.tintColor = Colors.gray.returnColor()
    }
    @IBOutlet weak var btnOffice: UIButton!
    @IBAction func btnOfficeTap(_ sender: UIButton) {
        self.btnOffice.isSelected = true
        self.btnOffice.tintColor = Colors.themeGreen.returnColor()
        self.isOffice = true
        self.isWareHouse = false
        self.btnWarehouse.isSelected = false
        self.btnWarehouse.tintColor = Colors.gray.returnColor()
    }
    
    @IBOutlet weak var viewUseBillToAdd: UIView!
    @IBOutlet weak var btnUseBillToAdd: UIButton!
    @IBAction func btnUseBillToAddTap(_ sender: UIButton) {
        if self.btnUseBillToAdd.isSelected {
            self.btnUseBillToAdd.isSelected = false
            self.btnUseBillToAdd.tintColor = Colors.gray.returnColor()
            self.isUseBillToAdd = false
        }
        else {
            self.btnUseBillToAdd.isSelected = true
            self.btnUseBillToAdd.tintColor = Colors.themeGreen.returnColor()
            self.isUseBillToAdd = true
        }
    }
    
    @IBOutlet weak var viewAddressTitle: UIView!
    @IBOutlet weak var txtAddressTitle: TLTextField!
    @IBOutlet weak var lblErrorAddressTitle: UILabel!
    
    @IBOutlet weak var viewBlockNo: UIView!
    @IBOutlet weak var txtBlockNo: TLTextField!
    @IBOutlet weak var lblErrorBlockNo: UILabel!
    
    @IBOutlet weak var viewBuildingFloorRoom: UIView!
    @IBOutlet weak var txtBuildingFloorRoom: TLTextField!
    @IBOutlet weak var lblErrorBuildingFloorRoom: UILabel!
    
    @IBOutlet weak var viewStreetPOBox: UIView!
    @IBOutlet weak var txtStreetPOBox: TLTextField!
    @IBOutlet weak var lblErrorStreetPOBox: UILabel!
    
    @IBOutlet weak var viewStreetNo: UIView!
    @IBOutlet weak var txtStreetNo: TLTextField!
    @IBOutlet weak var lblErrorStreetNo: UILabel!
    
    @IBOutlet weak var viewZipCode: UIView!
    @IBOutlet weak var txtZipCode: TLTextField!
    @IBOutlet weak var lblErrorZipCode: UILabel!
    
    @IBOutlet weak var viewLandmark: UIView!
    @IBOutlet weak var txtLandmark: TLTextField!
    @IBOutlet weak var lblErrorLandmark: UILabel!
    
    @IBOutlet weak var viewCountry: UIView!
    @IBOutlet weak var txtCountry: TLTextField!
    @IBOutlet weak var lblErrorCountry: UILabel!
    
    @IBOutlet weak var viewMSelectState: UIView!
    @IBOutlet weak var viewSelectState: UIView!
    @IBOutlet weak var lblSelectState: UILabel!
    @IBOutlet weak var btnSelectState: UIButton!
    @IBAction func btnSelectStateTap(_ sender: UIButton) {
        let arrTempState: [String] = (self.arrState ?? []).map { $0.stateName! }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = Title.BPSelectStateTitle
        popupVC.value = arrTempState
        popupVC.selectedValue = self.lblSelectState.text ?? "Select State"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strValue in
            if strValue != self.lblSelectState.text! {
                self.lblSelectState.text = strValue
                self.lblErrorSelectState.text = ""
                
                let tempState = self.arrState?.filter{ ($0.stateName! == strValue) }
                let tempStateId = tempState?[0].id ?? 0
                self.intStateId = tempStateId
                
                self.lblSelectCity.text = "Select City"
                self.isStateSelect = true
                self.getCities(intStateId: tempStateId)
            }
        }
        popupVC.onClose = { strValue in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var lblErrorSelectState: UILabel!
    
    @IBOutlet weak var viewMSelectCity: UIView!
    @IBOutlet weak var viewSelectCity: UIView!
    @IBOutlet weak var lblSelectCity: UILabel!
    @IBOutlet weak var btnSelectCity: UIButton!
    @IBAction func btnSelectCityTap(_ sender: UIButton) {
        if self.isStateSelect && !((self.arrCity ?? []).isEmpty) {
            let arrTempCity: [String] = (self.self.arrCity ?? []).map { $0.cityName! }
            
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.BPSelectCityTitle
            popupVC.value = arrTempCity
            popupVC.selectedValue = self.lblSelectCity.text ?? "Select City"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.lblSelectCity.text = strValue
                
                let tempCity = self.arrCity?.filter{ ($0.cityName! == strValue) }
                let tempCityId = tempCity?[0].id ?? 0
                self.intCityId = tempCityId
                
                self.lblErrorSelectCity.text = ""
            }
            popupVC.onClose = { strValue in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
        else {
            Utilities.showPopup(title: "Select the state first.", type: .error)
        }
    }
    @IBOutlet weak var lblErrorSelectCity: UILabel!
    
    @IBOutlet weak var switchGSTRequired: UISwitch!
    @IBAction func switchGSTRequiredTap(_ sender: UISwitch) {
        if sender.isOn {
            self.constraintBottomGSTRequired.priority = .defaultLow
            self.isGSTRequired = true
            self.viewGSTNo.isHidden = false
        }
        else {
            self.constraintBottomGSTRequired.priority = .required
            self.isGSTRequired = false
            self.viewGSTNo.isHidden = true
        }
    }
    @IBOutlet weak var constraintBottomGSTRequired: NSLayoutConstraint!
    
    @IBOutlet weak var viewGSTNo: UIView!
    @IBOutlet weak var txtGSTNo: TLTextField!
    @IBOutlet weak var lblErrorGSTNo: UILabel!
    
    @IBOutlet weak var btnAdd: UIButton!
    @IBAction func btnAddTap(_ sender: UIButton) {
        if self.checkValidation(to: self.txtAddressTitle.tag, from: self.txtGSTNo.tag + 1) && (self.intCityId != 0 && self.intStateId != 0) {
            if  self.isGSTRequired {
                self.verifyGSTNumber(gstNo: self.txtGSTNo.text!, stateId: self.intStateId, cityId: self.intCityId, pincode: self.txtZipCode.text!, addressType: self.addressType)
            }
            else {
                self.addBPAddress()
            }
        }
        else {
            if self.intStateId == 0 {
                self.lblErrorSelectState.setLeftArrow(title: Valid_AddBPSelectState)
            }
            
            if self.intCityId == 0 {
                self.lblErrorSelectCity.setLeftArrow(title: Valid_AddBPSelectCity)
            }
        }
    }
    
    // MARK: - Variable
    
    var onAddTap: ((Bool)->Void)?
    var businessPartnerId: Int?
    var addressType: Int = 1
    var isFromAddSalesOrder: Bool = false
    
    
    var arrState: [State]?
    var arrCity: [City]?
    var isStateSelect: Bool = false
    var isWareHouse: Bool = false
    var isOffice: Bool = true
    var isUseBillToAdd: Bool = false
    var isGSTRequired: Bool = false
    
    var intStateId: Int = 0
    var intCityId: Int = 0
    var isBillingAddVerify: Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.constraintBottomGSTRequired.priority = .required
        self.isGSTRequired = false
        self.viewGSTNo.isHidden = true
        
        self.btnAdd.backgroundColor = Colors.theme.returnColor()
        self.btnAdd.corners(radius: 10)
        
        self.isWareHouse = true
        self.btnWarehouse.isSelected = true
        self.btnWarehouse.tintColor = Colors.themeGreen.returnColor()
        self.btnOffice.tintColor = Colors.gray.returnColor()
        
        self.btnUseBillToAdd.tintColor = Colors.gray.returnColor()
        
        self.txtCountry.isEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.getStates()
        self.checkKeyboard(kView: self.viewScrollInMain)
    }
    
    
}


// MARK: - UITextFieldDelegate

extension AddBillingLocationVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        if (textField == self.txtZipCode) {
            if (self.txtZipCode.text?.isNumber)! {
                return newString.length <= MAX_ZIP_LENGTH
            }
            else {
                return true
            }
        }
        else {
            return true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //self.txtCompanyName.resignFirstResponder()
        textField.resignFirstResponder()
        
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            if i == 0 {
                self.txtAddressTitle.text = self.txtAddressTitle.text?.trimmingCharacters(in: .whitespaces)
                if self.txtAddressTitle.text == "" {
                    self.lblErrorAddressTitle.getEmptyValidationString((txtAddressTitle.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorAddressTitle.text = ""
                }
            }
            else if i == 1 {
                self.txtBlockNo.text = self.txtBlockNo.text?.trimmingCharacters(in: .whitespaces)
                if self.txtBlockNo.text == "" {
                    self.lblErrorBlockNo.getEmptyValidationString((txtBlockNo.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorBlockNo.text = ""
                }
            }
            else if i == 2 {
                self.txtBuildingFloorRoom.text = self.txtBuildingFloorRoom.text?.trimmingCharacters(in: .whitespaces)
                if self.txtBuildingFloorRoom.text == "" {
                    self.lblErrorBuildingFloorRoom.getEmptyValidationString((txtBuildingFloorRoom.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorBuildingFloorRoom.text = ""
                }
            }
            else if i == 3 {
                self.txtStreetPOBox.text = self.txtStreetPOBox.text?.trimmingCharacters(in: .whitespaces)
                if self.txtStreetPOBox.text == "" {
                    self.lblErrorStreetPOBox.getEmptyValidationString((txtStreetPOBox.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorStreetPOBox.text = ""
                }
            }
            else if i == 4 {
                self.txtStreetNo.text = self.txtStreetNo.text?.trimmingCharacters(in: .whitespaces)
                if self.txtStreetNo.text == "" {
                    self.lblErrorStreetNo.getEmptyValidationString((txtStreetNo.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorStreetNo.text = ""
                }
            }
            else if i == 5 {
                self.txtZipCode.text = self.txtZipCode.text?.trimmingCharacters(in: .whitespaces)
                if self.txtZipCode.text == "" {
                    self.lblErrorZipCode.getEmptyValidationString((txtZipCode.placeholder ?? "").lowercased())
                    value = false
                }
                else if !Validations.isValidZip(self.txtZipCode.text!) {
                    self.lblErrorZipCode.setLeftArrow(title: Valid_Zip)
                    value = false
                }
                else {
                    self.lblErrorZipCode.text = ""
                }
            }
            else if i == 6 {
                self.txtLandmark.text = self.txtLandmark.text?.trimmingCharacters(in: .whitespaces)
                /*if self.txtLandmark.text == "" {
                    self.lblErrorLandmark.getEmptyValidationString((txtLandmark.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorLandmark.text = ""
                }   //  */
            }
            else if i == 7 {
                /*self.txtCountry.text = self.txtCountry.text?.trimmingCharacters(in: .whitespaces)
                if self.txtContactName.text == "" {
                    self.lblErrorCountry.getEmptyValidationString((txtCountry.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorCountry.text = ""
                }   //  */
            }
            else if i == 8 {
                if self.isGSTRequired {
                    self.txtGSTNo.text = self.txtGSTNo.text?.trimmingCharacters(in: .whitespaces)
                    if self.txtGSTNo.text == "" {
                        self.lblErrorGSTNo.getEmptyValidationString((txtGSTNo.placeholder ?? "").lowercased())
                        value = false
                    }
                    else if !Validations.isValidGSTNo(self.txtGSTNo.text!) {
                        self.lblErrorGSTNo.setLeftArrow(title: Valid_GSTNo)
                    }
                    else {
                        self.lblErrorGSTNo.text = ""
                    }
                }
            }
        }
        return value
    }
}


// MARK: - Keyboard

extension AddBillingLocationVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard(){
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomBSheet.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            
            self.constraintBottomViewInMain.constant = keyboardOverlap > 0 ? (keyboardOverlap - 70) : 10
            
            /*if self.intSelectedTab == 0 {
                self.constraintBottomViewTabCompany.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            else if self.intSelectedTab == 1 {
                self.constraintBottomViewTabContact.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            else if self.intSelectedTab == 2 {
                self.constraintBottomViewTabBilling.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            else if self.intSelectedTab == 3 {
                self.constraintBottomViewTabDelivery.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }
            else if self.intSelectedTab == 4 {
                self.constraintBottomViewTabTransport.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            }   //  */
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}


// MARK: - Webservices

extension AddBillingLocationVC {
    
    func getStates() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getStates()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_STATES, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrState = response?.result?.state ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getCities(intStateId: Int = 0, isDelivery: Bool = false) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getCities(intStateId: intStateId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "state_id": intStateId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_CITIES, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrCity = response?.result?.city ?? []
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func verifyGSTNumber(gstNo: String, stateId: Int, cityId: Int, pincode: String, addressType: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.verifyGSTNumber(gstNo: gstNo, stateId: stateId, cityId: cityId, pincode: pincode, addressType: addressType)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "gst_no": gstNo,
            "state_id": stateId,
            "city_id": cityId,
            "pin_code": pincode,
            "addressType": addressType
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GST_NUMBER_VERIFY, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.addBPAddress()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func addBPAddress() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addBPAddress()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partners_id": self.businessPartnerId ?? 0,
            "address_title": self.txtAddressTitle.text!,
            "block_no": self.txtBlockNo.text!,
            "building_floor_room": self.txtBuildingFloorRoom.text!,
            "street_po_box": self.txtStreetPOBox.text!,
            "street_no": self.txtStreetNo.text!,
            "pin_code": self.txtZipCode.text!,
            "landmark": self.txtLandmark.text!,
            "country_id": 1,
            "state_id": self.intStateId,
            "city_id": self.intCityId,
            "city_name": self.lblSelectCity.text!,
            "is_gst": self.isGSTRequired ? 1 : 0,
            "GstIn": self.txtGSTNo.text!,
            "address_type": self.addressType,
            "address_location_type": self.isWareHouse ? "Warehouse" : "Office",
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_BP_ADDRESS_DETAIL, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.dismiss(animated: true) {
                        if self.onAddTap != nil {
                            self.onAddTap!(true)
                        }
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func displayMessage(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.navigationController?.popViewController(animated: true)
        }
        self.present(popupVC, animated: true)
    }
}
