//
//  BillingLocationListVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 04/06/24.
//

import Foundation
import UIKit

// MARK: - UITableView Delegate, Datasourse

extension BillingLocationListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.businessPartnerAddress?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddOrderAddressTVCell", for: indexPath) as! AddOrderAddressTVCell
        
        cell.lblAddressTitle.text = self.businessPartnerAddress?[indexPath.row].addressTitle ?? ""
        
        let blockNo = (self.businessPartnerAddress?[indexPath.row].blockNo ?? "") != "" ? "\(self.businessPartnerAddress?[indexPath.row].blockNo ?? ""), " : ""
        let building = (self.businessPartnerAddress?[indexPath.row].buildingFloorRoom ?? "") != "" ? "\(self.businessPartnerAddress?[indexPath.row].buildingFloorRoom ?? ""), " : ""
        let street = (self.businessPartnerAddress?[indexPath.row].streetPoBox ?? "") != "" ? "\(self.businessPartnerAddress?[indexPath.row].streetPoBox ?? ""), " : ""
        let city = (self.businessPartnerAddress?[indexPath.row].city ?? "") != "" ? "\(self.businessPartnerAddress?[indexPath.row].city ?? ""), " : ""
        let state = (self.businessPartnerAddress?[indexPath.row].state ?? "") != "" ? "\(self.businessPartnerAddress?[indexPath.row].state ?? "") - " : ""
        let zip = (self.businessPartnerAddress?[indexPath.row].pinCode ?? "") != "" ? "\(self.businessPartnerAddress?[indexPath.row].pinCode ?? "")" : ""
        
        cell.lblAddress.text = blockNo + building + street + city + state + zip
        cell.lblAddressType.text = self.businessPartnerAddress?[indexPath.row].addressLocationType ?? ""
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.dismiss(animated: true) {
            if self.onCellTap != nil {
                self.onCellTap!(true, self.businessPartnerAddress?[indexPath.row])
            }
        }
    }
}

// MARK: - Webservices

extension BillingLocationListVC {
    func getBusinessPAddressDetail(businessPartnersId: Int, search: String = "", addressType: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBusinessPAddressDetail(businessPartnersId: businessPartnersId, search: search, addressType: addressType)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "business_partners_id": businessPartnersId,
            "search": search,
            "address_type": addressType
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_BUSINESS_PARTNER_ADDRESS_DETAIL, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.businessPartnerAddress = response?.result?.businessPartnerAddress ?? []
                    self.tvAddressList.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
