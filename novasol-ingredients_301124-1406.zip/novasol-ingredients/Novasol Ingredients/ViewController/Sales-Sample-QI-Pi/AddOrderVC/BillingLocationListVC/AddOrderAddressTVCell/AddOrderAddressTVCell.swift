//
//  AddOrderAddressTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 04/06/24.
//

import UIKit

class AddOrderAddressTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblAddressTitle: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblAddressType: UILabel!
    @IBOutlet weak var btnSelectAddress: UIButton!
    @IBAction func btnSelectAddressTap(_ sender: UIButton) {
        if self.onSelect != nil {
            self.onSelect!(index)
        }
    }
    
    @IBOutlet weak var lblSeparator: UILabel!
    
    // MARK: - Variable
    
    var index: Int = 0
    var onSelect:((Int)->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
