//
//  BillingLocationListVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 04/06/24.
//

import UIKit

class BillingLocationListVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onCellTap != nil {
                self.onCellTap!(false, nil)
            }
        }
    }
    
    @IBOutlet weak var viewAddBillingAddress: UIView!
    @IBOutlet weak var btnAddBBillingAddress: UIButton!
    @IBAction func btnAddBBillingAddressTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "AddBillingLocationVC") as! AddBillingLocationVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.isFromAddSalesOrder = true
        popupVC.businessPartnerId = self.intBusinessPartnerId ?? 0
        popupVC.addressType = self.addressType
        popupVC.onAddTap = { isAddressAdded in
            if isAddressAdded {
                self.getBusinessPAddressDetail(businessPartnersId: self.intBusinessPartnerId ?? 0, addressType: self.addressType)
            }
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var tvAddressList: UITableView! {
        didSet {
            self.tvAddressList.delegate = self
            self.tvAddressList.dataSource = self
            self.tvAddressList.register(UINib(nibName: "AddOrderAddressTVCell", bundle: nil), forCellReuseIdentifier: "AddOrderAddressTVCell")
        }
    }
    
    // MARK: - Variable
    
    var onCellTap: ((Bool, BusinessPartnerAddress?)->Void)?
    //var businessPartner: BusinessPartner?
    var intBusinessPartnerId: Int?
    var businessPartnerAddress: [BusinessPartnerAddress]?
    var addressType: Int = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.btnAddBBillingAddress.cornersWFullBorder(radius: 15, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.getBusinessPAddressDetail(businessPartnersId: self.intBusinessPartnerId ?? 0, addressType: self.addressType)
    }
}
