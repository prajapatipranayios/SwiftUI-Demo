//
//  OrderDetailsTVCell.swift
//  GE Sales
//
//  Created by Auxano on 06/05/24.
//

import UIKit

class OrderDetailsTVCell: UITableViewCell {

    // MARK: - Outtlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewProduct: UIView!
    @IBOutlet weak var lblProductName: UILabel!
    
    @IBOutlet weak var lblSeparator1: UILabel!
    @IBOutlet weak var lblSeparator2: UILabel!
    
    @IBOutlet weak var lblUnitPriceTitle: UILabel!
    @IBOutlet weak var lblUnitPrice: UILabel!
    @IBOutlet weak var lblOriginalQtyTitle: UILabel!
    @IBOutlet weak var lblOriginalQty: UILabel!
    @IBOutlet weak var lblRemainQtyTitle: UILabel!
    @IBOutlet weak var lblRemainQty: UILabel!
    @IBOutlet weak var lblDiscountTitle: UILabel!
    @IBOutlet weak var lblDiscount: UILabel!
    @IBOutlet weak var lblApprovedQtyTitle: UILabel!
    @IBOutlet weak var lblApprovedQty: UILabel!
    @IBOutlet weak var lblMOQTitle: UILabel!
    @IBOutlet weak var lblMOQ: UILabel!
    @IBOutlet weak var lblCommissionTitle: UILabel!
    @IBOutlet weak var lblCommission: UILabel!
    @IBOutlet weak var lblGSTTitle: UILabel!
    @IBOutlet weak var lblGST: UILabel!
    
    @IBOutlet weak var lblSeparator3: UILabel!
    
    @IBOutlet weak var lblBasicTitle: UILabel!
    @IBOutlet weak var lblBasic: UILabel!
    @IBOutlet weak var lblDiscountAmtTitle: UILabel!
    @IBOutlet weak var lblDiscountAmt: UILabel!
    @IBOutlet weak var lblGSTAmountTitle: UILabel!
    @IBOutlet weak var lblGSTAmount: UILabel!
    @IBOutlet weak var lblNetTitle: UILabel!
    @IBOutlet weak var lblNet: UILabel!
    
    @IBOutlet weak var lblSeparator4: UILabel!
    
    @IBOutlet weak var lblReason: UILabel!
    
    @IBOutlet weak var constraintBottomRemainQtyToSeparator: NSLayoutConstraint!
    
    @IBOutlet weak var viewQuestion: UIView!
    
    @IBOutlet weak var viewQue1: UIView!
    @IBOutlet weak var lblQue1: UILabel!
    @IBOutlet weak var lblAns1: UILabel!
    @IBOutlet weak var lblSeparatorQue1: UILabel!
    
    @IBOutlet weak var viewQue2: UIView!
    @IBOutlet weak var lblQue2: UILabel!
    @IBOutlet weak var lblAns2: UILabel!
    @IBOutlet weak var lblSeparatorQue2: UILabel!
    
    @IBOutlet weak var viewQue3: UIView!
    @IBOutlet weak var lblQue3: UILabel!
    @IBOutlet weak var lblAns3: UILabel!
    @IBOutlet weak var lblSeparatorQue3: UILabel!
    
    @IBOutlet weak var viewQue4: UIView!
    @IBOutlet weak var lblQue4: UILabel!
    @IBOutlet weak var lblAns4: UILabel!
    @IBOutlet weak var lblSeparatorQue4: UILabel!
    
    @IBOutlet weak var constraintHeightQuestionView: NSLayoutConstraint!
    @IBOutlet weak var constraintBottomSuper: NSLayoutConstraint!
    
    @IBOutlet weak var btnViewOrders: UIButton!
    @IBOutlet weak var lblBtnViewOrderSeparator: UILabel!
    @IBOutlet weak var btnViewHistory: UIButton!
    @IBOutlet weak var lblBtnViewHistorySeparator: UILabel!
    
    // MARK: - Variable
    
    var onTapViewOrders: ((Int)->Void)?
    var onTapViewHistory: ((Int)->Void)?
    var index = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        //constraintBottomNet.priority = .required
        
        self.btnViewOrders.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.lblBtnViewOrderSeparator.backgroundColor = Colors.theme.returnColor()
        
        self.lblNet.textColor = Colors.theme.returnColor()
        
        self.viewProduct.backgroundColor = .white
        self.viewProduct.cornersWFullBorder(radius: 25, borderColor: UIColor(hexString: "#CFCFCF"), colorOpacity: 0.4)
        
        self.constraintBottomRemainQtyToSeparator.priority = .required
        
        DispatchQueue.main.async {
            self.lblQue1.text = SampleOrderQuestions.questions(no: 1)
            self.lblQue2.text = SampleOrderQuestions.questions(no: 2)
            self.lblQue3.text = SampleOrderQuestions.questions(no: 3)
            self.lblQue4.text = SampleOrderQuestions.questions(no: 4)
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnViewOrdersTap(_ sender: UIButton) {
        if onTapViewOrders != nil {
            onTapViewOrders!(index)
        }
    }
    
    @IBAction func btnViewHistoryTap(_ sender: UIButton) {
        if onTapViewHistory != nil {
            onTapViewHistory!(index)
        }
    }
}
