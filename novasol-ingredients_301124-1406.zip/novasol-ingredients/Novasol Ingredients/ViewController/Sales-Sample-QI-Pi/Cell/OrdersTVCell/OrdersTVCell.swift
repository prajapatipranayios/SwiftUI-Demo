//
//  OrdersTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 25/05/24.
//

import UIKit

class OrdersTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewSideColorBar: UIView!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    @IBOutlet weak var lblProductCount: UILabel!
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    @IBOutlet weak var constraintBottomCode: NSLayoutConstraint!
    
    // MARK: - Variable
    
    var index: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
