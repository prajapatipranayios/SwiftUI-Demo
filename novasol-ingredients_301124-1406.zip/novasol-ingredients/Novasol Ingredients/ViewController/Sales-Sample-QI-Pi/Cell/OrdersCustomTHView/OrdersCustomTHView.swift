//
//  OrdersTHView.swift
//  Novasol Ingredients
//
//  Created by Auxano on 28/05/24.
//

import UIKit

class OrdersCustomTHView: UITableViewHeaderFooterView {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblCommission: UILabel!
    @IBOutlet weak var lblOrderCount: UILabel!
    
    @IBOutlet weak var constraintHeightLblAmount: NSLayoutConstraint!
    @IBOutlet weak var constraintHeightLblCommission: NSLayoutConstraint!
}
    
