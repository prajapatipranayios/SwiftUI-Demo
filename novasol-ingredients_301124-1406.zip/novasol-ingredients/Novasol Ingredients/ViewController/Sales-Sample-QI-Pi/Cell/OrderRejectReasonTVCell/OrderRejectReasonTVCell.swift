//
//  OrderRejectReasonTVCell.swift
//  Novasol Ingredients
//
//  Created by Cpt n3m0 on 30/05/24.
//

import UIKit

class OrderRejectReasonTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblReason: UILabel!
    @IBOutlet weak var btnReason: UIButton!
    @IBAction func btnReasonTap(_ sender: UIButton) {
        if self.selectReason != nil {
            self.selectReason!(self.index)
        }
    }
    
    // MARK: - Variable
    
    var selectReason: ((Int)->Void)?
    var index: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
