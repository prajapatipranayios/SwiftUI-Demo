//
//  OrderRejectPopupVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 30/05/24.
//

import UIKit

class OrderRejectPopupVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain : UIView!
    @IBOutlet weak var btnClose: UIButton!
    @IBAction func btnCloseTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onClose != nil {
                self.onClose!("")
            }
        }
    }
    
    @IBOutlet weak var viewBottomSheet : UIView!
    @IBOutlet weak var lblTitle : UILabel!
    
    @IBOutlet weak var tvRejectReason : UITableView! {
        didSet {
            self.tvRejectReason.delegate = self
            self.tvRejectReason.dataSource = self
            
            self.tvRejectReason.register(UINib(nibName: "OrderRejectReasonTVCell", bundle: nil), forCellReuseIdentifier: "OrderRejectReasonTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVRejectReason: NSLayoutConstraint!
    
    @IBOutlet weak var viewBranchNReason: UIView!
    @IBOutlet weak var lblWarehouseTitle: UILabel!
    @IBOutlet weak var btnWarehouse: UIButton!
    @IBAction func btnWarehouseTap(_ sender: UIButton) {
        let arrBranch: [String] = (APIManager.sharedManager.arrBranches ?? []).map { $0.branchName! }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithColleVC") as! PopupWithColleVC
        popupVC.titleTxt = Title.BPBrachTitle
        popupVC.value = arrBranch
        popupVC.selectedValue = self.btnWarehouse.titleLabel?.text ?? "Select Branch"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelect = { strValue in
            self.btnWarehouse.setTitle(strValue, for: .normal)
            
            let tempBranch = APIManager.sharedManager.arrBranches?.filter{ ($0.branchName! == strValue) }
            self.intWarehouseId = tempBranch?[0].id ?? 0
        }
        popupVC.onClose = { strValue in
        }
        self.present(popupVC, animated: true)
        
    }
    @IBOutlet weak var txtReason: UITextField!
    @IBOutlet weak var lblErrorRejectReason: UILabel!
    @IBOutlet weak var constraintTopTxtReason: NSLayoutConstraint!
    @IBOutlet weak var constraintBottomTvToSubmit: NSLayoutConstraint!
    
    @IBOutlet weak var viewSubmit: UIView!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBAction func btnSubmitTap(_ sender: UIButton) {
        var isValid: Bool = true
        
        if (self.strSelectedReason == "Insufficient Stock") || (self.strSelectedReason == "Other") {
            self.strSelectedReason = self.txtReason.text ?? ""
            self.lblErrorRejectReason.text = ""
            if (self.txtReason.text ?? "").isEmpty {
                self.lblErrorRejectReason.getEmptyValidationString(("Reject Reason").lowercased())
                isValid = false
            }
        }
        
        if isValid {
            self.dismiss(animated: true) {
                if self.didSelect != nil {
                    self.didSelect!(self.strSelectedReason, self.intWarehouseId)
                }
            }
        }
    }
    
    @IBOutlet weak var bottomSheetbottomConstraint : NSLayoutConstraint!
    
   
    
    // MARK: - Variable
    
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    var didSelect: ((String, Int)->Void)?
    var onClose: ((String)->Void)?
    var titleTxt: String = ""
    var intSelectedReason: Int = 0
    var strSelectedReason: String = ""
    var intWarehouseId: Int = 0
    
    private var arrRejectReason: [String]?
    var intReasonType: Int = 1
    var isFromSalesOrder: Bool = false
    var isFromQiOrder: Bool = false
    var isFromPiOrder: Bool = false
    var isFromSampleOrder: Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
        self.viewMain.backgroundColor = .clear
        self.viewBottomSheet.corners([.topLeft, .topRight], radius: 25)
        self.btnSubmit.corners(radius: 15.0)
        
        self.constraintBottomTvToSubmit.priority = .required
        
        if APIManager.sharedManager.arrBranches?.count ?? 0 > 0 {
            
            self.btnWarehouse.setTitle(APIManager.sharedManager.arrBranches?[0].branchName ?? "", for: .normal)
        }
        
        self.lblWarehouseTitle.textColor = Colors.gray.returnColor()
        self.btnWarehouse.backgroundColor = Colors.gray.returnColor()
        self.btnWarehouse.setTitleColor(.black, for: .normal)
        self.lblErrorRejectReason.textColor = Colors.validationMsg.returnColor()
        
        
        
        self.getRejectReason(type: self.intReasonType)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tvRejectReason.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tvRejectReason.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize") {
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                self.constraintHeightTVRejectReason.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                self.updateViewConstraints()
            }
        }
    }
}

// MARK: - UITableView Delegate, DataSource

extension OrderRejectPopupVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrRejectReason?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderRejectReasonTVCell", for: indexPath) as! OrderRejectReasonTVCell
        
        cell.index = indexPath.row
        cell.lblReason.text = self.arrRejectReason?[indexPath.row] ?? ""
        cell.btnReason.isSelected = false
        cell.btnReason.tintColor = Colors.gray.returnColor()
        if self.intSelectedReason == indexPath.row {
            cell.btnReason.isSelected = true
            cell.btnReason.tintColor = Colors.themeGreen.returnColor()
        }
        
        cell.selectReason = { index in
            self.intSelectedReason = index
            
            self.tvRejectReason.reloadData()
            self.setupView(reason: self.arrRejectReason?[indexPath.row] ?? "")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func setupView(reason: String) {
        self.strSelectedReason = reason
        
        if (reason == "Insufficient Stock") {
            self.constraintBottomTvToSubmit.priority = .defaultLow
            self.constraintTopTxtReason.priority = .defaultLow
            
            let tempBranch = APIManager.sharedManager.arrBranches?.filter{ ($0.branchName! == self.btnWarehouse.titleLabel?.text ?? "") }
            if tempBranch?.count ?? 0 > 0 {
                self.intWarehouseId = tempBranch?[0].id ?? 0
            }
        }
        else if (reason == "Other") {
            self.constraintBottomTvToSubmit.priority = .defaultLow
            self.constraintTopTxtReason.priority = .required
            
            self.intWarehouseId = 0
        }
        else {
            self.lblErrorRejectReason.text = ""
            self.constraintBottomTvToSubmit.priority = .required
            self.intWarehouseId = 0
        }
    }
}

// MARK: - Webservices

extension OrderRejectPopupVC {
    func getRejectReason(type: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getRejectReason(type: type)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "type": type
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_REJECT_REASON, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrRejectReason = response?.result?.rejectReason ?? []
                    self.arrRejectReason?.append("Other")
                    self.tvRejectReason.reloadData()
                    self.strSelectedReason = self.arrRejectReason?[0] ?? ""
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
