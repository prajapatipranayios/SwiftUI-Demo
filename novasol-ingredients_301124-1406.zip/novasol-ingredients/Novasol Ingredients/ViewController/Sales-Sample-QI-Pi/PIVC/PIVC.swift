//
//  PIVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 25/05/24.
//

import UIKit

class PIVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        APIManager.sharedManager.isRefreshData = false
        revealViewController()?.revealSideMenu()
    }
    
    @IBOutlet weak var viewTab: UIView!
    @IBOutlet weak var lblSeparator1: UILabel!
    @IBOutlet weak var colleTab: UICollectionView! {
        didSet {
            self.colleTab.delegate = self
            self.colleTab.dataSource = self
        }
    }
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var viewDateNBP: UIView!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var imgStartD: UIImageView!
    @IBOutlet weak var btnStartDate: UIButton!
    @IBAction func btnStartDateTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.dateFormat = "dd-MMM-yyyy"
        popupVC.didSelectDate = { date in
            self.imgStartD.isHidden = true
            
            self.lblStartDate.text = date
            self.strStartDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy/MM/dd")
        }
        popupVC.onClose = {
            self.lblStartDate.text = "Start Date"
            self.lblEndDate.text = "End Date"
            self.strStartDate = ""
            self.strEndDate = ""
            self.imgStartD.isHidden = false
            self.imgEndD.isHidden = false
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var imgEndD: UIImageView!
    @IBOutlet weak var btnEndDate: UIButton!
    @IBAction func btnEndDateTap(_ sender: UIButton) {
        if self.lblStartDate.text == "Start Date" {
            Utilities.showPopup(title: Messages.SelectStartDate, type: .error)
        }
        else {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.minStartDate = lblStartDate.text!
            popupVC.dateFormat = "dd-MMM-yyyy"
            popupVC.didSelectDate = { date in
                self.imgEndD.isHidden = true
                
                self.lblEndDate.text = date
                self.strEndDate = Utilities.convertStrDateToString(date: date, CurrentDateFormate: "dd-MMM-yyyy", NewDateFormate: "yyyy/MM/dd")
                
                if (self.lblStartDate.text != "Start Date" && self.lblEndDate.text != "End Date") && (self.strStartDate != "" && self.strEndDate != "") {
                    self.page = 1
                    
                    self.arrTempDate.removeAll()
                    self.arrDateNOrderList?.removeAll()
                    self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: self.searchText, page: self.page, startDate: self.strStartDate, endDate: self.strEndDate, businessPartnerId: self.intSelectedBusinessPId, employeeId: self.intSelectedEmployeeId, orderType: self.intOrderType)
                }
            }
            popupVC.onClose = {
                self.lblEndDate.text = "End Date"
                self.strEndDate = ""
                self.imgEndD.isHidden = false
            }
            self.present(popupVC, animated: true, completion: nil)
        }
    }
    
    @IBOutlet weak var viewBusinessP: UIView!
    @IBOutlet weak var lblBusinessP: UILabel!
    @IBOutlet weak var btnBusinessP: UIButton!
    @IBAction func btnBusinessPTap(_ sender: UIButton) {
        var arrTempBPName: [String] = (self.arrOrderedBusinessPartner ?? []).map { $0.name ?? "" }
        arrTempBPName.insert("Select BP", at: 0)
        
        if arrTempBPName.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.SelectBP
            popupVC.value = arrTempBPName
            popupVC.selectedValue = self.lblBusinessP.text ?? "Select BP"
            popupVC.isSearchActive = true
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                let tempList = self.arrOrderedBusinessPartner?.filter{ (($0.name ?? "") == strValue) }
                self.intSelectedBusinessPId = 0
                if tempList?.count ?? 0 > 0 {
                    self.intSelectedBusinessPId = tempList?[0].id ?? 0
                }
                self.lblBusinessP.text = strValue
                self.page = 1
                
                self.arrTempDate.removeAll()
                self.arrDateNOrderList?.removeAll()
                self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: self.searchText, page: self.page, startDate: self.strStartDate, endDate: self.strEndDate, businessPartnerId: self.intSelectedBusinessPId, employeeId: self.intSelectedEmployeeId, orderType: self.intOrderType)
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    @IBOutlet weak var constraintBottomDateToTVOrdes: NSLayoutConstraint!
    
    @IBOutlet weak var viewEmpFilter: UIView!
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var btnSelectEmp: UIButton!
    @IBAction func btnSelectEmpTap(_ sender: UIButton) {
        
        var arrTempEmpName: [String] = (self.arrOrderedEmployees ?? []).map { $0.employeeName ?? "" }
        arrTempEmpName.insert("Select Employee Name", at: 0)
        
        if arrTempEmpName.count > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.SelectEmployee
            popupVC.value = arrTempEmpName
            popupVC.selectedValue = self.lblEmpName.text ?? "Select Employee Name"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { name in
                let tempList = self.arrOrderedEmployees?.filter{ (($0.employeeName ?? "") == name) }
                self.intSelectedEmployeeId = 0
                if tempList?.count ?? 0 > 0 {
                    self.intSelectedEmployeeId = tempList?[0].employeeId ?? 0
                }
                self.lblEmpName.text = name
                self.page = 1
                
                self.arrTempDate.removeAll()
                self.arrDateNOrderList?.removeAll()
                self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: self.searchText, page: self.page, startDate: self.strStartDate, endDate: self.strEndDate, businessPartnerId: self.intSelectedBusinessPId, employeeId: self.intSelectedEmployeeId, orderType: self.intOrderType)
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    
    @IBOutlet weak var tvOrders: UITableView! {
        didSet {
            self.tvOrders.delegate = self
            self.tvOrders.dataSource = self
            self.tvOrders.register(UINib(nibName: "OrdersTVCell", bundle: nil), forCellReuseIdentifier: "OrdersTVCell")
            self.tvOrders.register(UINib(nibName: "OrdersCustomTHView", bundle: nil), forHeaderFooterViewReuseIdentifier: "OrdersCustomTHView")
            if #available(iOS 15.0, *) {
                self.tvOrders.sectionHeaderTopPadding = 0
            } else { }
        }
    }
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    @IBOutlet weak var btnAddPI: UIButton!
    @IBAction func btnAddPIsTap(_ sender: UIButton) {
        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "AddOrderVC") as! AddOrderVC
        viewController.strScreenTitle = "PI (Proforma Invoice)"
        viewController.isFromPI = true
        viewController.isAddOtherProduct = self.isAddOtherProduct
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    // MARK: - Variable
    
    var strScreenTitle: String = "PI"
    var strStartDate: String = ""
    /// 0 -> Sales,     1 -> QI,    2 -> PI,    3 -> Sample
    var arrTab: [String] = OrdersMScreen.getTab(intScreen: 1)
    var strEndDate: String = ""
    var intSelectedEmployeeId: Int = 0
    var intSelectedBusinessPId: Int = 0
    var page: Int = 1
    var searchText: String = ""
    var businessPartners: [BusinessPartner]?
    var hasMore: Bool = false
    var isLoadMore: Bool = false
    var intSelectedTab: Int = 0
    var arrOrderedBusinessPartner: [OrderedBusinessPartner]?
    var arrOrderedEmployees: [OrderedEmployee]?
    var arrOrderCounts: [SalesOrderCount]?
    var arrOrdersList: [SalesOrdersList]?
    var arrDateNOrderList: [SalesOrderCount]? = []
    var arrTempDate: [String] = []
    /// 0 -> Sales,     1 -> QI,    2 -> PI/Sample
    var intOrderType: Int = 2
    var intOrderStatus: Int = 0
    var dictCounts: OrderCount?
    var isOrderCountAvailable: Bool = false
    
    var isSampleOrder: Bool = false
    var isFollowUp: Bool = false
    
    // Add Order
    var isAddOtherProduct: Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblScreenTitle.text = self.strScreenTitle//.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        if APIManager.sharedManager.userDetail?.roleId ?? 0 == 2 {
            self.constraintBottomDateToTVOrdes.priority = .required
            self.viewEmpFilter.isHidden = true
        }
        
        self.page = 1
        self.arrTempDate.removeAll()
        self.arrDateNOrderList?.removeAll()
        
        self.getBusinessPNEmployeeList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: 0, type: 1, orderType: self.intOrderType)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if APIManager.sharedManager.isRefreshData {
            self.page = 1
            self.arrTempDate.removeAll()
            self.arrDateNOrderList?.removeAll()
            self.getBusinessPNEmployeeList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: 0, type: 1, orderType: self.intOrderType)
        }
    }
    
    func setDetail(ordersList: [SalesOrdersList]?) {
        
        if self.page == 1 {
            self.arrTempDate.removeAll()
            self.arrDateNOrderList?.removeAll()
        }
        
        for i in 0 ..< (ordersList?.count ?? 0)
        {
            let strDate: String = ordersList?[i].requestDate ?? ""
            if self.arrTempDate.contains(strDate) {
                for j in 0 ..< (self.arrDateNOrderList?.count ?? 0) {
                    if strDate == (self.arrDateNOrderList?[j].requestDate ?? "") {
                        self.arrDateNOrderList?[j].ordersList?.append((ordersList?[i])!)
                    }
                }
            }
            else {
                self.arrTempDate.append(strDate)
                let tempLObj = ordersList?[i]
                var tempCObj = (self.arrOrderCounts ?? []).filter { $0.requestDate == strDate }
                tempCObj[0].ordersList = []
                tempCObj[0].ordersList?.append(tempLObj!)
                
                self.arrDateNOrderList?.append(tempCObj[0])
            }
        }
        DispatchQueue.main.async {
            //if (self.arrDateNOrderList?.count ?? 0) > 0 {
            self.isOrderCountAvailable = true
            self.isLoadMore = self.hasMore
            self.viewNoData.isHidden = true
            
            self.colleTab.reloadData()
            self.tvOrders.reloadData()
            //}
        }
    }
    
    func setCountToCollection(name: String) -> String {
        var strName: String = ""
        switch name {
        case OrdersMScreen.all.rawValue:
            strName = name + " (\(self.dictCounts?.all ?? 0))"
        case OrdersMScreen.pending.rawValue:
            strName = name + " (\(self.dictCounts?.pending ?? 0))"
        case OrdersMScreen.approved.rawValue:
            strName = name + " (\(self.dictCounts?.approved ?? 0))"
        case OrdersMScreen.sOBookedInSAP.rawValue:
            strName = name + " (\(self.dictCounts?.sOBookedInSAP ?? 0))"
        case OrdersMScreen.qIBookedInSAP.rawValue:
            strName = name + " (\(self.dictCounts?.qIBookedInSAP ?? 0))"
        case OrdersMScreen.pIBookedInSAP.rawValue:
            strName = name + " (\(self.dictCounts?.pIBookedInSAP ?? 0))"
        case OrdersMScreen.sOApprovalInSAP.rawValue:
            strName = name + " (\(self.dictCounts?.sOApprovalInSAP ?? 0))"
        case OrdersMScreen.deliveryGenerated.rawValue:
            strName = name + " (\(self.dictCounts?.deliveryGenerated ?? 0))"
        case OrdersMScreen.partiallyDeliveryGenerated.rawValue:
            strName = name + " (\(self.dictCounts?.partiallyDeliveryGenerated ?? 0))"
        case OrdersMScreen.invoiceGenerated.rawValue:
            strName = name + " (\(self.dictCounts?.invoiceGenerated ?? 0))"
        case OrdersMScreen.partiallyInvoiceGenerated.rawValue:
            strName = name + " (\(self.dictCounts?.partiallyInvoiceGenerated ?? 0))"
        case OrdersMScreen.materialDispatched.rawValue:
            strName = name + " (\(self.dictCounts?.materialDispatched ?? 0))"
        case OrdersMScreen.partiallyMaterialDispatched.rawValue:
            strName = name + " (\(self.dictCounts?.partiallyMaterialDispatched ?? 0))"
        case OrdersMScreen.sOCancelledInSAP.rawValue:
            strName = name + " (\(self.dictCounts?.sOCancelledInSAP ?? 0))"
        case OrdersMScreen.rejected.rawValue:
            strName = name + " (\(self.dictCounts?.rejected ?? 0))"
        case OrdersMScreen.sORejectedInSAP.rawValue:
            strName = name + " (\(self.dictCounts?.sORejectedInSAP ?? 0))"
        case OrdersMScreen.open.rawValue:
            strName = name + " (\(self.dictCounts?.open ?? 0))"
        case OrdersMScreen.inProcess.rawValue:
            strName = name + " (\(self.dictCounts?.inProcess ?? 0))"
        case OrdersMScreen.hold.rawValue:
            strName = name + " (\(self.dictCounts?.hold ?? 0))"
        case OrdersMScreen.cancelled.rawValue:
            strName = name + " (\(self.dictCounts?.cancelled ?? 0))"
        case OrdersMScreen.dispatched.rawValue:
            strName = name + " (\(self.dictCounts?.dispatched ?? 0))"
        case OrdersMScreen.completed.rawValue:
            strName = name + " (\(self.dictCounts?.completed ?? 0))"
        default:
            strName = name
        }
        return strName
    }
}
