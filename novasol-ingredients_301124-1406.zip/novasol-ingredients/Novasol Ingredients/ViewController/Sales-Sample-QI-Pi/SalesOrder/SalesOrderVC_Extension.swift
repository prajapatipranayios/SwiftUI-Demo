//
//  SalesOrderVC_Ex.swift
//  GE Sales
//
//  Created by Auxano on 30/04/24.
//

import Foundation
import UIKit


// MARK: - UICollectionView DataSource, Delegate

extension SalesOrderVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrTab.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TabCellCV", for: indexPath) as! TabCVCell
        
        var name: String = self.arrTab[indexPath.item]
        
        if self.isOrderCountAvailable {
            name = self.setCountToCollection(name: name)
        }
        
        cell.lblName.text = name
        cell.lblName.textColor = (Colors.gray.returnColor()).withAlphaComponent(0.7)
        cell.lblName.backgroundColor = .white
        cell.lblUnderline.backgroundColor = (Colors.gray.returnColor()).withAlphaComponent(0.5)
        cell.constraintHeightUnderLine.constant = 3
        
        if self.intSelectedTab == indexPath.item {
            cell.lblName.textColor = Colors.theme.returnColor()
            cell.lblUnderline.backgroundColor = Colors.theme.returnColor()
            cell.constraintHeightUnderLine.constant = 4
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = ("\(self.arrTab[indexPath.item])000").size(withAttributes:[NSAttributedString.Key.font: Fonts.Regular.returnFont(size: 15.0)])
        let width = size.width + 40
        let height = 50.0
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.dismissMyKeyboard()
        self.intSelectedTab = indexPath.item
        self.intOrderStatus = OrdersMScreen.getStatusNo(status: self.arrTab[indexPath.item])
        self.arrTempDate.removeAll()
        self.arrDateNOrderList?.removeAll()
        self.page = 1
        self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: self.searchText, page: self.page, startDate: self.strStartDate, endDate: self.strEndDate, businessPartnerId: self.intSelectedBusinessPId, employeeId: self.intSelectedEmployeeId, orderType: self.intOrderType)
        
        self.colleTab.reloadData()
    }
}

// MARK: - UITableView Delegate, Datasource

extension SalesOrderVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.arrDateNOrderList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "OrdersCustomTHView") as! OrdersCustomTHView
        headerView.viewMain.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
        headerView.lblDate.text = self.arrDateNOrderList?[section].requestDate ?? ""
        headerView.lblAmount.text = self.arrDateNOrderList?[section].totalAmount ?? ""
        headerView.lblCommission.text = "COMMISSION: \(self.arrDateNOrderList?[section].totalCommission ?? 0)"
        headerView.lblOrderCount.text = "ORDER COUNT: \(self.arrDateNOrderList?[section].totalOrder ?? "0")"
        
        // Show Commission
        if [3, 4, 10, 12].contains(APIManager.sharedManager.userDetail?.roleId ?? 0) {
            headerView.lblCommission.isHidden = false
            headerView.constraintHeightLblCommission.constant = 17
        }
        else {
            headerView.lblCommission.isHidden = true
            headerView.constraintHeightLblCommission.constant = 0
        }
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return self.arrOrdersList?.count ?? 0
        return self.arrDateNOrderList?[section].ordersList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrdersTVCell", for: indexPath) as! OrdersTVCell
        
        cell.lblName.text = self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].businessPartnerName ?? ""
        cell.lblAmount.text = "₹ \(self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].grandTotalAmount ?? "")"
        cell.lblName.textColor = Colors.theme.returnColor()
        cell.lblAmount.textColor = Colors.theme.returnColor()
        
        let strStatusTitle: String = self.intOrderStatus == 0 ? "(\(OrderStatus.getStatusTitle(status: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].orderStatus ?? 0)))" : ""
        let colorStatus: UIColor = OrderStatus.getStatusColor(status: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].orderStatus ?? 0)
        
        cell.viewSideColorBar.backgroundColor = colorStatus
        cell.lblCode.attributedText = "\(self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].orderCode ?? "") \(strStatusTitle)".setColorToString(strValue: [strStatusTitle], color: [colorStatus], fontSize: 14)
        cell.lblProductCount.text = "\(self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].totalProduct ?? 0) Products"
        
        cell.constraintBottomCode.priority = .required
        cell.lblEmpName.text = ""
        if (self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].employeeName ?? "") != "" {
            cell.constraintBottomCode.priority = .defaultLow
            cell.lblEmpName.text = self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].employeeName ?? ""
        }
        
        cell.lblSeparator.backgroundColor = Colors.separator.returnColor()
        
        cell.viewMain.backgroundColor = self.getBackgroundColor(
            orderType: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].orderType ?? 0,
            isPurchaseManager: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].isPurchaseManager ?? 0,
            orderStatus: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].orderStatus ?? 0,
            userId: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].userId ?? 0,
            statusBy: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].statusBy ?? 0,
            roleId: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].roleId ?? 0)
        
        if self.hasMore {
            var isApiCall: Bool = false
            
            if self.arrTempDate.count > 1 {
                if (self.arrDateNOrderList?[(self.arrDateNOrderList?.count ?? 0) - 1].ordersList?.count ?? 0) > 3
                {
                    if (indexPath.section == ((self.arrDateNOrderList?.count ?? 0) - 1)) &&
                        (indexPath.row >= (self.arrDateNOrderList?[(self.arrDateNOrderList?.count ?? 0) - 1].ordersList?.count ?? 0) - 3) &&
                        self.isLoadMore
                    {   // From 1
                        isApiCall = !isApiCall
                        self.isLoadMore = !self.isLoadMore
                        print("Api call --- From 1")
                    }
                }
                else {
                    if self.isLoadMore &&
                        (indexPath.section == ((self.arrDateNOrderList?.count ?? 0) - 2)) &&
                            (indexPath.row >= ((self.arrDateNOrderList?[(self.arrDateNOrderList?.count ?? 0) - 2].ordersList?.count ?? 0) - 1))
                    {   // From 2
                        isApiCall = !isApiCall
                        self.isLoadMore = !self.isLoadMore
                        print("Api call --- From 2")
                    }
                }
            }
            else {
                if (indexPath.section == ((self.arrDateNOrderList?.count ?? 0) - 1)) &&
                    (indexPath.row >= (self.arrDateNOrderList?[(self.arrDateNOrderList?.count ?? 0) - 1].ordersList?.count ?? 0) - 3) &&
                    self.isLoadMore
                {   // From 3
                    isApiCall = !isApiCall
                    self.isLoadMore = !self.isLoadMore
                    print("Api call --- From 3")
                }
            }
            
            if isApiCall {
                self.page += 1
                self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: self.searchText, page: self.page, startDate: self.strStartDate, endDate: self.strEndDate, businessPartnerId: self.intSelectedBusinessPId, employeeId: self.intSelectedEmployeeId, orderType: self.intOrderType)
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 54
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.intOrderType == 0 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "SalesOrderDetailsVC") as! SalesOrderDetailsVC
            /// Pass value.
            viewController.isSalesOrderDetail = true
            viewController.strScreenTitle = "Sales Order Details"
            viewController.intOrderId = self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].id ?? 0
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let approve = UIContextualAction(style: .normal, title: "Approve") { action, view, complete in
            
            /*self.changeOrderStatus(orderId: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].id ?? 0,
                                   orderStatus: (self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].isPurchaseManager ?? 0) == 1 ? 2 : 12,
                                   reason: "",
                                   preferredWarehouse: 0)   //  */
            
            self.changeOrderStatus(orderId: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].id ?? 0,
                                   orderStatus: 2,
                                   reason: "",
                                   preferredWarehouse: 0)
            
            complete(true)
        }
        let lblApprove = UILabel()
        lblApprove.text = "Approve"
        lblApprove.font = Fonts.Regular.returnFont(size: 20.0)
        lblApprove.sizeToFit()
        lblApprove.textColor = .white
        //call.image = UIImage(systemName: "checkmark.circle.fill")    //UIImage(named: "call")
        approve.image = Utilities.addLabelToImage(image: UIImage(named: "ApproveCircleW")!, label: lblApprove)
        approve.image?.withTintColor(.white)
        approve.backgroundColor = UIColor(hexString: "#5FA02E", alpha: 1.0)
        
        let delete = UIContextualAction(style: .normal, title: "Delete") { action, view, complete in
            
            // Open popup for reason.
            //self.changeOrderStatus(orderId: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].id ?? 0,
                                   //orderStatus: 7)
            self.openRejectPopup(order: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row])
            complete(true)
        }
        let lblDelete = UILabel()
        lblDelete.text = "Reject"
        lblDelete.font = Fonts.Regular.returnFont(size: 20.0)
        lblDelete.sizeToFit()
        lblDelete.textColor = .white
        //delete.image = UIImage(systemName: "xmark.circle")     //UIImage(named: "Delete")
        
        delete.image = Utilities.addLabelToImage(image: UIImage(named: "DeleteCircleW")!, label: lblDelete)
        delete.backgroundColor = .red
        
        //let isSwipe = true
        var isSwipe = self.swipeCell(orderType: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].orderType ?? 0,
                       isPurchaseManager: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].isPurchaseManager ?? 0,
                       orderStatus: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].orderStatus ?? 0,
                       userId: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].userId ?? 0,
                       statusBy: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].statusBy ?? 0,
                       roleId: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].roleId ?? 0,
                       employeeOrder: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].employeeOrder ?? 0,
                       accessId: self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].accessId ?? 0)
        
        if (self.arrDateNOrderList?[indexPath.section].ordersList?[indexPath.row].orderStatus ?? 0) == 2 {
            isSwipe = false
        }
        
        if isSwipe {
            return UISwipeActionsConfiguration(actions: [delete,approve])
        }
        else {
            return nil
        }
    }
    
    func openRejectPopup(order: SalesOrdersList?) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "OrderRejectPopupVC") as! OrderRejectPopupVC
        popupVC.titleTxt = Title.ProductCatePopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.intReasonType = 1
        popupVC.didSelect = { reason, warehouseId in
            
            print("Reason -> \(reason)")
            print("Warehouse Id -> \(warehouseId)")
            
            self.changeOrderStatus(orderId: order?.id ?? 0,
                                   orderStatus: 7,
                                   reason: reason,
                                   preferredWarehouse: warehouseId)
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
//    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        let action = UIContextualAction(style: .normal,
//                                        title: nil) { [weak self] (action, view, completionHandler) in
//            self?.swipeReplyMsg = self?.arrSectionMsg![indexPath.section][indexPath.row]
//            self?.replyMsg()
//            completionHandler(true)
//        }
}

// MARK: - Cell BG Color and Swipe action.

extension SalesOrderVC {
    
    // orderType -> 0- Sales Order, 1- QI, 2- PI
    func swipeCell(orderType: Int, isPurchaseManager: Int, orderStatus: Int, userId: Int, statusBy: Int, roleId: Int, employeeOrder: Int, accessId: Int) -> Bool {
        var isSwipe: Bool = false
        let myRoleId : Int = APIManager.sharedManager.userDetail?.roleId ?? 0
        
        if [0, 1, 2].contains(orderType) {
            if myRoleId == 2 {
                isSwipe = false
            }
            else {
                if orderType == 0 && myRoleId == 4 && orderStatus == 1 {
                    if myRoleId == 4 {
                        if roleId == 2 {
                            isSwipe = false
                        }
                        else {
                            isSwipe = true
                        }
                    }
                    else {
                        isSwipe = true
                    }
                }
                else if userId == APIManager.sharedManager.userId {
                    isSwipe = false
                }
                else if employeeOrder == 1 {
                    isSwipe = false
                }
                else {
                    if orderStatus == 1 {
                        if [3, 4, 11].contains(myRoleId) {
                            if myRoleId == 4 {
                                if roleId == 2 {
                                    isSwipe = false
                                }
                                else {
                                    isSwipe = true
                                }
                            }
                            else {
                                isSwipe = true
                            }
                        }
                        else {
                            isSwipe = false
                        }
                    }
                    else {
                        isSwipe = false
                    }
                }
                
                if myRoleId == 13 {
                    if isPurchaseManager == 1 && orderStatus != 7 && orderStatus != 2 {
                        isSwipe = true
                    }
                    else {
                        isSwipe = true
                    }
                }
                else if myRoleId == 3 {
                    if isPurchaseManager == 0 && (orderStatus == 1 || orderStatus == 2) && userId != APIManager.sharedManager.userId && (statusBy == APIManager.sharedManager.userId || statusBy == 0) {
                         isSwipe = true
                    }
                    else {
                        isSwipe = false
                    }
                }
                else if myRoleId == 4 {
                    if (statusBy == APIManager.sharedManager.userId || roleId == 3) && (orderStatus == 1 || orderStatus == 2) {
                        if orderStatus == 1 || orderStatus == 2 {
                            if isPurchaseManager == 0 {
                                if statusBy == APIManager.sharedManager.userId {
                                    isSwipe = true
                                }
                                else {
                                    if statusBy == 0 {
                                        if roleId == 3 {
                                            isSwipe = true
                                        }
                                        else {
                                            isSwipe = false
                                        }
                                    }
                                    else {
                                        isSwipe = false
                                    }
                                }
                            }
                            else {
                                isSwipe = false
                            }
                        }
                        else {
                            isSwipe = false
                        }
                    }
                    else {
                        isSwipe = false
                    }
                }
            }
        }
        else if self.isSampleOrder {
            if myRoleId == 2 {
                isSwipe = false
            }
            else {
                if userId == APIManager.sharedManager.userId {
                    isSwipe = false
                }
                else {
                    if [3, 4, 11].contains(myRoleId) {
                        if orderStatus == 1 {
                            if accessId == APIManager.sharedManager.userId {
                                if statusBy == 1 {
                                    isSwipe = true
                                }
                                else {
                                    isSwipe = false
                                }
                            }
                            else {
                                isSwipe = true
                            }
                        }
                        else {
                            isSwipe = false
                        }
                    }
                    else {
                        isSwipe = false
                    }
                }
                
                if myRoleId == 13 {
                    if isPurchaseManager == 1 && orderStatus != 7 && orderStatus != 2 {
                        isSwipe = true
                    }
                    else {
                        isSwipe = false
                    }
                }
                else if myRoleId == 3 {
                    if isPurchaseManager == 0 && orderStatus == 1 && userId != APIManager.sharedManager.userId && (statusBy == APIManager.sharedManager.userId || statusBy != 0) {
                        isSwipe = true
                    }
                    else {
                        isSwipe = false
                    }
                }
                else if myRoleId == 4 {
                    if (statusBy == APIManager.sharedManager.userId || roleId == 3) && orderStatus == 1 {
                        if orderStatus == 1 {
                            if isPurchaseManager == 0 {
                                if statusBy == APIManager.sharedManager.userId {
                                    isSwipe = true
                                }
                                else {
                                    if statusBy == 0 {
                                        if roleId == 3 {
                                            isSwipe = true
                                        }
                                        else {
                                            isSwipe = false
                                        }
                                    }
                                    else
                                    {
                                        isSwipe = false
                                    }
                                }
                            }
                            else {
                                isSwipe = false
                            }
                        }
                        else {
                            isSwipe = false
                        }
                    }
                    else {
                        isSwipe = false
                    }
                }
                else {
                    isSwipe = false
                }
            }
        }
        
        if self.isFollowUp {
            isSwipe = false
        }
        
        return isSwipe
    }
    
    func getBackgroundColor(orderType: Int, isPurchaseManager: Int, orderStatus: Int, userId: Int, statusBy: Int, roleId: Int) -> UIColor {
        var bgColor: UIColor = .black
        let myRoleId: Int = APIManager.sharedManager.userDetail?.roleId ?? 0
        let myUserId: Int = APIManager.sharedManager.userId
        
        if [0, 1, 2].contains(orderType) {
            if [5, 7, 19, 22].contains(orderStatus) {
                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
            }
            else if myRoleId == 13 {
                if (isPurchaseManager != 1) || (orderStatus == 2) {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                }
                else {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                }
            }
            else if myRoleId == 3 {
                if isPurchaseManager == 1 || userId == myUserId || statusBy != myUserId || (orderStatus != 1 && orderStatus != 2) {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                    
                    if (statusBy == 0) && (isPurchaseManager != 1) && ((orderStatus == 1) || (orderStatus == 2)) {
                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                    }
                }
                else {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                }
            }
            else if myRoleId == 4 {
                if (isPurchaseManager == 1) || (statusBy != myUserId) || (roleId != 3) {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                    if (orderStatus == 1) || (orderStatus == 2) {
                        if (statusBy == myUserId) {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                            
                            if (isPurchaseManager == 1) {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            }
                        }
                        else if roleId == 3 {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            if statusBy == 0 {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                            }
                            if isPurchaseManager == 1 {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            }
                        }
                        else {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                        }
                    }
                }
                else {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                    if (orderStatus == 1) || (orderStatus == 2) {
                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                    }
                }
            }
            else {
                bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
            }
        }
        else if orderType == 3 {
            if [5, 7, 19, 22].contains(orderStatus) {
                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
            }
            else if myRoleId == 13 {
                if (isPurchaseManager != 1) || (orderStatus == 2) {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                }
                else {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                }
            }
            else if myRoleId == 3 {
                if isPurchaseManager == 1 || userId == myUserId || statusBy != myUserId || (orderStatus != 1) {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                    
                    if (statusBy == 0) && (isPurchaseManager != 1) && (orderStatus == 1) {
                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                    }
                }
                else {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                }
            }
            else if myRoleId == 4 {
                if (isPurchaseManager == 1) || (statusBy != myUserId) || (roleId != 3) {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                    if (orderStatus == 1) {
                        if (statusBy == myUserId) {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                            
                            if (isPurchaseManager == 1) {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            }
                        }
                        else if roleId == 3 {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            if statusBy == 0 {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                            }
                            if isPurchaseManager == 1 {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            }
                        }
                        else {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                        }
                    }
                }
                else {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                    if (orderStatus == 1) {
                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                    }
                }
            }
            else {
                bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
            }
        }
        
        return bgColor
    }
    
    func getBackgroundColor1(orderType: Int, isPurchaseManager: Int, orderStatus: Int, userId: Int, statusBy: Int, roleId: Int) -> UIColor {
        var bgColor: UIColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
        let myRoleId: Int = APIManager.sharedManager.userDetail?.roleId ?? 0
        let myUserId: Int = APIManager.sharedManager.userId
        
        if [0, 1, 2].contains(orderType) || self.isSampleOrder {
            if myRoleId == 13 {
                if isPurchaseManager != 1 || orderStatus == 7 || orderStatus == 2 {
                    if [5, 7, 19, 22].contains(orderStatus) {
                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                    }
                    else {
                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                    }
                }
                else {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                }
            }
            else if myRoleId == 3 {
                if self.isSampleOrder {
                    if (isPurchaseManager == 1) || (userId == myUserId) || (statusBy != myUserId) || (orderStatus != 1) {
                        if [5, 7, 19, 22].contains(orderStatus) {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                        }
                        else {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                        }
                        
                        if (statusBy == 0) && (isPurchaseManager != 1) && (orderStatus == 1) {
                            if (statusBy != 0) {
                                if [5, 7, 19, 22].contains(orderStatus) {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                }
                                else {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                }
                            }
                            else {
                                if [5, 7, 19, 22].contains(orderStatus) {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                }
                                else {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                                }
                            }
                        }
                    }
                    else {
                        if [5, 7, 19, 22].contains(orderStatus) {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                        }
                        else {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                        }
                    }
                }
                else {
                    if isPurchaseManager == 1 || userId == myUserId || statusBy != myUserId || (orderStatus != 1 && orderStatus != 2) {
                        if [5, 7, 19, 22].contains(orderStatus) {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                        }
                        else {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                        }
                        
                        if statusBy == 0 && isPurchaseManager != 1 && (orderStatus == 1 || orderStatus == 2) {
                            if orderStatus == 2 && statusBy != 0 {
                                if [5, 7, 19, 22].contains(orderStatus) {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                }
                                else {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                }
                            }
                            else {
                                if [5, 7, 19, 22].contains(orderStatus) {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                }
                                else {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                                }
                            }
                        }
                    }
                    else {
                        if [5, 7, 19, 22].contains(orderStatus) {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                        }
                        else {
                            bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                        }
                    }
                }
            }
            else if myRoleId == 4 {
                if self.isSampleOrder {
                    if isPurchaseManager == 1 || statusBy != myUserId || roleId != 3 {
                        if orderStatus == 1 {
                            if statusBy == myUserId {
                                if [5, 7, 19, 22].contains(orderStatus) {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                }
                                else {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                                }
                                
                                if isPurchaseManager == 1 {
                                    if [5, 7, 19, 22].contains(orderStatus) {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                    }
                                    else {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                    }
                                }
                            }
                            else if roleId == 3 {
                                if statusBy == 0 {
                                    if [5, 7, 19, 22].contains(orderStatus) {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                    }
                                    else {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                                    }
                                }
                                else {
                                    if [5, 7, 19, 22].contains(orderStatus) {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                    }
                                    else {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                    }
                                }
                                
                                if isPurchaseManager == 1 {
                                    if [5, 7, 19, 22].contains(orderStatus) {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                    }
                                    else {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                    }
                                }
                            }
                            else {
                                if [5, 7, 19, 22].contains(orderStatus) {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                }
                                else {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                }
                            }
                        }
                        else {
                            if [5, 7, 19, 22].contains(orderStatus) {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                            }
                            else {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            }
                        }
                    }
                    else {
                        if orderStatus == 1 {
                            if [5, 7, 19, 22].contains(orderStatus) {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                            }
                            else {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                            }
                        }
                        else {
                            if [5, 7, 19, 22].contains(orderStatus) {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                            }
                            else {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            }
                        }
                    }
                }
                else {
                    if isPurchaseManager == 1 || statusBy != myUserId || roleId != 3 {
                        if orderStatus == 1 || orderStatus == 2 {
                            if statusBy == myUserId {
                                if [5, 7, 19, 22].contains(orderStatus) {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                }
                                else {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                                }
                                
                                if isPurchaseManager == 1 {
                                    if [5, 7, 19, 22].contains(orderStatus) {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                    }
                                    else {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                    }
                                }
                            }
                            else if roleId == 3 {
                                if statusBy == 0 {
                                    if [5, 7, 19, 22].contains(orderStatus) {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                    }
                                    else {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                                    }
                                }
                                else {
                                    if [5, 7, 19, 22].contains(orderStatus) {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                    }
                                    else {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                    }
                                }
                                
                                if isPurchaseManager == 1 {
                                    if [5, 7, 19, 22].contains(orderStatus) {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                    }
                                    else {
                                        bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                    }
                                }
                            }
                            else {
                                if [5, 7, 19, 22].contains(orderStatus) {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                                }
                                else {
                                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                                }
                            }
                        }
                        else {
                            if [5, 7, 19, 22].contains(orderStatus) {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                            }
                            else {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            }
                        }
                    }
                    else {
                        if orderStatus == 1 || orderStatus == 2 {
                            if [5, 7, 19, 22].contains(orderStatus) {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                            }
                            else {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                            }
                        }
                        else {
                            if [5, 7, 19, 22].contains(orderStatus) {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                            }
                            else {
                                bgColor = OrdersMScreen.getOrderBgColor(strColor: .purchaseManagerHeighlightColor)
                            }
                        }
                    }
                }
            }
            else {
                if [5, 7, 19, 22].contains(orderStatus) {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
                }
                else {
                    bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
                }
            }
        }
        else {
            if [22, 5, 7, 19].contains(orderStatus) {
                bgColor = OrdersMScreen.getOrderBgColor(strColor: .rejectColor)
            }
            else {
                bgColor = OrdersMScreen.getOrderBgColor(strColor: .whiteColor)
            }
        }
        
        return bgColor
    }
}

// MARK: - SearchBar Delegate

extension SalesOrderVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchText = searchText
        self.page = 1
        
        self.arrTempDate.removeAll()
        self.arrDateNOrderList?.removeAll()
        self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: self.searchText, page: self.page, startDate: self.strStartDate, endDate: self.strEndDate, businessPartnerId: self.intSelectedBusinessPId, employeeId: self.intSelectedEmployeeId, orderType: self.intOrderType)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        self.searchBar.text = ""
        self.searchText = ""
        self.page = 1
        
        self.arrTempDate.removeAll()
        self.arrDateNOrderList?.removeAll()
        self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: self.searchText, page: self.page, startDate: self.strStartDate, endDate: self.strEndDate, businessPartnerId: self.intSelectedBusinessPId, employeeId: self.intSelectedEmployeeId, orderType: self.intOrderType)
    }
}

// MARK: - Webservices

extension SalesOrderVC {
    
    func getBusinessPNEmployeeList(companyType: Int, orderStatus: Int, type: Int, orderType: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getBusinessPNEmployeeList(companyType: companyType, orderStatus: orderStatus, type: type, orderType: orderType)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": companyType,
            "order_status": orderStatus,
            "type": type,
            "order_type": orderType
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ORDERED_BUSINESS_PARTNERS, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrOrderedBusinessPartner = response?.result?.orderedBusinessPartners ?? []
                    self.arrOrderedEmployees = response?.result?.orderedEmployees ?? []
                    
                    self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: "", page: self.page, startDate: "", endDate: "", businessPartnerId: 0, employeeId: 0, orderType: self.intOrderType)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getOrderList(companyType: Int, orderStatus: Int, searchText: String, page: Int, startDate: String, endDate: String, businessPartnerId: Int, employeeId: Int, orderType: Int) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getOrderList(companyType: companyType, orderStatus: orderStatus, searchText: searchText, page: page, startDate: startDate, endDate: endDate, businessPartnerId: businessPartnerId, employeeId: employeeId, orderType: orderType)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": companyType,
            "order_status": orderStatus,
            "search": searchText,
            "page": page,
            "start_date": startDate,
            "end_date": endDate,
            "business_partner_id": businessPartnerId,
            "employee_id": employeeId,
            "order_type": orderType
        ] as? [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_ORDERS_LIST_BASED_ON_STATUS, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //print("Get response. -- \(response?.result?.productList ?? [])")
                    
                    self.hasMore = response?.result?.hasMore ?? false
                    self.dictCounts = response?.result?.counts
                    
                    let arrTempOrderCounts = response?.result?.orderCounts ?? []
                    let arrTempOrdersList = response?.result?.ordersList ?? []
                    
                    self.arrOrderCounts = arrTempOrderCounts
                    self.arrOrdersList = arrTempOrdersList
                    
                    /*if self.page == 1 {
                        //self.arrOrderCounts = arrTempOrderCounts
                        self.arrOrdersList = arrTempOrdersList
                    }
                    else {
                        //self.arrOrderCounts?.append(contentsOf: arrTempOrderCounts)
                        self.arrOrdersList?.append(contentsOf: arrTempOrdersList)
                    }   //  */
                    //self.tvOrders.reloadData()
                    self.setDetail(ordersList: self.arrOrdersList)
                }
            }
            else {
                DispatchQueue.main.async {
                    self.page -= 1
                    //Utilities.showPopup(title: response?.message ?? "", type: .error)
                    self.viewNoData.isHidden = false
                    self.lblNoData.text = response?.message ?? ""
                }
            }
        }
    }
    
    func changeOrderStatus(orderId: Int, orderStatus: Int, reason: String, preferredWarehouse: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.changeOrderStatus(orderId: orderId, orderStatus: orderStatus, reason: reason, preferredWarehouse: preferredWarehouse)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "order_id": orderId,
            "status": orderStatus,
            "reason": reason,
            "preferredWarehouse": preferredWarehouse
        ] as? [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CHANGE_ORDER_STATUS, parameters: param) { (response: ApiResponseSalesOrder?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrTempDate.removeAll()
                    self.arrDateNOrderList?.removeAll()
                    self.getOrderList(companyType: APIManager.sharedManager.companyType ?? 1, orderStatus: self.intOrderStatus, searchText: self.searchText, page: 1, startDate: self.strStartDate, endDate: self.strEndDate, businessPartnerId: self.intSelectedBusinessPId, employeeId: self.intSelectedEmployeeId, orderType: self.intOrderType)
                }
            }
            else {
                DispatchQueue.main.async {
                    Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }
}

// MARK: - Keyboard

extension SalesOrderVC {
    func checkKeyboard() {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        initializeHideKeyboard()
    }
    
    func initializeHideKeyboard(){
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        self.viewMain.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard(){
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomBSheet.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            
//            if self.intSelectedTab == 0 {
//                self.constraintBottomViewTabCompany.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
//            }
//            else if self.intSelectedTab == 1 {
//                self.constraintBottomViewTabContact.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
//            }
//            else if self.intSelectedTab == 2 {
//                self.constraintBottomViewTabBilling.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
//            }
//            else if self.intSelectedTab == 3 {
//                self.constraintBottomViewTabDelivery.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
//            }
//            else if self.intSelectedTab == 4 {
//                self.constraintBottomViewTabTransport.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
//            }
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}
