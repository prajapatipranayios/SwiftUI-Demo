//
//  ViewStocksVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 07/06/24.
//

import UIKit

class ViewStocksVC: UIViewController {

    // MARK: - Outlet
    @IBOutlet weak var viewMain : UIView!
    @IBOutlet weak var btnClose: UIButton!
    @IBAction func btnCloseTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onClose != nil {
                self.onClose!()
            }
        }
    }
    
    @IBOutlet weak var viewBottomSheet : UIView!
    @IBOutlet weak var lblTitle : UILabel!
    
    @IBOutlet weak var viewSearchBar: UIView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var constraintHeightViewSearchBar: NSLayoutConstraint!
    
    @IBOutlet weak var cvStocks: UICollectionView! {
        didSet {
            self.cvStocks.delegate = self
            self.cvStocks.dataSource = self
            self.cvStocks.register(UINib(nibName: "WarehouseCVCell", bundle: nil), forCellWithReuseIdentifier: "WarehouseCVCell")
        }
    }
    @IBOutlet weak var heightCVStocks : NSLayoutConstraint!
    @IBOutlet weak var bottomSheetbottomConstraint : NSLayoutConstraint!
    
    
    
    // MARK: - Variable
    var didSelect: ((String)->Void)?
    var onClose: (()->Void)?
    var rowHeaders: [String] = ["Warehouse", "Phy. Stock", "SO Commited", "Available"]
    var arrProductWarehouse: [ProductWarehouse]?
    var titleTxt: String = ""
    var selectedValue = "All"
    var isSearchActive: Bool = false
    
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblTitle.text = self.titleTxt
        self.lblTitle.textColor = Colors.titleLabel.returnColor()
        
        self.viewMain.backgroundColor = .clear
        self.viewBottomSheet.corners([.topLeft, .topRight], radius: 25)
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
        
        self.constraintHeightViewSearchBar.constant = 0
        if self.isSearchActive {
            self.constraintHeightViewSearchBar.constant = 44
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.cvStocks.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.cvStocks.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                self.heightCVStocks.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                self.updateViewConstraints()
            }
        }
    }
}

extension ViewStocksVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return (self.arrProductWarehouse?.count ?? 0) + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return rowHeaders.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WarehouseCVCell", for: indexPath) as! WarehouseCVCell
        cell.lblValue.backgroundColor = .clear
        if indexPath.section == 0 {
            cell.lblValue.text = rowHeaders[indexPath.item]
            cell.lblValue.textAlignment = .left
            cell.viewMain.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        }
        else {
            cell.viewMain.backgroundColor = .white
            if indexPath.item == 0 {
                let warehouse = APIManager.sharedManager.userDetail?.warehouse?.filter { $0.id == self.arrProductWarehouse?[indexPath.section - 1].branchId ?? 0 }
                cell.lblValue.text = "\(warehouse?[0].branchName ?? "")"
                cell.lblValue.textAlignment = .left
            }
            else if indexPath.item == 1 {
                cell.lblValue.text = "\(self.arrProductWarehouse?[indexPath.section - 1].inStock ?? "")"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 2 {
                cell.lblValue.text = "\(self.arrProductWarehouse?[indexPath.section - 1].inCommited ?? 0)"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 3 {
                cell.lblValue.text = "\(self.arrProductWarehouse?[indexPath.section - 1].available ?? 0)"
                cell.lblValue.textAlignment = .center
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 0) / 4
        let height = 40.0
        return CGSize(width: width, height: height)
    }
}
