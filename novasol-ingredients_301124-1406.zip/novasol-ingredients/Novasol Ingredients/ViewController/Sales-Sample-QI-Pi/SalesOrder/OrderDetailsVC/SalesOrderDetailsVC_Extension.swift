//
//  SalesOrderDetailsVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 03/05/24.
//

import Foundation
import UIKit


// MARK: - TableView DataSource, Delegate

extension SalesOrderDetailsVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.bpOrderDetail?.products?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderDetailsTVCell", for: indexPath) as! OrderDetailsTVCell
        
        cell.index = indexPath.row
        cell.lblProductName.text = self.bpOrderDetail?.products?[indexPath.row].productName ?? ""
        
        let unitPrice: String = "\(self.bpOrderDetail?.products?[indexPath.row].productPrice ?? 0.0)".curFormatAsRegion()
        cell.lblUnitPrice.text = "₹ \(unitPrice)"
        
        cell.lblDiscount.text = "\(self.bpOrderDetail?.products?[indexPath.row].productDiscount ?? 0.0)%"
        
        cell.lblOriginalQty.text = "\(self.bpOrderDetail?.products?[indexPath.row].productQty ?? 0) \(self.bpOrderDetail?.products?[indexPath.row].moqUnit ?? "KG")"
        cell.lblApprovedQty.text = "\(self.bpOrderDetail?.products?[indexPath.row].requiredQty ??   0) \(self.bpOrderDetail?.products?[indexPath.row].moqUnit ?? "KG")"
        cell.lblRemainQty.text = "\(self.bpOrderDetail?.products?[indexPath.row].remainingQty ?? 0) \(self.bpOrderDetail?.products?[indexPath.row].moqUnit ?? "KG")"
        cell.lblMOQ.text = "\(self.bpOrderDetail?.products?[indexPath.row].moq ?? 0) \(self.bpOrderDetail?.products?[indexPath.row].moqUnit ?? "KG")"
        
        cell.lblCommission.text = "₹ " + "\(self.bpOrderDetail?.products?[indexPath.row].commission ?? 0)".curFormatAsRegion()
        
        let gst: String = "\(Double(self.bpOrderDetail?.products?[indexPath.row].sgstPercentage ?? 0.0) + Double(self.bpOrderDetail?.products?[indexPath.row].cgstPercentage ?? 0.0) + Double(self.bpOrderDetail?.products?[indexPath.row].igstPercentage ?? 0.0))".curFormatAsRegion()
        cell.lblGST.text = "\(gst)%"
        
        cell.lblBasic.text = "₹ " + "\(self.bpOrderDetail?.products?[indexPath.row].basicProductTotal ?? 0.0)".curFormatAsRegion()
        
        let discountAmount = self.bpOrderDetail?.products?[indexPath.row].discountAmount ?? 0.0
        cell.lblDiscountAmt.text = "₹ " + "\(discountAmount)".curFormatAsRegion()
        
        let amount = Double(self.bpOrderDetail?.products?[indexPath.row].sgstAmount ?? 0.0) + Double(self.bpOrderDetail?.products?[indexPath.row].cgstAmount ?? 0.0) + Double(self.bpOrderDetail?.products?[indexPath.row].igstAmount ?? 0.0)
        cell.lblGSTAmount.text = "₹ " + "\(amount)".curFormatAsRegion()
        
        let net = Double(self.bpOrderDetail?.products?[indexPath.row].sgstAmount ?? 0.0) + Double(self.bpOrderDetail?.products?[indexPath.row].cgstAmount ?? 0.0) + (Double(self.bpOrderDetail?.products?[indexPath.row].igstAmount ?? 0.0) + Double(self.bpOrderDetail?.products?[indexPath.row].basicProductTotal ?? 0.0))
        cell.lblNet.text = "₹ " + "\(net - discountAmount)".curFormatAsRegion()
        
        cell.onTapViewOrders = { index in
            let sb = UIStoryboard(name: "Main", bundle: nil)
            let vc = sb.instantiateViewController(withIdentifier: "ProductOrderVC") as! ProductOrderVC
            vc.productId = self.bpOrderDetail?.products?[indexPath.row].productId ?? 0
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        cell.onTapViewHistory = { index in
            
            var isOpen: Bool = false
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithTableVC") as! PopupWithTableVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            
            popupVC.strTitle = "Products History"
            popupVC.isOrderHistory = true
            popupVC.arrProductHistory = self.bpOrderDetail?.products?[index].productHistory ?? []
            popupVC.intUserId = self.bpOrderDetail?.userID ?? 0
            popupVC.strOrderStatus = OrderStatus.getStatusTitle(status: self.bpOrderDetail?.orderStatus ?? 0)
            isOpen = true
            
            popupVC.onClose = { _ in
            }
            if isOpen {
                self.present(popupVC, animated: true)
            }
        }
        
        if self.isSampleOrderDetail {
            cell.constraintHeightQuestionView.priority = .defaultLow
            
            cell.lblAns1.text = self.bpOrderDetail?.products?[indexPath.row].questions?.qApplication ?? ""
            cell.lblAns2.text = self.bpOrderDetail?.products?[indexPath.row].questions?.qTrailBachSize ?? ""
            cell.lblAns3.text = self.bpOrderDetail?.products?[indexPath.row].questions?.qBrand ?? ""
            cell.lblAns4.text = "\(self.bpOrderDetail?.products?[indexPath.row].questions?.qPotentialQty ?? "") \(self.bpOrderDetail?.products?[indexPath.row].questions?.qPotentialMeasurement ?? "") /\(self.bpOrderDetail?.products?[indexPath.row].questions?.qPotentialType ?? "")"
        }
        else {
            cell.constraintHeightQuestionView.priority = .required
        }
        
        var isReason: Bool = false
        isReason = (self.bpOrderDetail?.products?[indexPath.row].rejectReason ?? "") == "" ? false : true
        
        if isReason {
            cell.constraintBottomSuper.priority = .defaultLow
            cell.lblReason.isHidden = false
            cell.lblSeparator4.isHidden = false
            cell.lblReason.text = "Reason: \(self.bpOrderDetail?.products?[indexPath.row].rejectReason ?? "")"
        }
        else {
            cell.constraintBottomSuper.priority = .required
            cell.lblReason.isHidden = true
            cell.lblSeparator4.isHidden = true
        }
        
        return cell
    }
}


//

extension SalesOrderDetailsVC {
    
    func editBtnVisible() -> Bool {
        
        var isEdit: Bool = true
        let myUserId: Int = APIManager.sharedManager.userId
        let orderUserId: Int = self.bpOrderDetail?.userID ?? 0
        
        if orderUserId == myUserId {
            if [7, 9, 19].contains(self.bpOrderDetail?.orderStatus ?? 0) {
                var isEditable: Bool = false
                
                for i in 0..<(self.bpOrderDetail?.products?.count ?? 0) {
                    if (self.bpOrderDetail?.products?[i].status ?? "" == "Rejected") || (self.bpOrderDetail?.orderStatus ?? 0 == 19) {
                        isEditable = true
                        break
                    }
                }
                isEdit = false
                if isEditable {
                    isEdit = true
                }
            }
            else {
                isEdit = false
            }
        }
        else {
            isEdit = false
        }
        
        return isEdit
    }
    
    func editOrderDetails() {
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "AddOrderVC") as! AddOrderVC
        viewController.isFromEditRejectedOrder = true
        if isSalesOrderDetail {
            viewController.isFromSalesOrder = true
            viewController.strScreenTitle = "Add SALES ORDER".capitalized
        } else if isSampleOrderDetail {
            viewController.isFromSampleRequest = true
            viewController.strScreenTitle = "NEW SAMPLE REQUEST".capitalized
        }
        viewController.editOrderDetail = self.bpOrderDetail
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}



// MARK: - Webservices

extension SalesOrderDetailsVC {
    
    func getSalesOrderDetail(orderId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getSalesOrderDetail(orderId: orderId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "order_id": orderId
//            "user_id": 97,
//            "order_id": 40550
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_SINGLE_OEDER, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //self.arrEmployee = response?.result?.employees ?? []
                    self.bpOrderDetail = response?.result?.orderDetail
                    
                    self.setDetail(bpOrderDetail: self.bpOrderDetail!)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getSampleOrderDetail(orderId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getSampleOrderDetail(orderId: orderId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "order_id": orderId
//            "user_id": 97,
//            "order_id": 40550
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_SAMPLE_ORDER_DETAIL, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //self.arrEmployee = response?.result?.employees ?? []
                    self.bpOrderDetail = response?.result?.orderDetail
                    
                    self.setDetail(bpOrderDetail: self.bpOrderDetail!)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func changeFollowUpStatus(orderId: Int, comment: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.changeFollowUpStatus(orderId: orderId, comment: comment)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "order_id": orderId,
            "delivery_status": "YES",
            "delivery_comment": comment
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CHANGE_SAMPLE_ORDER_DELIVERY_STATUS, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.bpOrderDetail?.deliveryStatus = "YES"
                    self.setDetail(bpOrderDetail: self.bpOrderDetail!)
                    self.popupWImg(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func popupWImg(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
        }
        self.present(popupVC, animated: true)
    }
}
