//
//  SalesOrderDetailsVC.swift
//  GE Sales
//
//  Created by Auxano on 03/05/24.
//

import UIKit

class SalesOrderDetailsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var btnEdit: UIButton!
    @IBAction func btnEditTap(_ sender: UIButton) {
        
        self.editOrderDetails()
    }
    
    @IBOutlet weak var viewBasicDetails: UIView!
    
    @IBOutlet weak var viewBasic: UIView!
    @IBOutlet weak var lblBasicTitle: UILabel!
    @IBOutlet weak var lblBasic: UILabel!
    
    @IBOutlet weak var viewGST: UIView!
    @IBOutlet weak var lblGSTTitle: UILabel!
    @IBOutlet weak var lblGST: UILabel!
    
    @IBOutlet weak var viewNetAmount: UIView!
    @IBOutlet weak var lblNetAmountTitle: UILabel!
    @IBOutlet weak var lblNetAmount: UILabel!
    
    @IBOutlet weak var viewButtonsM: UIView!
    @IBOutlet weak var viewButtons: UIView!
    @IBOutlet weak var btnProducts: UIButton!
    @IBAction func btnProductsTap(_ sender: UIButton) {
        
        self.btnOrderDetails.layer.shadowOpacity = 0
        self.btnOrderDetails.backgroundColor = .clear
        self.btnOrderDetails.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnOrderDetails.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.btnProducts.backgroundColor = .white
        self.btnProducts.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnProducts.titleLabel?.font = UIFont(name: "Roboto-Bold", size: 16.0)
        self.btnProducts.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.viewOrderDetails.isHidden = true
        self.constraintHeightTVProduct.priority = .required
        self.constraintBottomOrderDetail.priority = .defaultLow
        
    }
    @IBOutlet weak var btnOrderDetails: UIButton!
    @IBAction func btnOrderDetailsTap(_ sender: UIButton) {
        
        self.btnProducts.layer.shadowOpacity = 0
        self.btnProducts.backgroundColor = .clear
        self.btnProducts.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnProducts.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.btnOrderDetails.backgroundColor = .white
        self.btnOrderDetails.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnOrderDetails.titleLabel?.font = UIFont(name: "Roboto-Bold", size: 16.0)
        self.btnOrderDetails.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.viewOrderDetails.isHidden = false
        self.constraintHeightTVProduct.priority = .defaultLow
        self.constraintBottomOrderDetail.priority = .required
    }
    
    @IBOutlet weak var viewProductDetails: UIView!
    @IBOutlet weak var tvProductDetail: UITableView! {
        didSet {
            self.tvProductDetail.delegate = self
            self.tvProductDetail.dataSource = self
            self.tvProductDetail.register(UINib(nibName: "OrderDetailsTVCell", bundle: nil), forCellReuseIdentifier: "OrderDetailsTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVProduct: NSLayoutConstraint!
    
    @IBOutlet weak var viewOrderDetails: UIView!
    @IBOutlet weak var ViewOrder: UIView!
    @IBOutlet weak var viewBilling: UIView!
    @IBOutlet weak var lblSalesOrderNoTitle: UILabel!
    @IBOutlet weak var lblSalesOrderNo: UILabel!
    @IBOutlet weak var lblCodeTitle: UILabel!
    @IBOutlet weak var lblCode: UILabel!
    @IBOutlet weak var lblOrderDateTitle: UILabel!
    @IBOutlet weak var lblOrderDate: UILabel!
    @IBOutlet weak var lblDeliveryDateTitle: UILabel!
    @IBOutlet weak var lblDeliveryDate: UILabel!
    @IBOutlet weak var lblDeliveryTo: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var lblBillingLocation: UILabel!
    @IBOutlet weak var lblDeliveryOption: UILabel!
    @IBOutlet weak var lblDeliveryLocaation: UILabel!
    @IBOutlet weak var lblDeliveryType: UILabel!
    @IBOutlet weak var lblTransportName: UILabel!
    @IBOutlet weak var lblTransportGSTNo: UILabel!
    @IBOutlet weak var lblFreightCharges: UILabel!
    @IBOutlet weak var lblBookingPoint: UILabel!
    @IBOutlet weak var lblComments: UILabel!
    @IBOutlet weak var lblReferenceName: UILabel!
    @IBOutlet weak var lblPaymentType: UILabel!
    @IBOutlet weak var btnPurchasedOrder: UIButton!
    @IBAction func btnPurchasedOrderTap(_ sender: UIButton) {
    }
    @IBOutlet weak var btnTReceiptTap: UIButton!
    @IBAction func btnTReceiptTap(_ sender: UIButton) {
    }
    
    @IBOutlet weak var constraintBottomOrderDetail: NSLayoutConstraint!
    
    @IBOutlet weak var constraintBotttomSalesOrderStatusToView: NSLayoutConstraint!
    @IBOutlet weak var viewSampleButtons: UIView!
    @IBOutlet weak var btnSampleHistory: UIButton!
    @IBAction func btnSampleHistoryTap(_ sender: UIButton) {
        var isOpen: Bool = false
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithTableVC") as! PopupWithTableVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        
        popupVC.strTitle = "Sample History"
        popupVC.isSampleHistory = true
        popupVC.arrSampleHistory = self.bpOrderDetail?.history ?? []
        //popupVC.intOrderUserId = self.bpOrderDetail?.userID ?? 0
        //popupVC.strOrderStatus = OrderStatus.getStatusTitle(status: self.bpOrderDetail?.orderStatus ?? 0)
        isOpen = true
        
        popupVC.onClose = { _ in
        }
        if isOpen {
            self.present(popupVC, animated: true)
        }
    }
    @IBOutlet weak var lblSeparatorBtnSampleHistory: UILabel!
    
    @IBOutlet weak var btnTrialHistory: UIButton!
    @IBAction func btnTrialHistoryTap(_ sender: UIButton) {
        var isOpen: Bool = false
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWithTableVC") as! PopupWithTableVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        
        popupVC.strTitle = "Trial History"
        popupVC.isTrialHistory = true
        popupVC.intUserId = self.bpOrderDetail?.userID ?? 0
        popupVC.arrTrialHistory = self.bpOrderDetail?.trailReportsHistory?.products ?? []
        isOpen = true
        
        popupVC.onClose = { _ in
        }
        if isOpen {
            self.present(popupVC, animated: true)
        }
    }
    @IBOutlet weak var lblSeparatorBtnTrialHistory: UILabel!
    
    @IBOutlet weak var constraintBottomViewProductNOrderDetails: NSLayoutConstraint!
    // FollowUp
    @IBOutlet weak var viewFollowUpButtons: UIView!
    @IBOutlet weak var stackFollowUpButons: UIStackView!
    @IBOutlet weak var btnCallToFollowUp: UIButton!
    @IBAction func btnCallToFollowUpTap(_ sender: UIButton) {
        if self.strPhoneNumber == "" {
            Utilities.showPopup(title: "Number not available.", type: .error)
        }
        else {
            var arrPhoneNo: [String] = []
            if self.strPhoneNumber.contains(";") {
                arrPhoneNo = self.strPhoneNumber.components(separatedBy: ";")
            }
            else if self.strPhoneNumber.contains(",") {
                arrPhoneNo = self.strPhoneNumber.components(separatedBy: ",")
            }
            else
            {
                arrPhoneNo.append(self.strPhoneNumber)
            }
            
            /*let phoneNumber = self.strPhoneNumber
             let numberUrl = URL(string: "tel://\(phoneNumber)")!
             if UIApplication.shared.canOpenURL(numberUrl) {
             UIApplication.shared.open(numberUrl)
             }   //  */
            
            let app = UIApplication.shared
            guard let number = URL(string: "tel://" + arrPhoneNo[0]), app.canOpenURL(number) else {
                Utilities.showPopup(title: "Can't dial from dummy device.", type: .error)
                return
            }
            app.open(number)    //  */
        }
    }
    @IBOutlet weak var btnDeliveryStatus: UIButton!
    @IBAction func btnDeliveryStatusTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationPopupVC") as! ConfirmationPopupVC
        popupVC.titleTxt = Title.ConfirmationPopupTitle
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strMessage = "Is Product(s) delivered ?"
        popupVC.colorTitleText = .black
        popupVC.colorBtnYesText = Colors.theme.returnColor()
        popupVC.colorBtnNoText = Colors.theme.returnColor()
        popupVC.onYesTap = { ans in
            self.viewStatusComment.isHidden = false
        }
        popupVC.onNoTap = { ans in
        }
        self.present(popupVC, animated: true)
    }
    @IBOutlet weak var btnRequiredTechPerson: UIButton!
    @IBAction func btnRequiredTechPersonTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "FollowUpSelectProductVC") as! FollowUpSelectProductVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strScreenTitle = "SELECT PRODUCTS"
        popupVC.bpOrderDetail = self.bpOrderDetail
        popupVC.onCloseScreen = { isValid, strValue in
            if isValid {
                self.navigationController?.popViewController(animated: true)
            }
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewStatusComment: UIView!
    @IBOutlet weak var btnCloseViewComment: UIButton!
    @IBAction func btnCloseViewCommentTap(_ sender: UIButton) {
        self.viewStatusComment.isHidden = true
    }
    @IBOutlet weak var txtCommentStatusChange: UITextField!
    @IBOutlet weak var btnDoneViewComment: UIButton!
    @IBAction func btnDoneViewCommentTap(_ sender: UIButton) {
        if (self.txtCommentStatusChange.text ?? "").trimmedString != "" {
            self.viewStatusComment.isHidden = true
            self.stackFollowUpButons.isHidden = true
            self.btnRequiredTechPerson.isHidden = false
            // Call api
            self.changeFollowUpStatus(orderId: self.bpOrderDetail?.id ?? 0, comment: self.txtCommentStatusChange.text ?? "")
        }
        else {
            Utilities.showPopup(title: "Please enter comment.", type: .error)
        }
    }
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = ""
    var intOrderId: Int?
    var isSalesOrderDetail: Bool = false
    var isSampleOrderDetail: Bool = false
    var bpOrderDetail: BPOrderDetail?
    var strBtnName: String? = "Order Details"
    
    var isFromFollowUp: Bool = false
    var strPhoneNumber: String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.btnEdit.tintColor = .black
        self.btnEdit.isHidden = true
        
        self.btnProducts.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.lblNetAmount.textColor = Colors.theme.returnColor()
        
        self.viewButtons.layer.cornerRadius = self.viewButtons.frame.height / 2
        self.btnProducts.layer.cornerRadius = self.btnProducts.frame.height / 2
        self.btnOrderDetails.layer.cornerRadius = self.btnOrderDetails.frame.height / 2
        
        self.btnPurchasedOrder.layer.cornerRadius = 5
        self.btnTReceiptTap.layer.cornerRadius = 5
        
        self.btnSampleHistory.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnTrialHistory.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.lblSeparatorBtnSampleHistory.backgroundColor = Colors.theme.returnColor()
        self.lblSeparatorBtnTrialHistory.backgroundColor = Colors.theme.returnColor()
        
        self.viewSampleButtons.isHidden = true
        self.viewSampleButtons.backgroundColor = .systemBackground
        self.constraintBotttomSalesOrderStatusToView.priority = .required
        self.constraintBottomViewProductNOrderDetails.priority = .required
        self.viewStatusComment.isHidden = true
        
        self.btnCallToFollowUp.corners(radius: 15.0)
        self.btnDeliveryStatus.corners(radius: 15.0)
        self.btnRequiredTechPerson.corners(radius: 15.0)
        self.btnDoneViewComment.corners(radius: 15.0)
        
        self.btnRequiredTechPerson.isHidden = true
        
        if self.isSampleOrderDetail {
            self.viewSampleButtons.isHidden = false
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.tvProductDetail.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        self.btnProducts.addShadow(offset: .zero, color: .black, radius: 5, opacity: 0.5)
        
        self.btnOrderDetails.backgroundColor = .clear
        self.btnOrderDetails.setTitleColor(Colors.gray.returnColor(), for: .normal)
        self.btnOrderDetails.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 16.0)
        
        self.ViewOrder.cornersWFullBorder(radius: 25, borderColor: UIColor(hexString: "#CFCFCF"), colorOpacity: 0.4)
        
        self.viewOrderDetails.isHidden = true
        self.constraintHeightTVProduct.priority = .required
        
        self.btnCallToFollowUp.backgroundColor = Colors.theme.returnColor()
        self.btnDeliveryStatus.backgroundColor = Colors.theme.returnColor()
        self.btnRequiredTechPerson.backgroundColor = Colors.theme.returnColor()
        
        if self.isSalesOrderDetail {
            //self.strScreenTitle = "Sales Order Details"
            self.strBtnName = "Order Details"
            self.btnOrderDetails.setTitle(strBtnName, for: .normal)
            self.lblSalesOrderNoTitle.text = "Sales Order Number"
            self.getSalesOrderDetail(orderId: self.intOrderId ?? 0)
        }
        else {
            //self.strScreenTitle = "Sample Order Details"
            self.strBtnName = "Sample Details"
            self.btnOrderDetails.setTitle(strBtnName, for: .normal)
            self.lblSalesOrderNoTitle.text = "Sample Order Number"
            self.getSampleOrderDetail(orderId: self.intOrderId ?? 0)
        }
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.tvProductDetail.removeObserver(self, forKeyPath: "contentSize")
    }
    
//    override func viewDidDisappear(_ animated: Bool) {
//        self.tvProductDetail.removeObserver(self, forKeyPath: "contentSize")
//    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                //self.constraintHeightTVProduct.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                self.constraintHeightTVProduct.constant = newsize.height
                self.updateViewConstraints()
            }
        }
    }
    
    func setDetail(bpOrderDetail: BPOrderDetail) {
        
        if self.isFromFollowUp {
            constraintBotttomSalesOrderStatusToView.priority = .defaultLow
            
            if APIManager.sharedManager.userId == bpOrderDetail.userID ?? 0 {
                if bpOrderDetail.isFollowup ?? 0 == 1 {
                    self.stackFollowUpButons.isHidden = true
                    self.btnRequiredTechPerson.isHidden = true
                    self.constraintBottomViewProductNOrderDetails.priority = .required
                }
                else if bpOrderDetail.deliveryStatus ?? "" == "YES" {
                    self.stackFollowUpButons.isHidden = true
                    self.btnRequiredTechPerson.isHidden = true
                    self.constraintBottomViewProductNOrderDetails.priority = .required
                    if (bpOrderDetail.orderStatus ?? 0 == 8) || (bpOrderDetail.orderStatus ?? 0 == 4) {
                        self.stackFollowUpButons.isHidden = true
                        self.btnRequiredTechPerson.isHidden = false
                        self.constraintBottomViewProductNOrderDetails.priority = .defaultLow
                    }
                }
                else {
                    self.stackFollowUpButons.isHidden = false
                    self.btnRequiredTechPerson.isHidden = true
                    self.constraintBottomViewProductNOrderDetails.priority = .defaultLow
                }
            }
        }
        
        self.strPhoneNumber = bpOrderDetail.contactPersonPhonePrimary ?? ""
        
        let basic: String = "\(bpOrderDetail.basicTotal ?? 0)".curFormatAsRegion()
        self.lblBasic.text = "₹\(basic)"
        
        let gst: String = "\(bpOrderDetail.gstTotal ?? 0)".curFormatAsRegion()
        self.lblGST.text = "₹\(gst)"
        
        let netAmount: String = "\(bpOrderDetail.grandTotalAmount ?? 0)".curFormatAsRegion()
        self.lblNetAmount.text = "₹\(netAmount)"
        
        self.lblSalesOrderNo.text = bpOrderDetail.orderCode ?? ""
        self.lblCode.text = bpOrderDetail.codeID ?? ""
        self.lblOrderDate.text = Utilities.convertStrDateToString(date: bpOrderDetail.orderDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy hh:mm a", NewDateFormate: "MMM dd, yyyy")
        self.lblDeliveryDate.text = Utilities.convertStrDateToString(date: bpOrderDetail.requiredDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "MMM dd, yyyy")
        
        self.lblDeliveryTo.text = bpOrderDetail.deliveryTo ?? ""
        self.lblStatus.text = OrderStatus.getStatusTitle(status: bpOrderDetail.orderStatus ?? 0)
        self.lblStatus.textColor = OrderStatus.getStatusColor(status: bpOrderDetail.orderStatus ?? 0)
        
        self.lblEmpName.text = "\((bpOrderDetail.userName ?? "") == "" ? "-" : bpOrderDetail.userName ?? "")"
        self.lblBillingLocation.text = "\((bpOrderDetail.billingLocation ?? "") == "" ? "-" : bpOrderDetail.billingLocation ?? "")"
        self.lblDeliveryOption.text = "\((bpOrderDetail.deliveryOption ?? "") == "" ? "-" : bpOrderDetail.deliveryOption ?? "")"
        self.lblDeliveryLocaation.text = "\((bpOrderDetail.deliveryLocation ?? "") == "" ? "-" : bpOrderDetail.deliveryLocation ?? "")"
        
        self.lblDeliveryType.text = "\((bpOrderDetail.orderDeliveryType ?? "") == "" ? "-" : bpOrderDetail.orderDeliveryType ?? "")"
        self.lblTransportName.text = "\((bpOrderDetail.transporterName ?? "") == "" ? "-" : bpOrderDetail.transporterName ?? "")"
        self.lblTransportGSTNo.text = "\((bpOrderDetail.transporterGSTNo ?? "") == "" ? "-" : bpOrderDetail.transporterGSTNo ?? "")"
        self.lblFreightCharges.text = "\((bpOrderDetail.freightCharges ?? "") == "" ? "-" : bpOrderDetail.freightCharges ?? "")"
        self.lblBookingPoint.text = "\((bpOrderDetail.bookingPoint ?? "") == "" ? "-" : bpOrderDetail.bookingPoint ?? "")"
        self.lblComments.text = "\((bpOrderDetail.comment ?? "") == "" ? "-" : bpOrderDetail.comment ?? "")"
        self.lblReferenceName.text = "\((bpOrderDetail.referenceEmployeeName ?? "") == "" ? "-" : bpOrderDetail.referenceEmployeeName ?? "")"
        self.lblPaymentType.text = PaymentTypes.getPaymentType(type: bpOrderDetail.paymentType ?? 0)
        
        self.constraintHeightTVProduct.constant = CGFloat((bpOrderDetail.products?.count ?? 0) * 541)
        self.constraintHeightTVProduct.priority = .defaultHigh
        self.constraintBottomOrderDetail.priority = .defaultLow
        
        self.tvProductDetail.reloadData()
        
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            self.btnEdit.isHidden = !self.editBtnVisible()
        }
    }
}
