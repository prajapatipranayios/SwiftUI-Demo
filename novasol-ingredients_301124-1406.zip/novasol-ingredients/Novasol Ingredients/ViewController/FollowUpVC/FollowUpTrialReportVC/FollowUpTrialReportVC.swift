//
//  FollowUpTrialReportVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 09/07/24.
//

import UIKit

class FollowUpTrialReportVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onCloseScreen != nil {
                self.onCloseScreen!(false, self.intProductIndex, self.isSubmitTrialReportYes ? "Yes" : "No")
            }
        }
    }
    
    @IBOutlet weak var viewScrollOut: UIView!
    @IBOutlet weak var constraintBottomViewScrollOutToSuper: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var viewScrollIn: UIView!
    
    @IBOutlet weak var viewSubmitTrialReport: UIView!
    @IBOutlet weak var btnYes: UIButton!
    @IBAction func btnYesTap(_ sender: UIButton) {
        self.isSubmitTrialReportYes = true
        self.btnYes.isSelected = true
        self.btnNo.isSelected = false
        
        self.constraintHeightViewUpload.priority = .defaultLow
    }
    @IBOutlet weak var btnNo: UIButton!
    @IBAction func btnNoTap(_ sender: UIButton) {
        self.isSubmitTrialReportYes = false
        self.btnYes.isSelected = false
        self.btnNo.isSelected = true
        
        self.constraintHeightViewUpload.priority = .required
    }
    
    
    @IBOutlet weak var cvUploadImg: UICollectionView! {
        didSet {
            self.cvUploadImg.delegate = self
            self.cvUploadImg.dataSource = self
            self.cvUploadImg.register(UINib(nibName: "AddOrderUploadImgCVCell", bundle: nil), forCellWithReuseIdentifier: "AddOrderUploadImgCVCell")
        }
    }
    @IBOutlet weak var constraintHeightCVUploadImg: NSLayoutConstraint!
    @IBOutlet weak var viewUpload: UIView!
    @IBOutlet weak var constraintHeightViewUpload: NSLayoutConstraint!
    @IBOutlet weak var lblUploadProductTrialReportTittle: UILabel!
    @IBOutlet weak var btnUpload: UIButton!
    @IBAction func btnUploadTap(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            print("Button capture")
            
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    @IBOutlet weak var viewMProductStatus: UIView!
    @IBOutlet weak var constraintHeightViewMProductStatus: NSLayoutConstraint!
    @IBOutlet weak var lblProductStatusTitle: UILabel!
    @IBOutlet weak var viewProductStatus: UIView!
    @IBOutlet weak var lblProductStatus: UILabel!
    @IBOutlet weak var btnProductStatus: UIButton!
    @IBAction func btnProductStatusTap(_ sender: UIButton) {
        
        if self.arrProductStatus?.count ?? 0 > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = Title.SelectProductStatus
            popupVC.value = self.arrProductStatus ?? []
            popupVC.selectedValue = self.lblProductStatus.text ?? "Select Product Status"
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { strValue in
                self.lblProductStatus.text = strValue
                
                self.intProductStatus = self.getProductStatus(value: strValue)
                
                if self.intProductStatus == 0 {
                    self.btnSave.setTitle("SAVE", for: .normal)
                }
                else {
                    self.btnSave.setTitle("SUBMIT REPORT", for: .normal)
                }
                
                if strValue == "Reject" {
                    self.constraintHeightTXTProductStatusReason.constant = 35
                }
                else {
                    self.constraintHeightTXTProductStatusReason.constant = 0
                }
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    
    @IBOutlet weak var txtProductStatusReason: UITextField!
    @IBOutlet weak var constraintHeightTXTProductStatusReason: NSLayoutConstraint!
    
    @IBOutlet weak var btnSave: UIButton!
    @IBAction func btnSaveTap(_ sender: UIButton) {
        
        self.dismissMyKeyboard()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            var isValid: Bool = true
            
            /*if self.lblProductStatus.text! == "Select Product Status" {
                isValid = false
                Utilities.showPopup(title: "Select product status.", type: .error)
            }
            else if self.lblProductStatus.text == "Reject" {
                if self.txtProductStatusReason.text! == "" {
                    isValid = false
                    Utilities.showPopup(title: "Enter reason.", type: .error)
                }
            }
            else {
                if self.isSubmitTrialReportYes {
                    if (self.arrUploadImg?.count ?? 0) > 0 {
                        for i in 0..<(self.arrUploadImg?.count ?? 0) {
                            if self.arrUploadImg?[i].comment == "" {
                                isValid = false
                                Utilities.showPopup(title: "Enter comment.", type: .error)
                                break
                            }
                        }
                    }
                    else {
                        isValid = false
                        Utilities.showPopup(title: "Upload image.", type: .error)
                    }
                }
            }   //  */
            var type: Int = 0
            var intTrailReportId: Int = 0
            if (self.bpOrderProduct?.trailReports?.count ?? 0) > 0 {
                intTrailReportId = self.bpOrderProduct?.trailReports?[0].id ?? 0
            }
            if self.lblProductStatus.text! != "Select Product Status" {
                type = 1
            }
            
            if self.lblProductStatus.text == "Reject" {
                if self.txtProductStatusReason.text! == "" {
                    isValid = false
                    Utilities.showPopup(title: "Enter reason.", type: .error)
                }
            }
            
            if isValid {
                print("Valid --> \(isValid)")
                
                self.submitTrailReport(type: type, trailReportId: intTrailReportId)
            }
            else {
                print("Valid --> \(isValid)")
            }
        }
    }
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Trial Report"
    //var bpOrderDetail: BPOrderDetail?
    var bpOrderProduct: ProductList?
    var onCloseScreen: ((Bool, Int, String)->Void)?
    var intProductIndex: Int = 0
    var strYesNo: String = "Yes"
    var isSubmitTrialReportYes: Bool = false
    var intProductId: Int? = 0
    var intProductStatus: Int = 0
    
    var arrProductStatus: [String]? = ["Select Product Status",         //  0
                                       "Approve(Quotation or PI)",      //  1
                                       "Win(Create sales order)",       //  2
                                       "Reject",                        //  3
                                       "WIP(work in process)"           //  4
    ]
    var imagePicker = UIImagePickerController()
    var arrImg: [String] = []
    var arrUploadImg: [ImgUpload]? = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.btnYes.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnYes.tintColor = Colors.theme.returnColor()
        self.btnNo.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnNo.tintColor = Colors.theme.returnColor()
        
        self.btnUpload.backgroundColor = Colors.theme.returnColor()
        self.btnSave.backgroundColor = Colors.theme.returnColor()
        
        self.btnUpload.corners(radius: 10.0)
        self.btnSave.corners(radius: 12.0)
        self.constraintHeightCVUploadImg.constant = 0
        
        if self.lblProductStatus.text ?? "" == "Reject" {
            self.constraintHeightTXTProductStatusReason.constant = 35
        }
        else {
            self.constraintHeightTXTProductStatusReason.constant = 0
        }
        
        self.intProductId = self.bpOrderProduct?.id ?? 0
        
        self.checkKeyboard(kView: self.viewMain)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if self.strYesNo == "Yes" {
            self.constraintHeightViewUpload.priority = .defaultLow
            self.isSubmitTrialReportYes = true
            self.btnYes.isSelected = true
            self.btnNo.isSelected = false
        }
        else if self.strYesNo == "No" {
            self.constraintHeightViewUpload.priority = .required
            self.isSubmitTrialReportYes = false
            self.btnYes.isSelected = false
            self.btnNo.isSelected = true
        }
    }
    
    func getProductStatus(value: String) -> Int {
        switch (value) {
        case "Approve(Quotation or PI)":
            return 1
        case "Win(Create sales order)":
            return 2
        case "Reject":
            return 3
        case "WIP(work in process)":
            return 4
        default:
            return 0
        }
    }
}
