//
//  FollowUpTrialReportVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 09/07/24.
//

import Foundation
import UIKit


// MARK: UICollectionView Delegate, DataSource, FlowLayout

extension FollowUpTrialReportVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrImg.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddOrderUploadImgCVCell", for: indexPath) as! AddOrderUploadImgCVCell
        
        cell.index = indexPath.item
        cell.ivUploadImg.setImage(imageUrl: self.arrUploadImg?[indexPath.item].img ?? "")
        
        cell.txtComment.tag = indexPath.item
        cell.txtComment.delegate = self
        
        cell.onDeleteTap = { index in
            self.arrImg.remove(at: index)
            self.arrUploadImg?.remove(at: index)
            
            if (self.arrUploadImg?.count ?? 0) <= 0 {
                self.constraintHeightCVUploadImg.constant = 0
            }
            self.cvUploadImg.reloadData()
            self.btnUpload.isHidden = false
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        //let width = (collectionView.frame.width - 40) / 3
        let height = 170.0
        return CGSize(width: 100.0, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
}


// MARK: - Selet Image

extension FollowUpTrialReportVC: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
//    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!){
//        self.dismiss(animated: true, completion: { () -> Void in
//
//        })
//        self.arrImg.append(image)
//        DispatchQueue.main.async {
//            self.cvUploadImg.reloadData()
//        }
//    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            // You now have the selected or captured image (pickedImage).
            // You can use it as needed within your app.
            
            self.imagePicker.dismiss(animated: true) {
                let checkUrl: String = String(describing: info[.referenceURL] ?? "")
                let imgUrl: String = String(describing: info[.imageURL] ?? "")
                if !self.arrImg.contains(checkUrl) {
                    self.arrImg.append(checkUrl)
                    let temp = ImgUpload(img: imgUrl, comment: "")
                    self.arrUploadImg?.append(temp)
                }
                else {
                    Utilities.showPopup(title: "Please select different image.", type: .error)
                }
                DispatchQueue.main.async {
                    if self.arrImg.count > 0 {
                        self.constraintHeightCVUploadImg.constant = 170
                    }
                    self.cvUploadImg.reloadData()
                    
                    if self.arrImg.count > 4 {
                        self.btnUpload.isHidden = true
                    }
                }
            }
        }
    }
}


// MARK: - TextField Delegate

extension FollowUpTrialReportVC: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
//        if textField.tag == 1 {
//            self.txtSelectAttachment.placeholder = ""
//        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
//        if textField == self.txtCustomFollowUpDays {
//            switch string {
//            case "0","1","2","3","4","5","6","7","8","9":
//                return true
//            case ".":
//                return false
//                
//                /*let array = (textField.text)!.map { String($0) }
//                 var decimalCount = 0
//                 for character in array {
//                 if character == "." {
//                 decimalCount += 1
//                 }
//                 }
//                 
//                 if decimalCount == 1 {
//                 return false
//                 } else {
//                 return true
//                 }   //  */
//            default:
//                let array = Array(string)
//                if array.count == 0 {
//                    return true
//                }
//                return false
//            }
//        }
//        else {
            return true
        //}
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        
        if textField == self.txtProductStatusReason {
            
        }
        else {
            let index = IndexPath(row: textField.tag, section: 0)
            //let cell = self.cvUploadImg.cellForRow(at: index) as! AddOrderUploadImgCVCell
            let cell = self.cvUploadImg.cellForItem(at: index) as! AddOrderUploadImgCVCell
            self.arrUploadImg?[textField.tag].comment = cell.txtComment.text ?? ""
        }
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
        }
        return value
    }
}

// MARK: - Keyboard

extension FollowUpTrialReportVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            self.constraintBottomViewScrollOutToSuper.constant = keyboardOverlap > 0 ? (keyboardOverlap - 0) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}


// MARK: - Web Services

extension FollowUpTrialReportVC {
    
    func submitTrailReport(type: Int, trailReportId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.submitTrailReport(type: type, trailReportId: trailReportId)
                }
            }
            return
        }
        
        let param = [ "user_id": APIManager.sharedManager.userId,
                      "order_id": self.bpOrderProduct?.ordersID ?? 0,
                      "order_product_id": self.bpOrderProduct?.id ?? 0,
                      "is_trail": self.isSubmitTrialReportYes ? 1 : 0,
                      "reason": self.txtProductStatusReason.text ?? "",
                      "status": self.intProductStatus,
                      "type": type,
                      "trail_report_id": trailReportId
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.SUBMIT_TRAIL_REPORT, parameters: param) { (response: ApiResponseFollowUp?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    if self.arrImg.count > 0 {
                        self.showLoadingWMsg(strMsg: "Uploading image...")
                        self.uploadImage(reportId: response?.result?.trailReportId ?? 0, strMessage: response?.message ?? "")
                    }
                    else {
                        self.popupWImg(message: response?.message ?? "")
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func uploadImage(reportId: Int, index: Int = 0, strMessage: String) {
        var imgFileName: String = ""
        imgFileName = imgFileName == "" ? (URL(string: (self.arrUploadImg?[index].img ?? ""))?.lastPathComponent)! : imgFileName
        imgFileName = imgFileName != "" ? imgFileName : "\(Utilities.fileName()).png"
        var ivUploadImg = UIImageView()
        ivUploadImg.setImage(imageUrl: self.arrUploadImg?[index].img ?? "")
        
        //showLoading()
        APIManager.sharedManager.uploadImage(url: APIManager.sharedManager.UPLOAD_REPORT_ATTACHMENT,
                                             dictiParam: [ "user_id": APIManager.sharedManager.userId,
                                                           "trail_report_id": reportId,
                                                           "caption": self.arrUploadImg?[index].comment ?? "",
                                                           "image": imgFileName
                                                         ],
                                             image: ivUploadImg.image as Any,
                                             type: "image",
                                             contentType: imgFileName.mimeType())
        { isValid, strValue in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                //self.hideLoading()
                if ((self.arrUploadImg?.count ?? 0) - 1) > index {
                    let i = index + 1
                    self.uploadImage(reportId: reportId, index: i, strMessage: strMessage)
                }
                else {
                    DispatchQueue.main.async {
                        self.hideLoadingWMsg()
                        self.popupWImg(message: strMessage)
                    }
                }
            }
        } errorCompletion: { isValid, strValue in
            print("Close with error")
            self.hideLoadingWMsg()
            //self.hideLoading()
        }
    }
    
    func popupWImg(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            //APIManager.sharedManager.isRefreshData = true
            self.dismiss(animated: true) {
                if self.onCloseScreen != nil {
                    self.onCloseScreen!(true, self.intProductIndex, "")
                }
            }
        }
        self.present(popupVC, animated: true)
    }
}
