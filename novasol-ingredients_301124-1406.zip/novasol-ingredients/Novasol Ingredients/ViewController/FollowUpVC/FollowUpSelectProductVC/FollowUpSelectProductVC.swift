//
//  FollowUpSelectProductVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 08/07/24.
//

import UIKit

class FollowUpSelectProductVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onCloseScreen != nil {
                self.onCloseScreen!(false, "")
            }
        }
    }
    
    @IBOutlet weak var viewTVProducts: UIView!
    @IBOutlet weak var tvProducts: UITableView! {
        didSet {
            self.tvProducts.delegate = self
            self.tvProducts.dataSource = self
            self.tvProducts.register(UINib(nibName: "FollowUpSelectProductTVCell", bundle: nil), forCellReuseIdentifier: "FollowUpSelectProductTVCell")
        }
    }
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "SELECT PRODUCTS"
    var bpOrderDetail: BPOrderDetail?
    //var arrBPOrderProduct: [BPOrderProduct]? = []
    var arrBPOrderProduct: [ProductList]? = []
    var strBtnName: String? = "Order Details"
    var onCloseScreen: ((Bool, String)->Void)?
    
    var isFromFollowUp: Bool = false
    var arrProductYesNo: [String] = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = self.strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.getSampleReportsDetail(orderId: self.bpOrderDetail?.id ?? 0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
}
