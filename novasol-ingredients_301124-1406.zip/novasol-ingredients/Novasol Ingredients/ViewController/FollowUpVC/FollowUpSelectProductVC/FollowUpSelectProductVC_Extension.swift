//
//  FollowUpSelectProductVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 08/07/24.
//

import Foundation
import UIKit


// MARK: - TableView DataSource, Delegate

extension FollowUpSelectProductVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrBPOrderProduct?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FollowUpSelectProductTVCell", for: indexPath) as! FollowUpSelectProductTVCell
        
        cell.index = indexPath.row
        cell.lblProductName.text = self.arrBPOrderProduct?[indexPath.row].productName ?? ""
        
        /*if (self.arrBPOrderProduct?[indexPath.row].trailReports?.count ?? 0) > 0 {
            if (self.arrBPOrderProduct?[indexPath.row].trailReports?[0].isTrail ?? 0) == 1 {
                cell.btnYes.isSelected = true
                cell.btnNo.isSelected = false
            }
            else if (self.arrBPOrderProduct?[indexPath.row].trailReports?[0].isTrail ?? 0) == 0 {
                cell.btnYes.isSelected = false
                cell.btnNo.isSelected = true
            }
            else {
                cell.btnYes.isSelected = false
                cell.btnNo.isSelected = false
            }
        }   //  */
        
        cell.btnYes.isSelected = false
        cell.btnNo.isSelected = false
        
        if self.arrProductYesNo[indexPath.row] == "Yes" {
            cell.btnYes.isSelected = true
            cell.btnNo.isSelected = false
        }
        else if self.arrProductYesNo[indexPath.row] == "No" {
            cell.btnYes.isSelected = false
            cell.btnNo.isSelected = true
        }
        
        cell.onYesNoTap = { isYes, index in
            if isYes {
                if self.arrProductYesNo[index] != "Yes" {
                    //self.arrProductYesNo[index] = "Yes"
                    self.openTrialReport(index: index, value: "Yes")
                }
            }
            else {
                if self.arrProductYesNo[index] != "No" {
                    //self.arrProductYesNo[index] = "No"
                    self.openTrialReport(index: index, value: "No")
                }
            }
            self.tvProducts.reloadData()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.arrProductYesNo[indexPath.row] != "" {
            print("Open page to trial report")
            self.openTrialReport(index: indexPath.row, value: self.arrProductYesNo[indexPath.row])
        }
    }
    
    func openTrialReport(index: Int, value: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "FollowUpTrialReportVC") as! FollowUpTrialReportVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strScreenTitle = "Trial Report"
        popupVC.bpOrderProduct = self.arrBPOrderProduct?[index]
        popupVC.intProductIndex = index
        popupVC.strYesNo = value
        popupVC.onCloseScreen = { isValid, intProductIndex, strValue in
            if isValid {
                //self.arrProductYesNo[intProductIndex] = strValue
                //self.tvProducts.reloadData()
                self.dismiss(animated: false) {
                    if self.onCloseScreen != nil {
                        self.onCloseScreen!(true, "")
                    }
                }
            }
        }
        self.present(popupVC, animated: true)
    }
}


// MARK: - Web Services

extension FollowUpSelectProductVC {
    
    func getSampleReportsDetail(orderId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getSampleReportsDetail(orderId: orderId)
                }
            }
            return
        }
        
        let param = [ "user_id": APIManager.sharedManager.userId,
                      "order_id": orderId
        ] as [String : Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_SAMPLE_REPORTS_DETAILS, parameters: param) { (response: ApiResponseFollowUp?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrBPOrderProduct = response?.result?.trailReport?.products ?? []
                    
                    for i in 0..<(self.arrBPOrderProduct?.count ?? 0) {
                        if (self.arrBPOrderProduct?[i].trailReports?.count ?? 0) > 0 {
                            if self.arrBPOrderProduct?[i].trailReports?[0].isTrail ?? 0 == 1 {
                                self.arrProductYesNo.append("Yes")
                            }
                            else if self.arrBPOrderProduct?[i].trailReports?[0].isTrail ?? 0 == 0 {
                                self.arrProductYesNo.append("No")
                            }
                            else {
                                self.arrProductYesNo.append("")
                            }
                        }
                        else {
                            self.arrProductYesNo.append("")
                        }
                    }
                    self.arrBPOrderProduct
                    
                    self.tvProducts.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
