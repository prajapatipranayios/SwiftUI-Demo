//
//  FollowUpSelectProductTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 08/07/24.
//

import UIKit

class FollowUpSelectProductTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var btnYes: UIButton!
    @IBAction func btnYesTap(_ sender: UIButton) {
        if self.onYesNoTap != nil {
            self.onYesNoTap?(true, index)
        }
    }
    @IBOutlet weak var btnNo: UIButton!
    @IBAction func btnNoTap(_ sender: UIButton) {
        if self.onYesNoTap != nil {
            self.onYesNoTap?(false, index)
        }
    }
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onYesNoTap: ((Bool, Int)->Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.btnYes.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnYes.tintColor = Colors.theme.returnColor()
        self.btnNo.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnNo.tintColor = Colors.theme.returnColor()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
