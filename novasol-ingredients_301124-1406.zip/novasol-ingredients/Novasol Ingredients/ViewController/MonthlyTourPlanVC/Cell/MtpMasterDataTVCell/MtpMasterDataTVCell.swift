//
//  MtpMasterDataTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 30/07/24.
//

import UIKit

class MtpMasterDataTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewDetails: UIView!
    
    @IBOutlet weak var lblDateTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var viewCity: UIView!
    @IBOutlet weak var lblCityTitle: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var constraintHeightViewCity: NSLayoutConstraint!
    
    @IBOutlet weak var viewJointWorkingWith: UIView!
    @IBOutlet weak var lblJointWorkingWithTitle: UILabel!
    @IBOutlet weak var lblJointWorkingWith: UILabel!
    @IBOutlet weak var constraintHeightViewJointWorkingWith: NSLayoutConstraint!
    
    @IBOutlet weak var viewRejectReason: UIView!
    @IBOutlet weak var lblRejectReasonTitle: UILabel!
    @IBOutlet weak var lblRejectReason: UILabel!
    @IBOutlet weak var constraintHeightViewRejectReason: NSLayoutConstraint!
    
    @IBOutlet weak var viewReply: UIView!
    @IBOutlet weak var lblReplyTitle: UILabel!
    @IBOutlet weak var lblReply: UILabel!
    @IBOutlet weak var constraintHeightViewReply: NSLayoutConstraint!
    
    @IBOutlet weak var viewLeave: UIView!
    @IBOutlet weak var lblLeaveTitle: UILabel!
    @IBOutlet weak var lblLeave: UILabel!
    @IBOutlet weak var constraintHeightViewLeave: NSLayoutConstraint!
    
    @IBOutlet weak var viewEstimatedCost: UIView!
    @IBOutlet weak var lblEstimatedCostTitle: UILabel!
    @IBOutlet weak var lblEstimatedCost: UILabel!
    @IBOutlet weak var constraintHeightViewEstimatedCost: NSLayoutConstraint!
    
    @IBOutlet weak var viewButton: UIView!
    @IBOutlet weak var constraintHeightViewButton: NSLayoutConstraint!
    
    @IBOutlet weak var btnEdit: UIButton!
    @IBAction func btnEditTap(_ sender: UIButton) {
        if self.onEditTap != nil {
            self.onEditTap!(index)
        }
    }
    
    @IBOutlet weak var btnReply: UIButton!
    @IBAction func btnReplyTap(_ sender: UIButton) {
        if self.onReplyTap != nil {
            self.onReplyTap!(index)
        }
    }
    @IBOutlet weak var constraintTrailingBtnReplyToSuper: NSLayoutConstraint!
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var onEditTap:((Int)->Void)?
    var onReplyTap:((Int)->Void)?
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewDetails.corners(radius: 12.0)
        self.viewButton.corners([.bottomLeft, .bottomRight], radius: 12.0)
        
        self.lblEstimatedCostTitle.textColor = Colors.theme.returnColor()
        self.lblEstimatedCost.textColor = Colors.theme.returnColor()
        
        self.btnEdit.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnEdit.cornersWFullBorder(radius: 5, borderColor: .black, colorOpacity: 0.8)
        
        self.btnReply.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnReply.cornersWFullBorder(radius: 5, borderColor: .black, colorOpacity: 0.8)
        
        self.lblCityTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        
        self.viewJointWorkingWith.addBorders(edges: [.top], color: Colors.theme.returnColor())
        self.lblJointWorkingWithTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        
        self.viewRejectReason.addBorders(edges: [.top], color: Colors.theme.returnColor())
        self.lblRejectReasonTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        
        self.viewReply.addBorders(edges: [.top], color: Colors.theme.returnColor())
        self.lblReplyTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        
        self.viewLeave.addBorders(edges: [.top], color: Colors.theme.returnColor())
        self.lblLeaveTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        
        self.viewEstimatedCost.addBorders(edges: [.top, .bottom], color: Colors.theme.returnColor())
        self.lblEstimatedCostTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
