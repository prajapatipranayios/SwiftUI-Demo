//
//  EmpMTPTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/07/24.
//

import UIKit

class EmpMTPTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblEmpName: UILabel!
    
    @IBOutlet weak var viewMTPDate: UIView!
    @IBOutlet weak var lblMTPDate: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewMain.addShadow(offset: .zero, color: .black, radius: 1.5, opacity: 0.4)
        
        self.lblEmpName.textColor = Colors.theme.returnColor()
        self.lblStatus.textColor = Colors.themeRed.returnColor()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
