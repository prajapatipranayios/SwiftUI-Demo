//
//  MTPFilterZoneEmpTHView.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/08/24.
//

import UIKit

class MTPFilterZoneEmpTHView: UITableViewHeaderFooterView {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblZone: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!

}
