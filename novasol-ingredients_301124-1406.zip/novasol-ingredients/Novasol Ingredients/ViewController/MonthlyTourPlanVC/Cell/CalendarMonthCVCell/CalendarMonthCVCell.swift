//
//  CalendarMonthCVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/07/24.
//

import UIKit

class CalendarMonthCVCell: UICollectionViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewDate: UIView!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var viewEmpName: UIView!
    
    @IBOutlet weak var viewEmp1: UIView!
    @IBOutlet weak var lblEmp1: UILabel!
    @IBOutlet weak var btnEmp1: UIButton!
    @IBAction func btnEmp1Tap(_ sender: UIButton) { }
    
    @IBOutlet weak var viewEmp2: UIView!
    @IBOutlet weak var lblEmp2: UILabel!
    @IBOutlet weak var btnEmp2: UIButton!
    @IBAction func btnEmp2Tap(_ sender: UIButton) { }
    
    @IBOutlet weak var viewEmp3: UIView!
    @IBOutlet weak var lblEmp3: UILabel!
    @IBOutlet weak var btnEmp3: UIButton!
    @IBAction func btnEmp3Tap(_ sender: UIButton) { }
    
    @IBOutlet weak var btnCell: UIButton!
    @IBAction func btnCellTap(_ sender: UIButton) {
        if self.onCellTap != nil { self.onCellTap!(index) }
    }
    
    // MARK: - Variable
    
    var index: Int = 0
    var onCellTap: ((Int)->Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.viewDate.addBorders(edges: [.right], color: .white)
        
        self.viewEmpName.addBorders(edges: [.right, .bottom], color: Colors.theme.returnColor())
        
        self.btnCell.isHidden = true
        
        self.btnEmp1.isHidden = true
        self.btnEmp2.isHidden = true
        self.btnEmp3.isHidden = true
    }

}
