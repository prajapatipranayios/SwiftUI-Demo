//
//  EmpMTPDataFilerMonthTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/08/24.
//

import UIKit

class EmpMTPDataFilerMonthTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMainBorder: UIView!
    @IBOutlet weak var viewZoneEmp: UIView!
    
    @IBOutlet weak var lblMonth: UILabel!
    @IBOutlet weak var lblMonthTotal: UILabel!
    
    @IBOutlet weak var tvZoneEmp: UITableView! {
        didSet {
            self.tvZoneEmp.delegate = self
            self.tvZoneEmp.dataSource = self
            self.tvZoneEmp.register(UINib(nibName: "MTPFilterZoneEmpTVCell", bundle: nil), forCellReuseIdentifier: "MTPFilterZoneEmpTVCell")
            self.tvZoneEmp.register(UINib(nibName: "MTPFilterZoneEmpTHView", bundle: nil), forHeaderFooterViewReuseIdentifier: "MTPFilterZoneEmpTHView")
            
            if #available(iOS 15.0, *) {
                self.tvZoneEmp.sectionHeaderTopPadding = 0
            } else {
                // Fallback on earlier versions
            }
        }
    }
    @IBOutlet weak var constraintHeightViewZoneEmp: NSLayoutConstraint!
    
    // MARK: - Variable
    
    var index: Int = 0
    var arrZone: [Zone]? {
        didSet {
            var headerEmpCellHeight = 0
            for i in 0..<(self.arrZone?.count ?? 0) {
                headerEmpCellHeight += 45
                for _ in 0..<(self.arrZone?[i].employee?.count ?? 0) {
                    headerEmpCellHeight += 45
                }
            }
            
            self.constraintHeightViewZoneEmp.constant = CGFloat(headerEmpCellHeight > 45 ? headerEmpCellHeight + 8 : headerEmpCellHeight)
            self.tvZoneEmp.reloadData()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.viewMainBorder.corners(radius: 7.0)
        self.viewMainBorder.addShadow(offset: .zero, color: .black, radius: 2, opacity: 0.3)
        self.viewZoneEmp.corners([.bottomLeft, .bottomRight], radius: 7.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}

// MARK: - UITableView Delegate, Datasourse

extension EmpMTPDataFilerMonthTVCell: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.arrZone?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "MTPFilterZoneEmpTHView") as! MTPFilterZoneEmpTHView
        //headerView.viewMain.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
        headerView.lblZone.text = self.arrZone?[section].zoneName ?? ""
        headerView.lblAmount.text = "₹" + "\(self.arrZone?[section].zoneTotal ?? 0.0)".curFormatAsRegion()
        headerView.lblAmount.textColor = Colors.theme.returnColor()
        headerView.lblSeparator.backgroundColor = Colors.theme.returnColor()
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 45
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrZone?[section].employee?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //var cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        //if( !(cell != nil)) { cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "Cell") }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MTPFilterZoneEmpTVCell", for: indexPath) as! MTPFilterZoneEmpTVCell
        
        cell.lblEmpName?.text = self.arrZone?[indexPath.section].employee?[indexPath.row].fullname ?? ""
        cell.lblAmount.text = "₹" + "\(self.arrZone?[indexPath.section].employee?[indexPath.row].estimatedCost ?? 0.0)".curFormatAsRegion()
        cell.lblSeparator.isHidden = true
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //return UITableView.automaticDimension
        return 45
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}
