//
//  MTPFilterZoneEmpTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/08/24.
//

import UIKit

class MTPFilterZoneEmpTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.lblSeparator.backgroundColor = Colors.gray.returnColor()   
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
