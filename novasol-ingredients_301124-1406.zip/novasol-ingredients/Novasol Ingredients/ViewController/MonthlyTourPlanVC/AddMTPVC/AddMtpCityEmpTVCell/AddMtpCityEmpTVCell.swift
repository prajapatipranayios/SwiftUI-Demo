//
//  AddMtpCityEmpTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 09/08/24.
//

import UIKit

class AddMtpCityEmpTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBorder: UIView!
    @IBOutlet weak var lblValue: UILabel!
    @IBOutlet weak var btnDelete: UIButton!
    @IBAction func btnDeleteTap(_ sender: UIButton) {
        if self.didSelect != nil {
            self.didSelect!(index)
        }
    }
    
    // MARK: - Variable
    
    var index: Int = 0
    var didSelect: ((Int)->Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.viewBorder.cornersWFullBorder(radius: 4, borderColor: .black, colorOpacity: 1.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
