//
//  MTPEmpListVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/07/24.
//

import UIKit
import Fastis
import SearchTextField

class AddMTPVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var btnDone: UIButton!
    @IBAction func btnDoneTap(_ sender: UIButton) {
        var isValid = true
        var strMsg: String = ""
        
        if !self.isDateSelect {
            isValid = false
            strMsg = "Please select start-end date"
        }
        else if (!self.isCitySelect) && ((self.arrSelectedCity?.count ?? 0) == 0) && (self.txtCity.text == "") && (!self.isLeaveFDay) {
            //if !self.isLeaveFDay {
                if self.txtCity.text != "" {
                    self.arrSelectedCity?.append(self.txtCity.text ?? "")
                    self.txtCity.text = ""
                    
                    self.constraintHeightTVCity.constant = CGFloat((self.arrSelectedCity?.count ?? 0) * 37)
                    self.tvCity.reloadData()
                }
                else {
                    isValid = false
                    strMsg = "Please select city"
                }
            //}
        }
        else if ((self.txtEstimatedCost.text ?? "") == "") && (!self.isForLeave) {
            isValid = false
            strMsg = "Please enter estimated cost"
        }
        else if self.isLeaveFDay {
            if self.txtRemarks.text ?? "" == "" {
                isValid = false
                strMsg = "Please enter remark"
            }
        }
        
        if self.txtCity.text != "" {
            self.arrSelectedCity?.append(self.txtCity.text ?? "")
            self.txtCity.text = ""
            self.isCitySelect = true
            self.constraintHeightTVCity.constant = CGFloat((self.arrSelectedCity?.count ?? 0) * 37)
            self.tvCity.reloadData()
        }
        
        if self.lblEmpName.text != "Select Employee Name" {
            if self.lblEmpName.text != "Other" {
                if !(self.arrSelectedEmp ?? []).contains(self.lblEmpName.text ?? "") {
                    self.arrSelectedEmp?.append(self.lblEmpName.text ?? "")
                    self.lblEmpName.text = "Select Employee Name"
                    
                    self.constraintHeightTVEmp.constant = CGFloat((self.arrSelectedEmp?.count ?? 0) * 37)
                    self.tvEmp.reloadData()
                }
                else {
                    self.lblEmpName.text = "Select Employee Name"
                    Utilities.showPopup(title: "Employee already added", type: .error)
                }
            }
            else {
                if self.txtOtherEmpName.text == "" {
                    Utilities.showPopup(title: "Please enter employee name", type: .error)
                }
                else {
                    if !(self.arrSelectedEmp ?? []).contains(self.txtOtherEmpName.text ?? "") {
                        self.arrSelectedEmp?.append(self.txtOtherEmpName.text ?? "")
                        self.txtOtherEmpName.text = ""
                        self.lblEmpName.text = "Select Employee Name"
                        
                        self.constraintHeightAddOtherEmp.priority = .required
                        
                        self.constraintHeightTVEmp.constant = CGFloat((self.arrSelectedEmp?.count ?? 0) * 37)
                        self.tvEmp.reloadData()
                    }
                    else {
                        Utilities.showPopup(title: "Employee already added", type: .error)
                    }
                }
            }
        }
        
        if isValid {
            if self.isForLeave {
                if self.isLeaveFDay || self.isLeaveHDay {
                    if !self.isFromEdit {
                        self.addMTP(startDate: self.strSelectedStartDate,
                                    endDate: self.strSelectedEndDate,
                                    intLeave: self.isForLeave ? 1 : 0,
                                    intWorkingFromHome: 0,
                                    leaveType: self.isLeaveFDay ? "Full Day" : "Half Day",
                                    arrCity: self.isLeaveFDay ? [] : (self.arrSelectedCity ?? []),
                                    arrWithWhooms: self.isLeaveFDay ? [] : (self.arrSelectedEmp ?? []),
                                    objectives: self.isLeaveFDay ? "" : (self.txtObjectives.text ?? ""),
                                    estimatedCost: self.isLeaveFDay ? 0 : (Int(self.txtEstimatedCost.text ?? "0") ?? 0),
                                    remark: self.txtRemarks.text ?? "")
                    }
                    else {
                        self.updateMTP(mtpId: self.intMtpId, startDate: self.strSelectedStartDate,
                                    endDate: self.strSelectedEndDate,
                                    intLeave: self.isForLeave ? 1 : 0,
                                    intWorkingFromHome: 0,
                                    leaveType: self.isLeaveFDay ? "Full Day" : "Half Day",
                                    arrCity: self.isLeaveFDay ? [] : (self.arrSelectedCity ?? []),
                                    arrWithWhooms: self.isLeaveFDay ? [] : (self.arrSelectedEmp ?? []),
                                    objectives: self.isLeaveFDay ? "" : (self.txtObjectives.text ?? ""),
                                    estimatedCost: self.isLeaveFDay ? 0 : (Int(self.txtEstimatedCost.text ?? "0") ?? 0),
                                    remark: self.txtRemarks.text ?? "")
                    }
                }
            }
            else if self.isWFH {
                if !self.isFromEdit {
                    self.addMTP(startDate: self.strSelectedStartDate,
                                endDate: self.strSelectedEndDate,
                                intLeave: self.isForLeave ? 1 : 0,
                                intWorkingFromHome: self.isWFH ? 1 : 0,
                                leaveType: "",
                                arrCity: self.arrSelectedCity ?? [],
                                arrWithWhooms: [],
                                objectives: self.txtObjectives.text ?? "",
                                estimatedCost: Int(self.txtEstimatedCost.text ?? "0") ?? 0,
                                remark: self.txtRemarks.text ?? "")
                }
                else {
                    self.updateMTP(mtpId: self.intMtpId,
                                   startDate: self.strSelectedStartDate,
                                   endDate: self.strSelectedEndDate,
                                   intLeave: self.isForLeave ? 1 : 0,
                                   intWorkingFromHome: self.isWFH ? 1 : 0,
                                   leaveType: "",
                                   arrCity: self.arrSelectedCity ?? [],
                                   arrWithWhooms: [],
                                   objectives: self.txtObjectives.text ?? "",
                                   estimatedCost: Int(self.txtEstimatedCost.text ?? "0") ?? 0,
                                   remark: self.txtRemarks.text ?? "")
                }
            }
            else {
                if !self.isFromEdit {
                    self.addMTP(startDate: self.strSelectedStartDate,
                                endDate: self.strSelectedEndDate,
                                intLeave: 0,
                                intWorkingFromHome: 0,
                                leaveType: "",
                                arrCity: self.arrSelectedCity ?? [],
                                arrWithWhooms: self.arrSelectedEmp ?? [],
                                objectives: self.txtObjectives.text ?? "",
                                estimatedCost: Int(self.txtEstimatedCost.text ?? "0") ?? 0,
                                remark: self.txtRemarks.text ?? "")
                }
                else {
                    self.updateMTP(mtpId: self.intMtpId,
                                   startDate: self.strSelectedStartDate,
                                   endDate: self.strSelectedEndDate,
                                   intLeave: 0,
                                   intWorkingFromHome: 0,
                                   leaveType: "",
                                   arrCity: self.arrSelectedCity ?? [],
                                   arrWithWhooms: self.arrSelectedEmp ?? [],
                                   objectives: self.txtObjectives.text ?? "",
                                   estimatedCost: Int(self.txtEstimatedCost.text ?? "0") ?? 0,
                                   remark: self.txtRemarks.text ?? "")
                }
            }
        }
        else {
            Utilities.showPopup(title: strMsg, type: .error)
        }   ///  */
    }
    
    @IBOutlet weak var viewSelectDate: UIView!
    @IBOutlet weak var lblMTPStartDate: UILabel!
    @IBOutlet weak var lblMTPEndDate: UILabel!
    @IBOutlet weak var btnSelectMTPDates: UIButton!
    @IBAction func btnSelectMTPDatesTap(_ sender: UIButton) {
        self.selectMtpDate()
    }
    
    @IBOutlet weak var viewScrollOut: UIView!
    @IBOutlet weak var constraintBottomViewScrollOutToSuper: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var viewScrollIn: UIView!
    
    /// View Leave WFH
    
    @IBOutlet weak var viewLeaveWFH: UIView!
    @IBOutlet weak var btnApplyForLeave: UIButton!
    @IBAction func btnApplyForLeaveTap(_ sender: UIButton) {
        self.isForLeave = !self.isForLeave
        self.btnApplyForLeave.isSelected = self.isForLeave
        self.btnApplyForLeave.tintColor = self.isForLeave ? Colors.theme.returnColor() : Colors.gray.returnColor()
        self.constraintBottomBtnApplyForLeaveToSuper.priority = self.isForLeave ? .required : .defaultLow
        
        if self.isForLeave && !self.isFromEdit {
            self.btnLeaveFDayTap(UIButton())
        }
        
        self.isWFH = false
        self.btnWFH.isSelected = self.isWFH
        self.btnWFH.tintColor = Colors.gray.returnColor()
        
        self.setPageView()
    }
    @IBOutlet weak var constraintBottomBtnApplyForLeaveToSuper: NSLayoutConstraint!
    
    @IBOutlet weak var btnWFH: UIButton!
    @IBAction func btnWFHTap(_ sender: UIButton) {
        self.isWFH = !self.isWFH
        self.btnWFH.isSelected = self.isWFH
        self.btnWFH.tintColor = self.isWFH ? Colors.theme.returnColor() : Colors.gray.returnColor()
        
        self.isForLeave = false
        self.btnApplyForLeave.isSelected = self.isForLeave
        self.btnApplyForLeave.tintColor = Colors.gray.returnColor()
        
        self.setPageView()
    }
    
    
    /// View Leave Type
    
    @IBOutlet weak var viewLeaveType: UIView!
    @IBOutlet weak var constraintHeightViewLeaveType: NSLayoutConstraint!
    
    @IBOutlet weak var lblLeaveTypeTitle: UILabel!
    @IBOutlet weak var btnLeaveFDay: UIButton!
    @IBAction func btnLeaveFDayTap(_ sender: UIButton) {
        self.isLeaveFDay = !self.isLeaveFDay
        self.btnLeaveFDay.isSelected = self.isLeaveFDay
        self.btnLeaveFDay.tintColor = self.isLeaveFDay ? Colors.theme.returnColor() : Colors.gray.returnColor()
        
        self.isLeaveHDay = false
        self.btnLeaveHDay.isSelected = self.isLeaveHDay
        self.btnLeaveHDay.tintColor = Colors.gray.returnColor()
        
        self.setPageView()
    }
    
    @IBOutlet weak var btnLeaveHDay: UIButton!
    @IBAction func btnLeaveHDayTap(_ sender: UIButton) {
        self.isLeaveHDay = !self.isLeaveHDay
        self.btnLeaveHDay.isSelected = self.isLeaveHDay
        self.btnLeaveHDay.tintColor = self.isLeaveHDay ? Colors.theme.returnColor() : Colors.gray.returnColor()
        
        self.isLeaveFDay = false
        self.btnLeaveFDay.isSelected = self.isLeaveFDay
        self.btnLeaveFDay.tintColor = Colors.gray.returnColor()
        
        self.setPageView()
    }
    
    
    /// View Add City
    
    @IBOutlet weak var viewAddCity: UIView!
    @IBOutlet weak var constraintHeightViewAddCity: NSLayoutConstraint!
    //@IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtCity: SearchTextField!
    
    @IBOutlet weak var btnAddCity: UIButton!
    @IBAction func btnAddCityTap(_ sender: UIButton) {
        if self.txtCity.text != "" {
            if !(self.arrSelectedCity ?? []).contains(self.txtCity.text ?? "") {
                self.arrSelectedCity?.append(self.txtCity.text ?? "")
                self.txtCity.text = ""
                
                self.constraintHeightTVCity.constant = CGFloat((self.arrSelectedCity?.count ?? 0) * 37)
                self.tvCity.reloadData()
                
                self.txtCity.filteredResults.removeAll()
                self.txtCity.tableView?.removeFromSuperview()
            }
            else {
                self.txtCity.text = ""
                Utilities.showPopup(title: "City already added", type: .error)
            }
        }
        else {
            Utilities.showPopup(title: "Enter city name", type: .error)
        }
    }
    @IBOutlet weak var tvCity: UITableView! {
        didSet {
            self.tvCity.delegate = self
            self.tvCity.dataSource = self
            self.tvCity.register(UINib(nibName: "AddMtpCityEmpTVCell", bundle: nil), forCellReuseIdentifier: "AddMtpCityEmpTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVCity: NSLayoutConstraint!
    
    
    /// Joint Working With
    
    @IBOutlet weak var viewJointWorkingWith: UIView!
    @IBOutlet weak var constraintHeightViewJointWorkingWith: NSLayoutConstraint!
    @IBOutlet weak var lblJointWorkingWithTitle: UILabel!
    
    @IBOutlet weak var viewSelectEmp: UIView!
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var btnSelectEmpName: UIButton!
    @IBAction func btnSelectEmpNameTap(_ sender: UIButton) {
        
        if (self.arrEmployee?.count ?? 0) > 0 {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
            popupVC.titleTxt = "Employee"
            popupVC.value = self.arrEmployee ?? []
            popupVC.selectedValue = self.lblEmpName.text ?? ""
            popupVC.isSearchActive = true
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.didSelectItem = { name in
                self.lblEmpName.text = name
                if name == "Other" {
                    self.constraintHeightAddOtherEmp.priority = .defaultLow
                }
                else {
                    self.constraintHeightAddOtherEmp.priority = .required
                }
            }
            popupVC.onClose = { name in
                print("Dialog close.")
            }
            self.present(popupVC, animated: true)
        }
    }
    
    @IBOutlet weak var viewAddOtherEmp: UIView!
    @IBOutlet weak var constraintHeightAddOtherEmp: NSLayoutConstraint!
    @IBOutlet weak var txtOtherEmpName: UITextField!
    @IBOutlet weak var txtOtherCompanyName: UITextField!
    @IBOutlet weak var btnAddPerson: UIButton!
    @IBAction func btnAddPersonTap(_ sender: UIButton) {
        if self.lblEmpName.text != "Select Employee Name" {
            if self.lblEmpName.text != "Other" {
                if !(self.arrSelectedEmp ?? []).contains(self.lblEmpName.text ?? "") {
                    self.arrSelectedEmp?.append(self.lblEmpName.text ?? "")
                    self.lblEmpName.text = "Select Employee Name"
                    
                    self.constraintHeightTVEmp.constant = CGFloat((self.arrSelectedEmp?.count ?? 0) * 37)
                    self.tvEmp.reloadData()
                }
                else {
                    self.lblEmpName.text = "Select Employee Name"
                    Utilities.showPopup(title: "Employee already added", type: .error)
                }
            }
            else {
                if self.txtOtherEmpName.text == "" {
                    Utilities.showPopup(title: "Please enter employee name", type: .error)
                }
                else {
                    if !(self.arrSelectedEmp ?? []).contains(self.txtOtherEmpName.text ?? "") {
                        self.arrSelectedEmp?.append(self.txtOtherEmpName.text ?? "")
                        self.txtOtherEmpName.text = ""
                        self.lblEmpName.text = "Select Employee Name"
                        
                        self.constraintHeightAddOtherEmp.priority = .required
                        
                        self.constraintHeightTVEmp.constant = CGFloat((self.arrSelectedEmp?.count ?? 0) * 37)
                        self.tvEmp.reloadData()
                    }
                    else {
                        Utilities.showPopup(title: "Employee already added", type: .error)
                    }
                }
            }
        }
        else {
            Utilities.showPopup(title: "Please select employee name", type: .error)
        }
    }
    
    @IBOutlet weak var tvEmp: UITableView! {
        didSet {
            self.tvEmp.delegate = self
            self.tvEmp.dataSource = self
            self.tvEmp.register(UINib(nibName: "AddMtpCityEmpTVCell", bundle: nil), forCellReuseIdentifier: "AddMtpCityEmpTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVEmp: NSLayoutConstraint!
    
    
    /// View Objective
    
    @IBOutlet weak var viewObjectives: UIView!
    @IBOutlet weak var constraintHeightViewObjectives: NSLayoutConstraint!
    @IBOutlet weak var lblObjectivesTitle: UILabel!
    @IBOutlet weak var txtObjectives: UITextField!
    
    
    
    /// View Estimated Cost
    
    @IBOutlet weak var viewEstimatedCost: UIView!
    @IBOutlet weak var constraintHeightViewEstimatedCost: NSLayoutConstraint!
    @IBOutlet weak var lblEstimatedCostTitle: UILabel!
    @IBOutlet weak var txtEstimatedCost: UITextField!
    
    
    
    /// View Remarks
    
    @IBOutlet weak var viewRemarks: UIView!
    @IBOutlet weak var constraintHeightViewRemarks: NSLayoutConstraint!
    @IBOutlet weak var lblRemarksTitle: UILabel!
    @IBOutlet weak var txtRemarks: UITextField!
    
    
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "MONTHLY TOUR PLAN".capitalized
    private lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter
    }()
    
    var strSelectedStartDate: String = ""
    var strSelectedEndDate: String = ""
    
    var strCalendarStartDate: String? = ""
    var strCalendarEndDate: String? = ""
    
    var arrMonth: [String: String] = [
        "1": "Jan-31", "2": "Feb-28", "3": "Mar-31", "4": "Apr-30", "5": "May-31", "6": "Jun-30", "7": "Jul-31", "8": "Aug-31", "9": "Sep-30", "10": "Oct-31", "11": "Nov-30", "12": "Dec-31"]
    
    var isForLeave: Bool = false
    var isWFH: Bool = false
    var isLeaveFDay: Bool = false
    var isLeaveHDay: Bool = false
    
    //var arrStrSearchCountry: [String] = ["IN", "US", "UK"]
    var arrStrSearchCountry: [String] = ["IN"]
    var arrCities: [CityInfo]? = []
    var arrCityType: [CityType]? = []
    var arrEmployee: [String]? = []
    
    var arrSelectedCity: [String]? = []
    
    var tempSelectEmp: String? = ""
    var arrSelectedEmp: [String]? = []
    
    var isDateSelect: Bool = false
    var isCitySelect: Bool = false
    var isEstimateCostAdded: Bool = false
    
    var arrStrUsedDates: [String]? = []
    var arrUsedDates: [Date]? = []
    
    var isFromEdit: Bool = false
    var strCity: String = ""
    var arrSelectedWhoms: [Whom] = []
    var strObjective: String = ""
    var strEstimateCost: String = ""
    var strRemark: String = ""
    var intMtpId: Int = 0
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.btnApplyForLeave.tintColor = Colors.gray.returnColor()
        self.btnWFH.tintColor = Colors.gray.returnColor()
        
        self.constraintHeightViewLeaveType.priority = .required
        
        self.btnAddCity.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnAddCity.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        
        self.btnAddPerson.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnAddPerson.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        
        self.lblJointWorkingWithTitle.textColor = Colors.theme.returnColor()
        
        self.lblObjectivesTitle.textColor = Colors.theme.returnColor()
        self.lblEstimatedCostTitle.textColor = Colors.theme.returnColor()
        self.lblRemarksTitle.textColor = Colors.theme.returnColor()
        
        (self.strCalendarStartDate, self.strCalendarEndDate) = self.setCalendarStartEndDate()
        
        self.arrCities = self.loadDataFromJson(fileName: "Cities", as: [CityInfo].self)
        self.arrCityType = self.loadDataFromJson(fileName: "CityType", as: [CityType].self)
        
        self.setStartEndDateUsedDate()
        self.getEmployee()
        self.configureCitySearchTextField()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.checkKeyboard(kView: self.viewAddCity)
        self.checkKeyboard(kView: self.viewJointWorkingWith)
        self.checkKeyboard(kView: self.viewObjectives)
        self.checkKeyboard(kView: self.viewEstimatedCost)
        self.checkKeyboard(kView: self.viewRemarks)
        
        if isFromEdit {
            self.setEditDetail()
        }
    }
    
    func setPageView() {
        self.constraintHeightViewLeaveType.priority = .required
        self.constraintHeightViewAddCity.priority = .defaultLow
        self.constraintHeightViewJointWorkingWith.priority = .defaultLow
        
        self.constraintHeightViewObjectives.priority = .defaultLow
        self.constraintHeightViewEstimatedCost.priority = .defaultLow
        self.constraintHeightViewRemarks.priority = .defaultLow
        
        if self.isForLeave {
            self.constraintHeightViewLeaveType.priority = .defaultLow
            
            if self.isLeaveFDay {
                self.constraintHeightViewAddCity.priority = .required
                self.constraintHeightViewJointWorkingWith.priority = .required
                
                self.constraintHeightViewObjectives.priority = .required
                self.constraintHeightViewEstimatedCost.priority = .required
            }
            else if self.isLeaveHDay {
                
            }
        }
        else if self.isWFH {
            self.constraintHeightViewJointWorkingWith.priority = .required
        }
        else {
            self.isLeaveFDay = false
            self.isLeaveHDay = false
        }
    }
    
    fileprivate func configureCitySearchTextField() {
        // Start visible even without user's interaction as soon as created - Default: false
        self.txtCity.startVisibleWithoutInteraction = false
        
        self.txtCity.theme = SearchTextFieldTheme.defaultTheme(font: Fonts.Regular.returnFont(size: 17.0))
        self.txtCity.theme.bgColor = UIColor(hexString: "#FEFEFE", alpha: 1.0)
        self.txtCity.maxResultsListHeight = 200
        self.txtCity.font = Fonts.Regular.returnFont(size: 19)
        
        // Set data source
        let cities = (self.arrCities ?? []).map { $0.name! }
        self.txtCity.filterStrings(cities)
    }
    
    private func setEditDetail() {
        self.lblMTPStartDate.text = Utilities.convertStrDateToString(date: self.strSelectedStartDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd MMM yyyy")
        self.lblMTPEndDate.text = Utilities.convertStrDateToString(date: self.strSelectedEndDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd MMM yyyy")
        
        self.strSelectedStartDate = Utilities.convertStrDateToString(date: self.strSelectedStartDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "yyyy-MM-dd")
        self.strSelectedEndDate = Utilities.convertStrDateToString(date: self.strSelectedEndDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "yyyy-MM-dd")
        self.isDateSelect = true
        
        DispatchQueue.main.async {
            if self.isForLeave {
                self.isForLeave = false
                self.btnApplyForLeaveTap(UIButton())
                
                if self.isLeaveFDay {
                    self.isLeaveFDay = false
                    self.btnLeaveFDayTap(UIButton())
                }
                else {
                    self.isLeaveHDay = false
                    self.btnLeaveHDayTap(UIButton())
                }
            }
            else if self.isWFH {
                self.isForLeave = false
                self.btnWFHTap(UIButton())
            }
        }
        
        
        if self.strCity != "" {
            self.arrSelectedCity = self.strCity.components(separatedBy: ",")
        }
        
        if self.arrSelectedWhoms.count > 0 {
            self.arrSelectedEmp = self.arrSelectedWhoms.map{ $0.otherName! }
        }
        
        self.constraintHeightTVCity.constant = CGFloat((self.arrSelectedCity?.count ?? 0) * 37)
        self.tvCity.reloadData()
        
        self.constraintHeightTVEmp.constant = CGFloat((self.arrSelectedEmp?.count ?? 0) * 37)
        self.tvEmp.reloadData()
        
        self.txtObjectives.text = self.strObjective
        self.txtEstimatedCost.text = self.strEstimateCost
        self.txtRemarks.text = self.strRemark
    }
}


// MARK: - Pick date(s)...

extension AddMTPVC {
    
    func setStartEndDateUsedDate() {
        self.dateFormatter.calendar = .current
        let tempComponen = Calendar.current.dateComponents([.day, .month, .year], from: Date())
        
        let intCurMonth = tempComponen.month ?? 0
        let intCurYear = tempComponen.year ?? 0
        
        var intNextMonth = intCurMonth + 1
        var intNextYear = intCurYear
        
        if intNextMonth > 12 {
            intNextMonth = intNextMonth - intCurMonth
            intNextYear = intCurYear + 1
        }
        
        var strStartDate = "\(tempComponen.year ?? 0)-\(tempComponen.month ?? 0)-\(tempComponen.day ?? 0)"
        var strEndDate = "\(intNextYear)-\(intNextMonth)-\(01)"
        
        self.getMtpUsedDate(startDate: strStartDate, endDate: strEndDate)
    }
    
    func convertStrDateToDate() {
        self.arrUsedDates = []
        for (_, value) in (self.arrStrUsedDates ?? []).enumerated() {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date = dateFormatter.date(from: value)
            //dateFormatter.string(from: date!)
            self.arrUsedDates?.append(date!)
        }
    }
    
    func selectMtpDate() {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale.current
        dateFormatter.dateFormat = "dd/MMM/yyyy" //  Current Date Format
        
        let tempStartDate = dateFormatter.date(from: self.strCalendarStartDate ?? "")!
        let tempEndDate = dateFormatter.date(from: self.strCalendarEndDate ?? "")!
        
        let fastisController = FastisController(mode: .range)
        fastisController.title = "Choose range"
        fastisController.initialValue = nil     //self.currentValue as? FastisRange
        //fastisController.minimumDate = Calendar.current.date(byAdding: .month, value: 0, to: tempStartDate)
        fastisController.minimumDate = Date()
        fastisController.maximumDate = Calendar.current.date(byAdding: .month, value: 0, to: tempEndDate)
        fastisController.allowToChooseNilDate = false
        //fastisController.shortcuts = [.today, .lastWeek, .lastMonth]
        
        fastisController.doneHandler = { action in
            switch action {
            case .some(let newValue):
                //self.currentValue = newValue
                //print("\(newValue.fromDate) -- \(newValue.toDate)")
                self.setMtpRangeDate(startDate: newValue.fromDate, endDate: newValue.toDate)
            case .none:
                print("any actions")
            }
        }
        fastisController.present(above: self)
    }
    
    private func setCalendarStartEndDate() -> (String, String) {
        self.dateFormatter.calendar = .current
        let tempComponen = Calendar.current.dateComponents([.day, .month, .year], from: Date())
        
        let intCurMonth = tempComponen.month ?? 0
        let intCurYear = tempComponen.year ?? 0
        var intNextMonth = 1
        var intNextYear = intCurYear + 1
        
        if intCurMonth <= 11 {
            intNextMonth = intCurMonth + 1
            intNextYear = intCurYear
        }
        
        let arrTempCurMonth = (self.arrMonth["\(intCurMonth)"])?.components(separatedBy: "-")
        let arrTempNextMonth = (self.arrMonth["\(intNextMonth)"])?.components(separatedBy: "-")
        
        let strCurMonth = arrTempCurMonth?[0] ?? ""
        let strNextMonth = arrTempNextMonth?[0] ?? ""
        var strNextMonthDay = arrTempNextMonth?[1] ?? ""
        if intNextMonth == 2 {
            if (intNextYear % 4) == 0 {
                strNextMonthDay = "29"
            }
        }
        
        return ("01/\(strCurMonth)/\(intCurYear)", "\(strNextMonthDay)/\(strNextMonth)/\(intNextYear)")
    }
    
    func setMtpRangeDate(startDate: Date, endDate: Date) {
        
        let startDateComponen = Calendar.current.dateComponents([.day, .month, .year], from: startDate)
        let endDateComponen = Calendar.current.dateComponents([.day, .month, .year], from: endDate)
        
        if startDateComponen.month ?? 0 == endDateComponen.month ?? 0 {
            
            let dateFormatter = DateFormatter()
            //dateFormatter.dateFormat = "yyyy-MM-dd hh:mm:ss Z"
            dateFormatter.dateFormat = "dd MMM yyyy"
            self.lblMTPStartDate.text = dateFormatter.string(from: startDate)
            self.lblMTPEndDate.text = dateFormatter.string(from: endDate)
            
            dateFormatter.dateFormat = "yyyy-MM-dd"
            self.strSelectedStartDate = dateFormatter.string(from: startDate)
            self.strSelectedEndDate = dateFormatter.string(from: endDate)
            
            self.isDateSelect = true
            print(self.strSelectedStartDate)
            print(self.strSelectedEndDate)
            
            self.checkMtpDate(startDate: self.strSelectedStartDate, endDate: self.strSelectedEndDate)
        }
        else {
            Utilities.showPopup(title: "Please select both dates from single month", type: .error)
        }
    }
}
