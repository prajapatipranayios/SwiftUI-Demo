//
//  AddMTPVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 27/07/24.
//

import Foundation
import UIKit



// MARK: - UITableView Delegate, Datasourse

extension AddMTPVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    /*func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
     let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "DashboardSalesOrderTVHFView") as! DashboardSalesOrderTVHFView
     headerView.viewMain.backgroundColor = UIColor(hexString: "#F7F7F7", alpha: 1.0)
     headerView.lblTotalOrderTitle.textColor = Colors.theme.returnColor()
     headerView.lblTotalValue.textColor = Colors.theme.returnColor()
     
     headerView.lblTotalOrder.text = "\(self.total?.orders ?? 0)"
     headerView.lblTotalValue.text = "₹ " + "\(self.total?.amount ?? 0.0)".curFormatAsRegion()
     
     headerView.lblMaterialDispatchColor.backgroundColor = Colors.themeGreen.returnColor()
     headerView.lblMaterialDispatchColor.corners(radius: headerView.lblMaterialDispatchColor.frame.height / 2)
     
     headerView.lblBackOrdersColor.backgroundColor = Colors.themeRed.returnColor()
     headerView.lblBackOrdersColor.corners(radius: headerView.lblBackOrdersColor.frame.height / 2)
     return headerView
     }   /// */
    
    /*func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
     if self.intSelectedOption == 2 {
     if self.arrOrders?.count ?? 0 > 0 {
     return 66
     }
     return 0
     }
     return 0
     }   ///  */
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tvCity {
            return self.arrSelectedCity?.count ?? 0
        }
        else if tableView == self.tvEmp {
            return self.arrSelectedEmp?.count ?? 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddMtpCityEmpTVCell", for: indexPath) as! AddMtpCityEmpTVCell
        
        cell.index = indexPath.row
        
        if tableView == self.tvCity {
            cell.lblValue.text = self.arrSelectedCity?[indexPath.row] ?? ""
        }
        else if tableView == self.tvEmp {
            cell.lblValue.text = self.arrSelectedEmp?[indexPath.row] ?? ""
        }
        
        cell.didSelect = { index in
            if tableView == self.tvCity {
                self.arrSelectedCity?.remove(at: index)
                self.constraintHeightTVCity.constant = CGFloat((self.arrSelectedCity?.count ?? 0) * 37)
                self.tvCity.reloadData()
            }
            else if tableView == self.tvEmp {
                self.arrSelectedEmp?.remove(at: index)
                self.constraintHeightTVEmp.constant = CGFloat((self.arrSelectedEmp?.count ?? 0) * 37)
                self.tvEmp.reloadData()
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //return UITableView.automaticDimension
        return 37
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("TV cell tap...")
    }
}


// MARK: - UITextFieldDelegate

extension AddMTPVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        if textField == self.txtCity {
            let currentText = textField.text ?? ""
            
            guard let stringRange = Range(range, in: currentText) else {
                return false
            }
            
            //            let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
            //            self.searchCities(startingWith: updatedText) { arrTempCity in
            //                print(arrTempCity)
            //            }
            
            return true
        }
        /*else if textField == self.txtAnnualTurnover {
         switch string {
         case "0","1","2","3","4","5","6","7","8","9":
         return true
         case ".":
         let array = (textField.text)!.map { String($0) }
         var decimalCount = 0
         for character in array {
         if character == "." {
         decimalCount += 1
         }
         }
         
         if decimalCount == 1 {
         return false
         } else {
         return true
         }
         default:
         let array = Array(string)
         if array.count == 0 {
         return true
         }
         return false
         }
         }   //  */
        else {
            return true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //self.txtCompanyName.resignFirstResponder()
        textField.resignFirstResponder()
        
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        if self.checkValidation(to: textField.tag, from: textField.tag + 1) {
        }
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
        }
        return value
    }
}


// MARK: - Search Place (City)

extension AddMTPVC {
    /*func searchCities(startingWith letter: String, completion: @escaping ([String]) -> Void) {
     let filter = GMSAutocompleteFilter()
     filter.type = .city
     filter.countries = self.arrStrSearchCountry // Add country codes if you want to limit the search
     
     let placesClient = GMSPlacesClient.shared()
     
     placesClient.findAutocompletePredictions(fromQuery: letter, filter: filter, sessionToken: nil) { (results, error) in
     if let error = error {
     print("Error: \(error.localizedDescription)")
     completion([])
     return
     }
     
     var cityNames = [String]()
     
     results?.forEach { result in
     let cityName = result.attributedPrimaryText.string
     cityNames.append(cityName)
     }
     
     completion(cityNames)
     }
     } /// */
    
    /*func getAllCities(inCountry countryCode: String, completion: @escaping ([GoogleCityInfo]) -> Void) {
     let filter = GMSAutocompleteFilter()
     filter.type = .city
     filter.countries = [countryCode]
     
     let placesClient = GMSPlacesClient.shared()
     let alphabet = "abcdefghijklmnopqrstuvwxyz"
     var cityInfos = [GoogleCityInfo]()
     let dispatchGroup = DispatchGroup()
     
     for letter in alphabet {
     dispatchGroup.enter()
     placesClient.findAutocompletePredictions(fromQuery: String(letter), filter: filter, sessionToken: nil) { (results, error) in
     if let error = error {
     print("Error: \(error.localizedDescription)")
     dispatchGroup.leave()
     return
     }
     
     results?.forEach { result in
     dispatchGroup.enter()
     let placeID = result.placeID
     placesClient.lookUpPlaceID(placeID) { (place, error) in
     if let place = place {
     let cityInfo = GoogleCityInfo(
     name: place.name ?? "",
     placeID: place.placeID,
     state: place.addressComponents?.first(where: { $0.types.contains("administrative_area_level_1") })?.name ?? ""
     )
     cityInfos.append(cityInfo)
     }
     dispatchGroup.leave()
     }
     }
     dispatchGroup.leave()
     }
     }
     
     dispatchGroup.notify(queue: .main) {
     completion(cityInfos)
     }
     }   ///  */
}


// MARK: - Keyboard

extension AddMTPVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            self.constraintBottomViewScrollOutToSuper.constant = keyboardOverlap > 0 ? (keyboardOverlap - 0) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}


// MARK: - Webservices

extension AddMTPVC {
    
    func getEmployee() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployee()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EMPLOYEES, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    let arrTempEmployee = response?.result?.employees ?? []
                    self.arrEmployee = arrTempEmployee.map { $0.employeeName! }
                    self.arrEmployee?.insert("Other", at: 0)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getMtpUsedDate(startDate: String, endDate: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getMtpUsedDate(startDate: startDate, endDate: endDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_MTP_USED_DATE, parameters: param) { (response: ApiResponseMTP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrStrUsedDates = response?.result?.dates ?? []
                    self.convertStrDateToDate()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func addMTP(startDate: String, endDate: String, intLeave: Int, intWorkingFromHome: Int, leaveType: String, arrCity: [String], arrWithWhooms: [String], objectives: String, estimatedCost: Int, remark: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addMTP(startDate: startDate, endDate: endDate, intLeave: intLeave, intWorkingFromHome: intWorkingFromHome, leaveType: leaveType, arrCity: arrCity, arrWithWhooms: arrWithWhooms, objectives: objectives, estimatedCost: estimatedCost, remark: remark)
                }
            }
            return
        }
        
        var arrTempWithWhooms: [Any] = []
        
        for (_, value) in arrWithWhooms.enumerated() {
            var tempObj = [
                "user_id": "",
                "other_name": value,
                "company_name": ""
            ]
            arrTempWithWhooms.append(tempObj)
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate,
            "is_leave": intLeave,
            "isWorkingFromHome": intWorkingFromHome,
            "leave_type": leaveType,
            "city": arrCity.joined(separator: ","),
            "with_whooms": arrTempWithWhooms,
            "objectives": objectives,
            "estimated_cost": estimatedCost,
            "remark": remark
            
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_MPT, parameters: param) { (response: ApiResponseMTP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.displaySuccessMsg(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func updateMTP(mtpId: Int, startDate: String, endDate: String, intLeave: Int, intWorkingFromHome: Int, leaveType: String, arrCity: [String], arrWithWhooms: [String], objectives: String, estimatedCost: Int, remark: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.updateMTP(mtpId: mtpId, startDate: startDate, endDate: endDate, intLeave: intLeave, intWorkingFromHome: intWorkingFromHome, leaveType: leaveType, arrCity: arrCity, arrWithWhooms: arrWithWhooms, objectives: objectives, estimatedCost: estimatedCost, remark: remark)
                }
            }
            return
        }
        
        var arrTempWithWhooms: [Any] = []
        
        for (_, value) in arrWithWhooms.enumerated() {
            var tempObj = [
                "user_id": 0,
                "other_name": value,
                "company_name": ""
            ] as [String : Any]
            arrTempWithWhooms.append(tempObj)
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate,
            "is_leave": intLeave,
            "isWorkingFromHome": intWorkingFromHome,
            "leave_type": leaveType,
            "city": arrCity.joined(separator: ","),
            "with_whooms": arrTempWithWhooms,
            "objectives": objectives,
            //"estimated_cost": estimatedCost,
            "estimated_cost": (objectives == "") ? "0" : estimatedCost ,
            "remark": remark,
            "mtp_id": mtpId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.UPDATE_MASTER_MPT, parameters: param) { (response: ApiResponseMTP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.displaySuccessMsg(message: response?.message ?? "")
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func checkMtpDate(startDate: String, endDate: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.checkMtpDate(startDate: startDate, endDate: endDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate,
            
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CHECK_MTP_DATE, parameters: param) { (response: ApiResponseMTP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                if response?.result?.dateValid ?? 0 == 0 {
                    DispatchQueue.main.async {
                        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
                        popupVC.modalPresentationStyle = .overCurrentContext
                        popupVC.modalTransitionStyle = .crossDissolve
                        popupVC.titleTxt = "Alert"
                        popupVC.strImgName = "InfoWLightRed"
                        popupVC.strMessage = response?.message ?? ""
                        popupVC.onTapOk = { str in
                            /*self.lblMTPStartDate.text = "Start Date"
                             self.lblMTPEndDate.text = "End Date"
                             self.strSelectedStartDate = ""
                             self.strSelectedEndDate = ""
                             self.isDateSelect = false   //  */
                        }
                        self.present(popupVC, animated: true)
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func displaySuccessMsg(message: String) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.navigationController?.popViewController(animated: true)
        }
        self.present(popupVC, animated: true)
    }
}
