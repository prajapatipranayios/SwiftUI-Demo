//
//  MonthlyTourPlanVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 26/07/24.
//

import Foundation
import UIKit



// MARK: UICollectionView Delegate, DataSource, FlowLayout

extension MonthlyTourPlanVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        //return self.colleSection ?? 0
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //return (section == 0) ? self.categoryCell?.count ?? 0 : self.TADACell?.count ?? 0
        return self.arrMtpCalData?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CalendarMonthCVCell", for: indexPath) as! CalendarMonthCVCell
        
        cell.index = indexPath.item
        cell.lblDate.text = Utilities.convertStrDateToString(date: self.arrMtpCalData?[indexPath.item].date ?? "", CurrentDateFormate: "yyyy-MM-dd", NewDateFormate: "dd-MMM-yy")
        
        cell.lblEmp1.text = ""
        cell.lblEmp2.text = ""
        cell.lblEmp3.text = ""
        
        if (self.arrMtpCalData?[indexPath.item].employee?.count ?? 0) > 0 {
            cell.viewEmpName.backgroundColor = UIColor(hexString: "#FFFFFF", alpha: 1.0)
            let count = (self.arrMtpCalData?[indexPath.item].employee?.count ?? 0) <= 3 ? (self.arrMtpCalData?[indexPath.item].employee?.count ?? 0) : 3
            for i in 0..<count {
                if i == 0 { cell.lblEmp1.text = "1. " + "\(self.arrMtpCalData?[indexPath.item].employee?[i].fullname ?? "")"
                    cell.lblEmp1.textColor = (self.arrMtpCalData?[indexPath.item].employee?[i].isLeave ?? 0) == 1 ? Colors.themeRed.returnColor() : Colors.theme.returnColor()
                }
                else if i == 1 { cell.lblEmp2.text = "2. " + "\(self.arrMtpCalData?[indexPath.item].employee?[i].fullname ?? "")"
                    cell.lblEmp2.textColor = (self.arrMtpCalData?[indexPath.item].employee?[i].isLeave ?? 0) == 1 ? Colors.themeRed.returnColor() : Colors.theme.returnColor()
                }
                else if i == 2 { cell.lblEmp3.text = "3. " + "\(self.arrMtpCalData?[indexPath.item].employee?[i].fullname ?? "")"
                    cell.lblEmp3.textColor = (self.arrMtpCalData?[indexPath.item].employee?[i].isLeave ?? 0) == 1 ? Colors.themeRed.returnColor() : Colors.theme.returnColor()
                }
            }
        }
        else {
            cell.viewEmpName.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        }
        
        return cell
        //return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 0) / 3
        let height = 100.0
        return CGSize(width: width, height: height)
    }
    
    /*func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        switch kind {
        case UICollectionView.elementKindSectionHeader:
            if indexPath.section == 1 {
                let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HeaderRV", for: indexPath) as! HeaderRV
                //headerView.lblHeader.text = "TA & DA"
                return headerView
            }
            else {
                assert(false, "Unexpected element kind")
            }
        default:
            assert(false, "Unexpected element kind")
        }
    }   /// */
    
    /*func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 1 {
            return CGSizeMake(collectionView.frame.size.width, 65)
        }
        else {
            return CGSizeZero
        }
    }   /// */
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if (self.arrMtpCalData?[indexPath.item].employee?.count ?? 0) > 0 {
            self.viewMain.isHidden = true
            self.viewMTPEmpList.isHidden = false
            self.mtpCalData = self.arrMtpCalData?[indexPath.row]
            self.lblMTPEmpListDate.text = Utilities.convertStrDateToString(date: self.mtpCalData?.date ?? "", CurrentDateFormate: "yyyy-MM-dd", NewDateFormate: "dd-MMM-yy")
            self.tvEmpMTP.reloadData()
        }
    }
}


// MARK: - UITableView Delegate, Datasourse

extension MonthlyTourPlanVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.tvEmpMTP == tableView {
            return self.mtpCalData?.employee?.count ?? 0
        }
        else if self.tvMtpData == tableView {
            return self.arrMtpMasterData?.count ?? 0
        }
        else if self.tvMonthWiseFilerEmpMTPData == tableView {
            return (self.filterDataResult?.data?.count ?? 0) == 0 ? 0 : ((self.filterDataResult?.data?.count ?? 0) + 1)
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if self.tvEmpMTP == tableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EmpMTPTVCell", for: indexPath) as! EmpMTPTVCell
            
            cell.index = indexPath.row
            
            cell.lblEmpName.text = self.mtpCalData?.employee?[indexPath.row].fullname ?? ""
            cell.lblEmpName.textColor = Colors.theme.returnColor()
            
            cell.lblCity.text = self.mtpCalData?.employee?[indexPath.row].city ?? ""
            
            if (((self.mtpCalData?.employee?[indexPath.row].leaveType ?? "").lowercased() == "full day") && ((self.mtpCalData?.employee?[indexPath.row].isLeave ?? 0) == 1)) || ((self.mtpCalData?.employee?[indexPath.row].isWorkingFromHome ?? 0) == 1) {
                if ((self.mtpCalData?.employee?[indexPath.row].isWorkingFromHome ?? 0) == 1) {
                    cell.lblStatus.text = "WFH"
                }
                else {
                    cell.lblStatus.text = "On Leave"
                }
            }
            else {
                cell.lblStatus.text = ""
            }
            
            cell.lblMTPDate.text = self.setMTPDisplayDate(startDate: self.mtpCalData?.employee?[indexPath.row].startDate ?? "", endDate: self.mtpCalData?.employee?[indexPath.row].endDate ?? "")
            
            return cell
        }
        else if self.tvMtpData == tableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MtpMasterDataTVCell", for: indexPath) as! MtpMasterDataTVCell
            
            cell.index = indexPath.row
            
            let arrTemp: [String] = (self.arrMtpMasterData?[indexPath.row].whoms ?? []).map { $0.otherName! }
            
            var strTempJointWorkingWith: String = "-"
            if arrTemp.count > 0 {
                strTempJointWorkingWith = arrTemp.joined(separator: "\n")
            }
            
            cell.lblDate.text = self.setMTPDisplayDate(startDate: self.arrMtpMasterData?[indexPath.row].startDate ?? "", endDate: self.arrMtpMasterData?[indexPath.row].endDate ?? "")
            
            cell.lblCity.text = self.arrMtpMasterData?[indexPath.row].city ?? ""
            cell.lblJointWorkingWith.text = strTempJointWorkingWith
            cell.lblRejectReason.text = "\(self.arrMtpMasterData?[indexPath.row].comment ?? "")" != "" ? "\(self.arrMtpMasterData?[indexPath.row].comment ?? "")" : "-"
            cell.lblReply.text = "\(self.arrMtpMasterData?[indexPath.row].reply ?? "")" != "" ? "\(self.arrMtpMasterData?[indexPath.row].reply ?? "")" : "-"
            cell.lblLeave.text = "\(self.arrMtpMasterData?[indexPath.row].leaveType ?? "")" != "" ? "\(self.arrMtpMasterData?[indexPath.row].leaveType ?? "")" : "-"
            cell.lblEstimatedCost.text = "₹ 0"
            if "\(self.arrMtpMasterData?[indexPath.row].estimatedCost ?? 0)" != "0" {
                cell.lblEstimatedCost.text = "₹ " + "\(self.arrMtpMasterData?[indexPath.row].estimatedCost ?? 0)".curFormatAsRegion()
            }
            
            cell.constraintHeightViewRejectReason.priority = .required
            cell.constraintHeightViewReply.priority = .required
            cell.constraintHeightViewLeave.priority = .required
            
            if "\(self.arrMtpMasterData?[indexPath.row].comment ?? "")" != "" {
                cell.constraintHeightViewRejectReason.priority = .defaultLow
            }
            
            if "\(self.arrMtpMasterData?[indexPath.row].reply ?? "")" != "" {
                cell.constraintHeightViewReply.priority = .defaultLow
            }
            
            if (self.arrMtpMasterData?[indexPath.row].isLeave ?? 0) == 1 {
                cell.constraintHeightViewLeave.priority = .defaultLow
            }
            
            cell.constraintHeightViewButton.priority = .defaultLow
            
            cell.onEditTap = { index in
                
                let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                let viewController = storyBoard.instantiateViewController(withIdentifier: "AddMTPVC") as! AddMTPVC
                viewController.isFromEdit = true
                
                viewController.intMtpId = self.arrMtpMasterData?[index].masterId ?? 0
                
                viewController.strSelectedStartDate = self.arrMtpMasterData?[index].startDate ?? ""
                viewController.strSelectedEndDate = self.arrMtpMasterData?[index].endDate ?? ""
                
                viewController.isForLeave = ((self.arrMtpMasterData?[index].isLeave ?? 0) == 1) ? true : false
                viewController.isLeaveFDay = ((self.arrMtpMasterData?[index].leaveType ?? "") == "Full Day") ? true : false
                viewController.isLeaveHDay = ((self.arrMtpMasterData?[index].leaveType ?? "") == "Half Day") ? true : false
                viewController.isWFH = ((self.arrMtpMasterData?[index].isWorkingFromHome ?? 0) == 1) ? true : false
                
                viewController.strCity = self.arrMtpMasterData?[index].city ?? ""
                viewController.arrSelectedWhoms = self.arrMtpMasterData?[index].whoms ?? []
                
                viewController.strObjective = self.arrMtpMasterData?[index].objectives ?? ""
                viewController.strEstimateCost = "\(self.arrMtpMasterData?[index].estimatedCost ?? 0.0)"
                viewController.strRemark = self.arrMtpMasterData?[index].remark ?? ""
                self.isEditMtp = true
                self.navigationController?.pushViewController(viewController, animated: true)
            }
            
            cell.onReplyTap = { index in
                self.intIndexRejectReasonData = index
                self.mtpMasterDataRejctReason = self.arrMtpMasterData?[index]
                self.isRejectTap = false
                self.isReplyTap = true
                self.lblRejectReasonTitle.text = "Reply"
                self.viewRejectReasonPopup.isHidden = false
            }
            
            cell.btnEdit.isHidden = false
            var isBtnEditHide = false
            if ((self.arrMtpMasterData?[indexPath.row].employeeAction ?? 0) == 0) && (self.arrMtpMasterData?[indexPath.row].status ?? "") != "Rejected" {
                //edit btn hide
                cell.btnEdit.isHidden = true
                isBtnEditHide = true
            }   //  else visible
            
            cell.btnReply.isHidden = true
            cell.constraintTrailingBtnReplyToSuper.priority = .defaultLow
            var isBtnReplyHide = true
            if (self.arrMtpMasterData?[indexPath.row].status ?? "") == "Rejected" && (self.arrMtpMasterData?[indexPath.row].reply ?? "") == "" {
                //reply btn visible
                cell.btnReply.isHidden = false
                isBtnReplyHide = false
                
                if isBtnEditHide {
                    cell.constraintTrailingBtnReplyToSuper.priority = .required
                }
            }   //  else hide
            
            if isBtnEditHide && isBtnReplyHide {
                cell.constraintHeightViewButton.priority = .required
            }
            
            return cell
        }
        else if self.tvMonthWiseFilerEmpMTPData == tableView {
            if indexPath.row == (self.filterDataResult?.data?.count ?? 0) {
                var cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
                if( !(cell != nil)) {
                    cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "Cell")
                }
                
                let button = UIButton(type: .system)
                button.setTitle("View PDF", for: .normal)
                button.titleLabel?.font = Fonts.Regular.returnFont(size: 17)
                button.translatesAutoresizingMaskIntoConstraints = false
                button.cornersWFullBorder(radius: 5, borderColor: .black, colorOpacity: 1.0)
                button.addTarget(self, action: #selector(self.btnViewPDF_MtpFilterTap), for: .touchUpInside)
                cell?.contentView.addSubview(button)
                
                // Set up constraints
                NSLayoutConstraint.activate([
                    //button.trailingAnchor.constraint(equalTo: cell!.contentView.trailingAnchor, constant: -15),
                    button.centerYAnchor.constraint(equalTo: cell!.contentView.centerYAnchor),
                    button.centerXAnchor.constraint(equalTo: cell!.contentView.centerXAnchor),
                    button.heightAnchor.constraint(equalToConstant: 35),
                    button.widthAnchor.constraint(equalToConstant: 100)
                ])
                
                return cell!
                //return UITableViewCell()
            }
            else {
                let cell = tableView.dequeueReusableCell(withIdentifier: "EmpMTPDataFilerMonthTVCell", for: indexPath) as! EmpMTPDataFilerMonthTVCell
                
                cell.index = indexPath.row
                cell.lblMonth.text = self.filterDataResult?.data?[indexPath.row].month ?? ""
                cell.lblMonthTotal.text = "₹" + "\(self.filterDataResult?.data?[indexPath.row].monthTotal ?? 0.0)".curFormatAsRegion()
                cell.arrZone = self.filterDataResult?.data?[indexPath.row].zone
                
                return cell
            }
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.tvMonthWiseFilerEmpMTPData == tableView {
        }
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.tvEmpMTP == tableView {
            self.intIndexEmpDetails = indexPath.row
            self.isEmpMTPDetails = true
            self.viewEmpMTPDetails.isHidden = false
            
            self.lblDate.text = self.setMTPDisplayDate(startDate: self.mtpCalData?.employee?[indexPath.row].startDate ?? "", endDate: self.mtpCalData?.employee?[indexPath.row].endDate ?? "")
            self.setSelectedEmpDetails((self.mtpCalData?.employee ?? [])[indexPath.row])
        }
    }
    
    @objc func btnViewPDF_MtpFilterTap(_ sendar: UIButton) {
        if self.arrSelectedMonth.count > 0 {
            self.getMtpDetailsFilter(zone: self.arrSelectedZone, month: self.arrSelectedMonth, year: self.arrSelectedYear, empIds: self.arrSelectedEmp, intPdf: 1)
        }
        else {
            Utilities.showPopup(title: "Select month(s).", type: .error)
        }
    }
    
    /// Set date range of tour
    func setMTPDisplayDate(startDate: String, endDate: String, currentDateFormate: String = "dd-MMMM-yyyy", newDateFormate: String = "dd-MMM-yyyy") -> String {
        let startDateComponent = Calendar.current.dateComponents([.day, .month, .year], from: Utilities.convertStringToDate(date: startDate, CurrentDateFormate: currentDateFormate, NewDateFormate: newDateFormate))
        
        let endDateComponent = Calendar.current.dateComponents([.day, .month, .year], from: Utilities.convertStringToDate(date: endDate, CurrentDateFormate: currentDateFormate, NewDateFormate: newDateFormate))
        
        var date: String = ""
        if (startDateComponent.year ?? 0) == (endDateComponent.year ?? 0) {
            date = "\(Utilities.convertStrDateToString(date: startDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd MMM")) to \(Utilities.convertStrDateToString(date: endDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd MMM yyyy"))"
            
            if ((startDateComponent.month ?? 0) == (endDateComponent.month ?? 0)) {
                
                date = "\(Utilities.convertStrDateToString(date: startDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd")) to \(Utilities.convertStrDateToString(date: endDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd MMM yyyy"))"
                
                if ((startDateComponent.day ?? 0) == (endDateComponent.day ?? 0)) {
                    date = "\(Utilities.convertStrDateToString(date: startDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd MMM yyyy"))"
                }
            }
        }
        else {
            date = "\(Utilities.convertStrDateToString(date: startDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd MMM yyyy")) to \(Utilities.convertStrDateToString(date: endDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd MMM yyyy"))"
        }
        
        return date
    }
    
    func setSelectedEmpDetails(_ tempEmployee: Employee) {
//        let tempComponent = Calendar.current.dateComponents([.day, .month, .year], from: Utilities.convertStringToDate(date: startDate, CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd-MMM-yyyy"))
        
        let tempComponent = Calendar.current.dateComponents([.day, .month, .year], from: Utilities.convertStringToDate(date: tempEmployee.startDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd-MMMM-yyyy"), to: Utilities.convertStringToDate(date: tempEmployee.endDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy", NewDateFormate: "dd-MMMM-yyyy"))
        
        self.lblEmpName.text = tempEmployee.fullname ?? ""
        self.lblTotalDays.text = "Total Days: \((tempComponent.day ?? 0) + 1)"
        
        let arrTemp: [String] = (tempEmployee.whoms ?? []).map { "\($0.otherName!) \($0.companyName!)" }
        
        var strTempJointWorkingWith: String = "-"
        if arrTemp.count > 0 {
            strTempJointWorkingWith = arrTemp.joined(separator: "\n")
        }
        
        self.lblEmpCity.text = "\(tempEmployee.city ?? "")" != "" ? "\(tempEmployee.city ?? "")" : "-"
        self.lblEmpJointWorkingWith.text = strTempJointWorkingWith
        self.lblEmpObjectives.text = "\(tempEmployee.objectives ?? "")" != "" ? "\(tempEmployee.objectives ?? "")" : "-"
        self.lblEmpRemarks.text = "\(tempEmployee.remark ?? "")" != "" ? "\(tempEmployee.remark ?? "")" : "-"
        self.lblEmpRejectReason.text = "\(tempEmployee.comment ?? "")" != "" ? "\(tempEmployee.comment ?? "")" : "-"
        self.lblEmpReply.text = "\(tempEmployee.reply ?? "")" != "" ? "\(tempEmployee.reply ?? "")" : "-"
        self.lblEmpEstimatedCost.text = "₹ 0"
        if "\(tempEmployee.estimatedCost ?? 0)" != "0" {
            self.lblEmpEstimatedCost.text = "₹ " + "\(tempEmployee.estimatedCost ?? 0)".curFormatAsRegion()
        }
        
        self.constraintHeightViewEmpLeave.constant = 0
        if (tempEmployee.isLeave ?? 0) == 1 {
            self.constraintHeightViewEmpLeave.constant = 35
            self.lblEmpLeave.text = tempEmployee.leaveType ?? ""
        }
        
        if tempEmployee.isWorkingFromHome ?? 0 == 1 {
            self.constraintTopBtnReject.priority = .defaultLow
        } else {
            self.constraintTopBtnReject.priority = .required
        }
        
        if tempEmployee.status ?? "" != "Rejected"
        {
            self.lblEmpStatus.isHidden = true
            if APIManager.sharedManager.userId == tempEmployee.userId ?? 0 {
                //self.btnEditNReject
                self.isBtnRejectVisible = false
            }
            else {
                self.isBtnRejectVisible = true
            }
        }
        else {
            self.lblEmpStatus.isHidden = false
            self.isBtnRejectVisible = false
        }
        
        if APIManager.sharedManager.userId == tempEmployee.userId ?? 0 {
            if tempEmployee.employeeAction ?? 0 == 0 && tempEmployee.status ?? "" != "Rejected" {
                self.isBtnEditVisible = false
            }
            else {
                self.isBtnEditVisible = true
            }
        }
        else {
            if tempEmployee.employeeAction ?? 0 < 2 {
                self.isBtnEditVisible = true
                self.isBtnRejectVisible = true
            }
            else {
                self.isBtnEditVisible = false
                self.isBtnRejectVisible = false
            }
        }
        
        if isBtnRejectVisible {
            if (tempEmployee.roleId ?? 0 == 2) && (APIManager.sharedManager.userDetail?.roleId ?? 0 == 4) {
                self.isBtnRejectVisible = false
            }
        }
        
        if isBtnEditVisible {
            if (tempEmployee.roleId ?? 0 == 2) && (APIManager.sharedManager.userDetail?.roleId ?? 0 == 4) {
                self.isBtnEditVisible = false
            }
        }
        
        if APIManager.sharedManager.userDetail?.roleId ?? 0 == 10 {
            self.isBtnEditVisible = false
            self.isBtnRejectVisible = false
        }
        
        self.btnReject.isHidden = true
        self.btnEdit.isHidden = true
        self.constraintTrailingToSuper.priority = .defaultLow
        
        if self.isBtnRejectVisible {
            self.btnReject.isHidden = false
        }
        else {
            self.constraintTrailingToSuper.priority = .required
        }
        
        if self.isBtnEditVisible {
            self.btnEdit.isHidden = false
        }
    }
}


// MARK: - WebServices

extension MonthlyTourPlanVC {
    func getMtpDetailsOnCalenderView(intMonth: Int, intYear: Int) {
            
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getMtpDetailsOnCalenderView(intMonth: intMonth, intYear: intYear)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "month": intMonth,
            "year": intYear
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_MTP_DETAILS_ON_CALENDER_VIEW, parameters: param) { (response: ApiResponseMTP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrMtpCalData = response?.result?.data ?? []
                    self.colleMonthWEmp.reloadData()
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getMtpDetailsFilter(zone: [String], month: [String], year: [Int], empIds: [Int], intPdf: Int = 0) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getMtpDetailsFilter(zone: zone, month: month, year: year, empIds: empIds, intPdf: intPdf)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "pdf": intPdf,
            "zone": zone,
            "month": month,
            "year": year,
            "user_ids": empIds
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_MTP_DETAILS_FILTER, parameters: param) { (response: ApiResponseMTP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    if intPdf == 0 {
                        self.filterDataResult = response?.result?.dataResult
                        self.tvMonthWiseFilerEmpMTPData.reloadData()
                    }
                    else if intPdf == 1 {
                        guard let url = URL(string: response?.result?.dataResult?.pdfUrl ?? "") else { return }
                        UIApplication.shared.open(url)
                    }
                }
            }
            else {
                    
            }
        }
    }
    
    func getEmploye() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmploye()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": 1
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_MY_TEAM, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrMyTeamMember = response?.result?.teamMembers ?? []
                }
            }
            else {
                    
            }
        }
    }
    
    func getMtpMasterData(startDate: String, endDate: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getMtpMasterData(startDate: startDate, endDate: endDate)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "start_date": startDate,
            "end_date": endDate
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_MTP_MASTER_DATA, parameters: param) { (response: ApiResponseMTP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrMtpMasterData = response?.result?.mtp ?? []
                    self.tvMtpData.reloadData()
                    
                    if self.arrMtpMasterData?.count ?? 0 > 0 {
                        self.constraintBottomTVMtpDataToSuper.priority = .defaultLow
                    }
                }
            }
            else {
                self.constraintBottomTVMtpDataToSuper.priority = .required
            }
        }
    }
    
    func submitReplyMTP(id: Int, reply: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.submitReplyMTP(id: id, reply: reply)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "id": id,
            "reply": reply
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.SUBMIT_REPLY_MTP, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.viewRejectReasonPopup.isHidden = true
                    //self.getMtpMasterData(startDate: self.strSelectedStartDate, endDate: self.strSelectedEndDate)
                    
                    self.arrMtpMasterData?[self.intIndexRejectReasonData] = (response?.result?.mtp)!
                    self.tvMtpData.reloadData()
                }
            }
            else {
                
            }
        }
    }
    
    func submitRejectReason(id: Int, reply: String) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.submitRejectReason(id: id, reply: reply)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "id": id,
            "status": "Rejected",
            "comment": reply,
            "reply": reply
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.SUBMIT_REPLY_MTP, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.viewRejectReasonPopup.isHidden = true
                    //self.getMtpMasterData(startDate: self.strSelectedStartDate, endDate: self.strSelectedEndDate)
                    
                    //self.arrMtpMasterData?[self.intIndexRejectReasonData] = (response?.result?.mtp)!
                    self.mtpMasterDataRejctReason = (response?.result?.mtp)!
                    self.mtpCalData?.employee?[self.intIndexRejectReasonData] = (response?.result?.mtp)!
                    self.tvMtpData.reloadData()
                    self.setSelectedEmpDetails((response?.result?.mtp)!)
                }
            }
            else {
                
            }
        }
    }
}
