//
//  MonthlyTourPlanVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 26/07/24.
//

import UIKit
import Fastis

class MonthlyTourPlanVC: UIViewController {

    // MARK: - Controls
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    
    @IBOutlet weak var btnAddMTP: UIButton!
    @IBAction func btnAddMTPTap(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "AddMTPVC") as! AddMTPVC
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    
    /// View Calendar
    
    @IBOutlet weak var viewCalendar: UIView!
    
    @IBOutlet weak var viewFilterCalendar: UIView!
    
    @IBOutlet weak var viewMonthYearFilter: UIView!
    @IBOutlet weak var lblMonthYear: UILabel!
    @IBOutlet weak var btnMonthYear: UIButton!
    @IBAction func btnMonthYearTap(_ sender: UIButton) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = "Select"
        popupVC.value = self.arrMonthYear
        popupVC.selectedValue = self.lblMonthYear.text ?? ""
        popupVC.isSearchActive = false
        popupVC.isOpenCloseAnimation = false
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strMonthYear in
            self.lblMonthYear.text = strMonthYear
            
            let arrTemp: [String] = strMonthYear.components(separatedBy: " ")
            
            self.getMtpDetailsOnCalenderView(intMonth: MTP.Month(arrTemp[0]), intYear: Int(arrTemp[1]) ?? 0)
        }
        popupVC.onClose = { name in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var btnEmpMTPDataFilter: UIButton!
    @IBAction func btnEmpMTPDataFilterTap(_ sender: UIButton) {
        self.viewMain.isHidden = true
        self.viewMTPEmpList.isHidden = true
        self.viewEmpMTPDataFiler.isHidden = false
        self.isViewEmpMtpEmpFilter = true
        
        self.getEmploye()
    }
    
    @IBOutlet weak var viewCollCalendar: UIView!
    @IBOutlet weak var colleMonthWEmp: UICollectionView! {
        didSet {
            self.colleMonthWEmp.delegate = self
            self.colleMonthWEmp.dataSource = self
            self.colleMonthWEmp.register(UINib(nibName: "CalendarMonthCVCell", bundle: nil), forCellWithReuseIdentifier: "CalendarMonthCVCell")
        }
    }
    
    
    /// View Display MTP Data
    
    @IBOutlet weak var viewDisplayMTPData: UIView!
    
    @IBOutlet weak var viewSelectDate: UIView!
    @IBOutlet weak var lblMTPStartDate: UILabel!
    @IBOutlet weak var lblMTPEndDate: UILabel!
    @IBOutlet weak var btnSelectMTPDates: UIButton!
    @IBAction func btnSelectMTPDatesTap(_ sender: UIButton) {
        self.selectMtpDate()
    }
    
    @IBOutlet weak var viewTVMTPData: UIView! 
    @IBOutlet weak var tvMtpData: UITableView! {
        didSet {
            self.tvMtpData.delegate = self
            self.tvMtpData.dataSource = self
            self.tvMtpData.register(UINib(nibName: "MtpMasterDataTVCell", bundle: nil), forCellReuseIdentifier: "MtpMasterDataTVCell")
        }
    }
    @IBOutlet weak var constraintBottomTVMtpDataToSuper: NSLayoutConstraint!
    @IBOutlet weak var btnViewPDF: UIButton!
    @IBAction func btnViewPDFTap(_ sender: UIButton) {
        if self.arrMtpMasterData?.count ?? 0 > 0 {
            guard let url = URL(string: self.arrMtpMasterData?[0].reportURL ?? "") else { return }
            UIApplication.shared.open(url)
        }
    }
    
    
    /// View Display MTP Data
    
    @IBOutlet weak var viewMTPEmpList: UIView!
    
    @IBOutlet weak var viewMTPEmpListBack: UIView!
    @IBOutlet weak var lblScreenMTPEmpListTitle: UILabel!
    @IBOutlet weak var btnMTPEmpListBack: UIButton!
    @IBAction func btnMTPEmpListBackTap(_ sender: UIButton) {
        if self.isEmpMTPDetails {
            self.isEmpMTPDetails = !self.isEmpMTPDetails
            self.viewEmpMTPDetails.isHidden = true
            self.viewMTPEmpList.isHidden = false
        }
        else {
            self.viewMain.isHidden = false
            self.viewMTPEmpList.isHidden = true
            self.viewEmpMTPDataFiler.isHidden = true
        }
    }
    
    @IBOutlet weak var viewMTPEmpListDate: UIView!
    @IBOutlet weak var lblMTPEmpListDate: UILabel!
    
    @IBOutlet weak var viewTVEmpMTP: UIView!
    @IBOutlet weak var tvEmpMTP: UITableView! {
        didSet {
            self.tvEmpMTP.delegate = self
            self.tvEmpMTP.dataSource = self
            self.tvEmpMTP.register(UINib(nibName: "EmpMTPTVCell", bundle: nil), forCellReuseIdentifier: "EmpMTPTVCell")
        }
    }
    
    
    /// View Emp MTP Details
    
    @IBOutlet weak var viewEmpMTPDetails: UIView!
    
    @IBOutlet weak var viewEmpNameDate: UIView!
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var lblDateTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblTotalDays: UILabel!
    
    @IBOutlet weak var viewEmpDetail: UIView!
    
    @IBOutlet weak var viewEmpCity: UIView!
    @IBOutlet weak var lblEmpCityTitle: UILabel!
    @IBOutlet weak var lblEmpCity: UILabel!
    
    @IBOutlet weak var viewEmpJointWorkingWith: UIView!
    @IBOutlet weak var lblEmpJointWorkingWithTitle: UILabel!
    @IBOutlet weak var lblEmpJointWorkingWith: UILabel!
    
    @IBOutlet weak var viewEmpObjectives: UIView!
    @IBOutlet weak var lblEmpObjectivesTitle: UILabel!
    @IBOutlet weak var lblEmpObjectives: UILabel!
    
    @IBOutlet weak var viewEmpRemarks: UIView!
    @IBOutlet weak var lblEmpRemarksTitle: UILabel!
    @IBOutlet weak var lblEmpRemarks: UILabel!
    
    @IBOutlet weak var viewEmpRejectReason: UIView!
    @IBOutlet weak var lblEmpRejectReasonTitle: UILabel!
    @IBOutlet weak var lblEmpRejectReason: UILabel!
    
    @IBOutlet weak var viewEmpReply: UIView!
    @IBOutlet weak var lblEmpReplyTitle: UILabel!
    @IBOutlet weak var lblEmpReply: UILabel!
    
    @IBOutlet weak var viewEmpLeave: UIView!
    @IBOutlet weak var lblEmpLeaveTitle: UILabel!
    @IBOutlet weak var lblEmpLeave: UILabel!
    @IBOutlet weak var constraintHeightViewEmpLeave: NSLayoutConstraint!
    
    @IBOutlet weak var viewEmpEstimatedCost: UIView!
    @IBOutlet weak var lblEmpEstimatedCostTitle: UILabel!
    @IBOutlet weak var lblEmpEstimatedCost: UILabel!
    
    @IBOutlet weak var lblWorkFromHomeTitle: UILabel!
    @IBOutlet weak var lblEmpStatus: UILabel!
    
    @IBOutlet weak var btnReject: UIButton!
    @IBAction func btnRejectTap(_ sender: UIButton) {
        // NM emp details edit, reject button.
        self.intIndexRejectReasonData = intIndexEmpDetails
        self.mtpMasterDataRejctReason = (self.mtpCalData?.employee?[intIndexEmpDetails])!
        self.lblRejectReasonTitle.text = "Reject Reason"
        self.isRejectTap = true
        self.isReplyTap = false
        self.viewRejectReasonPopup.isHidden = false
    }
    @IBOutlet weak var constraintTopBtnReject: NSLayoutConstraint!
    
    @IBOutlet weak var btnEdit: UIButton!
    @IBAction func btnEditTap(_ sender: UIButton) {
        // NM emp details edit, reject button.
        
        let tempEmployee = (self.mtpCalData?.employee?[intIndexEmpDetails])!
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "AddMTPVC") as! AddMTPVC
        viewController.isFromEdit = true
        
        viewController.intMtpId = tempEmployee.masterId ?? 0
        
        viewController.strSelectedStartDate = tempEmployee.startDate ?? ""
        viewController.strSelectedEndDate = tempEmployee.endDate ?? ""
        
        viewController.isForLeave = ((tempEmployee.isLeave ?? 0) == 1) ? true : false
        viewController.isLeaveFDay = ((tempEmployee.leaveType ?? "") == "Full Day") ? true : false
        viewController.isLeaveHDay = ((tempEmployee.leaveType ?? "") == "Half Day") ? true : false
        viewController.isWFH = ((tempEmployee.isWorkingFromHome ?? 0) == 1) ? true : false
        
        viewController.strCity = tempEmployee.city ?? ""
        viewController.arrSelectedWhoms = tempEmployee.whoms ?? []
        
        viewController.strObjective = tempEmployee.objectives ?? ""
        viewController.strEstimateCost = "\(tempEmployee.estimatedCost ?? 0.0)"
        viewController.strRemark = tempEmployee.remark ?? ""
        self.isEditMtp = true
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    @IBOutlet weak var constraintTrailingToSuper: NSLayoutConstraint!
    
    
    // MARK: - View reject reason
    
    @IBOutlet weak var viewRejectReasonPopup: UIView!
    @IBOutlet weak var lblRejectReasonTitle: UILabel!
    
    @IBOutlet weak var btnRejectReasonClose: UIButton!
    @IBAction func btnRejectReasonCloseTap(_ sender: UIButton) {
        self.viewRejectReasonPopup.isHidden = true
        self.txtRejectReason.text = ""
    }
    @IBOutlet weak var txtRejectReason: UITextField!
    @IBOutlet weak var btnRejectReasonDone: UIButton!
    @IBAction func btnRejectReasonDoneTap(_ sender: UIButton) {
        //self.viewRejectReasonPopup.isHidden = true
        if self.txtRejectReason.text ?? "" != "" {
            if self.isRejectTap {
                self.submitRejectReason(id: self.mtpMasterDataRejctReason?.masterId ?? 0, reply: self.txtRejectReason.text!)
            }
            else if self.isReplyTap {
                self.submitReplyMTP(id: self.mtpMasterDataRejctReason?.masterId ?? 0, reply: self.txtRejectReason.text!)
            }
        }
        else {
            var msg: String = ""
            if self.isRejectTap {
                msg = "Enter reject reson."
            }
            else if self.isReplyTap {
                msg = "Please enter comment."
            }
            Utilities.showPopup(title: "Enter reject reson.", type: .error)
        }
    }
    
    
    // View Emp MTP Data Filter
    
    @IBOutlet weak var viewEmpMTPDataFiler: UIView!
    @IBOutlet weak var viewEmpMTPDataFilerSVOut: UIView!
    @IBOutlet weak var viewEmpMTPDataFilerSVIn: UIView!
    
    @IBOutlet weak var viewEmpMTPDataFilerBack: UIView!
    
    @IBOutlet weak var btnEmpMTPDataFilterBack: UIButton!
    @IBAction func btnEmpMTPDataFilterBackTap(_ sender: UIButton) {
        self.viewMain.isHidden = false
        self.viewMTPEmpList.isHidden = true
        self.viewEmpMTPDataFiler.isHidden = true
        
        self.arrSelectedMonth.removeAll()
        self.lblEmpMtpMonthFilter.text = "Months"
        
        self.arrSelectedZone.removeAll()
        self.lblEmpMtpZoneFilter.text = "Select Zones"
        
        self.arrSelectedEmp.removeAll()
        self.lblEmpMtpEmpFilter.text = "Employees"
        
        self.arrSelectedYear.removeAll()
        self.self.filterDataResult?.data?.removeAll()
        self.tvMonthWiseFilerEmpMTPData.reloadData()
    }
    @IBOutlet weak var lblEmpMTPDataFilterScreenTitle: UILabel!
    
    @IBOutlet weak var viewEmpMtpMonthFilter: UIView!
    @IBOutlet weak var lblEmpMtpMonthFilter: UILabel!
    @IBOutlet weak var btnEmpMtpMonthFilter: UIButton!
    @IBAction func btnEmpMtpMonthFilterTap(_ sender: UIButton) {
        
        let currMonth = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).month ?? 0
        let currYear = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).year ?? 0
        
        let tempMonth: [String] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        var tempMonthYear: [String] = []
        
        for i in 0..<tempMonth.count {
            tempMonthYear.append("\(tempMonth[i]) \(currYear - 1)")
        }
        
        if currMonth < 12 {
            for j in 0..<(currMonth + 1) {
                tempMonthYear.append("\(tempMonth[j]) \(currYear)")
            }
        }
        else if currMonth == 12 {
            for k in 0..<tempMonth.count {
                tempMonthYear.append("\(tempMonth[k]) \(currYear)")
            }
            tempMonthYear.append("\(tempMonth[0]) \(currYear + 1)")
        }
        
        
        let arrTempMonthYear: [String] = tempMonthYear.map{ "\($0.replacingOccurrences(of: " ", with: "-"))" }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Month"
        popupVC.arrSelectedValue = self.arrSelectedMonth
        popupVC.isReturnValueInSeq = true
        popupVC.value = arrTempMonthYear
        popupVC.didSelectItem = { arrValue in
            
            self.arrSelectedYear.removeAll()
            self.arrSelectedMonth = arrValue
            
            if arrValue.count > 0 {
                self.lblEmpMtpMonthFilter.text = arrValue.joined(separator: ", ")
                
                for i in 0..<arrValue.count {
                    let tempValue = arrValue[i]
                    let arrTemp = tempValue.components(separatedBy: "-")
                    if !self.arrSelectedYear.contains(Int(arrTemp[1]) ?? 0) {
                        self.arrSelectedYear.append(Int(arrTemp[1]) ?? 0)
                    }
                }
            }
            else {
                self.lblEmpMtpMonthFilter.text = "Months"
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewEmpMtpZoneFilter: UIView!
    @IBOutlet weak var lblEmpMtpZoneFilter: UILabel!
    @IBOutlet weak var btnEmpMtpZoneFilter: UIButton!
    @IBAction func btnEmpMtpZoneFilterTap(_ sender: UIButton) {
        struct Zone: Codable {
            var id: Int?
            var name: String?
        }
        
        var arrZone: [Zone] = []
        arrZone.append(Zone(id: 1, name: "North"))
        arrZone.append(Zone(id: 2, name: "East"))
        arrZone.append(Zone(id: 3, name: "South"))
        arrZone.append(Zone(id: 4, name: "West"))
        
        //let arrBranch: [String] = (APIManager.sharedManager.arrBranches ?? []).map { $0.branchName! }
        let arrTempZone: [String] = arrZone.map { $0.name! }
        
        var arrTempSelectedValue: [String] = []
        for strValue in self.arrSelectedZone.enumerated() {
            let tempValue = arrZone.filter { $0.name! == strValue.element }
            if tempValue.count > 0 {
                arrTempSelectedValue.append("\(tempValue[0].name!)")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Zone"
        popupVC.value = arrTempZone
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.didSelectItem = { arrValue in
            self.arrSelectedZone.removeAll()
            var  strZone: String = ""
            for strValue in arrValue.enumerated() {
                let tempValue = arrZone.filter { $0.name! == strValue.element }
                if tempValue.count > 0 {
                    self.arrSelectedZone.append(tempValue[0].name ?? "")
                    if strZone != "" {
                        strZone = strZone + ", " + strValue.element
                    }
                    else {
                        strZone = strValue.element
                    }
                }
            }
            if strZone != "" {
                self.lblEmpMtpZoneFilter.text = strZone
            }
            else {
                self.lblEmpMtpZoneFilter.text = "Select Zones"
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var viewEmpMtpEmpFilter: UIView!
    @IBOutlet weak var lblEmpMtpEmpFilter: UILabel!
    @IBOutlet weak var btnEmpMtpEmpFilter: UIButton!
    @IBAction func btnEmpMtpEmpFilterTap(_ sender: UIButton) {
        let arrTempEmp: [String] = (self.arrMyTeamMember ?? []).map { $0.name! }
        
        var arrTempSelectedValue: [String] = []
        for strValue in self.arrSelectedEmp.enumerated() {
            let tempValue = self.arrMyTeamMember?.filter { $0.id! == strValue.element }
            if (tempValue?.count ?? 0) > 0 {
                arrTempSelectedValue.append("\(tempValue?[0].name ?? "")")
            }
        }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Employees"
        popupVC.value = arrTempEmp
        popupVC.arrSelectedValue = arrTempSelectedValue
        popupVC.didSelectItem = { arrValue in
            self.arrSelectedEmp.removeAll()
            var strEmp: String = ""
            for strValue in arrValue.enumerated() {
                let tempValue = self.arrMyTeamMember?.filter { $0.name! == strValue.element }
                if (tempValue?.count ?? 0) > 0 {
                    self.arrSelectedEmp.append(tempValue?[0].id ?? 0)
                    if strEmp != "" {
                        strEmp = strEmp + ", " + strValue.element
                    }
                    else {
                        strEmp = strValue.element
                    }
                }
            }
            if strEmp != "" {
                self.lblEmpMtpEmpFilter.text = strEmp
            }
            else {
                self.lblEmpMtpEmpFilter.text = "Employees"
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var btnEmpMtpFilterSubmit: UIButton!
    @IBAction func btnEmpMtpFilterSubmitTap(_ sender: UIButton) {
        if self.arrSelectedMonth.count > 0 {
            self.getMtpDetailsFilter(zone: self.arrSelectedZone, month: self.arrSelectedMonth, year: self.arrSelectedYear, empIds: self.arrSelectedEmp, intPdf: 0)
        }
        else {
            Utilities.showPopup(title: "Select month(s).", type: .error)
        }
    }
    
    @IBOutlet weak var viewEmpMTPDataFilerTV: UIView!
    @IBOutlet weak var tvMonthWiseFilerEmpMTPData: UITableView! {
        didSet {
            self.tvMonthWiseFilerEmpMTPData.delegate = self
            self.tvMonthWiseFilerEmpMTPData.dataSource = self
            self.tvMonthWiseFilerEmpMTPData.register(UINib(nibName: "EmpMTPDataFilerMonthTVCell", bundle: nil), forCellReuseIdentifier: "EmpMTPDataFilerMonthTVCell")
        }
    }
    
    
    // MARK: - Variable
    
    var strScreenTitle: String = "MTP"
    let todayComponents = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date())
    var curMonth: Int = 0
    var curYear: Int = 0
    
    let selectedComponents = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date())
    var selectedMonth: Int = 0
    var selectedYear: Int = 0
    
    var arrMtpCalData: [MTPCalendarData]? = []
    
    var arrMonthYear: [String] = {
        let tempYear = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).year ?? 0
        
        let tempMonth: [String] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        var tempMonthYear: [String] = []
        
        for i in (0..<2).reversed() {
            for j in 0..<tempMonth.count {
                tempMonthYear.append("\(tempMonth[j]) \(tempYear - i)")
            }
        }
        return tempMonthYear
    }()
    
    
    
    /// View Display MTP Data
    
    var mtpCalData: MTPCalendarData?
    
    
    /// View Emp MTP Details
    
    var isEmpMTPDetails: Bool = false
    var intIndexEmpDetails: Int = 0
    
    var isBtnEditVisible: Bool = false
    var isBtnRejectVisible: Bool = false
    
    var arrMtpMasterData: [Employee]? = []
    
    var strSelectedStartDate: String = ""
    var strSelectedEndDate: String = ""
    
    private lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter
    }()
    
    /// View reject reason
    
    var mtpMasterDataRejctReason: Employee? = Employee()
    var intIndexRejectReasonData: Int = -1
    var isReplyTap: Bool = false
    var isRejectTap: Bool = false
    
    /// View Emp MTP Data Filter
    
    var isViewEmpMtpEmpFilter: Bool = false
    var arrSelectedMonth: [String] = []
    var arrSelectedYear: [Int] = []
    var arrSelectedZone: [String] = []
    var arrSelectedEmp: [Int] = []
    
    var filterDataResult: DataResult?
    var arrMyTeamMember: [TeamMember]? = []
    
    var isEditMtp: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblMTPStartDate.textColor = Colors.gray.returnColor()
        self.lblMTPEndDate.textColor = Colors.gray.returnColor()
        
        self.btnViewPDF.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnViewPDF.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 0.8)
        
        self.constraintBottomTVMtpDataToSuper.priority = .required
        
        self.viewMTPEmpList.isHidden = true
        self.viewEmpMTPDetails.isHidden = true
        self.viewEmpMTPDataFiler.isHidden = true
        
        self.lblDateTitle.textColor = Colors.theme.returnColor()
        self.lblDate.textColor = Colors.theme.returnColor()
        self.lblTotalDays.textColor = Colors.theme.returnColor()
        
        self.lblEmpEstimatedCostTitle.textColor = Colors.theme.returnColor()
        self.lblEmpEstimatedCost.textColor = Colors.theme.returnColor()
        
        self.lblEmpStatus.textColor = Colors.themeRed.returnColor()
        
        self.viewRejectReasonPopup.isHidden = true
        
        self.viewEmpCity.addBorders(edges: [.all], color: Colors.theme.returnColor())
        self.viewEmpJointWorkingWith.addBorders(edges: [.all], color: Colors.theme.returnColor())
        self.viewEmpObjectives.addBorders(edges: [.all], color: Colors.theme.returnColor())
        self.viewEmpRemarks.addBorders(edges: [.all], color: Colors.theme.returnColor())
        self.viewEmpRejectReason.addBorders(edges: [.all], color: Colors.theme.returnColor())
        self.viewEmpReply.addBorders(edges: [.all], color: Colors.theme.returnColor())
        self.viewEmpLeave.addBorders(edges: [.all], color: Colors.theme.returnColor())
        self.viewEmpEstimatedCost.addBorders(edges: [.all], color: Colors.theme.returnColor())
        
        self.lblEmpCityTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        self.lblEmpJointWorkingWithTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        self.lblEmpObjectivesTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        self.lblEmpRemarksTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        self.lblEmpRejectReasonTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        self.lblEmpReplyTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        self.lblEmpLeaveTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        self.lblEmpEstimatedCostTitle.addBorders(edges: [.right], color: Colors.theme.returnColor())
        
        self.btnReject.isHidden = true
        self.btnReject.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnReject.cornersWFullBorder(radius: 5, borderColor: .black, colorOpacity: 0.8)
        
        self.btnEdit.isHidden = true
        self.btnEdit.setTitleColor(Colors.theme.returnColor(), for: .normal)
        self.btnEdit.cornersWFullBorder(radius: 5, borderColor: .black, colorOpacity: 0.8)
        
        self.lblEmpStatus.isHidden = true
        self.constraintTopBtnReject.priority = .required
        
        self.curMonth = self.todayComponents.month ?? 0
        self.curYear = self.todayComponents.year ?? 0
        
        self.btnEmpMTPDataFilter.tintColor = Colors.gray.returnColor()
        
        self.lblMonthYear.text = "\(MTP.Month(self.curMonth)) \(self.curYear)"
        
        if APIManager.sharedManager.userDetail?.roleId == 2 {
            self.viewCalendar.isHidden = true
            self.viewDisplayMTPData.isHidden = false
            DispatchQueue.main.async {
                self.selectMtpDate()
            }
        }
        else {
            self.viewCalendar.isHidden = false
            self.viewDisplayMTPData.isHidden = true
            self.getMtpDetailsOnCalenderView(intMonth: self.curMonth, intYear: self.curYear)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if self.isEditMtp {
            self.isEditMtp = false
            self.getMtpMasterData(startDate: self.strSelectedStartDate, endDate: self.strSelectedEndDate)
        }
    }
}


// MARK: - Pick date(s)...

extension MonthlyTourPlanVC {
    
    func selectMtpDate() {
        self.dateFormatter.calendar = .current
        let tempComponen = Calendar.current.dateComponents([.day, .month, .year], from: Date())
        let tempStrStartDate = "01/Jan/\(tempComponen.year ?? 0)"
        let tempStrEndDate = "31/Dec/\(tempComponen.year ?? 0)"
        
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale.current
        dateFormatter.dateFormat = "dd/MMM/yyyy" //  Current Date Format
        
        let tempStartDate = dateFormatter.date(from: tempStrStartDate)!
        let tempEndDate = dateFormatter.date(from: tempStrEndDate)!
        
        let fastisController = FastisController(mode: .range)
        fastisController.title = "Choose range"
        fastisController.initialValue = nil     //self.currentValue as? FastisRange
        fastisController.minimumDate = Calendar.current.date(byAdding: .month, value: 0, to: tempStartDate)
        fastisController.maximumDate = Calendar.current.date(byAdding: .month, value: 0, to: tempEndDate)
        fastisController.allowToChooseNilDate = false
        //fastisController.shortcuts = [.today, .lastWeek, .lastMonth]
        
        fastisController.doneHandler = { action in
            switch action {
            case .some(let newValue):
                //self.currentValue = newValue
                //print("\(newValue.fromDate) -- \(newValue.toDate)")
                self.getMtpData(startDate: newValue.fromDate, endDate: newValue.toDate)
            case .none:
                print("any actions")
            }
        }
        fastisController.present(above: self)
    }
    
    func getMtpData(startDate: Date, endDate: Date) {
        
        let dateFormatter = DateFormatter()
        //dateFormatter.dateFormat = "yyyy-MM-dd hh:mm:ss Z"
        dateFormatter.dateFormat = "dd MMM yyyy"
        self.lblMTPStartDate.text = dateFormatter.string(from: startDate)
        self.lblMTPEndDate.text = dateFormatter.string(from: endDate)
        
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        self.strSelectedStartDate = dateFormatter.string(from: startDate)
        self.strSelectedEndDate = dateFormatter.string(from: endDate)
        
        self.getMtpMasterData(startDate: self.strSelectedStartDate, endDate: self.strSelectedEndDate)
    }
}
