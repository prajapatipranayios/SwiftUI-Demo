//
//  CategoryCVCell.swift
//  GE Sales
//
//  Created by Auxano on 16/04/24.
//

import UIKit

class CategoryCVCell: UICollectionViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var imgCategory: UIImageView!
    @IBOutlet weak var lblCount: UILabel!
    @IBOutlet weak var lblCategoryName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.viewMain.layer.cornerRadius = 25
        self.viewMain.layer.borderWidth = 1
        self.viewMain.layer.borderColor = UIColor(hexString: "#000000", alpha: 0.09).cgColor
        self.viewMain.clipsToBounds = true
    }

}
