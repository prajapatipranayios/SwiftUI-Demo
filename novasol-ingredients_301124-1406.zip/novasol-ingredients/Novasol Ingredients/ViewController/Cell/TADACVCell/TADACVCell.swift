//
//  TADACVCell.swift
//  GE Sales
//
//  Created by Auxano on 17/04/24.
//

import UIKit

class TADACVCell: UICollectionViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTaDaName: UILabel!
    @IBOutlet weak var lblTaDaFName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
