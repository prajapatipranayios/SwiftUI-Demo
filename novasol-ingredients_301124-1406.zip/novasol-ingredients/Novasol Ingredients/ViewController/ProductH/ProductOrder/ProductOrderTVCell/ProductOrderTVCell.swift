//
//  ProductOrderTVCell.swift
//  GE Sales
//
//  Created by Auxano on 24/04/24.
//

import UIKit

class ProductOrderTVCell: UITableViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblOrderStatus: UILabel!
    @IBOutlet weak var lblQty: UILabel!
    @IBOutlet weak var lblQtyValue: UILabel!
    @IBOutlet weak var lblAt: UILabel!
    @IBOutlet weak var lblBasePrice: UILabel!
    @IBOutlet weak var lblReQty: UILabel!
    @IBOutlet weak var lblReQtyValue: UILabel!
    @IBOutlet weak var lblUserDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.viewMain.layer.borderWidth = 1
        self.viewMain.layer.borderColor = UIColor.black.cgColor
        self.viewMain.layer.cornerRadius = 14
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
