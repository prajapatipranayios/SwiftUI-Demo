//
//  ProductOrderVC.swift
//  GE Sales
//
//  Created by Auxano on 24/04/24.
//

import UIKit

class ProductOrderVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        if self.isFromAddOrder {
            self.dismiss(animated: true) {
                if self.onCloseTap != nil {
                    self.onCloseTap!(true)
                }
            }
        }
        else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    @IBOutlet weak var viewTblOrders: UIView!
    @IBOutlet weak var tvOrders: UITableView!
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    // MARK: - Variables
    
    var strScreenTitle: String = "Sales Order"
    var productId: Int = 0
    var page: Int = 1
    var lastPage: Int = 1
    var isLoadMore: Bool = false
    var productOrders: OrderDetail?
    var productData: [ProductData]?
    
    // Present From Add Sales Order
    var isFromAddOrder: Bool = false
    var onCloseTap:((Bool)->Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.tvOrders.delegate = self
        self.tvOrders.dataSource = self
        
        self.tvOrders.register(UINib(nibName: "ProductOrderTVCell", bundle: nil), forCellReuseIdentifier: "ProductOrderTVCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.getProductOrder(page: self.page)
        
        self.lblNoData.text = "No Data Found"
    }
}

extension ProductOrderVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.productData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductOrderTVCell", for: indexPath) as! ProductOrderTVCell
        DispatchQueue.main.async {
            cell.lblProductName.text = self.productData?[indexPath.row].businessPartnerName ?? ""
            cell.lblOrderStatus.text = "(\(OrderStatus.getStatusTitle(status: self.productData?[indexPath.row].orderStatus ?? 0)))"
            cell.lblOrderStatus.textColor = OrderStatus.getStatusColor(status: self.productData?[indexPath.row].orderStatus ?? 0)
            cell.lblQtyValue.text = "\(self.productData?[indexPath.row].productQty ?? 0)"
            cell.lblBasePrice.text = "₹\(self.productData?[indexPath.row].productPrice ?? 0), Base Price: \(self.productData?[indexPath.row].productBasicPrice ?? 0)"
            cell.lblReQtyValue.text = "\(self.productData?[indexPath.row].remainingQty ?? 0)"
            cell.lblUserDate.text = "by \(self.productData?[indexPath.row].userName ?? "") on \(self.productData?[indexPath.row].orderDate ?? "")"
            
            cell.lblQtyValue.font = UIFont(name: "Roboto-Bold", size: 15)
            cell.lblBasePrice.font = UIFont(name: "Roboto-Bold", size: 15)
            cell.lblReQtyValue.font = UIFont(name: "Roboto-Bold", size: 15)
            
            if self.page < self.lastPage {
                if (indexPath.row >= (self.productData?.count ?? 0) - 3) && !self.isLoadMore {
                    self.isLoadMore = true
                    self.page += 1
                    self.getProductOrder(page: self.page)
                }
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 98
    }
}

// MARK: - Webservices

extension ProductOrderVC {
    func getProductOrder(page: Int = 1) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getProductOrder(page: page)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId, //  85,
            "product_id": self.productId,
            "page": page
        ] as? [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.PRODUCT_ORDER, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    var tempProductOrders: OrderDetail?
                    tempProductOrders = (response?.result?.orderDetail)!
                    self.lastPage = tempProductOrders?.lastPage ?? 1
                    
                    if !self.isLoadMore {
                        self.productOrders = tempProductOrders
                        self.productData = tempProductOrders?.data ?? []
                    }
                    else {
                        self.productData?.append(contentsOf: tempProductOrders?.data ?? [])
                    }
                    self.tvOrders.reloadData()
                    self.isLoadMore = false
                    
                    if (self.productData?.count ?? 0) <= 0 {
                        self.viewNoData.isHidden = false
                    }
                    else {
                        self.viewNoData.isHidden = true
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
                self.page -= 1
                self.isLoadMore = false
            }
        }
    }
}
