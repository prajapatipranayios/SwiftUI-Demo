//
//  ProductCategoryVC_Extension.swift
//  GE Sales
//
//  Created by Auxano on 22/04/24.
//

import Foundation
import UIKit


// MARK: - UITableView Delegate, Datasource

extension ProductCategoryVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.categoryList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCategoryTVCell", for: indexPath) as! ProductCategoryTVCell
        
        cell.lblCategory.text = self.categoryList?[indexPath.row].name ?? ""
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.isFromAddOrder {
            let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductListVC") as! ProductListVC
            popupVC.modalPresentationStyle = .overCurrentContext
            popupVC.modalTransitionStyle = .crossDissolve
            popupVC.isFromAddOrder = true
            popupVC.intCategoryId = self.categoryList?[indexPath.row].categoryId ?? 0
            popupVC.strScreenTitle = self.strScreenTitle
            popupVC.arrSelectedProductList = self.arrSelectedProductList
            popupVC.strFrom = self.strFrom
            popupVC.onCellTap = { isSelect, arrProductList in
                if isSelect {
                    self.dismiss(animated: false) {
                        if self.onCellTap != nil {
                            self.onCellTap!(true, arrProductList)
                        }
                    }
                }
                else {
                    self.arrSelectedProductList = arrProductList
                }
            }
            self.present(popupVC, animated: true, completion: nil)
        }
        else {
            let sb = UIStoryboard(name: "Main", bundle: nil)
            let vc = sb.instantiateViewController(withIdentifier: "ProductListVC") as! ProductListVC
            vc.intCategoryId = self.categoryList?[indexPath.row].categoryId ?? 0
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
}

// MARK: - Webservices

extension ProductCategoryVC {
    func getProductCategories() {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getProductCategories()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": companyType
        ]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_PRODUCT_CATEGORIES, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.categoryList = response?.result?.categoryList ?? []
                    self.tvProductCategoryList.reloadData()
                    
                    self.viewNoData.isHidden = true
                    self.lblNoData.text = response?.message ?? ""
                    
                    if (self.categoryList?.count ?? 0) == 0 {
                        self.viewNoData.isHidden = false
                        self.lblNoData.text = "Data not found."
                    }
                }
            }
            else {
                //Utilities.showPopup(title: response?.message ?? "", type: .error)
                DispatchQueue.main.async {
                    self.viewNoData.isHidden = false
                    self.lblNoData.text = response?.message ?? ""
                }
            }
        }
    }
}
