//
//  ProductListTVCell.swift
//  GE Sales
//
//  Created by Auxano on 23/04/24.
//

import UIKit

class ProductListTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblCategoryName: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    @IBOutlet weak var constraintLeadingName: NSLayoutConstraint!
    
    @IBOutlet weak var btnSelectProduct: UIButton!
    @IBAction func btnSelectProductTap(_ sender: UIButton) {
        if self.onSelect != nil {
            self.onSelect!(index)
        }
    }
    
    // MARK: - Variable
    
    var index: Int = 0
    var onSelect:((Int)->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.lblSeparator.backgroundColor = Colors.separator.returnColor()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
