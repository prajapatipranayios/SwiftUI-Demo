//
//  ProductCategoryTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/06/24.
//

import UIKit

class ProductCategoryTVCell: UITableViewCell {

    // MARK: Outlet
    
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    
    // MARK: - Variable
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.lblSeparator.backgroundColor = Colors.separator.returnColor()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }

}
