//
//  ProductCategoryVC.swift
//  GE Sales
//
//  Created by Auxano on 22/04/24.
//

import UIKit

class ProductCategoryVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        if self.isFromAddOrder {
            self.dismiss(animated: true) {
                if self.onCellTap != nil {
                    self.onCellTap!(false, nil)
                }
            }
        }
        else {
            revealViewController()?.revealSideMenu()
        }
    }
    @IBOutlet weak var btnInfo: UIButton!
    @IBAction func btnInfoTap(_ sender: UIButton) {
    }
    
    @IBOutlet weak var lblScreenTitle: UILabel!
    
    @IBOutlet weak var tvProductCategoryList: UITableView!{
        didSet {
            self.tvProductCategoryList.dataSource = self
            self.tvProductCategoryList.delegate = self
            self.tvProductCategoryList.register(UITableViewCell.self, forCellReuseIdentifier: "ProductCategoryVC")
        }
    }
    @IBOutlet weak var viewCategorySearch: UIView!
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    
    // MARK: - Variables
    
    var strScreenTitle: String = "Products Category"
    var companyType: Int? = APIManager.sharedManager.companyType ?? 1
    var categoryList: [CategoryList]?
    
    // Present From Add Sales Order
    var isFromAddOrder: Bool = false
    var onCellTap:((Bool, [ProductList]?)->Void)?
    var arrSelectedProductList: [ProductList]? = []
    var isFromSalesOrder: Bool = false
    var isFromSampleOrder: Bool = false
    var strFrom: String = "Sales"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        if self.isFromSalesOrder {
            self.strFrom = "Sales"
        }
        else if self.isFromSampleOrder {
            self.strFrom = "Sample"
        }
        
        self.viewNoData.isHidden = true
        
        self.getProductCategories()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        
        if self.isFromAddOrder {
            self.btnSideMenu.setImage(UIImage(named: "Back"), for: .normal)
        }
        else {
            self.btnSideMenu.setImage(UIImage(named: "Sidemenu"), for: .normal)
        }
    }
}
