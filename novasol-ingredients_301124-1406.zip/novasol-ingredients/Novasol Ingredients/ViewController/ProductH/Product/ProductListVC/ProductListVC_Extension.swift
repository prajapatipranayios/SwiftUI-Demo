//
//  ProductListVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/06/24.
//

import Foundation
import UIKit

// MARK: - SearchBar Delegate

extension ProductListVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        if searchText != "" {
            self.getProductList(searchText: searchText, categoryId: self.intCategoryId)
        }
        else {
            self.getProductList(categoryId: self.intCategoryId)
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
        self.searchBar.text = ""
        self.getProductList(categoryId: self.intCategoryId)
    }
}

// MARK: - UITableView Delegate, Datasource

extension ProductListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.productList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductListTVCell", for: indexPath) as! ProductListTVCell
        
        cell.index = indexPath.row
        
        cell.lblName.text = self.productList?[indexPath.row].name ?? ""
        cell.lblName.textColor = Colors.theme.returnColor()

        var categoryName = ""
        if self.productList?[indexPath.row].categoryName ?? "" != "" {
            categoryName = "(\(self.productList?[indexPath.row].categoryName ?? "")) "
        }
        
        if self.productList?[indexPath.row].remark ?? "" != "" {
            categoryName = categoryName + "(\(self.productList?[indexPath.row].remark ?? ""))"
        }
        cell.lblCategoryName.text = categoryName
        
        cell.onSelect = { index in
            if (self.productList?[indexPath.row].tax ?? 0 == 0) && (self.productList?[indexPath.row].isNill ?? 0 == 0) {
                Utilities.showPopup(title: "You can not place an order for this product,\nthe GST Code is not available.\nPlease contact Admin.", type: .error)
            }
            else {
                self.onSelectCell(index: index)
            }
        }
        
        cell.constraintLeadingName.priority = .required
        cell.btnSelectProduct.isHidden = true
        
        if self.isFromAddOrder {
            if self.strFrom == "Sales" {
                cell.btnSelectProduct.isHidden = false
                cell.constraintLeadingName.priority = .defaultLow
                
                if (self.arrSelectedProductId ?? []).contains("\(self.productList?[indexPath.row].id ?? 0)") {
                    cell.btnSelectProduct.isSelected = true
                    cell.tintColor = Colors.themeGreen.returnColor()
                }
                else {
                    cell.btnSelectProduct.isSelected = false
                    cell.tintColor = Colors.gray.returnColor()
                }
            }
        }
        
        if self.hasMore ?? false {
            if (indexPath.row >= (self.productList?.count ?? 0) - 3) && !self.isLoadMore {
                self.isLoadMore = true
                self.page += 1
                self.getProductList(page: self.page, categoryId: self.intCategoryId)
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if self.isFromAddOrder {
            if self.strFrom == "Sample" {
                if !((self.arrSelectedProductId ?? []).contains("\(self.productList?[indexPath.row].id ?? 0)")) {
                    //self.arrSelectedProductId?.append("\(self.productList?[indexPath.row].id ?? 0)")
                    self.arrSelectedProductList?.append((self.productList?[indexPath.row])!)
                    
                    DispatchQueue.main.async {
                        self.dismiss(animated: true) {
                            if self.onCellTap != nil {
                                self.onCellTap!(true, self.arrSelectedProductList)
                            }
                        }
                    }
                }
                else {
                    Utilities.showPopup(title: "This product already added", type: .error)
                }
            }
        }
        else {
            let sb = UIStoryboard(name: "Main", bundle: nil)
            let vc = sb.instantiateViewController(withIdentifier: "ProductDetailsVC") as! ProductDetailsVC
            vc.productDetails = self.productList?[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    func onSelectCell(index: Int) {
        
        if self.isFromAddOrder {
            if self.strFrom == "Sales" {
                if !((self.arrSelectedProductId ?? []).contains("\(self.productList?[index].id ?? 0)")) {
                    self.arrSelectedProductId?.append("\(self.productList?[index].id ?? 0)")
                    self.arrSelectedProductList?.append((self.productList?[index])!)
                }
                else {
                    for i in 0 ..< (self.arrSelectedProductId?.count ?? 0) {
                        if "\(self.productList?[index].id ?? 0)" == (self.arrSelectedProductId?[i] ?? "") {
                            self.arrSelectedProductId?.remove(at: i)
                            self.arrSelectedProductList?.remove(at: i)
                            break
                        }
                    }
                }
                self.tvProductList.reloadData()
            }
            else if self.strFrom == "Sample" {
                
            }
        }
    }
}


// MARK: - TextField Delegate

extension ProductListVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        textField.text = textField.text?.trimmedString
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.trimmedString
        
    }
    
    func checkValidation(to: Int, from: Int) -> Bool {
        var value = true
        for i in to..<from {
            if i == 0 {
                self.txtProductName.text = self.txtProductName.text?.trimmingCharacters(in: .whitespaces)
                if self.txtProductName.text == "" {
                    self.lblErrorProductName.setEmptyValidationStringNoPrefix("Please \((self.txtProductName.placeholder ?? "").lowercased())")
                    value = false
                }
                else {
                    self.lblErrorProductName.text = ""
                }
            }
            else if i == 1 {
                self.txtProductDescription.text = self.txtProductDescription.text?.trimmingCharacters(in: .whitespaces)
                /*if self.txtProductDescription.text == "" {
                    self.lblErrorReferenceName.getEmptyValidationString((self.txtProductDescription.placeholder ?? "").lowercased())
                    value = false
                }
                else {
                    self.lblErrorReferenceName.text = ""
                }*/
            }
            else if i == 2 {
                self.txtProductNote.text = self.txtProductNote.text?.trimmingCharacters(in: .whitespaces)
                if self.txtProductNote.text == "" {
                    self.lblErrorProductNote.setEmptyValidationStringNoPrefix("Please \((self.txtProductNote.placeholder ?? "").lowercased())")
                    value = false
                }
                else {
                    self.lblErrorProductNote.text = ""
                }
            }
        }
        return value
    }
}


// MARK: - Keyboard

extension ProductListVC {
    func checkKeyboard(kView: UIView) {
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        //view.addGestureRecognizer(tap)
        kView.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard() {
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            //self.constraintBottomBSheet.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            //self.constraintBottomTVProductList.constant = keyboardOverlap > 0 ? (keyboardOverlap - 85) : 0
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
}


// MARK: - Webservices

extension ProductListVC {
    func getProductList(page: Int = 1, searchText: String = "", categoryId: Int) {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getProductList(searchText: searchText, categoryId: categoryId)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "company_type": companyType ?? 1,
            "search_value": searchText,
            "page": page,
            "category_id": categoryId,
            "is_visible_other": 1
        ] as? [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_PRODUCT_LIST, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            DispatchQueue.main.async {
                if response?.status == 1 {
                    
                    //print("Get response. -- \(response?.result?.productList ?? [])")
                    var tempProductList: [ProductList]?
                    tempProductList = (response?.result?.productList)!
                    self.hasMore = response?.result?.hasMore ?? false
                    
                    if !self.isLoadMore {
                        self.productList = tempProductList
                    }
                    else {
                        self.productList?.append(contentsOf: tempProductList!)
                    }
                    self.isLoadMore = false
                    self.tvProductList.reloadData()
                    
                    if (self.productList?.count ?? 0) < 1 {
                        self.viewNoData.isHidden = false
                        self.lblNoData.text = response?.message ?? ""
                    }
                    else {
                        self.viewNoData.isHidden = true
                        self.lblNoData.text = response?.message ?? ""
                    }
                    
                }
                else {
                    self.isLoadMore = self.isLoadMore ? false : false
                    self.page -= 1
                    //Utilities.showPopup(title: response?.message ?? "", type: .error)
                    self.viewNoData.isHidden = false
                    self.lblNoData.text = response?.message ?? ""
                }
            }
        }
    }
    
    func addOtherProduct() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.addOtherProduct()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "name": self.txtProductName.text ?? "",
            "product_note": self.txtProductNote.text ?? "",
            "remark": self.txtProductDescription.text ?? "",
            "company_type": companyType ?? 1
        ] as? [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.ADD_OTHER_PRODUCT, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrSelectedProductList?.append((response?.result?.newProduct)!)
                    
                    DispatchQueue.main.async {
                        self.dismiss(animated: true) {
                            if self.onCellTap != nil {
                                self.onCellTap!(true, self.arrSelectedProductList)
                            }
                        }
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
}
