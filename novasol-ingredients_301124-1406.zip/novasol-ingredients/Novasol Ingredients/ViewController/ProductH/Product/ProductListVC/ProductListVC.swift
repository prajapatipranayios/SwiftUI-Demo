//
//  ProductListVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 05/06/24.
//

import UIKit

class ProductListVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBackTap(_ sender: UIButton) {
        if self.isFromAddOrder {
            self.dismiss(animated: true) {
                if self.onCellTap != nil {
                    self.onCellTap!(false, self.arrSelectedProductList)
                }
            }
        }
        else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    @IBOutlet weak var btnAdd: UIButton!
    @IBAction func btnAddTap(_ sender: UIButton) {
        if (self.arrSelectedProductList?.count ?? 0) > 0 {
            self.dismiss(animated: true) {
                if self.onCellTap != nil {
                    self.onCellTap!(true, self.arrSelectedProductList)
                }
            }
        }
    }
    
    @IBOutlet weak var lblScreenTitle: UILabel!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var viewBtnAddOther: UIView!
    @IBOutlet weak var btnAddOther: UIButton!
    @IBAction func btnAddOtherTap(_ sender: UIButton) {
        self.viewAddOtherProduct.isHidden = false
    }
    
    @IBOutlet weak var viewProductList: UIView!
    @IBOutlet weak var tvProductList: UITableView!{
        didSet {
            self.tvProductList.dataSource = self
            self.tvProductList.delegate = self
            self.tvProductList.register(UINib(nibName: "ProductListTVCell", bundle: nil), forCellReuseIdentifier: "ProductListTVCell")
        }
    }
    @IBOutlet weak var constraintTopViewProductListToSearchBar: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewAddOtherProduct: UIView!
    
    @IBOutlet weak var btnCloseAddOtherProduct: UIButton!
    @IBAction func btnCloseAddOtherProductTap(_ sender: UIButton) {
        self.viewAddOtherProduct.isHidden = true
        self.txtProductName.text = ""
        self.txtProductDescription.text = ""
        self.txtProductNote.text = ""
    }
    @IBOutlet weak var lblViewPopupTitle: UILabel!
    @IBOutlet weak var txtProductName: TLTextField!
    @IBOutlet weak var lblErrorProductName: UILabel!
    @IBOutlet weak var txtProductDescription: TLTextField!
    @IBOutlet weak var txtProductNote: TLTextField!
    @IBOutlet weak var lblErrorProductNote: UILabel!
    @IBOutlet weak var btnOtherSampleSubmit: UIButton!
    @IBAction func btnOtherSampleSubmitTap(_ sender: UIButton) {
        //self.viewAddOtherProduct.isHidden = true
        if self.checkValidation(to: 0, from: 3) {
            self.addOtherProduct()
        }
    }
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    
    // MARK: - Variables
    
    var strScreenTitle: String = "Products"
    var companyType: Int? = APIManager.sharedManager.companyType ?? 1
    var productList: [ProductList]?
    var hasMore: Bool?
    var isLoadMore: Bool = false
    var intCategoryId: Int = 0
    var page: Int = 1
    
    // Present From Add Sales Order
    var isFromAddOrder: Bool = false
    var onCellTap:((Bool, [ProductList]?)->Void)?
    var arrSelectedProductId: [String]? = []
    var arrSelectedProductList: [ProductList]? = []
    var strFrom: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.searchBar.delegate = self
        self.searchBar.showsCancelButton = true
        self.searchBar.enablesReturnKeyAutomatically = true
        
        self.constraintTopViewProductListToSearchBar
            .priority = .required
        
        self.viewAddOtherProduct.isHidden = true
        self.viewAddOtherProduct.clipsToBounds = true
        
        self.viewNoData.isHidden = true
        
        //self.checkKeyboard(kView: viewMain)
        //self.checkKeyboard(kView: tvProductList)
        self.checkKeyboard(kView: viewAddOtherProduct)
        
        self.btnOtherSampleSubmit.corners(radius: 14.0)
        self.btnOtherSampleSubmit.setTitleColor(.white, for: .normal)
        self.btnOtherSampleSubmit.backgroundColor = Colors.theme.returnColor()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        self.page = 1
        if self.productList?.count ?? 0 > 0 {
            let topRow = IndexPath(row: 0, section: 0)
            self.tvProductList.scrollToRow(at: topRow, at: .top, animated: false)
        }
        self.getProductList(page: self.page, categoryId: self.intCategoryId)
        
        if self.isFromAddOrder {
            self.arrSelectedProductId = (self.arrSelectedProductList ?? []).map{ String($0.id!) }
            self.btnAdd.tintColor = Colors.theme.returnColor()
            
            if self.strFrom == "Sales" {
                self.btnAdd.isHidden = false
            }
            else if self.strFrom == "Sample" {
                self.btnAdd.isHidden = true
                self.constraintTopViewProductListToSearchBar
                    .priority = .defaultLow
            }
        }
    }
}
