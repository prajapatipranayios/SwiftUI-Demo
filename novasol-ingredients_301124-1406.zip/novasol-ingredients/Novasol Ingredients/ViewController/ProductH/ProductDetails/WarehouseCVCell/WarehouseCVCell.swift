//
//  WarehouseCVCell.swift
//  GE Sales
//
//  Created by Auxano on 24/04/24.
//

import UIKit

class WarehouseCVCell: UICollectionViewCell {

    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var lblValue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.lblValue.textColor = Colors.theme.returnColor()
        self.viewMain.layer.borderWidth = 0.5
        self.viewMain.layer.borderColor = UIColor(hexString: "#A1A1A1", alpha: 1.0).cgColor
    }

}
