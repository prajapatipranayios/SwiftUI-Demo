//
//  ProductDetailsVC.swift
//  GE Sales
//
//  Created by Auxano on 23/04/24.
//

import UIKit

class ProductDetailsVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var lblScreenTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBAction func btnBaackTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var viewProductDetails: UIView!
    @IBOutlet weak var viewProductDetails2: UIView!
    
    @IBOutlet weak var viewImg: UIView!
    @IBOutlet weak var viewImgBg: UIView!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    
    @IBOutlet weak var lblItemCodeTitle: UILabel!
    @IBOutlet weak var lblItemCode: UILabel!
    @IBOutlet weak var lblItemCodeSeparatorTop: UILabel!
    @IBOutlet weak var lblItemCodeSeparator: UILabel!
    
    @IBOutlet weak var lblHSNCodeTitle: UILabel!
    @IBOutlet weak var lblHSNCode: UILabel!
    @IBOutlet weak var lblHSNCodeSeparator: UILabel!
    
    @IBOutlet weak var lblDescriTitle: UILabel!
    @IBOutlet weak var lblDescri: UILabel!
    @IBOutlet weak var lblDescriSeparator: UILabel!
    
    @IBOutlet weak var lblGSTTitle: UILabel!
    @IBOutlet weak var lblGST: UILabel!
    @IBOutlet weak var lblGSTSeparator: UILabel!
    
    @IBOutlet weak var lblItemGrpTitle: UILabel!
    @IBOutlet weak var lblItemGrp: UILabel!
    @IBOutlet weak var lblItemGrpSeparator: UILabel!
    
    @IBOutlet weak var lblQtyInKG: UILabel!
    
    @IBOutlet weak var viewWarehouse: UIView!
    @IBOutlet weak var colleWarehouse: UICollectionView! {
        didSet {
            self.colleWarehouse.delegate = self
            self.colleWarehouse.dataSource = self
            self.colleWarehouse.register(UINib(nibName: "WarehouseCVCell", bundle: nil), forCellWithReuseIdentifier: "WarehouseCVCell")
        }
    }
    @IBOutlet weak var constraintHeightWarehouseView: NSLayoutConstraint!
    @IBOutlet weak var viewViewOrders: UIView!
    @IBOutlet weak var btnViewOrders: UIButton!
    @IBAction func btnViewOrdersTap(_ sender: UIButton) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "ProductOrderVC") as! ProductOrderVC
        vc.productId = productDetails?.id ?? 0
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    // MARK: - Variable
    
    var strScreenTitle: String = "Product Details"
    var productDetails: ProductList?
    var rowHeaders: [String] = ["Warehouse", "Phy. Stock", "SO Commited", "Available"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.lblScreenTitle.text = strScreenTitle.capitalized
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        self.lblPrice.textColor = Colors.theme.returnColor()
        self.lblItemCodeTitle.textColor = Colors.theme.returnColor()
        self.lblHSNCodeTitle.textColor = Colors.theme.returnColor()
        self.lblDescriTitle.textColor = Colors.theme.returnColor()
        self.lblGSTTitle.textColor = Colors.theme.returnColor()
        self.lblItemGrpTitle.textColor = Colors.theme.returnColor()
        self.lblQtyInKG.textColor = Colors.theme.returnColor()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.lblName.text = self.productDetails?.name ?? ""
        
        var category = self.productDetails?.categoryName ?? ""
        if category != "" {
            category = "(\(category))"
        }
        if (self.productDetails?.remark ?? "") != "" {
            category = category + "(\(self.productDetails?.remark ?? ""))"
        }
        self.lblCategory.text = category
        let price = "\(Double(self.productDetails?.unitPrice ?? 0))"
        self.lblPrice.text = "₹ \(price.curFormatAsRegion()) / \(self.productDetails?.productUnit ?? "")"
        self.lblItemCode.text = self.productDetails?.productCode ?? ""
        self.lblHSNCode.text = self.productDetails?.hsnNumber ?? ""
        
        var desc = self.productDetails?.description ?? ""
        if desc == "" {
            desc = "-"
        }
        self.lblDescri.text = desc
        self.lblGST.text = "\(self.productDetails?.tax ?? 0)"
        self.lblItemGrp.text = self.productDetails?.categoryName ?? ""
        
        self.constraintHeightWarehouseView.constant = CGFloat(((self.productDetails?.productWarehouse?.count ?? 0) + 1) * 40)
    }
}

// MARK: UICollectionView Delegate, DataSource, FlowLayout

extension ProductDetailsVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return (self.productDetails?.productWarehouse?.count ?? 0) + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return rowHeaders.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WarehouseCVCell", for: indexPath) as! WarehouseCVCell
        cell.lblValue.backgroundColor = .clear
        if indexPath.section == 0 {
            cell.lblValue.text = rowHeaders[indexPath.item]
            cell.lblValue.textAlignment = .left
            cell.viewMain.backgroundColor = UIColor(hexString: "#EBEBEB", alpha: 1.0)
        }
        else {
            cell.viewMain.backgroundColor = .white
            if indexPath.item == 0 {
                let warehouse = APIManager.sharedManager.userDetail?.warehouse?.filter { $0.id == self.productDetails?.productWarehouse?[indexPath.section - 1].branchId ?? 0 }
                cell.lblValue.text = "\(warehouse?[0].branchName ?? "")"
                cell.lblValue.textAlignment = .left
            }
            else if indexPath.item == 1 {
                cell.lblValue.text = "\(self.productDetails?.productWarehouse?[indexPath.section - 1].inStock ?? "")"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 2 {
                cell.lblValue.text = "\(self.productDetails?.productWarehouse?[indexPath.section - 1].inCommited ?? 0)"
                cell.lblValue.textAlignment = .center
            }
            else if indexPath.item == 3 {
                cell.lblValue.text = "\(self.productDetails?.productWarehouse?[indexPath.section - 1].available ?? 0)"
                cell.lblValue.textAlignment = .center
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 0) / 4
        let height = 40.0
        return CGSize(width: width, height: height)
    }
}
