//
//  CommissionVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 13/09/24.
//

import UIKit

class CommissionVC: UIViewController {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBAction func btnSideMenuTap(_ sender: UIButton) {
        revealViewController()?.revealSideMenu()
    }
    
    
    @IBOutlet weak var viewBody: UIView!
    
    @IBOutlet weak var viewFilters: UIView!
    
    @IBOutlet weak var viewYearMonth: UIView!
    
    @IBOutlet weak var viewYear: UIView!
    @IBOutlet weak var lblSelectedYear: UILabel!
    @IBOutlet weak var btnSelectYear: UIButton!
    @IBAction func btnSelectYearTap(_ sender: UIButton) {
        
        let currYear = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).year ?? 0
        
        let tempYear: [String] = ["\(currYear)", "\(currYear - 1)", "\(currYear - 2)"]
        
        //let arrTempMonthYear: [String] = tempMonthYear.map{ "\($0.replacingOccurrences(of: " ", with: "-"))" }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = "Year"
        popupVC.value = tempYear
        popupVC.selectedValue = self.lblSelectedYear.text ?? "Year"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strValue in
            self.lblSelectedYear.text = strValue
            self.strSelectedYear = strValue
        }
        popupVC.onClose = { strValue in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    @IBOutlet weak var viewMonth: UIView!
    @IBOutlet weak var lblSelectedMonth: UILabel!
    @IBOutlet weak var btnSelectMonth: UIButton!
    @IBAction func btnSelectMonthTap(_ sender: UIButton) {
        
        let tempMonth: [String] = ["Month", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        
        //let arrTempMonthYear: [String] = tempMonthYear.map{ "\($0.replacingOccurrences(of: " ", with: "-"))" }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomPopup") as! CustomPopup
        popupVC.titleTxt = "Month"
        popupVC.value = tempMonth
        popupVC.selectedValue = self.lblSelectedMonth.text ?? "Month"
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.didSelectItem = { strValue in
            self.lblSelectedMonth.text = strValue
            self.strSelectedMonth = ""
            if strValue != "Month" {
                self.strSelectedMonth = strValue
            }
        }
        popupVC.onClose = { strValue in
            print("Dialog close.")
        }
        self.present(popupVC, animated: true)
    }
    
    
    @IBOutlet weak var viewMBP: UIView!
    @IBOutlet weak var constraintHeightViewMBP: NSLayoutConstraint!
    
    @IBOutlet weak var viewBP: UIView!
    @IBOutlet weak var lblSelectedBP: UILabel!
    @IBOutlet weak var btnSelectBP: UIButton!
    @IBAction func btnSelectBPTap(_ sender: UIButton) {
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "BusinessPartnerVC") as! BusinessPartnerVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.isFromAddOrder = true
        popupVC.onCellTap = { isSelect, businessP in
            if isSelect {
                self.objSelectedBP = businessP
                self.lblSelectedBP.text = self.objSelectedBP?.name ?? ""
                self.strBPId = "\(self.objSelectedBP?.id ?? 0)"
            }
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    
    @IBOutlet weak var viewMCUser: UIView!
    @IBOutlet weak var constraintHeightViewMCUser: NSLayoutConstraint!
    
    @IBOutlet weak var viewCUser: UIView!
    @IBOutlet weak var lblSelectedCUser: UILabel!
    @IBOutlet weak var btnSelectCUser: UIButton!
    @IBAction func btnSelectCUserTap(_ sender: UIButton) {
        
        let arrTempCUser: [String] = (self.arrCUser ?? []).map { "\($0.firstname ?? "") \($0.lastname ?? "")" }
        
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "PopupWMultiSelectionVC") as! PopupWMultiSelectionVC
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.strTitleText = "Commission User"
        popupVC.arrSelectedValue = self.arrSelectedCUser
        popupVC.value = arrTempCUser
        popupVC.isReturnValueInSeq = true
        popupVC.didSelectItem = { arrValue in
            self.arrSelectedCUser.removeAll()
            self.arrSelectedCUserId.removeAll()
            var  strZone: String = ""
            
            for strValue in arrValue.enumerated() {
                let tempValue = (self.arrCUser ?? []).filter { "\($0.firstname!) \($0.lastname!)" == strValue.element }
                if tempValue.count > 0 {
                    self.arrSelectedCUser.append(strValue.element)
                    self.arrSelectedCUserId.append("\(tempValue[0].id ?? 0)")
                    if strZone != "" {
                        strZone = strZone + ", " + strValue.element
                    }
                    else {
                        strZone = strValue.element
                    }
                }
            }
            
            if strZone != "" {
                self.lblSelectedCUser.text = strZone
            }
            else {
                self.lblSelectedCUser.text = "Commission User"
            }
        }
        popupVC.onClose = { arrValue in
        }
        self.present(popupVC, animated: true, completion: nil)
    }
    
    @IBOutlet weak var btnSearch: UIButton!
    @IBAction func btnSearchTap(_ sender: UIButton) {
        self.getUserCommissionData(intPdf: 0, intExcel: 0)
    }
    
    @IBOutlet weak var viewTVCommissionData: UIView!
    @IBOutlet weak var tvCommissionData: UITableView! {
        didSet {
            self.tvCommissionData.delegate = self
            self.tvCommissionData.dataSource = self
            self.tvCommissionData.register(UINib(nibName: "CommissionTVCell", bundle: nil), forCellReuseIdentifier: "CommissionTVCell")
        }
    }
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var lblNoData: UILabel!
    
    @IBOutlet weak var constraintBottomViewTV: NSLayoutConstraint!
    
    @IBOutlet weak var btnPDF: UIButton!
    @IBAction func btnPDFTap(_ sender: UIButton) {
        self.getUserCommissionData(intPdf: 1, intExcel: 0)
    }
    
    @IBOutlet weak var btnExcel: UIButton!
    @IBAction func btnExcelTap(_ sender: UIButton) {
        self.getUserCommissionData(intPdf: 0, intExcel: 1)
    }
    
    
    // MARK: - Variable
    
    var strSelectedYear: String = "0"
    var strSelectedMonth: String = "0"
    
    var objSelectedBP: BusinessPartner?
    var strBPId: String = ""
    
    var arrCUser: [Employee]? = []
    var arrSelectedCUser: [String] = []
    var arrSelectedCUserId: [String] = []
    var arrCommissionData: [CommissionData]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.btnSearch.corners(radius: self.btnSearch.frame.height / 2)
        
        self.viewNoData.isHidden = true
        
        let currYear = Calendar.current.dateComponents([.day, .month, .year, .hour, .minute], from: Date()).year ?? 0
        self.strSelectedYear = "\(currYear)"
        
        self.btnPDF.corners(radius: 15.0)
        self.btnExcel.corners(radius: 15.0)
        
        self.constraintHeightViewMBP.priority = .required
        self.constraintHeightViewMCUser.priority = .required
        self.constraintBottomViewTV.priority = .required
        
        if [3, 4, 10].contains(APIManager.sharedManager.userDetail?.roleId ?? 0) {
            self.constraintHeightViewMBP.priority = .defaultLow
            self.constraintHeightViewMCUser.priority = .defaultLow
            
            self.getEmployeeList()
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
}
