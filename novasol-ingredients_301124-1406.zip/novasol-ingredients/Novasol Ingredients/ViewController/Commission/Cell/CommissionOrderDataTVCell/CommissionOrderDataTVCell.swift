//
//  CommissionOrderDataTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 16/09/24.
//

import UIKit

class CommissionOrderDataTVCell: UITableViewCell {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewProductName: UIView!
    @IBOutlet weak var lblProductName: UILabel!
    
    @IBOutlet weak var viewProductAmount: UIView!
    @IBOutlet weak var lblProductAmount: UILabel!
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewProductName.addBorders(edges: [.top, .bottom, .right, .left], color: Colors.gray.returnColor())
        self.viewProductAmount.addBorders(edges: [.top, .bottom, .right], color: Colors.gray.returnColor())
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
