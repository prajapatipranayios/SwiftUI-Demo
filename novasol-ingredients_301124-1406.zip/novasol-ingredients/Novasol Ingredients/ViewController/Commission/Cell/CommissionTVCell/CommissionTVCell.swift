//
//  CommissionTVCell.swift
//  Novasol Ingredients
//
//  Created by Auxano on 16/09/24.
//

import UIKit

class CommissionTVCell: UITableViewCell {

    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var viewOrderDetails: UIView!
    @IBOutlet weak var lblBPName: UILabel!
    @IBOutlet weak var lblEmpName: UILabel!
    @IBOutlet weak var lblOrderCode: UILabel!
    @IBOutlet weak var lblOrderDate: UILabel!
    
    @IBOutlet weak var viewBtnStatus: UIView!
    @IBOutlet weak var btnStatus: UIButton!
    @IBAction func btnStatusTap(_ sender: UIButton) {
        if self.isButtonTapActive {
            if self.onButtonTap != nil {
                self.onButtonTap!(index)
            }
        }
    }
    @IBOutlet weak var constraintWidthBtnStatus: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewTVProductDetails: UIView!
    @IBOutlet weak var tvProductDetails: UITableView! {
        didSet {
            self.tvProductDetails.delegate = self
            self.tvProductDetails.dataSource = self
            self.tvProductDetails.register(UINib(nibName: "CommissionOrderDataTVCell", bundle: nil), forCellReuseIdentifier: "CommissionOrderDataTVCell")
        }
    }
    @IBOutlet weak var constraintHeightTVProductDetails: NSLayoutConstraint!
    
    
    @IBOutlet weak var viewMAmount: UIView!
    @IBOutlet weak var viewAmount: UIView!
    
    @IBOutlet weak var viewTotalAmount: UIView!
    @IBOutlet weak var lblTotalTitle: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    
    @IBOutlet weak var viewRemainPaidAmount: UIView!
    @IBOutlet weak var lblRemainTitle: UILabel!
    @IBOutlet weak var lblRemain: UILabel!
    @IBOutlet weak var lblPaidTitle: UILabel!
    @IBOutlet weak var lblPaid: UILabel!
    
    @IBOutlet weak var viewFinanceManager: UIView!
    @IBOutlet weak var lblFinanceManagerTitle: UILabel!
    @IBOutlet weak var lblFinanceManager: UILabel!
    
    
    
    // MARK: - Variable
    
    var index: Int = 0
    var isButtonTapActive: Bool = false
    var onButtonTap: ((Int)->Void)?
    var arrOrderData: [CommissionOrderData]? = [] {
        didSet {
            self.constraintHeightTVProductDetails.constant = CGFloat((self.arrOrderData?.count ?? 0) * 32)
            self.tvProductDetails.reloadData()
        }
    }
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.btnStatus.setTitleColor(.white, for: .normal)
        self.btnStatus.backgroundColor = Colors.theme.returnColor()
        
        self.viewAmount.cornersWFullBorder([.bottomLeft, .bottomRight], radius: 7.0, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.viewMAmount.cornersWFullBorder([.bottomLeft, .bottomRight], radius: 7.0, borderColor: Colors.gray.returnColor(), colorOpacity: 1.0)
        self.viewTotalAmount.addBorders(edges: [.top, .right, .bottom], color: Colors.gray.returnColor())
        self.viewRemainPaidAmount.addBorders(edges: [.top, .bottom], color: Colors.gray.returnColor())
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}


// MARK: - UITableView DataSource,

extension CommissionTVCell: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrOrderData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CommissionOrderDataTVCell", for: indexPath) as! CommissionOrderDataTVCell
        
        cell.index = indexPath.row
        
        cell.lblProductName.text = self.arrOrderData?[indexPath.row].categoryName ?? ""
        cell.lblProductAmount.text = "₹" + "\(self.arrOrderData?[indexPath.row].commission ?? 0)".curFormatAsRegion()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 32
    }
}
