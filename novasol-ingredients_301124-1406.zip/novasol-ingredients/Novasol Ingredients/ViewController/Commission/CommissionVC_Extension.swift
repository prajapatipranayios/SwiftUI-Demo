//
//  CommissionVC_Extension.swift
//  Novasol Ingredients
//
//  Created by Auxano on 13/09/24.
//

import Foundation
import UIKit


// MARK: - UITableView DataSource,

extension CommissionVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrCommissionData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CommissionTVCell", for: indexPath) as! CommissionTVCell
        
        cell.index = indexPath.row
        
        cell.lblBPName.text = self.arrCommissionData?[indexPath.row].orderInfo?.bmName ?? ""
        cell.lblEmpName.text = self.arrCommissionData?[indexPath.row].data?[0].employeeName ?? ""
        cell.lblOrderCode.text = self.arrCommissionData?[indexPath.row].orderInfo?.orderCode ?? ""
        cell.lblOrderDate.text = self.arrCommissionData?[indexPath.row].orderInfo?.orderDate ?? ""
        
        cell.arrOrderData = []
        if (self.arrCommissionData?[indexPath.row].data?.count ?? 0) > 0 {
            cell.arrOrderData = self.arrCommissionData?[indexPath.row].data ?? []
        }
        
        let arrTempData = self.arrCommissionData?[indexPath.row].data ?? []
        var totalCommissionAmt: Double = 0.0
        for (_, value) in arrTempData.enumerated() {
            totalCommissionAmt = totalCommissionAmt + Double(value.commission ?? 0)
        }
        
        cell.lblTotal.text = "₹" + "\(totalCommissionAmt)".curFormatAsRegion()
        cell.lblPaid.text = "₹" + "\(self.arrCommissionData?[indexPath.row].orderInfo?.paidCommission ?? 0)".curFormatAsRegion()
        cell.lblRemain.text = "₹" + "\(self.arrCommissionData?[indexPath.row].orderInfo?.remainCommission ?? 0)".curFormatAsRegion()
        cell.lblFinanceManager.text = self.arrCommissionData?[indexPath.row].orderInfo?.remark ?? ""
        
        cell.viewOrderDetails.backgroundColor = UIColor(hexString: "#F3F3F3", alpha: 1.0)
        cell.viewMAmount.backgroundColor = Colors.gray.returnColor()
        
        cell.isButtonTapActive = false
        var strBtnTitle = ""
        var btnBgColor: UIColor = .white
        var btnTextColor: UIColor = .white
        
        if self.arrCommissionData?[indexPath.row].orderInfo?.requestStatus ?? 0 == 1 {
            strBtnTitle = "Calim"
            cell.isButtonTapActive = false
            btnBgColor = Colors.gray.returnColor()
            btnTextColor = .white
            cell.viewMain.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
        }
        else if self.arrCommissionData?[indexPath.row].orderInfo?.requestStatus ?? 0 == 2 {
            strBtnTitle = "Paid"
            cell.isButtonTapActive = false
            btnBgColor = Colors.theme.returnColor()
            btnTextColor = .white
            cell.viewMain.cornersWFullBorder(radius: 5.0, borderColor: Colors.theme.returnColor(), colorOpacity: 1.0)
        }
        else if self.arrCommissionData?[indexPath.row].orderInfo?.requestStatus ?? 0 == 3 {
            strBtnTitle = "Paid"
            cell.isButtonTapActive = false
            //#FFF700
            btnBgColor = Colors.themeYellow.returnColor()
            btnTextColor = .white
            cell.viewMain.cornersWFullBorder(radius: 5.0, borderColor: Colors.themeYellow.returnColor(), colorOpacity: 1.0)
        }
        else {
            strBtnTitle = "Material Not Dispatch"
            cell.isButtonTapActive = false
            btnBgColor = Colors.theme.returnColor()
            btnTextColor = .white
            cell.viewMain.cornersWFullBorder(radius: 5.0, borderColor: .black, colorOpacity: 1.0)
            
            if [3, 4, 10].contains(APIManager.sharedManager.userDetail?.roleId ?? 0) {
                if self.arrCommissionData?[indexPath.row].orderInfo?.requestStatus ?? 0 == 17 {
                    strBtnTitle = "Material Dispatch"
                    cell.isButtonTapActive = false
                    btnBgColor = OrderStatus.materialDispatched.statusColor
                    btnTextColor = .white
                    cell.viewMain.cornersWFullBorder(radius: 5.0, borderColor: .clear, colorOpacity: 1.0)
                }
                else {
                    cell.isButtonTapActive = false
                    btnBgColor = Colors.theme.returnColor()
                    btnTextColor = .white
                    cell.viewMain.cornersWFullBorder(radius: 5.0, borderColor: .clear, colorOpacity: 1.0)
                }
            }
            else {
                if self.arrCommissionData?[indexPath.row].orderInfo?.requestStatus ?? 0 == 17 {
                    strBtnTitle = "Claim"
                    cell.isButtonTapActive = true
                    btnBgColor = OrderStatus.materialDispatched.statusColor
                    btnTextColor = .white
                    cell.viewMain.cornersWFullBorder(radius: 5.0, borderColor: .clear, colorOpacity: 1.0)
                }
            }
        }
        
        let font = Fonts.Regular.returnFont(size: 16)
        let textWidth = strBtnTitle.size(withAttributes: [NSAttributedString.Key.font: font]).width
        cell.constraintWidthBtnStatus.constant = textWidth
        cell.btnStatus.setTitle(strBtnTitle, for: .normal)
        cell.btnStatus.setTitleColor(btnTextColor, for: .normal)
        cell.btnStatus.backgroundColor = btnBgColor
        
        cell.onButtonTap = { index in
            self.claimCommissionRequest(index: index, userId: self.arrCommissionData?[indexPath.row].data?[0].userID ?? 0, orderId: self.arrCommissionData?[indexPath.row].orderInfo?.orderID ?? 0)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}


// MARK: Webservices

extension CommissionVC {
    
    func getEmployeeList() {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getEmployeeList()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            //"role_id": APIManager.sharedManager.userDetail?.roleId ?? 0
            "role_id": 12
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_EMPLOYEE_LIST, parameters: param) { (response: ApiResponseCommission?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.arrCUser = response?.result?.employees
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
            }
        }
    }
    
    func getUserCommissionData(intPdf: Int, intExcel: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getUserCommissionData(intPdf: intPdf, intExcel: intExcel)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "businessPartner": self.strBPId,
            "employee": self.arrSelectedCUserId,
            "month": MTP.Month(self.strSelectedMonth),
            "year": Int(self.strSelectedYear) ?? 0,
            "isPdf": intPdf,
            "isExcel": intExcel
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.GET_USER_COMMISSION, parameters: param) { (response: ApiResponseCommission?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    if intPdf == 1 || intExcel == 1 {
                        guard let url = URL(string: response?.result?.path ?? "") else { return }
                        UIApplication.shared.open(url)
                    }
                    else {
                        self.arrCommissionData = response?.result?.data ?? []
                        
                        self.viewNoData.isHidden = ((self.arrCommissionData?.count ?? 0) > 0) ? true : false
                        self.constraintBottomViewTV.priority = ((self.arrCommissionData?.count ?? 0) > 0) ? .defaultLow : .required
                        self.tvCommissionData.reloadData()
                    }
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
                self.viewNoData.isHidden = false
                self.constraintBottomViewTV.priority = .required
            }
        }
    }
    
    func claimCommissionRequest(index: Int, userId: Int, orderId: Int) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.claimCommissionRequest(index: index, userId: userId, orderId: orderId)
                }
            }
            return
        }
        
        let param = [
            "user_id": userId,
            "order_id": orderId
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.CLAIM_COMMISSION_REQUEST, parameters: param) { (response: ApiResponseCommission?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    self.displaySuccessMsg(message: response?.message ?? "", index: index)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
                self.viewNoData.isHidden = false
            }
        }
    }
    
    func displaySuccessMsg(message: String, index: Int = 0) {
        let popupVC = self.storyboard?.instantiateViewController(withIdentifier: "MsgPopupWImgVC") as! MsgPopupWImgVC
        popupVC.strMessage = message
        popupVC.modalPresentationStyle = .overCurrentContext
        popupVC.modalTransitionStyle = .crossDissolve
        popupVC.onTapOk = { str in
            self.arrCommissionData?[index].orderInfo?.requestStatus = 1
            self.tvCommissionData.reloadData()
        }
        self.present(popupVC, animated: true)
    }
}
