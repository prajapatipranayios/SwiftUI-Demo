//
//  SideMenuViewController.swift
//  CustomSideMenuiOSExample
//
//  Created by John Codeos on 2/7/21.
//

import UIKit

protocol SideMenuViewControllerDelegate {
    //func selectedCell(_ row: Int)
    func selectedCell(_ title: String)
}

class SideMenuViewController: UIViewController {
    @IBOutlet var headerImageView: UIImageView!
    @IBOutlet var sideMenuTableView: UITableView!
    @IBOutlet var footerLabel: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblRole: UILabel!
    
    var delegate: SideMenuViewControllerDelegate?
    var defaultHighlightedCell: Int = 0

    /*var menu: [SideMenuModel] = [
        SideMenuModel(icon: UIImage(systemName: "house.fill")!, title: "Home")
    ]   //  */
    
    //var menu: [String] = Role.getSideMenu(forRole: UserDefaults.standard.value(forKey: UserDefaultType.userRole) as? Int ?? 0)
    var menu: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load Menu Item
        if (UserDefaults.standard.value(forKey: UserDefaultType.userId) != nil) && ((UserDefaults.standard.value(forKey: UserDefaultType.userRole) as? Int ?? 0) != 0) {
            APIManager.sharedManager.isSideMenuLoad = true
            menu = Role.getSideMenu(forRole: UserDefaults.standard.value(forKey: UserDefaultType.userRole) as? Int ?? 0)
        }
        
        // TableView
        self.sideMenuTableView.delegate = self
        self.sideMenuTableView.dataSource = self
        self.sideMenuTableView.backgroundColor = .white
        self.sideMenuTableView.separatorStyle = .none

        // Set Highlighted Cell
        DispatchQueue.main.async {
            let defaultRow = IndexPath(row: self.defaultHighlightedCell, section: 0)
            self.sideMenuTableView.selectRow(at: defaultRow, animated: false, scrollPosition: .none)
        }

        // Footer
        self.footerLabel.textColor = .black       //UIColor.white
        //self.footerLabel.font = UIFont.systemFont(ofSize: 12, weight: .bold)
        //self.footerLabel.text = "Developed by John Codeos"
        self.footerLabel.text = "GE Version 0.0"

        // Register TableView Cell
        self.sideMenuTableView.register(SideMenuCell.nib, forCellReuseIdentifier: SideMenuCell.identifier)

        APIManager.sharedManager.userId = UserDefaults.standard.value(forKey: UserDefaultType.userId) as? Int ?? 0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // Get Data
        if APIManager.sharedManager.userId != 0 {
            self.getUserDetail()
        }
        //self.loadUserData(menuItem: Role.getSideMenu(forRole: APIManager.sharedManager.userDetail?.roleId ?? 0))
        // Update TableView with the data
        //self.sideMenuTableView.reloadData()
    }
    
    func loadUserData(menuItem: [String]) {
        //self.headerImageView.image = UIImage(systemName: "circle.fill")   //UIImage(named: "\(APIManager.sharedManager.userDetail?.image ?? "")")
        self.headerImageView.setImage(imageUrl: APIManager.sharedManager.userDetail?.image ?? "", placeHolder: "Default")
        self.lblUserName.text = "\(APIManager.sharedManager.userDetail?.firstname ?? "") \(APIManager.sharedManager.userDetail?.lastname ?? "")"
        self.lblRole.text = APIManager.sharedManager.userDetail?.userDesignation ?? ""
        self.footerLabel.text = "version \(APIManager.sharedManager.userDetail?.latestVersion ?? 0.0)"
        self.menu = menuItem
        self.sideMenuTableView.reloadData()
        APIManager.sharedManager.isSideMenuLoad = true
    }
}

// MARK: - UITableViewDelegate

extension SideMenuViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
}

// MARK: - UITableViewDataSource

extension SideMenuViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.menu.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SideMenuCell.identifier, for: indexPath) as? SideMenuCell else { fatalError("xib doesn't exist") }

        //cell.iconImageView.image = self.menu[indexPath.row].icon
        //cell.titleLabel.text = self.menu[indexPath.row].title
        
        cell.iconImageView.image = UIImage(named: "Sidemenu\((self.menu[indexPath.row]).replacingOccurrences(of: " ", with: "-"))")
        cell.iconImageView.scalesLargeContentImage = false
        cell.titleLabel.text = self.menu[indexPath.row]
        
        // Highlighted color
        let myCustomSelectionColorView = UIView()
        myCustomSelectionColorView.backgroundColor = .clear     // Colors.theme.returnColor()
        cell.selectedBackgroundView = myCustomSelectionColorView
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.delegate?.selectedCell(self.menu[indexPath.row])
        // Remove highlighted color when you press the 'Profile' and 'Like us on facebook' cell
        //if indexPath.row == 4 || indexPath.row == 6 {
            //tableView.deselectRow(at: indexPath, animated: true)
        //}
    }
}

extension SideMenuViewController {
    
    func getUserDetail () {
        
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.getUserDetail()
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId
        ]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.VIEW_USER_PROFILE, parameters: param) { (response: ApiResponse?, error) in
            self.hideLoading()
            DispatchQueue.main.async {
                
                if response?.status == 1 {
                    
                    APIManager.sharedManager.userDetail = response?.result?.userDetail
                    APIManager.sharedManager.userId = response?.result?.userDetail?.id ?? 0
                    
                    UserDefaults.standard.set(APIManager.sharedManager.userId, forKey: UserDefaultType.userId)
                    UserDefaults.standard.set(response?.result?.userDetail?.roleId ?? 0, forKey: UserDefaultType.userRole)
                    
                    self.loadUserData(menuItem: Role.getSideMenu(forRole: APIManager.sharedManager.userDetail?.roleId ?? 0))
                }
                else {
                    Utilities.showPopup(title: response?.message ?? "", type: .error)
                }
            }
        }
    }
}
