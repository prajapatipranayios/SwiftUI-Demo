//
//  SortVC.swift
//  GE Sales
//
//  Created by Cpt n3m0 on 26/04/24.
//

import UIKit

class SortVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewSort: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var viewOne: UIView!
    @IBOutlet weak var imgOne: UIImageView!
    @IBOutlet weak var lblOne: UILabel!
    @IBOutlet weak var btnOne: UIButton!
    
    @IBOutlet weak var viewTwo: UIView!
    @IBOutlet weak var imgTwo: UIImageView!
    @IBOutlet weak var lblTwo: UILabel!
    @IBOutlet weak var btnTwo: UIButton!
    
    @IBOutlet weak var viewThree: UIView!
    @IBOutlet weak var imgThree: UIImageView!
    @IBOutlet weak var lblThree: UILabel!
    @IBOutlet weak var btnThree: UIButton!
    
    @IBOutlet weak var viewFour: UIView!
    @IBOutlet weak var imgFour: UIImageView!
    @IBOutlet weak var lblFour: UILabel!
    @IBOutlet weak var btnFour: UIButton!
    
    @IBAction func btnTap(_ sender: UIButton) {
        var value: String = ""
        switch sender.tag {
        case 0:
            value = self.lblOne.text!
        case 1:
            value = self.lblTwo.text!
        case 2:
            value = self.lblThree.text!
        case 3:
            value = self.lblFour.text!
        default:
            value = self.selectedValue
        }
        
        self.dismiss(animated: true) {
            if self.didSelect != nil {
                self.didSelect!(value)
            }
        }
    }
    @IBOutlet weak var constraintLeadingOne: NSLayoutConstraint!
    @IBOutlet weak var constraintLeadingTwo: NSLayoutConstraint!
    @IBOutlet weak var constraintLeadingThree: NSLayoutConstraint!
    @IBOutlet weak var constraintLeadingFour: NSLayoutConstraint!
    
    // MARK: - Variable
    var didSelect: ((String)->Void)?
    var onClose: ((String)->Void)?
    var value = [String]()
    var tempValue = [String]()
    var option = [String]()
    var titleTxt: String = ""
    var selectedValue = "All"
    
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblTitle.text = self.titleTxt
        self.lblTitle.textColor = Colors.titleLabel.returnColor()
        
        self.viewMain.backgroundColor = .clear
        self.viewSort.layer.cornerRadius = 15
        
        self.viewOne.layer.cornerRadius = viewOne.frame.height / 2
        self.viewOne.layer.borderWidth = 1
        self.viewOne.layer.borderColor = Colors.disableButton.returnColor().cgColor
        
        self.viewTwo.layer.cornerRadius = viewTwo.frame.height / 2
        self.viewTwo.layer.borderWidth = 1
        self.viewTwo.layer.borderColor = Colors.disableButton.returnColor().cgColor
        
        self.viewThree.layer.cornerRadius = viewThree.frame.height / 2
        self.viewThree.layer.borderWidth = 1
        self.viewThree.layer.borderColor = Colors.disableButton.returnColor().cgColor
        
        self.viewFour.layer.cornerRadius = viewFour.frame.height / 2
        self.viewFour.layer.borderWidth = 1
        self.viewFour.layer.borderColor = Colors.disableButton.returnColor().cgColor
        
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if self.selectedValue == "Newest" {
            self.viewOne.layer.borderColor = Colors.theme.returnColor().cgColor
            self.imgOne.isHidden = false
            self.constraintLeadingOne.priority = .defaultLow
        }
        else if self.selectedValue == "Oldest" {
            self.viewTwo.layer.borderColor = Colors.theme.returnColor().cgColor
            self.imgTwo.isHidden = false
            self.constraintLeadingTwo.priority = .defaultLow
        }
        else if self.selectedValue == "A - Z" {
            self.viewThree.layer.borderColor = Colors.theme.returnColor().cgColor
            self.imgThree.isHidden = false
            self.constraintLeadingThree.priority = .defaultLow
        }
        else if self.selectedValue == "Z - A" {
            self.viewFour.layer.borderColor = Colors.theme.returnColor().cgColor
            self.imgFour.isHidden = false
            self.constraintLeadingFour.priority = .defaultLow
        }
    }
}
