//
//  CustomCV.swift
//  - Custom CollectionView to display Categories horizontally.
//
//  Created by Jaimesh Patel on 10/10/19.
//  Copyright © 2019 Auxano. All rights reserved.
//

import UIKit

class CustomCV: UICollectionView, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    var btnLeft: UIButton?
    var btnRight: UIButton?

    var colleItems: Array<String>?
    var selectedIndex: Int = -1
    var isWidthFix: Bool = false
    var didSelect: ((Int)->Void)?
        
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.register(UINib(nibName: "CustomCVCell", bundle: nil), forCellWithReuseIdentifier: "CustomCVCell")
    }
    
    func setupColleDataSource(items: Array<String>?, isWidthFix: Bool = false) {
        selectedIndex = self.tag == 1 ? selectedIndex == -1 ? 0 : selectedIndex  : -1
        self.isWidthFix = isWidthFix
        self.colleItems = items
        self.dataSource = self
        self.delegate = self
        self.reloadData()
    }
    
    // MARK: - UICollectionView DataSource, Delegate
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return colleItems?.count ?? 0    //0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomCVCell", for: indexPath) as! CustomCVCell
        
        if colleItems != nil {
            let item = colleItems?[indexPath.item]
            //cell.backgroundColor = selectedIndex == indexPath.item ? Colors.lightGray.returnColor() : UIColor.clear
            cell.lblName.text = item
            
            cell.backgroundColor = .orange
            if indexPath.item % 2 == 0 {
                cell.backgroundColor = .green
            }
        }
        else {
            cell.backgroundColor = UIColor.clear
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //remove below condition to enable league info and leaderboard tab for league tab
        //var isSelect = false
//        if isFromPlayerCard {
//            // By Pranay condition change
//            if (indexPath.item == 2) || (indexPath.item == 5) {
//                isSelect = false
//            } else {
//                /// 42 -  By Pranay
//                if self.isOtherUser && (indexPath.row == 3) { //  Condition for player card - By Pranay
//                    isSelect = false
//                } else if (self.isOtherUser) && (indexPath.row == 1) && ((APIManager.sharedManager.playerData?.playerStatus)! == 2) {
//                    isSelect = false
//                } else {
//                /// 42 .
//                    isSelect = true
//                }   /// 42 -  By Pranay
//            }
//        } else {
//            if APIManager.sharedManager.leagueType == "League" {
//                if indexPath.item != 1 && indexPath.item != 5 {
//                    isSelect = true
//                } else {
//                    isSelect = false
//                }
//            } else {
//                if indexPath.item != 4 {
//                    if indexPath.row == 1 && !isLeagueJoinStatus {
//                        isSelect = false
//                    } else {
//                        isSelect = true
//                    }
//                /// 1233 - Comment code by Pranay
//                } else {
//                    isSelect = false
//                } /// 1233 .
//            }
//        }
//        if isFromTeam {
//            // By Pranay condition change
//            if indexPath.item == 1 || indexPath.item == 2 || indexPath.item == 4 {
//                //.
//                isSelect = false
//            } else {
//                /// 322 - Condition By Pranay
//                if intTeamRole == 1 {
//                    isSelect = false
//                } else {
//                    isSelect = true
//                }
//                /// 322
//                //isSelect = true
//            }
//        }
        
//        if isSelect {
//            selectedIndex = indexPath.item
//            if didSelect != nil {
//                didSelect!(selectedIndex)
//            }
//            self.reloadData()
//            collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
//        }
    }
        
    // MARK: - UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if colleItems != nil {
            let size = (colleItems![indexPath.row]).size(withAttributes: [
                NSAttributedString.Key.font : Fonts.Regular.returnFont(size: 12.0)
                //NSAttributedString.Key.font : UIFont(name: "Roboto-Medium", size: 12.0)  //Fonts.Regular.returnFont(size: 12.0)
            ])
            
            if isWidthFix {
                return CGSize(width: (self.frame.width / CGFloat(self.colleItems?.count ?? 1)), height: 100.0)
                /*if size.width+16 > 100 {
                    return CGSize(width: 105, height: 96.0)
                }
                else {
                    return CGSize(width: colleItems![indexPath.row] == "Chat" ? size.width+46 : size.width+16, height: colleItems![indexPath.row] == "Chat" ? 93.0 : 96.0)
                }   //  */
            }
            else {
                return CGSize(width: size.width+16, height: 100.0)
            }
        }
        else {
            return CGSize(width: 96, height: 96)
        }
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
                
        let scrollViewWidth = scrollView.frame.size.width
        let scrollContentSizeWidth = scrollView.contentSize.width
        let scrollOffset = scrollView.contentOffset.x

        if (scrollOffset == 0) {
            // then we are at the top
            btnLeft?.isHidden = true
            btnRight?.isHidden = false
        } else if (scrollOffset + scrollViewWidth >= scrollContentSizeWidth - 2.0) {
            // then we are at the end
            btnLeft?.isHidden = false
            btnRight?.isHidden = true
        } else {
            btnLeft?.isHidden = false
            btnRight?.isHidden = false
        }
    }

    @objc func arrowLeftBtnClick() {
        let collectionBounds = self.bounds
        let contentOffset = CGFloat(floor(self.contentOffset.x - collectionBounds.size.width))
        self.moveToFrame(contentOffset: contentOffset)
    }

    @objc func arrowRightBtnClick() {
        let collectionBounds = self.bounds
        let contentOffset = CGFloat(floor(self.contentOffset.x + collectionBounds.size.width))
        self.moveToFrame(contentOffset: contentOffset)
    }

    func moveToFrame(contentOffset : CGFloat) {
        let frame: CGRect = CGRect(x : contentOffset ,y : self.contentOffset.y ,width : self.frame.width,height : self.frame.height)
        self.scrollRectToVisible(frame, animated: true)
    }
}
