//
//  CustomCVCell.swift
//  - Custom CollectionView Cell which contains relevant Name & Image.
//
//  Copyright © 2019 Auxano. All rights reserved.
//

import UIKit

class CustomCVCell: UICollectionViewCell {

    //Outlets
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var view : UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    
    }

//    func showAnimation() {
//        viewAnimation.showAnimatedSkeleton()
//    }
    
//    func hideAnimation() {
//        viewAnimation.hideSkeleton()
//    }
    
}
