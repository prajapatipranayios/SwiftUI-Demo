//
//  DateVC.swift
//  GE Sales
//
//  Created by Auxano on 25/04/24.
//

import UIKit

class DateVC: UIViewController {

    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewDatePicker: UIView!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var btnOK: UIButton!
    @IBAction func btnOKTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.didSelectDate != nil {
                self.didSelectDate!(self.strDate)
            }
        }
    }
    @IBOutlet weak var btnCancel: UIButton!
    @IBAction func btnCancelTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onClose != nil {
                self.onClose!()
            }
        }
    }
    @IBOutlet weak var constraaintTrailingCancel: NSLayoutConstraint!
    
    // MARK: - Variable
    
    var didSelectDate: ((String)->Void)?
    var onClose: (()->Void)?
    var selectedId = 0
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    var isHideOk: Bool = false
    private var strDate: String = ""
    var minStartDate: String = ""
    var dateFormat: String = "dd-MM-yyyy"
    var isMaxDateLimit: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if isHideOk {
            self.constraaintTrailingCancel.priority = .required
            self.btnOK.isHidden = true
        }
        else {
            self.constraaintTrailingCancel.priority = .defaultLow
            self.btnOK.isHidden = false
        }
        
        if self.minStartDate != "" {
            //self.datePicker.minimumDate = formatter.date(from: self.minStartDate)
            self.datePicker.minimumDate = Utilities.convertStringToDate(date: self.minStartDate, NewDateFormate: self.dateFormat)
        }
        
        if self.isMaxDateLimit {
            self.datePicker.maximumDate = Date()
        }
        
        if self.strDate == "" {
            //self.strDate = formatter.string(from: Date())
            self.strDate = Utilities.convertDateToString(date: Date(), NewDateFormate: self.dateFormat)
        }
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
        self.viewMain.backgroundColor = .clear
        
        self.datePicker.addTarget(self, action: #selector(datePickerValueChanged(sender:)), for: .allEvents)
        
        self.viewDatePicker.layer.cornerRadius = 10
        self.viewDatePicker.clipsToBounds = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }
    
    @objc func datePickerValueChanged(sender: UIDatePicker) {
        strDate = Utilities.convertDateToString(date: sender.date, NewDateFormate: self.dateFormat)
        
        if self.isHideOk {
            self.dismiss(animated: true) {
                if self.didSelectDate != nil {
                    self.didSelectDate!(self.strDate)
                }
            }
        }
    }
}

extension DateVC {
    
}
