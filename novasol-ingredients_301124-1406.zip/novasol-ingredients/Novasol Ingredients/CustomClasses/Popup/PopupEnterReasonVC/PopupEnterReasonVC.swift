//
//  PopupEnterReasonVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 04/09/24.
//

import UIKit

class PopupEnterReasonVC: UIViewController {

    
    // MARK: - Controls
    
    @IBOutlet weak var viewMain : UIView!
    @IBOutlet weak var viewBottomSheet : UIView!
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var lblTitle : UILabel!
    
    @IBOutlet weak var txtReason: UITextField!
    
    @IBOutlet weak var btnOnTapClose: UIButton!
    @IBAction func btnOnTapCloseTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onTapClose != nil {
                self.onTapClose!("")
            }
        }
    }
    @IBOutlet weak var btnClose: UIButton!
    @IBAction func btnCloseTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onTapClose != nil {
                self.onTapClose!("")
            }
        }
    }
    @IBOutlet weak var btnOk: UIButton!
    @IBAction func btnOkTap(_ sender: UIButton) {
        if self.txtReason.text ?? "" != "" {
            self.dismiss(animated: true) {
                if self.onTapOk != nil {
                    self.onTapOk!(self.txtReason.text ?? "")
                }
            }
        }
    }
    
    // MARK: - Variables
    
    var onTapClose: ((String)->Void)?
    var onTapOk: ((String)->Void)?
    var strPopupTitle: String = "Reject Reason"
    
    var bgColorMainView: UIColor = .white
    var bgColorTitleView: UIColor = .white
    var colorTitleText: UIColor = .black
    
    var strBtnCloseImg: String = "Close"
    
    var strTxtPlaceholder: String = "Type here"
    
    var strBtnOkTitle: String = "DONE"
    var bgColorBtnOk: UIColor = Colors.theme.returnColor()
    var colorTextBtnOk: UIColor = .white
    
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewMain.backgroundColor = .clear
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.viewBottomSheet.backgroundColor = self.bgColorMainView
        self.viewTitle.backgroundColor = self.bgColorTitleView
        self.lblTitle.textColor = self.colorTitleText
        self.lblTitle.text = self.strPopupTitle
        
        self.btnClose.setImage(UIImage(named: self.strBtnCloseImg), for: .normal)
        
        self.txtReason.placeholder = self.strTxtPlaceholder
        
        self.btnOk.setTitle(self.strBtnOkTitle, for: .normal)
        self.btnOk.setTitleColor(self.colorTextBtnOk, for: .normal)
        self.btnOk.backgroundColor = self.bgColorBtnOk
    }

}
