//
//  SelectOption.swift
//

import UIKit

class CustomPopup: UIViewController {
    
    // MARK: - Variables
    var didSelectItem: ((String)->Void)?
    var onClose: ((String)->Void)?
    var selectedId = 0
    var value = [String]()
    var tempValue = [String]()
    var option = [String]()
    var titleTxt: String = ""
    var selectedValue = "All"
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    var isSearchActive: Bool = false
    var isOpenCloseAnimation: Bool = false
    
    // Dashboard
    var isFromDashboard: Bool = false
    var isFromSalesReport: Bool = false
    
    // MARK: - Controls
    @IBOutlet weak var lblTitle : UILabel!
    @IBOutlet weak var tvOptions : UITableView!
    @IBOutlet weak var viewMain : UIView!
    @IBOutlet weak var viewBottomSheet : UIView!
    @IBOutlet weak var bottomSheetbottomConstraint : NSLayoutConstraint!
    @IBOutlet weak var heightTVOptions : NSLayoutConstraint!
    @IBOutlet weak var btnClose: UIButton!
    @IBAction func btnCloseTap(_ sender: UIButton) {
        if self.isOpenCloseAnimation {
            UIView.animate(withDuration: 0.5, animations: {
                if #available(iOS 11.0, *) {
                    self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
                } else {
                    self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
                }
                self.view.layoutIfNeeded()
            }) { (true) in
                self.dismiss(animated: true) {
                    if self.onClose != nil {
                        self.onClose!(self.selectedValue)
                    }
                }
            }
        }
        else {
            self.dismiss(animated: true) {
                if self.onClose != nil {
                    self.onClose!(self.selectedValue)
                }
            }
        }
    }
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var constraintHeightSearchBar: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.layoutIfNeeded()
        self.viewMain.backgroundColor = .clear
        
        self.lblTitle.textColor = Colors.titleLabel.returnColor()
        
        self.tvOptions.delegate = self
        self.tvOptions.dataSource = self
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
        viewBottomSheet.layer.cornerRadius = 15.0
        lblTitle.text = titleTxt
        tvOptions.rowHeight = UITableView.automaticDimension
        tvOptions.estimatedRowHeight = 100.0
        tvOptions.reloadData()
        
        self.constraintHeightSearchBar.constant = 0
        if self.isSearchActive {
            self.constraintHeightSearchBar.constant = 44
        }
        
        if self.isOpenCloseAnimation {
            if #available(iOS 11.0, *) {
                self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + view.safeAreaInsets.bottom + 16.0)
            } else {
                self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + view.layoutMargins.bottom + 16.0)
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.openBottomSheet()
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tvOptions.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        self.tempValue = self.value
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tvOptions.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                self.heightTVOptions.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                self.updateViewConstraints()
            }
        }
    }
    
    // MARK: - UI Methods
    
    func openBottomSheet() {
        UIView.animate(withDuration: 0.5, animations: {
            self.bottomSheetbottomConstraint.constant = 16
            self.view.layoutIfNeeded()
        })
    }
    
    func closeBottomSheet(index :Int) {
        if self.isOpenCloseAnimation {
            UIView.animate(withDuration: 0.5, animations: {
                if #available(iOS 11.0, *) {
                    self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
                } else {
                    self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
                }
                self.view.layoutIfNeeded()
            }) { (true) in
                self.dismiss(animated: true) {
                    if self.didSelectItem != nil {
                        self.didSelectItem!(self.tempValue[index] )
                    }
                }
            }
        }
        else {
            self.dismiss(animated: true) {
                if self.didSelectItem != nil {
                    self.didSelectItem!(self.tempValue[index] )
                }
            }
        }
    }
    
    // MARK: - IBAction Methods
    
}

// MARK: - UITableViewDelegate

extension CustomPopup: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tempValue.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomPopupCell", for: indexPath) as! CustomPopupCell
        
        cell.index = indexPath.row
        cell.btnOptionName.setTitle(self.tempValue[indexPath.row] , for: .normal)
        cell.btnOptionName.setTitleColor(UIColor.black, for: .normal)
        
        if self.selectedValue == self.tempValue[indexPath.row] {
            cell.imgSelected.image = UIImage(named: "Select")
        }
        else {
            cell.imgSelected.image = UIImage(named: "Deselect")
        }
        
        cell.imgSelected.isHidden = false
        if isFromDashboard && isFromSalesReport {
            cell.imgSelected.isHidden = true
        }
        
        cell.onCellTap = { index in
            self.closeBottomSheet(index: index)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

// MARK: - SearchBar Delegate

extension CustomPopup: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        if searchText != "" {
            self.tempValue = self.value.filter{
                ($0.lowercased()).contains(searchText.lowercased())
            }
        }
        else {
            self.searchBar.text = ""
            self.tempValue = self.value
        }
        self.tvOptions.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
        self.searchBar.text = ""
        self.tempValue = self.value
        self.tvOptions.reloadData()
    }
}
