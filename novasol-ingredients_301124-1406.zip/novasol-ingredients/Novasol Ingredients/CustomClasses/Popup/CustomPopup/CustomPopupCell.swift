//
//  SelectGamertagCellDelegate.swift
//


import UIKit

class CustomPopupCell: UITableViewCell {
    // MARK: - Controls
    
    @IBOutlet weak var btnOptionName: UIButton!
    @IBOutlet weak var viewBottom: UIView!
    @IBOutlet weak var imgSelected: UIImageView!
    @IBOutlet weak var viewBg: UIView!
    
    // MARK: - Variables
    var onCellTap: ((Int)->Void)?
    var index = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewBottom.isHidden = true
        //btnOptionName.layer.cornerRadius = 15.0
        self.viewBg.layer.cornerRadius = 10.0
        self.viewBg.layer.borderWidth = 1
        self.viewBg.layer.borderColor = UIColor.black.cgColor
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    // MARK: - Button Click Events
    
    @IBAction func didPressTitle(_ sender: UIButton) {
        if self.onCellTap != nil {
            self.onCellTap!(index)
        }
    }
}
