//
//  ContactPersonVC.swift
//  GE Sales
//
//  Created by Cpt n3m0 on 29/04/24.
//

import UIKit

class PopupWithTableVC: UIViewController {

    // MARK: - Controls
    
    @IBOutlet weak var lblScreenTitle : UILabel!
    @IBOutlet weak var tvContact : UITableView! {
        didSet {
            self.tvContact.delegate = self
            self.tvContact.dataSource = self
            
            self.tvContact.register(UINib(nibName: "ContactPersonTVCell", bundle: nil), forCellReuseIdentifier: "ContactPersonTVCell")
            self.tvContact.register(UINib(nibName: "ClientHistoryTVCell", bundle: nil), forCellReuseIdentifier: "ClientHistoryTVCell")
            self.tvContact.register(UINib(nibName: "BPAddressTVCell", bundle: nil), forCellReuseIdentifier: "BPAddressTVCell")
            self.tvContact.register(UINib(nibName: "TransporterTVCell", bundle: nil), forCellReuseIdentifier: "TransporterTVCell")
            self.tvContact.register(UINib(nibName: "OrderHistoryTVCell", bundle: nil), forCellReuseIdentifier: "OrderHistoryTVCell")
            self.tvContact.register(UINib(nibName: "TrialHistoryTVCell", bundle: nil), forCellReuseIdentifier: "TrialHistoryTVCell")
        }
    }
    @IBOutlet weak var viewMain : UIView!
    @IBOutlet weak var viewBottomSheet : UIView!
    @IBOutlet weak var constraintBottomBSheet: NSLayoutConstraint!
    
    @IBOutlet weak var heightTVContact : NSLayoutConstraint!
    @IBOutlet weak var btnClose: UIButton!
    @IBAction func btnCloseTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onClose != nil {
                self.onClose!("")
            }
        }
    }
    
    @IBOutlet weak var viewNoData: UIView!
    @IBOutlet weak var constraintHeightNoData: NSLayoutConstraint!
    @IBOutlet weak var lblNoData: UILabel!
    
    // MARK: - Variables
    
    var didSelectItem: ((String)->Void)?
    var onClose: ((String)->Void)?
    var strTitle: String = "Contact Person"
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    var intUserId: Int? = 0
    
    var isContectPerson: Bool = false
    var arrBusinessPartnerContactPerson: [BusinessPartnersContactPerson]?
    
    var isClientHistory: Bool = false
    var arrBusinessPartnerHistory: [BusinessPartnerHistory]?
    
    var isTransporter: Bool = false
    var arrBusinessPartnersTransporter: [BusinessPartnersTransporter]?
    
    var isAddress: Bool = false
    var billingAddress: Address?
    var deliveryAddress: Address?
    var intAddressCell: Int = 0
    
    var isOrderHistory: Bool = false
    var arrProductHistory: [ProductHistory]?
    var strOrderStatus: String? = "Hold"
    
    var isSampleHistory: Bool = false
    var arrSampleHistory: [History]?
    
    var isTrialHistory: Bool = false
    var arrTrialHistory: [BPProduct]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.layoutIfNeeded()
        self.viewMain.backgroundColor = .clear
        
        self.lblScreenTitle.text = self.strTitle
        self.lblScreenTitle.textColor = Colors.titleLabel.returnColor()
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
        //self.viewBottomSheet.layer.cornerRadius = 30
        self.viewBottomSheet.corners([.topLeft, .topRight], radius: 25)
        
        tvContact.reloadData()
        
        
        if self.billingAddress != nil {
            self.intAddressCell += 1
        }
        if self.deliveryAddress != nil {
            self.intAddressCell += 1
        }
        
        //Subscribe to a Notification which will fire before the keyboard will show
        subscribeToNotification(UIResponder.keyboardWillShowNotification, selector: #selector(keyboardWillShowOrHide))
        
        //Subscribe to a Notification which will fire before the keyboard will hide
        subscribeToNotification(UIResponder.keyboardWillHideNotification, selector: #selector(keyboardWillShowOrHide))
        
        //We make a call to our keyboard handling function as soon as the view is loaded.
        initializeHideKeyboard()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tvContact.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        self.constraintBottomBSheet.constant = 10
        
        self.viewNoData.isHidden = true
        self.constraintHeightNoData.priority = .defaultLow
        self.constraintHeightNoData.constant = 150
        
        if self.isContectPerson {
            if self.arrBusinessPartnerContactPerson?.count ?? 0 == 0 {
                self.viewNoData.isHidden = false
                self.constraintHeightNoData.priority = .required
            }
        }
        else if self.isClientHistory {
            if self.arrBusinessPartnerHistory?.count ?? 0 == 0 {
                self.viewNoData.isHidden = false
                self.constraintHeightNoData.priority = .required
            }
        }
        else if self.isTransporter {
            if self.arrBusinessPartnersTransporter?.count ?? 0 == 0 {
                self.viewNoData.isHidden = false
                self.constraintHeightNoData.priority = .required
            }
        }
        else if self.isAddress {
            if self.intAddressCell == 0 {
                self.viewNoData.isHidden = false
                self.constraintHeightNoData.priority = .required
            }
        }
        else if self.isOrderHistory {
            if self.arrProductHistory?.count ?? 0 == 0 {
                self.viewNoData.isHidden = false
                self.constraintHeightNoData.priority = .required
            }
        }
        else if self.isSampleHistory {
            if self.arrSampleHistory?.count ?? 0 == 0 {
                self.viewNoData.isHidden = false
                self.constraintHeightNoData.priority = .required
            }
        }
        else if self.isTrialHistory {
            if self.arrTrialHistory?.count ?? 0 == 0 {
                self.viewNoData.isHidden = false
                self.constraintHeightNoData.priority = .required
            }
        }
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tvContact.removeObserver(self, forKeyPath: "contentSize")
        
        unsubscribeFromAllNotifications()
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                self.heightTVContact.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                print(self.heightTVContact.constant
                )
                self.updateViewConstraints()
            }
        }
    }
    
    // MARK: - UI Methods
    
//    func openBottomSheet() {
//        UIView.animate(withDuration: 0.5, animations: {
//            //self.bottomSheetbottomConstraint.constant = 16
//            self.view.layoutIfNeeded()
//        })
//    }
    
    func closeBottomSheet(index :Int) {
//        UIView.animate(withDuration: 0.5, animations: {
//            if #available(iOS 11.0, *) {
//                self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
//            } else {
//                self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
//            }
//            self.view.layoutIfNeeded()
//        }) { (true) in
//            self.dismiss(animated: true) {
//                if self.didSelectItem != nil {
//                    self.didSelectItem!(self.value[index] )
//                }
//            }
//        }
    }
    
    // MARK: - IBAction Methods
    
}

extension PopupWithTableVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
}

// MARK: - UITableView Delegate, DataSource

extension PopupWithTableVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.isContectPerson {
            return self.arrBusinessPartnerContactPerson?.count ?? 0
        }
        else if self.isClientHistory {
            return self.arrBusinessPartnerHistory?.count ?? 0
        }
        else if self.isTransporter {
            return self.arrBusinessPartnersTransporter?.count ?? 0
        }
        else if self.isAddress {
            return self.intAddressCell
        }
        else if self.isOrderHistory {
            return self.arrProductHistory?.count ?? 0
        }
        else if self.isSampleHistory {
            return self.arrSampleHistory?.count ?? 0
        }
        else if self.isTrialHistory {
            return self.arrTrialHistory?.count ?? 0
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if self.isContectPerson {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ContactPersonTVCell", for: indexPath) as! ContactPersonTVCell
            cell.lblName.text = self.arrBusinessPartnerContactPerson?[indexPath.row].contactPersonName ?? ""
            cell.lblMobile.text = self.arrBusinessPartnerContactPerson?[indexPath.row].contactPersonPhonePrimary ?? ""
            cell.lblDesignation.text = ("\(self.arrBusinessPartnerContactPerson?[indexPath.row].contactPersonDesignation ?? "")" == "") ? "-" : (self.arrBusinessPartnerContactPerson?[indexPath.row].contactPersonDesignation ?? "")
            cell.lblEmail.text = self.arrBusinessPartnerContactPerson?[indexPath.row].contactPersonEmail ?? ""
            return cell
        }
        else if self.isClientHistory {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClientHistoryTVCell", for: indexPath) as! ClientHistoryTVCell
            cell.lblDate.text = Utilities.convertStrDateToString(date: self.arrBusinessPartnerHistory?[indexPath.row].historyDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy hh:mm a", NewDateFormate: "EEEE, d MMMM")
            cell.lblTime.text = Utilities.convertStrDateToString(date: self.arrBusinessPartnerHistory?[indexPath.row].historyDate ?? "", CurrentDateFormate: "dd-MMMM-yyyy hh:mm a", NewDateFormate: "h:mm a")
            cell.lblName.text = self.arrBusinessPartnerHistory?[indexPath.row].employeeName ?? ""
            cell.lblStatus.text = self.arrBusinessPartnerHistory?[indexPath.row].status ?? ""
            cell.lblStatus.textColor = ClientStatusColors.statusColor(status: self.arrBusinessPartnerHistory?[indexPath.row].status ?? "")
            return cell
        }
        else if self.isTransporter {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TransporterTVCell", for: indexPath) as! TransporterTVCell
            cell.lblTransporter.text = self.arrBusinessPartnersTransporter?[indexPath.row].transporterTitle ?? ""
            return cell
        }
        else if self.isAddress {
            let cell = tableView.dequeueReusableCell(withIdentifier: "BPAddressTVCell", for: indexPath) as! BPAddressTVCell
            if indexPath.row == 0 {
                cell.lblTitle.text = "Billing Type & Address"
                let address: String = "\(self.billingAddress?.addressTitle ?? ""), \(self.billingAddress?.buildingFloorRoom ?? ""), \(self.billingAddress?.blockNo ?? ""), \(self.billingAddress?.cityName ?? ""), \(self.billingAddress?.stateShortName ?? ""), \(self.billingAddress?.countryName ?? "") - \(self.billingAddress?.pinCode ?? "")"
                cell.lblAddress.text = address
            }
            else if indexPath.row == 1 {
                cell.lblTitle.text = "Delivery Type & Address"
                let address: String = "\(self.deliveryAddress?.addressTitle ?? ""), \(self.deliveryAddress?.buildingFloorRoom ?? ""), \(self.deliveryAddress?.blockNo ?? ""), \(self.deliveryAddress?.cityName ?? ""), \(self.deliveryAddress?.stateShortName ?? ""), \(self.deliveryAddress?.countryName ?? "") - \(self.deliveryAddress?.pinCode ?? "")"
                cell.lblAddress.text = address
            }
            return cell
        }
        else if self.isOrderHistory {
            let cell = tableView.dequeueReusableCell(withIdentifier: "OrderHistoryTVCell", for: indexPath) as! OrderHistoryTVCell
            //cell.lblTransporter.text = self.arrBusinessPartnersTransporter?[indexPath.row].transporterTitle ?? ""
            cell.index = indexPath.row
            cell.view.backgroundColor = .white
            cell.lblDate.text = self.arrProductHistory?[indexPath.row].statusDatetime ?? ""
            cell.lblStatus.text = (self.arrProductHistory?[indexPath.row].currentStatus ?? "") == "" ? "-" : (self.arrProductHistory?[indexPath.row].currentStatus ?? "")
            cell.lblStatus.textColor = OrderStatus.getStatusColor(status: (self.arrProductHistory?[indexPath.row].currentStatus ?? "") == "" ? "-" : (self.arrProductHistory?[indexPath.row].currentStatus ?? ""))
            cell.lblBy.text = "By \(self.arrProductHistory?[indexPath.row].parentName ?? "")"
            
            if (self.arrProductHistory?[indexPath.row].reason ?? "") == "" {
                cell.constraintHeightViewReason.priority = .required
                cell.viewReason.clipsToBounds = true
            }
            else {
                cell.constraintHeightViewReason.priority = .defaultLow
                cell.viewReason.clipsToBounds = true
                cell.lblReason.text = self.arrProductHistory?[indexPath.row].reason ?? ""
            }
            
            /// Replay section
            cell.btnReply.isHidden = true
            cell.constraintHeightViewEmpAns.priority = .required
            cell.viewEmpAns.isHidden = true
            
            if (self.arrProductHistory?[indexPath.row].reply ?? "") == "" {
                
                //if (indexPath.row == ((self.arrProductHistory?.count ?? 0) - 1)) && !(self.arrProductHistory?[indexPath.row].isReplyClicked ?? false) {
                
                if (self.arrProductHistory?[indexPath.row].currentStatus == "Hold" && self.strOrderStatus ?? "" == "Hold") && ((self.intUserId ?? 0) == APIManager.sharedManager.userId) && !(self.arrProductHistory?[indexPath.row].isReplyClicked ?? false) {
                    
                    cell.btnReply.isHidden = false
                    cell.constraintHeightViewEmpAns.priority = .defaultLow
                    
                    cell.onTapReply = { index in
                        self.arrProductHistory?[index].isReplyClicked = true
                        print(self.arrProductHistory?[index].isReplyClicked ?? false)
                        
                        self.tvContact.reloadData()
                    }
                }
                else {
                    if self.arrProductHistory?[indexPath.row].isReplyClicked ?? false {
                        cell.constraintHeightViewEmpAns.priority = .defaultLow
                        cell.viewEmpAns.isHidden = false
                        cell.txtReply.delegate = self
                        cell.onTapSend = { index, reply in
                            
                            //self.arrProductHistory?[index].isReplyClicked = false
                            //self.arrProductHistory?[index].reply = reply
                            
                            //print(self.arrProductHistory?[index].reply ?? "")
                            //self.tvContact.reloadData()
                            
                            self.holdStatusReply(historyId: self.arrProductHistory?[index].historyID ?? 0, strReply: reply, completion: { isSuccess in
                                if isSuccess {
                                    self.arrProductHistory?[index].isReplyClicked = false
                                    self.arrProductHistory?[index].reply = reply
                                    
                                    print(self.arrProductHistory?[index].reply ?? "")
                                    self.tvContact.reloadData()
                                }
                            })
                        }
                    }
                }
            }
            else {
                cell.viewEmpAns.clipsToBounds = true
                cell.viewEmpAns.isHidden = false
                
                cell.txtReply.isHidden = true
                cell.btnSend.isHidden = true
                
                cell.constraintHeightViewEmpAns.priority = .defaultLow
                cell.lblEmpAns.text = self.arrProductHistory?[indexPath.row].reply ?? ""
            }
            return cell
        }
        else if isSampleHistory {
            let cell = tableView.dequeueReusableCell(withIdentifier: "OrderHistoryTVCell", for: indexPath) as! OrderHistoryTVCell
            //cell.lblTransporter.text = self.arrBusinessPartnersTransporter?[indexPath.row].transporterTitle ?? ""
            cell.index = indexPath.row
            cell.view.backgroundColor = .white
            cell.lblStatusChangeDateTitle.text = "Request Date"
            cell.lblDate.text = self.arrSampleHistory?[indexPath.row].statusDatetime ?? ""
            cell.lblStatus.text = OrderStatus.getStatusTitle(status: self.arrSampleHistory?[indexPath.row].currentStatus ?? 0)
            cell.lblStatus.textColor = OrderStatus.getStatusColor(status: self.arrSampleHistory?[indexPath.row].currentStatus ?? 0)
            cell.lblBy.text = "By \(self.arrSampleHistory?[indexPath.row].employeeName ?? "")"
            
            if (self.arrSampleHistory?[indexPath.row].reason ?? "") == "" {
                cell.constraintHeightViewReason.priority = .required
                cell.viewReason.clipsToBounds = true
            }
            else {
                cell.constraintHeightViewReason.priority = .defaultLow
                cell.viewReason.clipsToBounds = true
                cell.lblReason.text = self.arrSampleHistory?[indexPath.row].reason ?? ""
            }
            
            /// Replay section
            cell.btnReply.isHidden = true
            cell.constraintHeightViewEmpAns.priority = .required
            cell.viewEmpAns.isHidden = true
            
            /*if (self.arrSampleHistory?[indexPath.row].reply ?? "") == "" {
                
                //if (indexPath.row == ((self.arrProductHistory?.count ?? 0) - 1)) && !(self.arrProductHistory?[indexPath.row].isReplyClicked ?? false) {
                
                if (self.arrProductHistory?[indexPath.row].currentStatus == "Hold" && self.strOrderStatus ?? "" == "Hold") && (intOrderUserId ?? 0 == 95 /*APIManager.sharedManager.userId*/) && !(self.arrProductHistory?[indexPath.row].isReplyClicked ?? false) {
                    
                    cell.btnReply.isHidden = false
                    cell.constraintHeightViewEmpAns.priority = .defaultLow
                    
                    cell.onTapReply = { index in
                        self.arrProductHistory?[index].isReplyClicked = true
                        print(self.arrProductHistory?[index].isReplyClicked ?? false)
                        
                        self.tvContact.reloadData()
                    }
                }
                else {
                    if self.arrProductHistory?[indexPath.row].isReplyClicked ?? false {
                        cell.constraintHeightViewEmpAns.priority = .defaultLow
                        cell.viewEmpAns.isHidden = false
                        cell.txtReply.delegate = self
                        cell.onTapSend = { index, reply in
                            
                            //self.arrProductHistory?[index].isReplyClicked = false
                            //self.arrProductHistory?[index].reply = reply
                            
                            //print(self.arrProductHistory?[index].reply ?? "")
                            //self.tvContact.reloadData()
                            
                            self.holdStatusReply(historyId: self.arrProductHistory?[index].historyID ?? 0, strReply: reply, completion: { isSuccess in
                                if isSuccess {
                                    self.arrProductHistory?[index].isReplyClicked = false
                                    self.arrProductHistory?[index].reply = reply
                                    
                                    print(self.arrProductHistory?[index].reply ?? "")
                                    self.tvContact.reloadData()
                                }
                            })
                        }
                    }
                }
            }
            else {
                cell.viewEmpAns.clipsToBounds = true
                cell.viewEmpAns.isHidden = false
                
                cell.txtReply.isHidden = true
                cell.btnSend.isHidden = true
                
                cell.constraintHeightViewEmpAns.priority = .defaultLow
                cell.lblEmpAns.text = self.arrSampleHistory?[indexPath.row].reply ?? ""
            }   /// */
            return cell
        }
        else if isTrialHistory {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TrialHistoryTVCell", for: indexPath) as! TrialHistoryTVCell
            
            cell.lblProductName.text = self.arrTrialHistory?[indexPath.row].productName ?? ""
            cell.index = indexPath.row
            cell.lblStatus.textColor = Colors.darkGray.returnColor()
            cell.lblReason.textColor = Colors.darkGray.returnColor()
            cell.lblSeparator.backgroundColor = Colors.separator.returnColor()
            
            cell.constraintHeightViewStatus.priority = .required
            cell.constraintHeightViewReason.priority = .required
            cell.constraintTrailStatus.priority = .required
            
            if !((self.arrTrialHistory?[indexPath.row].trailReports ?? []).isEmpty) {
                
                cell.constraintHeightViewStatus.priority = .defaultLow
                cell.lblStatus.text = BusinessP.getTrialHistoryStatus(status: self.arrTrialHistory?[indexPath.row].trailReports?[0].status ?? 0)
                
                if self.arrTrialHistory?[indexPath.row].trailReports?[0].reason ?? "" != "" {
                    cell.constraintHeightViewReason.priority = .defaultLow
                    cell.lblReason.text = self.arrTrialHistory?[indexPath.row].trailReports?[0].reason ?? ""
                }
                
                if (self.arrTrialHistory?[indexPath.row].trailReports?[0].status ?? 0) != 0 {
                    cell.btnChangeStatusNView.setTitle("View", for: .normal)
                    
                    if ((((self.arrTrialHistory ?? [])[indexPath.row].trailReports ?? [])[0].reportAttachments ?? []).isEmpty) {
                        cell.btnChangeStatusNView.isHidden = true
                        cell.constraintTrailStatus.priority = .required
                    }
                    else {
                        cell.btnChangeStatusNView.isHidden = false
                        cell.constraintTrailStatus.priority = .defaultLow
                    }
                }
                else {
                    cell.btnChangeStatusNView.isHidden = true
                    cell.constraintTrailStatus.priority = .required
                    
                    if self.intUserId == APIManager.sharedManager.userId {
                        cell.btnChangeStatusNView.setTitle("Change Status", for: .normal)
                        cell.btnChangeStatusNView.isHidden = false
                        cell.constraintTrailStatus.priority = .defaultLow
                    }
                    else {
                        cell.btnChangeStatusNView.isHidden = true
                        cell.constraintTrailStatus.priority = .required
                    }
                }
            }
            
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

// MARK: - Webservices

extension PopupWithTableVC {
    func holdStatusReply(historyId: Int, strReply: String, completion: @escaping (Bool) -> Void) {
        if !Network.reachability.isReachable {
            self.isRetryInternet { (isretry) in
                if isretry! {
                    self.holdStatusReply(historyId: historyId, strReply: strReply, completion: completion)
                }
            }
            return
        }
        
        let param = [
            "user_id": APIManager.sharedManager.userId,
            "history_id": historyId,
            "reply": strReply
        ] as [String: Any]
        
        showLoading()
        APIManager.sharedManager.postData(url: APIManager.sharedManager.PRODUCT_STATUS_HISTORY_HOLD_REPLY, parameters: param) { (response: ApiResponseBusinessP?, error) in
            self.hideLoading()
            if response?.status == 1 {
                DispatchQueue.main.async {
                    //self.arrEmployee = response?.result?.employees ?? []
                    completion(true)
                }
            }
            else {
                Utilities.showPopup(title: response?.message ?? "", type: .error)
                completion(false)
            }
        }
    }
}

extension PopupWithTableVC {
    
    func initializeHideKeyboard(){
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard(){
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
    func subscribeToNotification(_ notification: NSNotification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: notification, object: nil)
    }
    
    func unsubscribeFromAllNotifications() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShowOrHide(notification: NSNotification) {
        // Get required info out of the notification
        if let scrollView = self.viewMain, let userInfo = notification.userInfo, let endValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey], let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey], let curveValue = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] {
            
            // Transform the keyboard's frame into our view's coordinate system
            let endRect = view.convert((endValue as AnyObject).cgRectValue, from: view.window)
            
            // Find out how much the keyboard overlaps our scroll view
            let keyboardOverlap = scrollView.frame.maxY - endRect.origin.y
            
            // Set the scroll view's content inset & scroll indicator to avoid the keyboard
            //scrollView.contentInset.bottom = keyboardOverlap
            //scrollView.scrollIndicatorInsets.bottom = keyboardOverlap
            
            self.constraintBottomBSheet.constant = keyboardOverlap > 0 ? keyboardOverlap : 10
            
            let duration = (durationValue as AnyObject).doubleValue
            let options = UIView.AnimationOptions(rawValue: UInt((curveValue as AnyObject).integerValue << 16))
            UIView.animate(withDuration: duration!, delay: 0, options: options, animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }

}
