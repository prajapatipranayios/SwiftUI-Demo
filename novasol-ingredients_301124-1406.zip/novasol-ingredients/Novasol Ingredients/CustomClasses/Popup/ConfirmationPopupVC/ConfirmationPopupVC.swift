//
//  ConfirmationPopupVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 03/06/24.
//

import UIKit

class ConfirmationPopupVC: UIViewController {

    // MARK: - Controls
    
    @IBOutlet weak var viewMain : UIView!
    
    @IBOutlet weak var viewMsg : UIView!
    
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var lblTitle : UILabel!
    
    @IBOutlet weak var lblMsg: UILabel!
    
    @IBOutlet weak var btnYes: UIButton!
    @IBAction func btnYesTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onYesTap != nil {
                self.onYesTap!("Yes")
            }
        }
    }
    
    @IBOutlet weak var btnNo: UIButton!
    @IBAction func btnNoTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onNoTap != nil {
                self.onNoTap!("No")
            }
        }
    }
    
    // MARK: - Variables
    
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    var onYesTap: ((String)->Void)?
    var onNoTap: ((String)->Void)?
    
    var colorViewTitleBg: UIColor = .white      //Colors.theme.returnColor()
    var titleTxt: String = "Novasol Ingredients"
    var colorTitleText: UIColor = Colors.theme.returnColor()    //.white
    
    var strMessage = ""
    var colorMsgText: UIColor = .black
    
    var strBtnYesTitle: String = "Yes"
    var colorBtnYesBg: UIColor = .white         //Colors.theme.returnColor()
    var colorBtnYesText: UIColor = .black
    
    var strBtnNoTitle: String = "No"
    var colorBtnNoBg: UIColor = .white          //Colors.theme.returnColor()
    var colorBtnNoText: UIColor = .black
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewMain.backgroundColor = .clear
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.lblTitle.text = self.titleTxt.capitalized
        self.viewTitle.backgroundColor = self.colorViewTitleBg
        self.lblTitle.textColor = self.colorTitleText
        
        self.lblMsg.text = self.strMessage
        self.lblMsg.textColor = self.colorMsgText
        
        self.btnYes.setTitle(self.strBtnYesTitle, for: .normal)
        self.btnYes.setTitleColor(self.colorBtnYesText, for: .normal)
        self.btnYes.backgroundColor = self.colorBtnYesBg
        
        self.btnNo.setTitle(self.strBtnNoTitle, for: .normal)
        self.btnNo.setTitleColor(self.colorBtnNoText, for: .normal)
        self.btnNo.backgroundColor = self.colorBtnNoBg
    }
}
