//
//  PopupWMultiSelectionCell.swift
//


import UIKit

class PopupWMultiSelectionCell: UITableViewCell {
    // MARK: - Controls
    
    @IBOutlet weak var viewMain: UIView!
    
    @IBOutlet weak var lblValue: UILabel!
    @IBOutlet weak var btnSelectValue: UIButton!
    @IBAction func btnSelectValueTap(_ sender: UIButton) {
        if self.onCellTap != nil {
            self.onCellTap!(index)
        }
    }
    
    
    // MARK: - Variables
    var onCellTap: ((Int)->Void)?
    var index = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewMain.layer.cornerRadius = 10.0
        self.viewMain.layer.borderWidth = 1
        self.viewMain.layer.borderColor = UIColor.black.cgColor
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    // MARK: - Button Click Events
    
    @IBAction func didPressTitle(_ sender: UIButton) {
        if self.onCellTap != nil {
            self.onCellTap!(index)
        }
    }
}
