//
//  PopupWMultiSelectionVC.swift
//  Novasol Ingredients
//
//  Created by Auxano on 19/07/24.
//

import UIKit

class PopupWMultiSelectionVC: UIViewController {
    
    // MARK: - Controls
    
    @IBOutlet weak var viewMain : UIView!
    
    @IBOutlet weak var btnClose: UIButton!
    @IBAction func btnCloseTap(_ sender: UIButton) {
        if self.isOpenCloseAnimation {
            UIView.animate(withDuration: 0.5, animations: {
                if #available(iOS 11.0, *) {
                    self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
                } else {
                    self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
                }
                self.view.layoutIfNeeded()
            }) { (true) in
                self.dismiss(animated: true) {
                    if self.onClose != nil {
                        self.onClose!(self.arrSelectedValue)
                    }
                }
            }
        }
        else {
            self.dismiss(animated: true) {
                if self.onClose != nil {
                    self.onClose!(self.arrSelectedValue)
                }
            }
        }
    }
    
    @IBOutlet weak var viewBottomSheet : UIView!
    @IBOutlet weak var lblTitle : UILabel!
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var constraintHeightSearchBar: NSLayoutConstraint!
    
    @IBOutlet weak var tvOptions : UITableView! {
        didSet {
            self.tvOptions.delegate = self
            self.tvOptions.dataSource = self
            //PopupWMultiSelectionCell
        }
    }
    @IBOutlet weak var constraintHeightTVOptions : NSLayoutConstraint!
    
    @IBOutlet weak var btnOkValue: UIButton!
    @IBAction func btnOkTap(_ sender: UIButton) {
        
        if self.isReturnValueInSeq {
            self.arrSelectedValue.removeAll()
            for (_, value) in (self.tempValueSeq ?? []).enumerated() {
                if value.isSelected ?? false {
                    self.arrSelectedValue.append(value.value ?? "")
                }
            }
        }
        
        if self.isOpenCloseAnimation {
            UIView.animate(withDuration: 0.5, animations: {
                if #available(iOS 11.0, *) {
                    self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
                } else {
                    self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
                }
                self.view.layoutIfNeeded()
            }) { (true) in
                self.dismiss(animated: true) {
                    if self.didSelectItem != nil {
                        self.didSelectItem!(self.arrSelectedValue)
                    }
                }
            }
        }
        else {
            self.dismiss(animated: true) {
                if self.didSelectItem != nil {
                    self.didSelectItem!(self.arrSelectedValue)
                }
            }
        }
    }
    
    @IBOutlet weak var btnCancelValue: UIButton!
    @IBAction func btnCancelTap(_ sender: UIButton) {
        if self.isOpenCloseAnimation {
            UIView.animate(withDuration: 0.5, animations: {
                if #available(iOS 11.0, *) {
                    self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
                } else {
                    self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
                }
                self.view.layoutIfNeeded()
            }) { (true) in
                self.dismiss(animated: true) {
                    if self.didSelectItem != nil {
                        self.didSelectItem!(self.arrSelectedValue)
                    }
                }
            }
        }
        else {
            self.dismiss(animated: true) {
                if self.didSelectItem != nil {
                    self.didSelectItem!(self.arrSelectedValue)
                }
            }
        }
    }
    
    @IBOutlet weak var constraintBottomBottomSheet : NSLayoutConstraint!
    
    
    
    // MARK: - Variables
    
    struct TempValueSeq {
        var value: String?
        var isSelected: Bool? = false
    }
    
    var didSelectItem: (([String])->Void)?
    var onClose: (([String])->Void)?
    var selectedId = 0
    var value = [String]() {
        didSet {
            //self.tempValue = self.value
            self.tempValueSeq =  []
            for (_, value) in self.value.enumerated() {
                var isSelected: Bool = false
                if self.arrSelectedValue.contains(value) {
                    isSelected = true
                }
                let obj = TempValueSeq(value: value, isSelected: isSelected)
                self.tempValueSeq?.append(obj)
            }
        }
    }
    var tempValue = [String]()
    var tempValueSeq: [TempValueSeq]? = []
    var option = [String]()
    var strTitleText: String = ""
    var strSelectedValue = "All"
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    var isSearchActive: Bool = false
    var isOpenCloseAnimation: Bool = false
    
    var arrSelectedValue: [String] = []
    var isReturnValueInSeq: Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.layoutIfNeeded()
        self.viewMain.backgroundColor = .clear
        
        self.lblTitle.text = self.strTitleText
        self.lblTitle.textColor = Colors.titleLabel.returnColor()
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        self.blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        self.view.addSubview(blurView)
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        self.view.bringSubviewToFront(viewMain)
        self.viewBottomSheet.layer.cornerRadius = 15.0
        
        self.tvOptions.rowHeight = UITableView.automaticDimension
        self.tvOptions.estimatedRowHeight = 100.0
        self.tvOptions.reloadData()
        
        self.constraintHeightSearchBar.constant = 0
        if self.isSearchActive {
            self.constraintHeightSearchBar.constant = 44
        }
        
        if self.isOpenCloseAnimation {
            if #available(iOS 11.0, *) {
                self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
            } else {
                self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.openBottomSheet()
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tvOptions.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        self.tempValue = self.value
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tvOptions.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                self.constraintHeightTVOptions.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                self.updateViewConstraints()
            }
        }
    }
    
    // MARK: - UI Methods
    
    func openBottomSheet() {
        UIView.animate(withDuration: 0.5, animations: {
            self.constraintBottomBottomSheet.constant = 16
            self.view.layoutIfNeeded()
        })
    }
    
    /*func closeBottomSheet(index :Int) {
        if self.isOpenCloseAnimation {
            UIView.animate(withDuration: 0.5, animations: {
                if #available(iOS 11.0, *) {
                    self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
                } else {
                    self.constraintBottomBottomSheet.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
                }
                self.view.layoutIfNeeded()
            }) { (true) in
                self.dismiss(animated: true) {
                    if self.didSelectItem != nil {
                        self.didSelectItem!(self.arrSelectedItem)
                    }
                }
            }
        }
        else {
            self.dismiss(animated: true) {
                if self.didSelectItem != nil {
                    self.didSelectItem!(self.arrSelectedItem)
                }
            }
        }
    }   */
    
    // MARK: - IBAction Methods
    
}


// MARK: - UITableViewDelegate

extension PopupWMultiSelectionVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tempValue.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PopupWMultiSelectionCell", for: indexPath) as! PopupWMultiSelectionCell
        
        cell.index = indexPath.row
        
        cell.lblValue.text = self.tempValue[indexPath.row]
        
        if self.isReturnValueInSeq {
            cell.btnSelectValue.isSelected = self.tempValueSeq?[indexPath.row].isSelected ?? false
            cell.btnSelectValue.tintColor = (self.tempValueSeq?[indexPath.row].isSelected ?? false) ? Colors.themeGreen.returnColor() : Colors.gray.returnColor()
        }
        else {
            cell.btnSelectValue.isSelected = false
            cell.btnSelectValue.tintColor = Colors.gray.returnColor()
            if self.arrSelectedValue.contains(self.tempValue[indexPath.row]) {
                cell.btnSelectValue.isSelected = true
                cell.btnSelectValue.tintColor = Colors.themeGreen.returnColor()
            }
        }
        
        cell.onCellTap = { index in
            if self.isReturnValueInSeq {
                let isSelect = !(self.tempValueSeq?[index].isSelected ?? false)
                self.tempValueSeq?[index].isSelected = isSelect
            }
            else {
                if self.arrSelectedValue.contains(self.tempValue[indexPath.row]) {
                    for i in 0..<self.arrSelectedValue.count {
                        if self.arrSelectedValue[i] == self.tempValue[indexPath.row] {
                            self.arrSelectedValue.remove(at: i)
                            break
                        }
                    }
                }
                else {
                    self.arrSelectedValue.append(self.tempValue[index])
                }
            }
            self.tvOptions.reloadData()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

// MARK: - SearchBar Delegate

extension PopupWMultiSelectionVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        if searchText != "" {
            self.tempValue = self.value.filter{
                ($0.lowercased()).contains(searchText.lowercased())
            }
        }
        else {
            self.searchBar.text = ""
            self.tempValue = self.value
        }
        self.tvOptions.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder()
        self.searchBar.text = ""
        self.tempValue = self.value
        self.tvOptions.reloadData()
    }
}
