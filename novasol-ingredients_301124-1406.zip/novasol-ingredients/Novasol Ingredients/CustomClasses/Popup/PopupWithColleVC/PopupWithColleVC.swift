//
//  PopupWithColleVC.swift
//  GE Sales
//
//  Created by Auxano on 15/05/24.
//

import UIKit

class PopupWithColleVC: UIViewController {
    
    // MARK: - Outlet
    @IBOutlet weak var viewMain : UIView!
    @IBOutlet weak var viewBottomSheet : UIView!
    @IBOutlet weak var lblTitle : UILabel!
    
    @IBOutlet weak var viewSearchBar: UIView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var constraintHeightViewSearchBar: NSLayoutConstraint!
    
    @IBOutlet weak var cvOptions: UICollectionView! {
        didSet {
            self.cvOptions.delegate = self
            self.cvOptions.dataSource = self
        }
    }
    @IBOutlet weak var heightCVOptions : NSLayoutConstraint!
    @IBOutlet weak var bottomSheetbottomConstraint : NSLayoutConstraint!
    
    @IBOutlet weak var btnClose: UIButton!
    @IBAction func btnCloseTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onClose != nil {
                self.onClose!(self.selectedValue)
            }
        }
        
        /*UIView.animate(withDuration: 0.5, animations: {
            if #available(iOS 11.0, *) {
                self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + self.view.safeAreaInsets.bottom + 16.0)
            } else {
                self.bottomSheetbottomConstraint.constant = -(self.viewBottomSheet.frame.height + self.view.layoutMargins.bottom + 16.0)
            }
            self.view.layoutIfNeeded()
        }) { (true) in
            self.dismiss(animated: true) {
                if self.onClose != nil {
                    self.onClose!(self.selectedValue)
                }
            }
        }   //  */
    }
    
    // MARK: - Variable
    var didSelect: ((String)->Void)?
    var onClose: ((String)->Void)?
    var value = [String]()
    var tempValue = [String]()
    var option = [String]()
    var titleTxt: String = ""
    var selectedValue = "All"
    var isSearchActive: Bool = false
    
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblTitle.text = self.titleTxt
        self.lblTitle.textColor = Colors.titleLabel.returnColor()
        
        self.viewMain.backgroundColor = .clear
        self.viewBottomSheet.corners([.topLeft, .topRight], radius: 25)
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
        
        self.constraintHeightViewSearchBar.constant = 0
        if self.isSearchActive {
            self.constraintHeightViewSearchBar.constant = 44
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tempValue = self.value
        
        self.cvOptions.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.cvOptions.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if(keyPath == "contentSize"){
            if let newvalue = change?[.newKey]
            {
                let newsize  = newvalue as! CGSize
                self.heightCVOptions.constant = newsize.height <= (self.view.frame.height - 300) ? newsize.height : self.view.frame.height - 300
                self.updateViewConstraints()
            }
        }
    }
}

extension PopupWithColleVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.tempValue.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PopupWColleCVCell", for: indexPath) as! PopupWColleCVCell
        
        cell.lblValue.text  = self.tempValue[indexPath.item]
        
        DispatchQueue.main.async {
            cell.constraintLeadingValue.priority = .required
            cell.viewMain.layer.borderColor = Colors.disableButton.returnColor().cgColor
            cell.img.isHidden = true
            cell.btnSelect.isHidden = true
            
            if self.selectedValue == self.tempValue[indexPath.item] {
                cell.constraintLeadingValue.priority = .defaultLow
                cell.viewMain.layer.borderColor = Colors.theme.returnColor().cgColor
                cell.img.isHidden = false
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (collectionView.frame.width - 40) / 2
        let height = 45.0
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.dismiss(animated: true) {
            if self.didSelect != nil {
                self.didSelect!(self.tempValue[indexPath.item])
            }
        }
    }
}
