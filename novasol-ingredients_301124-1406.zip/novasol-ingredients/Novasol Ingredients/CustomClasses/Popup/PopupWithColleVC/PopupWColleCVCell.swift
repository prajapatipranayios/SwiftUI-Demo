//
//  popupWColleCVCell.swift
//  GE Sales
//
//  Created by Auxano on 15/05/24.
//

import UIKit

class PopupWColleCVCell: UICollectionViewCell {
    
    // MARK: - Outlet
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblValue: UILabel!
    @IBOutlet weak var constraintLeadingValue: NSLayoutConstraint!
    @IBOutlet weak var btnSelect: UIButton!
    @IBAction func btnSelectTap(_ sender: UIButton) {
        if self.onCellTap != nil {
            self.onCellTap!(index)
        }
    }
    
    // MARK: - Variable
    
    var onCellTap: ((Int)->Void)?
    var index: Int = 0
    
    override func awakeFromNib() {
        self.viewMain.layer.cornerRadius = viewMain.frame.height / 2
        self.viewMain.layer.borderWidth = 1
        self.viewMain.layer.borderColor = Colors.disableButton.returnColor().cgColor
    }
}
