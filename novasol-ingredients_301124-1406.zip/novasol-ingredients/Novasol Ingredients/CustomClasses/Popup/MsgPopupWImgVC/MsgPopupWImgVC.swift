//
//  MsgPopupWImgVC.swift
//  GE Sales
//
//  Created by Auxano on 22/05/24.
//

import UIKit

class MsgPopupWImgVC: UIViewController {

    // MARK: - Controls
    
    @IBOutlet weak var viewMain : UIView!
    @IBOutlet weak var viewBottomSheet : UIView!
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var lblTitle : UILabel!
    @IBOutlet weak var imgMsg: UIImageView!
    @IBOutlet weak var lblMsg: UILabel!
    @IBOutlet weak var btnOk: UIButton!
    @IBAction func btnOkTap(_ sender: UIButton) {
        self.dismiss(animated: true) {
            if self.onTapOk != nil {
                self.onTapOk!("")
            }
        }
    }
    
    // MARK: - Variables
    
    var onTapOk: ((String)->Void)?
    var titleTxt: String = "Congratulations"
    var strImgName = ""
    var strMessage = ""
    var bgColorViewTitle: UIColor = Colors.theme.returnColor()
    var colorTitleText: UIColor = .white
    var colorBtnBg: UIColor = Colors.theme.returnColor()
    var colorBtnText: UIColor = .white
    
    private let blurEffect = (NSClassFromString("_UICustomBlurEffect") as! UIBlurEffect.Type).init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewMain.backgroundColor = .clear
        
        let blurView = UIVisualEffectView(frame: UIScreen.main.bounds)
        blurEffect.setValue(2, forKeyPath: "blurRadius")
        blurView.effect = blurEffect
        view.addSubview(blurView)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        
        view.bringSubviewToFront(viewMain)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.viewTitle.backgroundColor = bgColorViewTitle
        self.lblTitle.textColor = self.colorTitleText
        
        self.btnOk.backgroundColor = self.colorBtnBg
        self.btnOk.setTitleColor(self.colorBtnText, for: .normal)
        
        self.lblTitle.text = self.titleTxt
        self.lblMsg.text = self.strMessage
        
        if self.strImgName != "" {
            self.imgMsg.image = UIImage(named: self.strImgName)
        }
    }
}
