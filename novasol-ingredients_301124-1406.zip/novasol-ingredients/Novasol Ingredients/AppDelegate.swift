//
//  AppDelegate.swift
//  GE Sales
//
//  Created by Auxano on 15/04/24.
//

import UIKit
import Firebase
import FirebaseMessaging
import FirebaseCore

let appDelegate = UIApplication.shared.delegate as! AppDelegate

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var reachability: Reachability?
    var isAutoLogin: Bool = false

    var myOrientation: UIInterfaceOrientationMask = .portrait
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        do {
            reachability = try Reachability()
            try reachability!.start()
        } catch {
            print("Unable to start notifier")
        }
        do {
            try Network.reachability = Reachability(hostname: "www.google.com")
        }
        catch {
            switch error as? Network.Error {
            case let .failedToCreateWith(hostname)?:
                print("Network error:\nFailed to create reachability object With host named:", hostname)
            case let .failedToInitializeWith(address)?:
                print("Network error:\nFailed to initialize reachability object With address:", address)
            case .failedToSetCallout?:
                print("Network error:\nFailed to set callout")
            case .failedToSetDispatchQueue?:
                print("Network error:\nFailed to set DispatchQueue")
            case .none:
                print(error)
            }
        }
        
        //UserDefaults.standard.set(97, forKey: UserDefaultType.userId)
        //UserDefaults.standard.set(2, forKey: UserDefaultType.userRole)
        if (UserDefaults.standard.value(forKey: UserDefaultType.userId) != nil) && UserDefaults.standard.value(forKey: UserDefaultType.userId)! is Int {
            isAutoLogin = true
        }
        
        FirebaseApp.configure()
        Messaging.messaging().delegate = self
        
        //if #available(iOS 10, *) {
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().requestAuthorization(options:[.badge, .alert, .sound]) { granted, error in
            let accept = UNNotificationAction(
                identifier: "Accept", title: "Accept",
                options: [.foreground])
            let decline = UNNotificationAction(
                identifier: "Decline", title: "Decline",
                options: [.foreground])
            
            let newsCategory = UNNotificationCategory(
                identifier: "button", actions: [accept,decline],
                intentIdentifiers: [], options: [])
            
            UNUserNotificationCenter.current().setNotificationCategories([newsCategory])
            
            print("print notification details in background... - 2")
        }
        //} else {
        //    application.registerUserNotificationSettings(UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil))
        //}
        application.registerForRemoteNotifications()
        
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

extension AppDelegate: MessagingDelegate {
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        print("fcmToken: \(fcmToken!)")
        UserDefaults.standard.set("\(fcmToken!)", forKey: UserDefaultType.fcmToken)
    }
}

extension AppDelegate: UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("print notification details in background... - 1")
        
        /*if (UserDefaults.standard.value(forKey: UserDefaultType.notificationCount) != nil) && UserDefaults.standard.value(forKey: UserDefaultType.notificationCount)! is Int {
            var notificationCount : Int = 0
            notificationCount = UserDefaults.standard.value(forKey: UserDefaultType.notificationCount) as! Int
            notificationCount += 1
            UserDefaults.standard.set(notificationCount, forKey: UserDefaultType.notificationCount)
            //UIApplication.shared.applicationIconBadgeNumber = UserDefaults.standard.value(forKey: UserDefaultType.notificationCount) as! Int
        }   //  */
        //notificationCount += 1
        //APIManager.sharedManager.intNotificationCount
        //tusslyTabVC!().notificationCount()
        // .
        completionHandler([.alert, .badge, .sound])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        if let notificationData = response.notification.request.content.userInfo as NSDictionary? as? [String: Any] {
            if notificationData["gcm.notification.tags"] != nil {
                if let data = notificationData["gcm.notification.tags"]! as? String {
                    let rawData = Data(data.utf8)
                    var dict : [String : Any]? = [:]
                    do {
                        dict = try JSONSerialization.jsonObject(with: rawData, options: []) as? [String: Any]
                        print(dict!["notificationId"]!)
                    } catch {
                        print("Error: \(error)")
                    }
                    
                }
            }
            else {
                
            }
        }
        do {
            completionHandler()
        }
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any]) {
        print("Received notification :: \(userInfo.description)")
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        
        switch UIApplication.shared.applicationState {
        case .background :
            //APIManager.sharedManager.intNotificationCount += 1
            //tusslyTabVC!().notificationCount()
            /*if (UserDefaults.standard.value(forKey: UserDefaultType.notificationCount) != nil) && UserDefaults.standard.value(forKey: UserDefaultType.notificationCount)! is Int {
                var notificationCount : Int = 0
                notificationCount = UserDefaults.standard.value(forKey: UserDefaultType.notificationCount) as! Int
                notificationCount += 1
                UserDefaults.standard.set(notificationCount, forKey: UserDefaultType.notificationCount)
                //UIApplication.shared.applicationIconBadgeNumber = UserDefaults.standard.value(forKey: UserDefaultType.notificationCount) as! Int
            }   //  */
            //notificationCount += 1
            //APIManager.sharedManager.intNotificationCount
            //tusslyTabVC!().notificationCount()
            break
        case .active:
            break
        case .inactive:
            break
        @unknown default:
            break
        }
        
        completionHandler(UIBackgroundFetchResult.newData)
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        Messaging.messaging().apnsToken = deviceToken
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Unable to register for remote notifications: \(error.localizedDescription)")
    }
}
