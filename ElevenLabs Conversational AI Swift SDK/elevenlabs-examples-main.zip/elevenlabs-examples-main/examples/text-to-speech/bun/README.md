# ElevenLabs - Bun

To install dependencies:

```bash
bun install
```

To run:

```bash
bun dev
```
