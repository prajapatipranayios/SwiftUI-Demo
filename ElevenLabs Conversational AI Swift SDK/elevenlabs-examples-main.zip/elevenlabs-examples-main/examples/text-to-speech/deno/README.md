## Text to Speech - Deno examples

- `cp .env.example .env`
- `deno run --allow-env --allow-read --allow-write --allow-net --allow-sys mod.ts`
