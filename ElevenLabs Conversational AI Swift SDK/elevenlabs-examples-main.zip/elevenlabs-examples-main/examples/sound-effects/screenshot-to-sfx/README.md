# Screenshot to SFX

Generate sound effects from images. Simply paste in a screenshot, let Gemini 2.0 generate the prompt, and generate the Sound Effect with ElevenLabs.

## Setup

1. `cp example.env.local .env.local`
1. Add your API keys.
1. Run `pnpm i`
1. Run `pnpm dev`
1. Enjoy SFX
