import 'dotenv/config';
import 'colors';
import { startApp } from './app';

startApp();
