# ElevenLabs - Twilio - Call

## Installation

```
pnpm install
```

## Local development

```
pnpm run dev
```
