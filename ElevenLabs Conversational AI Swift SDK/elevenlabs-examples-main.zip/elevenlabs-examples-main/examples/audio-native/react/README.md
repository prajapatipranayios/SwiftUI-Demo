## ElevenLabs React Audio Native

See the [ElevenLabs React Audio Native tutorial](https://elevenlabs.io/docs/audio-native/audio-native-react) for a walk through and details of how to setup ngrok
