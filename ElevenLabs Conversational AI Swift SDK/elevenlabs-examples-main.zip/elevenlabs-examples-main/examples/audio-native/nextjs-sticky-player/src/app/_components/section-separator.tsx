export function SectionSeparator() {
  return <hr className="border-neutral-200 mt-28 mb-24" />;
}
