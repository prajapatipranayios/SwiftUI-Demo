export const { VITE_API_URL } = import.meta.env;
