declare module "*.frag" {
  export default string;
}
declare module "*.vert" {
  export default string;
}
