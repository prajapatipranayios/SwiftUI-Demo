import SwiftUI

@main
struct ConversationalAISwiftApp: App {
    var body: some Scene {
        WindowGroup {
            ConversationalAIExampleView()
        }
    }
}
