// This file is auto-generated from git tags
// Run Scripts/generate-version.sh to update
import Foundation

enum SDKVersion {
    static let version = "2.0.11"
}
