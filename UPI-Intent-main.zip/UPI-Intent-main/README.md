# UPI-Intent
UPI Intent Flow in Swift for iOS apps


## List of UPI Apps with URL Scheme
- Phone Pe - phonePe
- Google Pay - gpay
- Paytm - Paytm
- Bhim - bhim
- Cred - cred
- Amazon - amazonToAlipay
- Whatsapp - whatsapp
- Slice - slice
- Mobikwik - mobikwik
- Kiwi - kiwi
- Payzapp - payzapp
- FreeCharge - freecharge
- My Jio - myjio