//
//  UPIApp.swift
//  UPI
//
//  Created by Debashish on 16/01/24.
//

import SwiftUI

@main
struct UPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
