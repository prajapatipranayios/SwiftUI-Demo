//
//  ImgSliderCVCell.swift
//  ShopzzApp
//
//  Created by Auxano Global Services on 6/7/18.
//  Copyright © 2018 Auxano Global Services. All rights reserved.
//

import UIKit

class ImgSliderCVCell: UICollectionViewCell {

    //Outlets
    @IBOutlet weak var ivProduct: UIImageView!
    @IBOutlet weak var btnPlay: UIButton!
    @IBOutlet weak var viewAlpha: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
